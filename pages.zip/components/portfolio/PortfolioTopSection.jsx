import React from 'react'

const PortfolioTopSection = ({projectData}) => {
    return (
        <>
            <div className='d-flex pt-5 pb-5'></div>
            <div className="container pt-5 pb-5">
                <div className="row g-4 justify-content-center">
                    <div className="col-lg-8">
                        <div className="breadcrumnd__wrap text-center">
                            <h1>
                                {projectData.title}
                            </h1>
                            <ul className="breakcrumnd__cont justify-content-center">
                                <li>
                                    <a href="index-2.html">
                                        Home
                                    </a>
                                </li>
                                <li className="white">
                                    /
                                </li>
                                <li className="base">
                                    {projectData.category}
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default PortfolioTopSection