import React from 'react'

const MarqueeSection = () => {
    return (
        <>
            <div className="marquee-wrapper text-slider" id="sers">
                <div className="marquee-inner to-left">
                    <ul className="marqee-list d-flex">
                        <li className="marquee-item">
                            <span>Satisfied Client</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                            <span>Branding App</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                            <span>Website</span> <span className="basee">*</span> <span className="stroke-text"></span><span>Lets's
                                Work</span> <span className="base">*</span>
                            <span>App Design</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                            <span>SEO Expart</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                            <span>Lets's Work</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                        </li>
                    </ul>
                </div>
            </div>
        </>
    )
}

export default MarqueeSection