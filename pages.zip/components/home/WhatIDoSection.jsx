import React from 'react'

const WhatIDoSection = () => {
    return (
        <>
            <section className="unique__commit bg1-img2 position-relative overflow-hidden">
                <div className="container-fluid p-0">
                    <div className="unique__commitwrap d-flex justify-content-between">
                        <div className="unique__comititem unc__1 d-flex align-items-end">
                            <div className="ucom">
                                <span>
                                    App
                                </span>
                            </div>
                            <div className="cont__box">
                                <span className="head-both">
                                    01
                                </span>
                                <h4>
                                    Designer
                                    <span className="d-block"> Illustration Design</span>
                                </h4>
                                <a href="service-details.html" className="cmn--btn">
                                    <span>
                                        More Details
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div className="unique__comititem unc__2 d-flex align-items-end">
                            <div className="ucom">
                                <span>
                                    Branding
                                </span>
                            </div>
                            <div className="cont__box">
                                <span className="head-both">
                                    02
                                </span>
                                <h4>
                                    Branding
                                    <span className="d-block"> Business Branding</span>
                                </h4>
                                <a href="service-details.html" className="cmn--btn">
                                    <span>
                                        More Details
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div className="unique__comititem unc__3 activecard d-flex align-items-end">
                            <div className="ucom">
                                <span>
                                    Designer
                                </span>
                            </div>
                            <div className="cont__box">
                                <span className="head-both">
                                    03
                                </span>
                                <h4>
                                    UI/UX Design
                                    <span className="d-block"> Web UI/UX Design</span>
                                </h4>
                                <a href="service-details.html" className="cmn--btn">
                                    <span>
                                        More Details
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div className="unique__comititem unc__4 d-flex align-items-end">
                            <div className="ucom">
                                <span>
                                    STRATEGY
                                </span>
                            </div>
                            <div className="cont__box">
                                <span className="head-both">
                                    04
                                </span>
                                <h4>
                                    SEO Analytics
                                    <span className="d-block"> Digital Marketing</span>
                                </h4>
                                <a href="service-details.html" className="cmn--btn">
                                    <span>
                                        More Details
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div className="unique__comititem unc__5 d-flex align-items-end">
                            <div className="ucom">
                                <span>
                                    App Branding
                                </span>
                            </div>
                            <div className="cont__box">
                                <span className="head-both">
                                    05
                                </span>
                                <h4>
                                    Building App
                                    <span className="d-block"> Web Building App</span>
                                </h4>
                                <a href="service-details.html" className="cmn--btn">
                                    <span>
                                        More Details
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default WhatIDoSection