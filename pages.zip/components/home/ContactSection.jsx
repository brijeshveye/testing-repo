import React from 'react'

const ContactSection = () => {
  return (
    <>
    <section id="contact" data-scroll-index="6" className="section contact-section">
            <div className="container">
                <div className="section-heading">
                    <h3>Take a Coffee & chat with me</h3>
                </div>
                <div className="row justify-content-center">
                    <div className="col-xl-8 col-lg-10">
                        <div className="row contact-info">
                            <div className="col-md-6">
                                <a className="email" href="#">
                                    <img src="assets/img/email.png" title="" alt="" />
                                    <span>info@mywebsite.com</span>
                                </a>
                            </div>
                            <div className="col-md-6">
                                <a className="phone" href="#">
                                    <img src="assets/img/phone.png" title="" alt="" />
                                    <span>+01 9033 333 333 / 123</span>
                                </a>
                            </div>
                        </div>
                        <div className="contact-form">
                            <form>
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="form-floating">
                                            <input type="email" className="form-control" id="you_name"
                                                placeholder="Your Name" />
                                            <label htmlFor="you_name">Your Name</label>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-floating">
                                            <input type="email" className="form-control" id="your_email"
                                                placeholder="name@example.com" />
                                            <label htmlFor="your_email">Email Address</label>
                                        </div>
                                    </div>
                                    <div className="col-12">
                                        <div className="form-floating">
                                            <input type="email" className="form-control" id="your_subject"
                                                placeholder="Subject" />
                                            <label htmlFor="your_subject">Subject</label>
                                        </div>
                                    </div>
                                    <div className="col-12">
                                        <div className="form-floating">
                                            <textarea className="form-control" placeholder="Leave a comment here"
                                                id="your_message" style={{ height: "150px" }}></textarea>
                                            <label htmlFor="your_message">Your Message here</label>
                                        </div>
                                    </div>
                                    <div className="col-12 btn-bar text-center">
                                        <button className="px-btn px-btn-primary">SEND INQUIRY</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </>
  )
}

export default ContactSection