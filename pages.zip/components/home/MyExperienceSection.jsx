import React from 'react'

const MyExperienceSection = () => {
  return (
    <>
    <section id="experience" className="br-experience padding-tb-80">
            <div className="container">
                <div className="row">
                    <div className="section-title">
                        <h2>My <span>Resume</span></h2>
                        <span className="ligh-title">Achievements</span>
                    </div>
                    <div className="col-lg-6 col-md-12 col-sm-12">
                        <div className="education br-ex-box m-b-991">
                            <h4>Education</h4>
                            <ul className="timeline">
                                <li className="timeline-item" data-aos="fade-up" data-aos-duration="2000"
                                    data-aos-delay="400">
                                    <div className="timeline-info">
                                        <span>June 15, 2013 - 2016</span>
                                    </div>
                                    <div className="timeline-content">
                                        <h5 className="timeline-title">Master in Computer Engineering<span className="sub">-
                                                First
                                                Class</span></h5>
                                        <p>Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do
                                            Eiusmod
                                            Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam
                                        </p>
                                    </div>
                                </li>
                                <li className="timeline-item" data-aos="fade-up" data-aos-duration="2000"
                                    data-aos-delay="600">
                                    <div className="timeline-info">
                                        <span>June 12, 2010 - 2013</span>
                                    </div>
                                    <div className="timeline-content">
                                        <h5 className="timeline-title">Bachelor in Computer Engineering<span className="sub">-
                                                First
                                                Class</span></h5>
                                        <p>Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do
                                            Eiusmod
                                            Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam
                                        </p>
                                    </div>
                                </li>
                                <li className="timeline-item" data-aos="fade-up" data-aos-duration="2000"
                                    data-aos-delay="800">
                                    <div className="timeline-info">
                                        <span>June 1, 2009 - 2010</span>
                                    </div>
                                    <div className="timeline-content">
                                        <h5 className="timeline-title">Higher Secondary<span className="sub">- (A+)</span></h5>
                                        <p>Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do
                                            Eiusmod
                                            Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam
                                        </p>
                                    </div>
                                </li>
                            </ul>

                        </div>
                    </div>
                    <div className="col-lg-6 col-md-12 col-sm-12">
                        <div className="experiense br-ex-box">
                            <h4>Experiense</h4>
                            <ul className="timeline">
                                <li className="timeline-item">
                                    <div className="timeline-info">
                                        <span>March 12, 2020</span>
                                    </div>
                                    <div className="timeline-content">
                                        <h5 className="timeline-title">Envato<span className="sub">- Team Leader</span></h5>
                                        <p>Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do
                                            Eiusmod
                                            Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam
                                        </p>
                                    </div>
                                </li>
                                <li className="timeline-item">
                                    <div className="timeline-info">
                                        <span>January 23, 2018 - 2020</span>
                                    </div>
                                    <div className="timeline-content">
                                        <h5 className="timeline-title">Facebook Company<span className="sub">- Sr.
                                                Developer</span>
                                        </h5>
                                        <p>Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do
                                            Eiusmod
                                            Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam
                                        </p>
                                    </div>
                                </li>
                                <li className="timeline-item">
                                    <div className="timeline-info">
                                        <span>July 23, 2016 - 2018</span>
                                    </div>
                                    <div className="timeline-content">
                                        <h5 className="timeline-title">Twitter Company<span className="sub">- Jr.
                                                Developer</span>
                                        </h5>
                                        <p>Lorem Ipsum Commodo Dolor Sit Amet, Consectetur Adipisicing Elit, Sed Do
                                            Eiusmod
                                            Tempor Incididunt Ut Labore Et Dolore Magna Aliqua. Ut Enim Ad Minim Veniam
                                        </p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </>
  )
}

export default MyExperienceSection