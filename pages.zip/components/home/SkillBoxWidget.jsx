import React from 'react'

const SkillBoxWidget = (props) => {
    return (
        <li>
            <div className="skill-box">
                <div className="skill-icon" style={{ background: props.background }}>
                    <i className="fab fa-css3-alt" style={{ color: props.color }}></i>
                    <span className="count after-p" data-to={ props.dataTo } data-speed="90">{ props.title }</span>
                </div>
                <h6>CSS</h6>
            </div>
        </li>
    )
}

SkillBoxWidget.defaultPops = {
    background: "#dee4ff",
    color: "264de4",
    dataTo: "90",
    title: "CSS"
}

export default SkillBoxWidget