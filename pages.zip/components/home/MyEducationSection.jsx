import React from 'react'

const MyEducationSection = () => {
    return (
        <>
            <div className="exprience2-sections bg1-img pb-4 pt-5 overflow-hidden position-relative">
                <div className="container">
                    <div className="g">
                        <h5 className="head-text mtitle">
                            My job info
                        </h5>
                        <div className="row g-4 align-items-lg-start align-items-center">
                            <div className="col-lg-5">
                                <div className="about__onethumb" data-aos="zoom-out-down" data-aos-duration="2000">
                                    <img src="assets/img/cart/t4.png" alt="img" />
                                </div>
                            </div>
                            <div className="col-lg-7">
                                <div className="about__onecontent">
                                    <h2 className="mtitle">
                                        My Experience
                                    </h2>
                                    <p className="mtitle">
                                        At dolor sit amet consectetur adipisicing elit. Voluptate iure in voluptatem
                                        accusamus culpa quisquam eos! Quis provident nobis assumenda ipsa, ratione
                                        temporibus explicabo.
                                    </p>
                                    <div className="exprience__box mt-30 position-relative z-1">
                                        <div className="row g-3">
                                            <div className="col-xl-6" data-aos="zoom-in" data-aos-duration="500">
                                                <div className="exri__item exri-items3">
                                                    <a href="#0" className="fz-18 fw-500 base ex-iconbox">
                                                        <i className="bi bi-arrow-up-right mtitle"></i>
                                                    </a>
                                                    <div className="expri__cont">
                                                        <p className="fz-16 mtitle d-block mb-2">
                                                            2016 - 2018
                                                        </p>
                                                        <h4 className="mb-1 mtitle">
                                                            Software Engineer
                                                        </h4>
                                                        <p className="fz-16 mtitle d-block">
                                                            Co Founder
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6" data-aos="zoom-in" data-aos-duration="900">
                                                <div className="exri__item exri-items3">
                                                    <a href="#0" className="fz-18 fw-500 base ex-iconbox">
                                                        <i className="bi bi-arrow-up-right mtitle"></i>
                                                    </a>
                                                    <div className="expri__cont">
                                                        <p className="fz-16 mtitle d-block mb-2">
                                                            2018 - 2020
                                                        </p>
                                                        <h4 className="mb-1 mtitle">
                                                            UI / Ux Designer
                                                        </h4>
                                                        <p className="fz-16 mtitle d-block">
                                                            Linkedin
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6" data-aos="zoom-in" data-aos-duration="1400">
                                                <div className="exri__item exri-items3">
                                                    <a href="#0" className="fz-18 fw-500 base ex-iconbox">
                                                        <i className="bi bi-arrow-up-right mtitle"></i>
                                                    </a>
                                                    <div className="expri__cont">
                                                        <p className="fz-16 mtitle d-block mb-2">
                                                            2020 - 2022
                                                        </p>
                                                        <h4 className="mb-1 mtitle">
                                                            Lead Product Designer
                                                        </h4>
                                                        <p className="fz-16 mtitle d-block">
                                                            Google
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="col-xl-6" data-aos="zoom-in" data-aos-duration="2000">
                                                <div className="exri__item exri-items3">
                                                    <a href="#0" className="fz-18 fw-500 base ex-iconbox">
                                                        <i className="bi bi-arrow-up-right mtitle"></i>
                                                    </a>
                                                    <div className="expri__cont">
                                                        <p className="fz-16 mtitle d-block mb-2">
                                                            2022 - 2025
                                                        </p>
                                                        <h4 className="mb-1 mtitle">
                                                            SEO Expart Team Lead
                                                        </h4>
                                                        <p className="fz-16 pra d-block">
                                                            Webflow
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <img src="assets/img/about/ellip.png" alt="img" className="ellip" />
                <img src="assets/img/about/ellip.png" alt="img" className="ellip2" />
            </div>
        </>
    )
}

export default MyEducationSection