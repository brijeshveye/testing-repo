import React from 'react'

const ExperienceCardWidget = () => {
    return (
        <>
            <div className="col-lg-8 mb-xxl-5 mb-4 d-flex justify-content-end ms-auto"
                data-aos="zoom-out-down" data-aos-duration="800">
                <div className="row g-4 align-items-center justify-content-between">
                    <div className="col-xl-9 col-lg-8">
                        <div className="aria-edubox">
                            <div className="expri__cont">
                                <h4 className="mb-15 mtitle">
                                    Web Design Course
                                </h4>
                                <p className="fz-18 mtitle d-block">
                                    Cansong London
                                </p>
                            </div>
                            <p className="mtitle">
                                Adipisicing elit. Illum totam nisi. Lorem ipsum dolor sit amet
                                consectetur adipisicing elit. A dignissimos itaque consequuntur in saepe
                                enim nihil pariatur, ab, molestias vel similique est, commodi nesciunt?
                                Odio inventore quis eius veniam. Aliquam rem.
                            </p>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4">
                        <span className="years-about fw-500 base">
                            2015-2018
                        </span>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ExperienceCardWidget