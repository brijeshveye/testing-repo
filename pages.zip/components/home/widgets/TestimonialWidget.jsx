import React from 'react'

const TestimonialWidget = (props) => {
    return (
        <>
            <div className="testimonial-box">
                <div className="icon">
                    <i className="fas fa-quote-left"></i>
                </div>
                <div className="testimonial-text">
                    <div className="d-flex star-box">
                        {[...Array(props.stars)].map((_, index) => (
                            <i key={index} className="bi bi-star-fill"></i>
                        ))}
                    </div>
                    <h6>{props.customerPosition}</h6>
                    <p>{props.customerFeedback}</p>
                    <h5>{props.customerName}</h5>
                </div>
            </div>
        </>
    )
}

TestimonialWidget.defaultProps = {
    stars: 5,
    customerName: 'pxdraft',
    customerFeedback: 'This is an amazing product! I highly recommend it to everyone.',
    customerPosition: 'CEO, Company Name'
}

export default TestimonialWidget