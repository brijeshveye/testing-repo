import React, { useEffect } from 'react'
import UserDataApi from '../../api/UserDataApi';
import TestimonialWidget from './widgets/TestimonialWidget';

const TestimonialsSection = () => {

    const [testimonialsData, setTestimonialsData] = React.useState([]);

    useEffect(() => {
        setTestimonialsData(UserDataApi.getTestimonials());
    }, []);

    return (
        <>
            <section className="section testimonial-section bg-no-repeat bg-center"
                style={{ backgroundPosition: "center 125%", backgroundImage: `url(assets/img/bg-1.png)` }}>
                <div className="container">
                    <div className="section-heading">
                        <h3>What people say about us?</h3>
                    </div>
                    <div className="owl-carousel" data-items="1" data-nav-dots="false" data-nav-arrow="true" data-md-items="1"
                        data-sm-items="1" data-xs-items="1" data-xx-items="1" data-space="20" data-autoplay="true">

                        {testimonialsData.map((testimonial, index) => (
                            <TestimonialWidget key={index} stars={testimonial.stars} customerName={testimonial.customerName} customerFeedback={testimonial.customerFeedback} customerPosition={testimonial.customerPosition} />
                        ))}

                    </div>
                </div>
            </section>
        </>
    )
}

export default TestimonialsSection