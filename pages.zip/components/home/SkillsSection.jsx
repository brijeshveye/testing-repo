import React, { useEffect } from 'react'
import SkillBoxWidget from './SkillBoxWidget'
import UserDataApi from '../../api/UserDataApi';

const SkillsSection = () => {

    const [tech, setTech] = React.useState([]);

    useEffect(() => {
        setTech(UserDataApi.getMySkills());
    }, [tech]);

    return (
        <>
            <section id="resume" data-scroll-index="2" className="section skills-section bg-gray">
                <div className="container">
                    <div className="section-heading">
                        <h3>Skills & Experience</h3>
                    </div>
                    <div className="row gy-4">
                        <div className="col-lg-6">
                            <ul className="skills-list counter">
                                {
                                    tech.map((item) => {
                                        return <SkillBoxWidget title={item.title} background={item.background} color={item.color} dataTo={item.dataTo} />
                                    })
                                }

                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style={{ background: '#ffe5dc' }}>
                                            <i className="fab fa-html5" style={{ color: '#e54c21' }}></i>
                                            <span className="count after-p" data-to="80" data-speed="80">80</span>
                                        </div>
                                        <h6>HTML</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style={{ background: '#dee4ff' }}>
                                            <i className="fab fa-css3-alt" style={{ color: '#264de4' }}></i>
                                            <span className="count after-p" data-to="90" data-speed="90">90</span>
                                        </div>
                                        <h6>CSS</h6>
                                    </div>
                                </li>
                                <li className="w-100 m-0 p-0 d-md-block d-none"></li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style={{ background: '#def5ff' }}>
                                            <i className="fab fa-wordpress" style={{ color: '#21759b' }}></i>
                                            <span className="count after-p" data-to="65" data-speed="65">65</span>
                                        </div>
                                        <h6>WordPress</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style={{ background: '#f0ffd0' }}>
                                            <i className="fab fa-node-js" style={{ color: '#80bd00' }}></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Node</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style={{ background: '#ffe1e1' }}>
                                            <i className="fab fa-gulp" style={{ color: '#eb4a4b' }}></i>
                                            <span className="count after-p" data-to="70" data-speed="70">70</span>
                                        </div>
                                        <h6>Gulp</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style={{ background: '#ffe2e9' }}>
                                            <i className="fab fa-angular" style={{ background: '#dd0031' }}></i>
                                            <span className="count after-p" data-to="70" data-speed="70">70</span>
                                        </div>
                                        <h6>Angular</h6>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div className="col-lg-6">
                            <div className="experiences-box">
                                <ul>
                                    <li>
                                        <h6>2021</h6>
                                        <div className="text">
                                            <h5>Senior Product Designer</h5>
                                            <span>vrteam designs</span>
                                        </div>
                                        <label>Continue</label>
                                    </li>
                                    <li>
                                        <h6>2020</h6>
                                        <div className="text">
                                            <h5>Senior Product Designer</h5>
                                            <span>vrteam designs</span>
                                        </div>
                                        <label>vrteam designs</label>
                                    </li>
                                    <li>
                                        <h6>2019</h6>
                                        <div className="text">
                                            <h5>Senior Product Designer</h5>
                                            <span>vrteam designs</span>
                                        </div>
                                        <label>1 yEAR</label>
                                    </li>
                                    <li>
                                        <h6>2018</h6>
                                        <div className="text">
                                            <h5>Senior Product Designer</h5>
                                            <span>vrteam designs</span>
                                        </div>
                                        <label>1 Year</label>
                                    </li>
                                    <li>
                                        <h6>2018</h6>
                                        <div className="text">
                                            <h5>Senior Product Designer</h5>
                                            <span>vrteam designs</span>
                                        </div>
                                        <label>6 months</label>
                                    </li>
                                    <li>
                                        <h6>2017</h6>
                                        <div className="text">
                                            <h5>Senior Product Designer</h5>
                                            <span>vrteam designs</span>
                                        </div>
                                        <label>3 months</label>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="resume" data-scroll-index="2" className="section skills-section bg-gray">
                <div className="container">
                    <div className="section-heading">
                        <h3>Skills & Experience</h3>
                    </div>
                    <div className="row gy-4">
                        <div className="col-lg-12">
                            <ul className="skills-list counter">
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #ffe5dc;">
                                            <i className="fab fa-html5" style="color: #e54c21;"></i>
                                            <span className="count after-p" data-to="80" data-speed="80">80</span>
                                        </div>
                                        <h6>HTML</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #dee4ff;">
                                            <i className="fab fa-css3-alt" style="color: #264de4;"></i>
                                            <span className="count after-p" data-to="90" data-speed="90">90</span>
                                        </div>
                                        <h6>CSS</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #f0ffd0;">
                                            <i className="fab fa-brands fa-js" style="color: #80bd00;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>JS</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #fce9e4;">
                                            <i className="fab fa-brands fa-laravel" style="color: #f53003;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Laravel</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #eceffd;">
                                            <i className="fab fa-brands fa-php" style="color: #4f5b93;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Php</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #fef9f2;">
                                            <i className="fab fa-brands fa-java" style="color: #f29111;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Java</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #ebe6f9;">
                                            <i className="fab fa-brands fa-korvue" style="color: #7f52ff;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Kotlin</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #eff8ff;">
                                            <i className="fab fa-brands fa-python" style="color: #3776ab;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Python</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #f4f8fd;">
                                            <i className="fab fa-solid fa-c" style="color: #a9bacd;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>C</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #f1f7fc;">
                                            <i className="fab fa-brands fa-cuttlefish" style="color: #004482;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>C++</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #f0ffd0;">
                                            <i className="fab fa-brands fa-square-js" style="color: #80bd00;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>React</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #f3fafd;">
                                            <i className="fab fa-brands fa-react" style="color: #087ea4;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>React</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #f4f0fd;">
                                            <i className="fab fa-brands fa-bootstrap" style="color: #712cf9;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Bootstrap</h6>
                                    </div>
                                </li>

                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #def5ff;">
                                            <i className="fab fa-wordpress" style="color: #21759b;"></i>
                                            <span className="count after-p" data-to="65" data-speed="65">65</span>
                                        </div>
                                        <h6>WordPress</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #f0ffd0;">
                                            <i className="fab fa-node-js" style="color: #80bd00;"></i>
                                            <span className="count after-p" data-to="75" data-speed="75">75</span>
                                        </div>
                                        <h6>Node</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #ffe1e1;">
                                            <i className="fab fa-gulp" style="color: #eb4a4b;"></i>
                                            <span className="count after-p" data-to="70" data-speed="70">70</span>
                                        </div>
                                        <h6>Gulp</h6>
                                    </div>
                                </li>
                                <li>
                                    <div className="skill-box">
                                        <div className="skill-icon" style="background: #ffe2e9;">
                                            <i className="fab fa-angular" style="color: #dd0031;"></i>
                                            <span className="count after-p" data-to="70" data-speed="70">70</span>
                                        </div>
                                        <h6>Angular</h6>
                                    </div>
                                </li>
                            </ul>
                        </div>

                    </div>
                </div>
            </section>
        </>
    )
}

export default SkillsSection