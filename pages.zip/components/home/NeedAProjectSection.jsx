import React, { useEffect, useState } from 'react'
import CertificateCardWidget from './widgets/CertificateCardWidget';

import { motion, AnimatePresence } from 'framer-motion';
import UserDataApi from '../../api/UserDataApi';

const NeedAProjectSection = () => {
    const [certificatesData, setCertificatesData] = useState([]);
    const [activeCategory, setActiveCategory] = useState('all');

    const categories = [
        'all',
        'web development',
        'programming',
        'frameworks',
        'cloud computing'
    ];

    useEffect(() => {
        setCertificatesData(UserDataApi.getMyCertificates());
    }, []);

    const filteredCertificates =
        activeCategory === 'all' 
            ? certificatesData
            : certificatesData.filter((cert) =>
                cert.category?.toLowerCase()?.includes(activeCategory)
            );

    return (
        <>
            <section className="about__section project__section cmn-thumbs pt-5 pb-5 position-relative overflow-hidden"
                id="prot">
                <div className="container position-relative z-1">
                    <div className="project__head text-center">
                        <span className="common__sub white" data-aos="fade-down" data-aos-duration="1000">
                            My Certifications
                        </span>
                        <h2 className="fw-500" data-aos="fade-down" data-aos-duration="2000">
                            Awesome Certificates
                        </h2>
                    </div>
                    <div className="singletab">
                        <div className="this-tabs">
                            <ul className="tablinks" data-aos="fade-up" data-aos-duration="2000">
                                
                                {categories.map((cat) => (
                                    <li
                                        key={cat}
                                        className={`nav-links ${activeCategory === cat ? 'active' : ''}`}
                                        onClick={() => setActiveCategory(cat)}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        <button className="tablink">{cat.toUpperCase()}</button>

                                    </li>
                                ))}
                            </ul>
                            <div className="tabcontent">
                                <div className="tabitem active">
                                    <div className="row g-4">

                                        <AnimatePresence mode="popLayout">
                                            {filteredCertificates.map((certificate, index) => (
                                                <motion.div
                                                    key={certificate.title + index}
                                                    layout
                                                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                                    exit={{ opacity: 0, scale: 0.9, y: 20 }}
                                                    transition={{ duration: 0.3 }}
                                                    className="col-xl-4 col-lg-4 col-md-6"
                                                >
                                                    <CertificateCardWidget
                                                        title={certificate.title}
                                                        description={certificate.description}
                                                        image={certificate.image}
                                                        year={certificate.year}
                                                        url={certificate.url}
                                                        category={certificate.category}
                                                    />
                                                </motion.div>
                                            ))}
                                        </AnimatePresence>

                                        <div className="col-xl-4 col-lg-4 col-md-6">
                                            <div className="project__item project-item-v2" data-aos="fade-up"
                                                data-aos-duration="1000">
                                                <div className="thumb position-relative">
                                                    <a href="assets/img/project/pro1.png" className="thumb mb-30 imgc">
                                                        <img src="assets/img/project/pro1.png" alt="img" />
                                                    </a>
                                                    <div
                                                        className="content d-flex align-items-center justify-content-between gap-2">
                                                        <a href="protfolio-details.html" className="left__cont">
                                                            <span className="base mb-2 mb-xxl-3 d-block text-uppercase">
                                                                Product Design
                                                            </span>
                                                            <h3>
                                                                Brand Identity & Motion Design
                                                            </h3>
                                                        </a>
                                                        <a href="assets/img/project/pro1.png" className="common__icon imgc">
                                                            <i className="bi bi-arrow-up-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-4 col-lg-4 col-md-6">
                                            <div className="project__item project-item-v2" data-aos="fade-up"
                                                data-aos-duration="1000">
                                                <div className="thumb position-relative">
                                                    <img src="assets/img/project/pro3.png" alt="img" className="rounded" />
                                                    <div
                                                        className="content d-flex align-items-center justify-content-between gap-2">
                                                        <a href="protfolio-details.html" className="left__cont">
                                                            <span className="base mb-2 mb-xxl-3 d-block text-uppercase">
                                                                Product Design
                                                            </span>
                                                            <h3>
                                                                Design & Branding Mokeup
                                                            </h3>
                                                        </a>
                                                        <a href="assets/img/project/pro3.png" className="common__icon imgc">
                                                            <i className="bi bi-arrow-up-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-4 col-lg-4 col-md-6">
                                            <div className="project__item project-item-v2" data-aos="fade-up"
                                                data-aos-duration="2200">
                                                <div className="thumb position-relative">
                                                    <img src="assets/img/project/pro4.png" alt="img" />
                                                    <div
                                                        className="content d-flex align-items-center justify-content-between gap-2">
                                                        <a href="protfolio-details.html" className="left__cont">
                                                            <span className="base mb-2 mb-xxl-3 d-block text-uppercase">
                                                                Design & Branding
                                                            </span>
                                                            <h3>
                                                                Creative Graphics Design
                                                            </h3>
                                                        </a>
                                                        <a href="assets/img/project/pro4.png" className="common__icon imgc">
                                                            <i className="bi bi-arrow-up-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-4 col-lg-4 col-md-6">
                                            <div className="project__item project-item-v2" data-aos="fade-up"
                                                data-aos-duration="2200">
                                                <div className="thumb position-relative">
                                                    <img src="assets/img/project/pro6.png" alt="img" />
                                                    <div
                                                        className="content d-flex align-items-center justify-content-between gap-2">
                                                        <a href="protfolio-details.html" className="left__cont">
                                                            <span className="base mb-2 mb-xxl-3 d-block text-uppercase">
                                                                MOCKUP DESIGN
                                                            </span>
                                                            <h3>
                                                                Brand Identity & Motion Design
                                                            </h3>
                                                        </a>
                                                        <a href="assets/img/project/pro6.png" className="common__icon imgc">
                                                            <i className="bi bi-arrow-up-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-4 col-lg-4 col-md-6">
                                            <div className="project__item project-item-v2" data-aos="fade-up"
                                                data-aos-duration="1000">
                                                <div className="thumb position-relative">
                                                    <img src="assets/img/project/pro5.png" alt="img" className="rounded" />
                                                    <div
                                                        className="content d-flex align-items-center justify-content-between gap-2">
                                                        <a href="protfolio-details.html" className="left__cont">
                                                            <span className="base mb-2 mb-xxl-3 d-block text-uppercase">
                                                                Ui/ux Design
                                                            </span>
                                                            <h3>
                                                                Mobile Application Development
                                                            </h3>
                                                        </a>
                                                        <a href="assets/img/project/pro5.png" className="common__icon imgc">
                                                            <i className="bi bi-arrow-up-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xl-4 col-lg-4 col-md-6">
                                            <div className="project__item project-item-v2" data-aos="fade-up"
                                                data-aos-duration="2200">
                                                <div className="thumb position-relative">
                                                    <img src="assets/img/project/pro2.png" alt="img" className="rounded" />
                                                    <div
                                                        className="content d-flex align-items-center justify-content-between gap-2">
                                                        <a href="protfolio-details.html" className="left__cont">
                                                            <span className="base mb-2 mb-xxl-3 d-block text-uppercase">
                                                                Creative
                                                            </span>
                                                            <h3>
                                                                Paper & Book Covers Design
                                                            </h3>
                                                        </a>
                                                        <a href="assets/img/project/pro2.png" className="common__icon imgc">
                                                            <i className="bi bi-arrow-up-right"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className="custom__hover">
                        <a href="portfolio-details.html" className="hover__circle mauto" data-aos="zoom-out-down"
                            data-aos-duration="2000">
                            <span className="box">
                                <i className="bi bi-arrow-up-right"></i>
                                <span className="textmore">
                                    Click More Work
                                </span>
                            </span>
                        </a>
                    </div>
                </div>
                <img src="assets/img/about/ellip.png" alt="img" className="ellip" />
                <img src="assets/img/about/ellip.png" alt="img" className="ellip2" />
            </section>
        </>
    )
}

export default NeedAProjectSection