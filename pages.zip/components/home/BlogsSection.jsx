import React, { useEffect } from 'react'
import UserDataApi from '../../api/UserDataApi'; // Assuming this is the correct path to your data API
import BlogCardWidget from './widgets/BlogCardWidget';

import Slider from 'react-slick';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";


const BlogsSection = () => {


    const [blogsData, setBlogsData] = React.useState([]);

    useEffect(() => {
        setBlogsData(UserDataApi.getBlogs());
    }, []);


    const settings = {
        dots: false,
        infinite: true,
        arrows: false,
        speed: 300,
        slidesToShow: 4,
        slidesToScroll: 4,
        adaptiveHeight: true,
        responsive: [
            {
                breakpoint: 1367,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4
                }
            },
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 992,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 768,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 575,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 0,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };


    return (
        <>
            <section id="news" className="br-news padding-tb-80">
                <div className="container">
                    <div className="section-title">
                        <h2>Latest <span>News</span></h2>
                        <span className="ligh-title">Blogs</span>
                    </div>
                    <div className="row m-b-minus-30px">
                        <Slider {...settings}>
                            {blogsData.map((blog, index) => (
                                <BlogCardWidget key={index} title={blog.title} description={blog.description} image={blog.image} date={blog.date} category={blog.category} postTitle={blog.postTitle} />
                            ))}
                        </Slider>

                        
                    </div>
                </div>
            </section>
        </>
    )
}

export default BlogsSection