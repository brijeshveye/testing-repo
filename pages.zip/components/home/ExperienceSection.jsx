import React from 'react'

const ExperienceSection = () => {
    return (
        <>
            <div className="about-sections bg1-img2 pt-5 pb-5 overflow-hidden">
                <div className="container">
                    <div className="row g-4 align-items-center">
                        <div className="col-lg-12">
                            <h5 className="head-text mtitle mb-5">
                                My Education
                            </h5>
                            <div className="about__onecontent">
                                <div className="col-lg-8 mb-xxl-5 mb-4" data-aos="zoom-out-down" data-aos-duration="700">
                                    <div className="row g-4 align-items-center justify-content-between">
                                        <div className="col-xl-9 col-lg-8">
                                            <div className="aria-edubox">
                                                <div className="expri__cont">
                                                    <h4 className="mb-15 mtitle">
                                                        Programming Course
                                                    </h4>
                                                    <p className="fz-18 mtitle d-block">
                                                        UK University
                                                    </p>
                                                </div>
                                                <p className="mtitle">
                                                    Adipisicing elit. Illum totam nisi. Lorem ipsum dolor sit amet
                                                    consectetur adipisicing elit. A dignissimos itaque consequuntur in saepe
                                                    enim nihil pariatur, ab, molestias vel similique est, commodi nesciunt?
                                                    Odio inventore quis eius veniam. Aliquam rem.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-3 col-lg-4">
                                            <span className="years-about fw-500 base">
                                                2010-2012
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-8 mb-xxl-5 mb-4 d-flex justify-content-end ms-auto"
                                    data-aos="zoom-out-down" data-aos-duration="800">
                                    <div className="row g-4 align-items-center justify-content-between">
                                        <div className="col-xl-9 col-lg-8">
                                            <div className="aria-edubox">
                                                <div className="expri__cont">
                                                    <h4 className="mb-15 mtitle">
                                                        Web Design Course
                                                    </h4>
                                                    <p className="fz-18 mtitle d-block">
                                                        Cansong London
                                                    </p>
                                                </div>
                                                <p className="mtitle">
                                                    Adipisicing elit. Illum totam nisi. Lorem ipsum dolor sit amet
                                                    consectetur adipisicing elit. A dignissimos itaque consequuntur in saepe
                                                    enim nihil pariatur, ab, molestias vel similique est, commodi nesciunt?
                                                    Odio inventore quis eius veniam. Aliquam rem.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-3 col-lg-4">
                                            <span className="years-about fw-500 base">
                                                2015-2018
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-8 mb-xxl-5 mb-4" data-aos="zoom-out-down" data-aos-duration="900">
                                    <div className="row g-4 align-items-center justify-content-between">
                                        <div className="col-xl-9 col-lg-8">
                                            <div className="aria-edubox">
                                                <div className="expri__cont">
                                                    <h4 className="mb-15 mtitle">
                                                        Graphic Design Course
                                                    </h4>
                                                    <p className="fz-18 mtitle d-block">
                                                        Cergos Germany
                                                    </p>
                                                </div>
                                                <p className="mtitle">
                                                    Adipisicing elit. Illum totam nisi. Lorem ipsum dolor sit amet
                                                    consectetur adipisicing elit. A dignissimos itaque consequuntur in saepe
                                                    enim nihil pariatur, ab, molestias vel similique est, commodi nesciunt?
                                                    Odio inventore quis eius veniam. Aliquam rem.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-3 col-lg-4">
                                            <span className="years-about fw-500 base">
                                                2017-2019
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-8 d-flex justify-content-end ms-auto" data-aos="zoom-out-down"
                                    data-aos-duration="1000">
                                    <div className="row g-4 align-items-center justify-content-between">
                                        <div className="col-xl-9 col-lg-8">
                                            <div className="aria-edubox">
                                                <div className="expri__cont">
                                                    <h4 className="mb-15 mtitle">
                                                        Senior Product Designer
                                                    </h4>
                                                    <p className="fz-18 mtitle d-block">
                                                        Cergos Germany
                                                    </p>
                                                </div>
                                                <p className="mtitle">
                                                    Adipisicing elit. Illum totam nisi. Lorem ipsum dolor sit amet
                                                    consectetur adipisicing elit. A dignissimos itaque consequuntur in saepe
                                                    enim nihil pariatur, ab, molestias vel similique est, commodi nesciunt?
                                                    Odio inventore quis eius veniam. Aliquam rem.
                                                </p>
                                            </div>
                                        </div>
                                        <div className="col-xl-3 col-lg-4">
                                            <span className="years-about fw-500 base">
                                                2018-2022
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <img src="assets/img/about/ellip.png" alt="img" className="ellip" />
                <img src="assets/img/about/ellip.png" alt="img" className="ellip2" />
            </div>
        </>
    )
}

export default ExperienceSection