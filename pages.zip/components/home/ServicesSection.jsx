import React from 'react'

const ServicesSection = () => {
    return (
        <>
            <section id="service" className="br-service padding-tb-80 sec-bg">
                <div className="container">
                    <div className="section-title d-none">
                        <h2>My<span> service</span></h2>
                        <span className="ligh-title">service</span>
                    </div>
                    <div className="row service-box m-tb-minus-15px">
                        <div className="col-lg-3 col-md-6 col-xs-12">
                            <div className="flipper">
                                <div className="main-box">
                                    <div className="box-front height-300 white-bg">
                                        <div className="content-wrap">
                                            <div className="icon">
                                                <img className="icofont icofont-headphone-alt font-40px dark-color svg_img"
                                                    src="assets/img/service/1.svg" alt="Graphics Design" />
                                            </div>
                                            <h3>Graphics Design</h3>
                                            <p>Develop the Visual Identity of Your Business</p>
                                        </div>
                                    </div>
                                    <div className="box-back height-300 gradient-bg">
                                        <div className="content-wrap">
                                            <h3>Graphics Design</h3>
                                            <p>Develop the Visual Identity of Your Business</p>
                                            <a href="#" className="btn">Read more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-xs-12">
                            <div className="flipper">
                                <div className="main-box">
                                    <div className="box-front height-300 white-bg">
                                        <div className="content-wrap">
                                            <div className="icon">
                                                <img className="icofont icofont-headphone-alt font-40px dark-color svg_img"
                                                    src="assets/img/service/2.svg" alt="web design" />
                                            </div>
                                            <h3>Web Design</h3>
                                            <p>Connect With Your Users, Not Just Your Business.</p>
                                        </div>
                                    </div>
                                    <div className="box-back height-300 gradient-bg">
                                        <div className="content-wrap">
                                            <h3>Web Design</h3>
                                            <p>Connect With Your Users, Not Just Your Business.</p>
                                            <a href="#" className="btn">Read more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-xs-12">
                            <div className="flipper">
                                <div className="main-box">
                                    <div className="box-front height-300 white-bg">
                                        <div className="content-wrap">
                                            <div className="icon">
                                                <img className="icofont icofont-headphone-alt font-40px dark-color svg_img"
                                                    src="assets/img/service/3.svg" alt="development" />
                                            </div>
                                            <h3>Development</h3>
                                            <p>We Develop the Visual Identity of Your Business.</p>
                                        </div>
                                    </div>
                                    <div className="box-back height-300 gradient-bg">
                                        <div className="content-wrap">
                                            <h3>Development</h3>
                                            <p>We Develop the Visual Identity of Your Business.</p>
                                            <a href="#" className="btn">Read more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3 col-md-6 col-xs-12">
                            <div className="flipper">
                                <div className="main-box">
                                    <div className="box-front height-300 white-bg">
                                        <div className="content-wrap">
                                            <div className="icon">
                                                <img className="icofont icofont-headphone-alt font-40px dark-color svg_img"
                                                    src="assets/img/service/4.svg" alt="seo friendly" />
                                            </div>
                                            <h3>Seo Friendly</h3>
                                            <p>Taking your site at the top of Google's ranking.</p>
                                        </div>
                                    </div>
                                    <div className="box-back height-300 gradient-bg">
                                        <div className="content-wrap">
                                            <h3>Seo Friendly</h3>
                                            <p>Taking your site at the top of Google's ranking.</p>
                                            <a href="#" className="btn">Read more</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default ServicesSection