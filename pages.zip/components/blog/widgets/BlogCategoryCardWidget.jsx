import React from 'react'

const BlogCategoryCardWidget = (props) => {
    return (
        <>
            <li>
                <a href={props.categoryLink} className="d-flex align-items-center justify-content-between">
                    <span className="fz-18 ptext">
                        {props.categoryName}
                    </span>
                    <span className="arrow">
                        <i className="bi bi-chevron-right"></i>
                    </span>
                </a>
            </li>
        </>
    )
}

BlogCategoryCardWidget.defaultProps = {
    categoryLink: '#',
    categoryName: 'Category Name'
}

export default BlogCategoryCardWidget