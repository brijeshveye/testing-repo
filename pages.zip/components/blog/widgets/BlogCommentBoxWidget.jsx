import React from 'react'

const BlogCommentBoxWidget = () => {
    return (
        <>
            <div className="replay__box cmn__bg">
                <h3>
                    Leave a Reply
                </h3>
                <p>
                    Your email address will not be published. Required fields are marked *
                </p>
                <form action="#" className="row g-4">
                    <div className="col-lg-6">
                        <input type="text" placeholder="Name" />
                    </div>
                    <div className="col-lg-6">
                        <input type="email" placeholder="Eamil" />
                    </div>
                    <div className="col-lg-12">
                        <textarea name="comment" rows="5" placeholder="Write Comments"></textarea>
                    </div>
                    <a href="contact.html/index.html"
                        className="d-flex fw-500 cmn--btn align-items-center gap-2">
                        <span className="get__text">
                            Submit Comment
                        </span>
                        <span>
                            <i className="bi bi-arrow-right fz-20"></i>
                        </span>
                    </a>
                </form>
            </div>
        </>
    )
}

export default BlogCommentBoxWidget