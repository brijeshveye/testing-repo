import React, { useEffect, useState } from 'react'
import BlogTopSection from '../components/blog/BlogTopSection'
import BlogSection from '../components/blog/BlogSection'
import UserDataApi from '../api/UserDataApi';


const BlogDetails = () => {
  const [blogData, setBlogData] = useState({});

  useEffect(() => {
    setBlogData(UserDataApi.getBlogs());
  }, []);

  return (
    <>
    <main className='wrapper'>
        <BlogTopSection blogData={blogData} />
        <BlogSection blogData={blogData} />
    </main>
    </>
  )
}

export default BlogDetails