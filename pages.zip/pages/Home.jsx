import React from 'react'
import HeroSection from '../components/home/HeroSection'
import AboutSection from '../components/home/AboutSection'
import SkillsSection from '../components/home/SkillsSection'
import MyEducationSection from '../components/home/MyEducationSection'
import MyExperienceSection from '../components/home/MyExperienceSection'
import ServicesSection from '../components/home/ServicesSection'
import MarqueeSection from '../components/home/MarqueeSection'
import WhatIDoSection from '../components/home/WhatIDoSection'
import NeedAProjectSection from '../components/home/NeedAProjectSection'
import MyProjectsSection from '../components/home/MyProjectsSection'
import TestimonialSection from '../components/home/TestimonialsSection'
import BlogsSection from '../components/home/BlogsSection'
import ContactSection from '../components/home/ContactSection'
import ExperienceSection from '../components/home/ExperienceSection'

const Home = () => {
  return (
    <>
      <main className='wrapper'>

        <HeroSection />

        <AboutSection />

        {/* <SkillsSection /> */}

        <MyEducationSection />

        <MyExperienceSection />

        <ServicesSection />

        <ExperienceSection />

        <MarqueeSection />

        <WhatIDoSection />

        <NeedAProjectSection />

        <MyProjectsSection />

        <TestimonialSection />

        <BlogsSection />

        <ContactSection />

      </main>
    </>
  )
}

export default Home