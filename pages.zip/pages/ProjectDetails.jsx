import React, { useEffect, useState } from 'react'
import PortfolioTopSection from '../components/portfolio/PortfolioTopSection'
import ProjectSection from '../components/portfolio/ProjectSection'
import UserDataApi from '../api/UserDataApi';


const ProjectDetails = () => {
  const [projectData, setProjectData] = useState({});

  useEffect(() => {
    setProjectData(UserDataApi.getMyProjects());
  }, []);


  return (
    <main className='wrapper'>
      <PortfolioTopSection projectData={projectData} />
      <ProjectSection projectData={projectData} />
    </main>
  )
}

export default ProjectDetails