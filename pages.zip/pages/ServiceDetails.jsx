import React, { useEffect, useState } from 'react'
import ServiceTopSection from '../components/service/ServiceTopSection'
import ServiceSection from '../components/service/ServiceSection'
import UserDataApi from '../api/UserDataApi';


const ServiceDetails = () => {
  const [serviceData, setServiceData] = useState({});

  useEffect(() => {
    setServiceData(UserDataApi.getServices());
  }, []);

  return (
    <main className='wrapper'>
        <ServiceTopSection serviceData={serviceData} />
        <ServiceSection serviceData={serviceData} />
    </main>
  )
}

export default ServiceDetails