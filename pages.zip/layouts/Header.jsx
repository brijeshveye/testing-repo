import React from 'react'

const Header = () => {
    return (
        <>
            <header className="main-header">
                <nav className="navbar navbar-expand-lg one-page-nav">
                    <div className="container">
                        <a className="navbar-brand" href="#">
                            <img src="assets/img/logo.svg" title="Logo" alt="Logo" />
                        </a>
                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbar-collapse-toggle" aria-controls="navbar-collapse-toggle"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                        <div className="collapse navbar-collapse justify-content-end" id="navbar-collapse-toggle">
                            <ul className="navbar-nav mx-auto">
                                <li className="nav-item"><a className="nav-link" data-scroll-nav="0" href="#home"><span>Home</span></a>
                                </li>
                                <li className="nav-item"><a className="nav-link" data-scroll-nav="1"
                                    href="#about"><span>About</span></a></li>
                                <li className="nav-item"><a className="nav-link" data-scroll-nav="2"
                                    href="#resume"><span>Resume</span></a></li>
                                <li className="nav-item"><a className="nav-link" data-scroll-nav="3"
                                    href="#services"><span>Services</span></a></li>
                                <li className="nav-item"><a className="nav-link" data-scroll-nav="4" href="#work"><span>Work</span></a>
                                </li>
                                <li className="nav-item"><a className="nav-link" data-scroll-nav="5" href="#blog"><span>Blog</span></a>
                                </li>
                                <li className="nav-item"><a className="nav-link" data-scroll-nav="6"
                                    href="#contact"><span>Contact</span></a></li>
                            </ul>
                        </div>
                        <div className="ms-auto d-lg-block d-none">
                            <a href="#contact" data-scroll-nav="6" className="px-btn px-btn-primary">HIRE ME</a>
                        </div>
                    </div>
                </nav>
            </header>
        </>
    )
}

export default Header