# Dynamic Widget System & Image Upload Setup

## Features Implemented

### 1. Dynamic Content Widgets
The system now supports 6 types of dynamic content widgets:

#### Widget Types:
- **📝 Heading Widget**: Configurable heading levels (H1-H6)
- **📄 Paragraph Widget**: Rich text content
- **📋 List Widget**: Bulleted or numbered lists with dynamic items
- **📏 Spacer Widget**: Adjustable spacing (10-200px)
- **🖼️ Image Widget**: Images with alignment, sizing, and captions
- **📺 YouTube Widget**: Embedded YouTube videos

#### Widget Features:
- **Drag & Drop Reordering**: Move widgets up/down
- **Live Preview**: Toggle between edit and preview modes
- **Real-time Editing**: Changes are instantly visible
- **Responsive Design**: Mobile-friendly interface
- **Data Persistence**: Widgets save with blog/project data

### 2. Image Upload System
Comprehensive image management with categorization:

#### Server-Side Features:
- **File Validation**: Type and size checking (5MB limit)
- **Category Organization**: Separate folders for different content types
- **Secure Upload**: File naming and path sanitization
- **Multiple Upload**: Batch image processing
- **File Management**: List, delete, and organize uploads

#### Client-Side Features:
- **Drag & Drop Upload**: Modern file upload interface
- **Progress Indicators**: Visual upload feedback
- **Error Handling**: User-friendly error messages
- **Image Preview**: Thumbnail previews
- **Category Support**: Organized by content type

#### Image Categories:
- `general` - General purpose images
- `profile` - User profile pictures
- `project` - Project-related images
- `blog` - Blog post images
- `content` - Dynamic content images
- `banner` - Banner/hero images
- `thumbnail` - Thumbnail images

## File Structure

```
client/src/admin/components/
├── widgets/
│   ├── DynamicWidgets.jsx     # Individual widget components
│   ├── WidgetManager.jsx      # Main widget manager
│   └── WidgetStyles.css       # Widget styling
├── ImageUpload.jsx            # Image upload utilities
├── AdminDashboard.jsx         # Admin dashboard
├── ProjectForm.jsx            # Enhanced project form
└── BlogForm.jsx               # Enhanced blog form

server/
├── routes/
│   └── uploadRoutes.js        # Image upload endpoints
├── uploads/                   # Upload directory (auto-created)
└── server.js                  # Updated with upload routes
```

## API Endpoints

### Image Upload
- `POST /api/upload/upload` - Single image upload
- `POST /api/upload/upload-multiple` - Multiple image upload
- `GET /api/upload/list/:category?` - List images by category
- `DELETE /api/upload/delete/:category/:filename` - Delete image
- `GET /uploads/:category/:filename` - Serve uploaded images

## Required Dependencies

### Server Dependencies
Add these to `server/package.json`:
```bash
npm install multer
```

### Client Dependencies
No additional dependencies required - uses existing React features.

## Usage Guide

### 1. Creating Dynamic Content

#### For Projects:
1. Go to Admin → Projects → Create/Edit
2. Navigate to "Dynamic Content" tab
3. Add widgets using the toolbar buttons
4. Configure each widget with content
5. Use Edit/Preview toggle to see results
6. Save the project

#### For Blogs:
1. Go to Admin → Blogs → Create/Edit
2. Navigate to "Dynamic Content" tab
3. Follow same process as projects

### 2. Image Management

#### Upload Images:
1. In any form, go to "Images" tab
2. Use drag & drop or file browser
3. Images are automatically categorized
4. Preview thumbnails appear instantly

#### Widget Images:
1. Add an Image Widget in Dynamic Content
2. Upload images directly within the widget
3. Configure alignment and sizing
4. Add captions and alt text

### 3. Content Display
Dynamic content is rendered using the `ContentRenderer` component:
```jsx
import ContentRenderer from '../components/common/ContentRenderer';

// In your component
<ContentRenderer widgets={project.widgets} />
```

## Data Structure

### Widget Data Format:
```json
{
  "widgets": [
    {
      "id": "1640995200000",
      "type": "heading",
      "data": {
        "text": "Project Overview",
        "level": "h2"
      }
    },
    {
      "id": "1640995300000",
      "type": "image",
      "data": {
        "src": "/uploads/content/image_123456.jpg",
        "alt": "Project screenshot",
        "caption": "Main application interface",
        "alignment": "center",
        "size": "large"
      }
    }
  ]
}
```

### Upload Response Format:
```json
{
  "success": true,
  "url": "/uploads/project/filename_123456.jpg",
  "filename": "filename_123456.jpg",
  "originalName": "screenshot.jpg",
  "size": 245760,
  "category": "project"
}
```

## Security Features

1. **File Type Validation**: Only image files allowed
2. **Size Limits**: Maximum 5MB per file
3. **Path Sanitization**: Prevents directory traversal
4. **Category Isolation**: Files organized by category
5. **Unique Naming**: Timestamp-based file naming

## Styling & Customization

The system includes comprehensive CSS styling:
- Responsive design for mobile devices
- Smooth animations and transitions
- Consistent color scheme
- Hover effects and visual feedback
- Drag & drop visual indicators

## Future Enhancements

Potential additions:
- Rich text editor widget
- Code snippet widget
- Gallery/carousel widget
- Audio/video widgets
- Form builder widgets
- Chart/graph widgets

## Troubleshooting

### Common Issues:

1. **Upload fails**: Check file size (max 5MB) and type (images only)
2. **Images not displaying**: Verify server is serving `/uploads` directory
3. **Widgets not saving**: Check form submission includes `widgets` field
4. **Style issues**: Ensure `WidgetStyles.css` is imported

### Debug Steps:
1. Check browser console for errors
2. Verify server logs for upload issues
3. Test with smaller image files
4. Ensure multer is installed on server
