const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Import models
const Project = require('../models/Project');
const Blog = require('../models/Blog');
const User = require('../models/User');
const Testimonial = require('../models/Testimonial');
const Certificate = require('../models/Certificate');
const Skill = require('../models/Skill');
const Education = require('../models/Education');
const Experience = require('../models/Experience');
const Service = require('../models/Service');
const Characteristic = require('../models/Characteristic');

// Import JSON data
const projectsData = require('../data/projectsData.json');
const blogsData = require('../data/blogsData.json');
const userData = require('../data/userData.json');
const characteristicsData = require('../data/characteristicsData.json');

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://sanjayveye:nsnGBIJHzrzkmZw6@cluster0.czkcxtw.mongodb.net/');
    console.log('✅ MongoDB connected for migration');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
};

// Migrate Projects
const migrateProjects = async () => {
  try {
    console.log('🔄 Migrating projects...');
    
    // Clear existing projects
    await Project.deleteMany({});
    
    for (const project of projectsData) {
      // Transform data structure if needed
      const projectDoc = new Project({
        title: project.title || 'Untitled Project',
        description: project.description || '',
        shortDescription: project.shortDescription || project.description || '',
        slug: project.slug || project.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        image: project.image || '',
        images: project.images || [],
        technologies: project.technologies || [],
        liveUrl: project.liveUrl || '',
        githubUrl: project.githubUrl || '',
        category: project.category || 'web',
        status: project.status || 'completed',
        featured: project.featured || false,
        startDate: project.startDate ? new Date(project.startDate) : new Date(),
        endDate: project.endDate ? new Date(project.endDate) : null,
        widgets: project.widgets || [],
        domains: project.domains || [],
        details: project.details || {}
      });
      
      await projectDoc.save();
      console.log(`✅ Migrated project: ${project.title}`);
    }
    
    console.log(`✅ Successfully migrated ${projectsData.length} projects`);
  } catch (error) {
    console.error('❌ Error migrating projects:', error);
  }
};

// Migrate Blogs
const migrateBlogs = async () => {
  try {
    console.log('🔄 Migrating blogs...');
    
    // Clear existing blogs
    await Blog.deleteMany({});
    
    for (const blog of blogsData) {
      const blogDoc = new Blog({
        title: blog.title || 'Untitled Blog',
        content: blog.content || '',
        excerpt: blog.excerpt || blog.content?.substring(0, 200) || '',
        slug: blog.slug || blog.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        featuredImage: blog.featuredImage || blog.image || '',
        images: blog.images || [],
        tags: blog.tags || [],
        category: blog.category || 'general',
        author: blog.author || 'Admin',
        published: blog.published !== false,
        featured: blog.featured || false,
        readTime: blog.readTime || 5,
        publishedAt: blog.publishedAt ? new Date(blog.publishedAt) : new Date(),
        widgets: blog.widgets || [],
        seo: blog.seo || {},
        details: blog.details || {}
      });
      
      await blogDoc.save();
      console.log(`✅ Migrated blog: ${blog.title}`);
    }
    
    console.log(`✅ Successfully migrated ${blogsData.length} blogs`);
  } catch (error) {
    console.error('❌ Error migrating blogs:', error);
  }
};

// Migrate User Data
const migrateUserData = async () => {
  try {
    console.log('🔄 Migrating user data...');
    
    // Clear existing user data
    await User.deleteMany({});
    
    const userDoc = new User({
      userId: 'portfolio_owner',
      aboutData: userData.aboutData || {},
      educationData: userData.educationData || [],
      experienceData: userData.experienceData || [],
      skillsData: userData.skillsData || [],
      certificatesData: userData.certificatesData || [],
      testimonialsData: userData.testimonialsData || [],
      servicesData: userData.servicesData || [],
      socialLinks: userData.socialLinks || {}
    });
    
    await userDoc.save();
    console.log('✅ Migrated user data');
  } catch (error) {
    console.error('❌ Error migrating user data:', error);
  }
};

// Migrate Testimonials from User Data
const migrateTestimonials = async () => {
  try {
    console.log('🔄 Migrating testimonials...');
    
    // Clear existing testimonials
    await Testimonial.deleteMany({});
    
    // Get testimonials from user data if exists
    const testimonialsFromUser = userData.testimonialsData || [];
    
    // Default testimonials if none exist in user data
    const defaultTestimonials = [
      {
        customerName: "Jane Smith",
        customerFeedback: "John's work on our project was exceptional. He delivered high-quality code and met all deadlines.",
        customerPosition: "CEO, Tech Solutions",
        stars: 5,
        featured: true,
        isActive: true
      },
      {
        customerName: "Michael Johnson", 
        customerFeedback: "A pleasure to work with! John has a keen eye for detail and a strong understanding of modern web technologies.",
        customerPosition: "CTO, Web Innovations",
        stars: 5,
        featured: false,
        isActive: true
      },
      {
        customerName: "Emily Davis",
        customerFeedback: "John's expertise in UI/UX design significantly improved our user engagement. Highly recommended!",
        customerPosition: "Product Manager, Creative Agency", 
        stars: 5,
        featured: false,
        isActive: true
      }
    ];
    
    const testimonialsToMigrate = testimonialsFromUser.length > 0 ? testimonialsFromUser : defaultTestimonials;
    
    for (const [index, testimonial] of testimonialsToMigrate.entries()) {
      const testimonialDoc = new Testimonial({
        customerName: testimonial.customerName,
        customerFeedback: testimonial.customerFeedback,
        designation: testimonial.customerPosition || testimonial.designation || '',
        company: testimonial.company || '',
        customerImage: testimonial.customerImage || '',
        rating: testimonial.stars || testimonial.rating || 5,
        featured: testimonial.featured || (index === 0), // Make first one featured by default
        isActive: testimonial.isActive !== false,
        slug: testimonial.customerName?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-testimonial',
        order: index + 1
      });
      
      await testimonialDoc.save();
    }
    
    console.log(`✅ Migrated ${testimonialsToMigrate.length} testimonials`);
  } catch (error) {
    console.error('❌ Error migrating testimonials:', error);
  }
};

// Migrate Certificates from User Data
const migrateCertificates = async () => {
  try {
    console.log('🔄 Migrating certificates...');
    
    // Clear existing certificates
    await Certificate.deleteMany({});
    
    // Get certificates from user data if exists
    const certificatesFromUser = userData.certificatesData || [];
    
    // Default certificates if none exist in user data
    const defaultCertificates = [
      {
        title: "Certified Full Stack Developer",
        description: "Full Stack Web Development Certification",
        issuer: "Tech Institute",
        year: "2021",
        image: "assets/img/project/pro1.png",
        url: "https://example.com/certificate/full-stack-developer",
        category: "Web Development",
        featured: true,
        isActive: true
      },
      {
        title: "JavaScript Mastery",
        description: "Advanced JavaScript Programming",
        issuer: "Online Academy",
        year: "2020",
        image: "assets/img/project/pro2.png",
        url: "https://example.com/certificate/javascript-mastery",
        category: "Programming",
        featured: false,
        isActive: true
      },
      {
        title: "UI/UX Design Fundamentals",
        description: "Introduction to UI/UX Design Principles",
        issuer: "Design School",
        year: "2019",
        image: "assets/img/project/pro3.png",
        url: "https://example.com/certificate/ui-ux-design-fundamentals",
        category: "Frameworks",
        featured: false,
        isActive: true
      },
      {
        title: "Cloud Computing Essentials",
        description: "Understanding Cloud Technologies and Services",
        issuer: "Cloud Academy",
        year: "2022",
        image: "assets/img/project/pro4.png",
        url: "https://example.com/certificate/cloud-computing-essentials",
        category: "Cloud Computing",
        featured: true,
        isActive: true
      },
      {
        title: "Data Science with Python",
        description: "Data Analysis and Machine Learning with Python",
        issuer: "Data Science Institute",
        year: "2023",
        image: "assets/img/project/pro5.png",
        url: "https://example.com/certificate/data-science-python",
        category: "Cloud Computing",
        featured: false,
        isActive: true
      },
      {
        title: "Agile Project Management",
        description: "Agile Methodologies and Project Management Techniques",
        issuer: "Project Management Institute",
        year: "2021",
        image: "assets/img/project/pro6.png",
        url: "https://example.com/certificate/agile-project-management",
        category: "Frameworks",
        featured: false,
        isActive: true
      }
    ];
    
    const certificatesToMigrate = certificatesFromUser.length > 0 ? certificatesFromUser : defaultCertificates;
    
    for (const [index, certificate] of certificatesToMigrate.entries()) {
      const certificateDoc = new Certificate({
        title: certificate.title,
        description: certificate.description,
        issuer: certificate.issuer,
        year: certificate.year,
        image: certificate.image || '',
        url: certificate.url || '',
        category: certificate.category || 'General',
        credentialId: certificate.credentialId || '',
        featured: certificate.featured || (index === 0), // Make first one featured by default
        isActive: certificate.isActive !== false,
        slug: certificate.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-certificate',
        order: index + 1,
        skills: certificate.skills || []
      });
      
      await certificateDoc.save();
    }
    
    console.log(`✅ Migrated ${certificatesToMigrate.length} certificates`);
  } catch (error) {
    console.error('❌ Error migrating certificates:', error);
  }
};

// Migrate Skills from User Data  
const migrateSkills = async () => {
  try {
    console.log('🔄 Migrating skills...');
    
    // Clear existing skills
    await Skill.deleteMany({});
    
    // Get skills from user data if exists
    const skillsFromUser = userData.skillsData || [];
    
    // Default skills if none exist in user data
    const defaultSkills = [
      // Languages
      { title: "JavaScript", icon: "fab fa-js", color: "#f0db4f", percentage: 85, category: "Language", level: "Advanced", yearsExperience: 4, featured: true },
      { title: "Python", icon: "fab fa-python", color: "#306998", percentage: 75, category: "Language", level: "Intermediate", yearsExperience: 3, featured: false },
      { title: "Java", icon: "fab fa-java", color: "#dd0031", percentage: 70, category: "Language", level: "Intermediate", yearsExperience: 2, featured: false },
      { title: "PHP", icon: "fab fa-php", color: "#8993be", percentage: 80, category: "Language", level: "Advanced", yearsExperience: 3, featured: false },
      
      // Frontend
      { title: "React", icon: "fab fa-react", color: "#61dafb", percentage: 90, category: "Frontend", level: "Expert", yearsExperience: 4, featured: true },
      { title: "HTML5", icon: "fab fa-html5", color: "#e54c21", percentage: 90, category: "Frontend", level: "Expert", yearsExperience: 5, featured: false },
      { title: "CSS3", icon: "fab fa-css3-alt", color: "#264de4", percentage: 80, category: "Frontend", level: "Advanced", yearsExperience: 5, featured: false },
      { title: "Bootstrap", icon: "fab fa-bootstrap", color: "#7952b3", percentage: 85, category: "Frontend", level: "Advanced", yearsExperience: 3, featured: false },
      
      // Backend
      { title: "Node.js", icon: "fab fa-node-js", color: "#80bd00", percentage: 80, category: "Backend", level: "Advanced", yearsExperience: 3, featured: true },
      { title: "Express", icon: "fas fa-server", color: "#000000", percentage: 70, category: "Backend", level: "Intermediate", yearsExperience: 2, featured: false },
      { title: "Laravel", icon: "fab fa-laravel", color: "#f55247", percentage: 75, category: "Backend", level: "Intermediate", yearsExperience: 2, featured: false },
      
      // Database
      { title: "MongoDB", icon: "fas fa-database", color: "#47a248", percentage: 80, category: "Database", level: "Advanced", yearsExperience: 3, featured: true },
      { title: "MySQL", icon: "fas fa-database", color: "#00758f", percentage: 75, category: "Database", level: "Intermediate", yearsExperience: 3, featured: false },
      
      // Cloud & DevOps
      { title: "AWS", icon: "fab fa-aws", color: "#ff9900", percentage: 75, category: "Cloud", level: "Intermediate", yearsExperience: 2, featured: false },
      { title: "Git", icon: "fab fa-git-alt", color: "#f1502f", percentage: 85, category: "DevOps", level: "Advanced", yearsExperience: 4, featured: false },
      
      // Design
      { title: "Figma", icon: "fab fa-figma", color: "#a259ff", percentage: 80, category: "Design", level: "Advanced", yearsExperience: 2, featured: false }
    ];
    
    const skillsToMigrate = skillsFromUser.length > 0 ? skillsFromUser : defaultSkills;
    
    for (const [index, skill] of skillsToMigrate.entries()) {
      const skillDoc = new Skill({
        title: skill.title,
        description: skill.description || `Professional experience with ${skill.title}`,
        icon: skill.icon || 'fas fa-code',
        color: skill.color || '#007bff',
        percentage: skill.percentage || 50,
        category: skill.category || 'Other',
        level: skill.level || 'Intermediate',
        yearsExperience: skill.yearsExperience || 1,
        certifications: skill.certifications || [],
        projects: skill.projects || [],
        featured: skill.featured || false,
        isActive: skill.isActive !== false,
        slug: skill.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: index + 1
      });
      
      await skillDoc.save();
    }
    
    console.log(`✅ Migrated ${skillsToMigrate.length} skills`);
  } catch (error) {
    console.error('❌ Error migrating skills:', error);
  }
};

// Migrate Education from User Data  
const migrateEducation = async () => {
  try {
    console.log('🔄 Migrating education...');
    
    // Clear existing education
    await Education.deleteMany({});
    
    // Get education from user data if exists
    const educationFromUser = userData.educationData || [];
    
    // Default education if none exist in user data
    const defaultEducation = [
      {
        title: "Computer Science",
        institution: "University of Technology",
        degree: "Bachelor of Science",
        fieldOfStudy: "Computer Science",
        startDate: "2015-09-01",
        endDate: "2019-06-01",
        current: false,
        grade: "First Class Honours",
        description: "Comprehensive study of computer science fundamentals including algorithms, data structures, software engineering, and system design.",
        activities: ["Programming Club", "Tech Society", "Hackathon Organizer"],
        achievements: ["Dean's List", "Best Final Year Project", "Programming Competition Winner"],
        skills: ["Java", "C++", "Python", "JavaScript", "Database Design", "Software Engineering"],
        location: "Tech City, USA",
        featured: true,
        isActive: true
      },
      {
        title: "Advanced Web Development",
        institution: "Online Tech Academy",
        degree: "Certificate",
        fieldOfStudy: "Web Development",
        startDate: "2020-01-01",
        endDate: "2020-06-01",
        current: false,
        grade: "Distinction",
        description: "Intensive program covering modern web development technologies and frameworks.",
        activities: ["Online Community Mentor"],
        achievements: ["Top 5% of class", "Capstone Project Excellence"],
        skills: ["React", "Node.js", "MongoDB", "Express", "REST APIs"],
        location: "Online",
        featured: false,
        isActive: true
      },
      {
        title: "Master of Software Engineering",
        institution: "Tech Institute",
        degree: "Master of Science",
        fieldOfStudy: "Software Engineering",
        startDate: "2023-09-01",
        endDate: null,
        current: true,
        grade: "",
        description: "Advanced study in software architecture, design patterns, and enterprise development.",
        activities: ["Research Assistant", "Graduate Student Association"],
        achievements: [],
        skills: ["System Architecture", "Design Patterns", "Cloud Computing", "DevOps"],
        location: "Tech City, USA",
        featured: true,
        isActive: true
      }
    ];
    
    const educationToMigrate = educationFromUser.length > 0 ? educationFromUser : defaultEducation;
    
    for (const [index, education] of educationToMigrate.entries()) {
      const educationDoc = new Education({
        title: education.title,
        institution: education.institution,
        degree: education.degree || '',
        fieldOfStudy: education.fieldOfStudy || '',
        startDate: education.startDate ? new Date(education.startDate) : new Date(),
        endDate: education.endDate ? new Date(education.endDate) : null,
        current: education.current || false,
        grade: education.grade || '',
        description: education.description || '',
        activities: education.activities || [],
        achievements: education.achievements || [],
        skills: education.skills || [],
        location: education.location || '',
        image: education.image || '',
        certificateUrl: education.certificateUrl || '',
        transcriptUrl: education.transcriptUrl || '',
        featured: education.featured || false,
        isActive: education.isActive !== false,
        slug: `${education.title}-${education.institution}`.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: index + 1
      });
      
      await educationDoc.save();
    }
    
    console.log(`✅ Migrated ${educationToMigrate.length} education records`);
  } catch (error) {
    console.error('❌ Error migrating education:', error);
  }
};

// Migrate Experience
const migrateExperience = async () => {
  try {
    console.log('🔄 Migrating experience...');
    
    // Clear existing experience
    await Experience.deleteMany({});
    
    // Get experience from user data if exists
    const experienceFromUser = userData.experienceData || [];
    
    // Default experience if none exist in user data
    const defaultExperience = [
      {
        title: "Senior Software Engineer",
        company: "Tech Solutions Inc.",
        location: "San Francisco, CA",
        startDate: "2020-03-01",
        endDate: null,
        current: true,
        employmentType: "Full-time",
        description: "Leading development of scalable web applications and mentoring junior developers.",
        responsibilities: [
          "Architecting and developing full-stack web applications using React and Node.js",
          "Leading a team of 4 developers and providing technical guidance",
          "Implementing CI/CD pipelines and DevOps best practices",
          "Collaborating with product managers and designers to deliver high-quality features"
        ],
        achievements: [
          "Increased application performance by 40% through optimization",
          "Reduced deployment time from 2 hours to 15 minutes with automated pipelines",
          "Successfully launched 3 major product features used by 100k+ users"
        ],
        skills: ["JavaScript", "React", "Node.js", "MongoDB", "AWS", "Docker", "Git"],
        technologies: ["React", "Express", "MongoDB", "Redis", "Docker", "AWS EC2/S3", "Jenkins"],
        industry: "Technology",
        featured: true,
        isActive: true
      },
      {
        title: "Full Stack Developer",
        company: "Digital Innovations Ltd.",
        location: "Austin, TX",
        startDate: "2018-06-01",
        endDate: "2020-02-28",
        current: false,
        employmentType: "Full-time",
        description: "Developed and maintained web applications for various clients across different industries.",
        responsibilities: [
          "Built responsive web applications using modern JavaScript frameworks",
          "Developed RESTful APIs and integrated with third-party services",
          "Collaborated with cross-functional teams to deliver projects on time",
          "Participated in code reviews and maintained coding standards"
        ],
        achievements: [
          "Delivered 15+ client projects with 100% client satisfaction",
          "Reduced bug reports by 60% through implementation of testing frameworks",
          "Mentored 2 junior developers"
        ],
        skills: ["JavaScript", "Vue.js", "PHP", "Laravel", "MySQL", "Git"],
        technologies: ["Vue.js", "Laravel", "MySQL", "Bootstrap", "jQuery", "Git"],
        industry: "Digital Agency",
        featured: true,
        isActive: true
      },
      {
        title: "Frontend Developer",
        company: "StartupXYZ",
        location: "Remote",
        startDate: "2017-01-01",
        endDate: "2018-05-31",
        current: false,
        employmentType: "Contract",
        description: "Focused on creating engaging user interfaces and improving user experience.",
        responsibilities: [
          "Developed responsive and interactive user interfaces",
          "Collaborated with UX/UI designers to implement pixel-perfect designs",
          "Optimized application performance and accessibility",
          "Maintained and updated existing codebase"
        ],
        achievements: [
          "Improved website loading speed by 50%",
          "Achieved 95+ scores on Google PageSpeed Insights",
          "Successfully completed 6-month contract ahead of schedule"
        ],
        skills: ["HTML5", "CSS3", "JavaScript", "React", "SASS", "Webpack"],
        technologies: ["React", "SASS", "Webpack", "Bootstrap", "jQuery"],
        industry: "Startup",
        featured: false,
        isActive: true
      },
      {
        title: "Web Developer Intern",
        company: "WebCorp Technologies",
        location: "New York, NY",
        startDate: "2016-06-01",
        endDate: "2016-12-31",
        current: false,
        employmentType: "Internship",
        description: "Gained hands-on experience in web development and learned industry best practices.",
        responsibilities: [
          "Assisted senior developers with various web development tasks",
          "Built small features and fixed bugs in existing applications",
          "Participated in daily standups and sprint planning meetings",
          "Learned version control with Git and agile development methodologies"
        ],
        achievements: [
          "Successfully completed 6-month internship program",
          "Received full-time job offer upon completion",
          "Contributed to 3 major projects during internship"
        ],
        skills: ["HTML", "CSS", "JavaScript", "PHP", "MySQL"],
        technologies: ["HTML5", "CSS3", "JavaScript", "PHP", "MySQL", "Git"],
        industry: "Technology",
        featured: false,
        isActive: true
      }
    ];
    
    const experienceToMigrate = experienceFromUser.length > 0 ? experienceFromUser : defaultExperience;
    
    for (const [index, experience] of experienceToMigrate.entries()) {
      const experienceDoc = new Experience({
        title: experience.title,
        company: experience.company,
        location: experience.location || '',
        startDate: experience.startDate ? new Date(experience.startDate) : new Date(),
        endDate: experience.endDate ? new Date(experience.endDate) : null,
        current: experience.current || false,
        employmentType: experience.employmentType || 'Full-time',
        description: experience.description || '',
        responsibilities: experience.responsibilities || [],
        achievements: experience.achievements || [],
        skills: experience.skills || [],
        technologies: experience.technologies || [],
        companyLogo: experience.companyLogo || '',
        companyWebsite: experience.companyWebsite || '',
        industry: experience.industry || '',
        featured: experience.featured || false,
        isActive: experience.isActive !== false,
        slug: `${experience.title}-${experience.company}`.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: index + 1
      });
      
      await experienceDoc.save();
    }
    
    console.log(`✅ Migrated ${experienceToMigrate.length} experience records`);
  } catch (error) {
    console.error('❌ Error migrating experience:', error);
  }
};

// Migrate Services
const migrateServices = async () => {
  try {
    console.log('🔄 Migrating services...');
    
    // Clear existing services
    await Service.deleteMany({});
    
    // Default services since there's no existing service data in user profile
    const defaultServices = [
      {
        title: "Web Development",
        description: "Building responsive and high-performance web applications using modern technologies.",
        shortDescription: "Custom web applications tailored to your business needs.",
        iconClass: "fas fa-code",
        category: "development",
        tag: "Development",
        number: 1,
        bgText: "Building scalable web solutions with modern technologies",
        technologies: ["React", "Node.js", "MongoDB", "JavaScript", "HTML5", "CSS3"],
        features: [
          "Responsive design for all devices",
          "SEO optimized structure",
          "Fast loading performance",
          "Modern UI/UX design",
          "Cross-browser compatibility"
        ],
        pricing: {
          startingPrice: 500,
          currency: "USD",
          pricingModel: "fixed"
        },
        deliveryTime: "2-4 weeks",
        processSteps: [
          { step: 1, title: "Planning", description: "Understanding requirements and project scope" },
          { step: 2, title: "Design", description: "Creating wireframes and UI/UX design" },
          { step: 3, title: "Development", description: "Coding and implementation" },
          { step: 4, title: "Testing", description: "Quality assurance and bug fixes" },
          { step: 5, title: "Deployment", description: "Launch and go-live" }
        ],
        featured: true,
        isActive: true,
        order: 1
      },
      {
        title: "Mobile App Development",
        description: "Creating user-friendly mobile applications for iOS and Android platforms.",
        shortDescription: "Native and cross-platform mobile apps.",
        iconClass: "fas fa-mobile-alt",
        category: "mobile",
        tag: "Mobile",
        number: 2,
        bgText: "Cross-platform mobile solutions for iOS and Android",
        technologies: ["React Native", "Flutter", "Swift", "Kotlin", "Firebase"],
        features: [
          "Cross-platform compatibility",
          "Native performance",
          "Offline functionality",
          "Push notifications",
          "App store optimization"
        ],
        pricing: {
          startingPrice: 1000,
          currency: "USD",
          pricingModel: "fixed"
        },
        deliveryTime: "6-12 weeks",
        processSteps: [
          { step: 1, title: "Concept", description: "App concept and feature planning" },
          { step: 2, title: "Design", description: "UI/UX design for mobile interfaces" },
          { step: 3, title: "Development", description: "Native app development" },
          { step: 4, title: "Testing", description: "Device testing and optimization" },
          { step: 5, title: "Publishing", description: "App store submission" }
        ],
        featured: true,
        isActive: true,
        order: 2
      },
      {
        title: "UI/UX Design",
        description: "Designing intuitive user interfaces and enhancing user experience for digital products.",
        shortDescription: "User-centered design for digital products.",
        iconClass: "fas fa-paint-brush",
        category: "design",
        tag: "Design",
        number: 3,
        bgText: "User-centered design solutions for digital products",
        technologies: ["Figma", "Adobe XD", "Sketch", "Photoshop", "Illustrator"],
        features: [
          "User research and analysis",
          "Wireframing and prototyping",
          "Visual design",
          "Usability testing",
          "Design system creation"
        ],
        pricing: {
          startingPrice: 300,
          currency: "USD",
          pricingModel: "fixed"
        },
        deliveryTime: "1-3 weeks",
        processSteps: [
          { step: 1, title: "Research", description: "User research and competitor analysis" },
          { step: 2, title: "Wireframing", description: "Creating wireframes and user flows" },
          { step: 3, title: "Design", description: "Visual design and prototyping" },
          { step: 4, title: "Testing", description: "Usability testing and feedback" },
          { step: 5, title: "Delivery", description: "Final design assets and documentation" }
        ],
        featured: false,
        isActive: true,
        order: 3
      },
      {
        title: "E-commerce Solutions",
        description: "Complete e-commerce platforms with payment integration and inventory management.",
        shortDescription: "Full-featured online stores and marketplaces.",
        iconClass: "fas fa-shopping-cart",
        category: "e-commerce",
        tag: "E-commerce",
        number: 4,
        bgText: "Complete online shopping solutions with secure payments",
        technologies: ["Shopify", "WooCommerce", "Magento", "Stripe", "PayPal"],
        features: [
          "Product catalog management",
          "Secure payment processing",
          "Inventory tracking",
          "Order management",
          "Analytics and reporting"
        ],
        pricing: {
          startingPrice: 800,
          currency: "USD",
          pricingModel: "fixed"
        },
        deliveryTime: "4-8 weeks",
        processSteps: [
          { step: 1, title: "Planning", description: "Store requirements and product catalog" },
          { step: 2, title: "Setup", description: "Platform setup and configuration" },
          { step: 3, title: "Design", description: "Store design and branding" },
          { step: 4, title: "Integration", description: "Payment and shipping integration" },
          { step: 5, title: "Launch", description: "Testing and store launch" }
        ],
        featured: true,
        isActive: true,
        order: 4
      },
      {
        title: "SEO & Digital Marketing",
        description: "Search engine optimization and digital marketing strategies to grow your online presence.",
        shortDescription: "Boost your online visibility and traffic.",
        iconClass: "fas fa-chart-line",
        category: "marketing",
        tag: "Marketing",
        number: 5,
        bgText: "Strategic digital marketing to boost your online presence",
        technologies: ["Google Analytics", "SEMrush", "Ahrefs", "Google Ads", "Facebook Ads"],
        features: [
          "Keyword research and optimization",
          "On-page and technical SEO",
          "Content marketing strategy",
          "Social media marketing",
          "Performance tracking"
        ],
        pricing: {
          startingPrice: 200,
          currency: "USD",
          pricingModel: "monthly"
        },
        deliveryTime: "Ongoing",
        processSteps: [
          { step: 1, title: "Audit", description: "Current website and SEO audit" },
          { step: 2, title: "Strategy", description: "SEO and marketing strategy development" },
          { step: 3, title: "Implementation", description: "On-page optimization and content" },
          { step: 4, title: "Monitoring", description: "Performance tracking and analysis" },
          { step: 5, title: "Optimization", description: "Continuous improvement and updates" }
        ],
        featured: false,
        isActive: true,
        order: 5
      },
      {
        title: "API Development",
        description: "Custom API development and third-party integrations for seamless data exchange.",
        shortDescription: "RESTful APIs and system integrations.",
        iconClass: "fas fa-plug",
        category: "backend",
        tag: "Backend",
        number: 6,
        bgText: "Robust API solutions for seamless system integrations",
        technologies: ["Node.js", "Express", "MongoDB", "PostgreSQL", "Redis"],
        features: [
          "RESTful API design",
          "Database integration",
          "Authentication and security",
          "API documentation",
          "Third-party integrations"
        ],
        pricing: {
          startingPrice: 400,
          currency: "USD",
          pricingModel: "fixed"
        },
        deliveryTime: "2-6 weeks",
        processSteps: [
          { step: 1, title: "Planning", description: "API requirements and endpoints design" },
          { step: 2, title: "Development", description: "API development and testing" },
          { step: 3, title: "Documentation", description: "API documentation and examples" },
          { step: 4, title: "Integration", description: "Testing with client applications" },
          { step: 5, title: "Deployment", description: "Production deployment and monitoring" }
        ],
        featured: false,
        isActive: true,
        order: 6
      }
    ];
    
    for (const [index, service] of defaultServices.entries()) {
      const serviceDoc = new Service({
        title: service.title,
        description: service.description,
        shortDescription: service.shortDescription,
        iconClass: service.iconClass,
        category: service.category,
        tag: service.tag || 'Service',
        number: service.number || index + 1,
        bgText: service.bgText || service.shortDescription,
        technologies: service.technologies || [],
        features: service.features || [],
        pricing: service.pricing,
        deliveryTime: service.deliveryTime,
        processSteps: service.processSteps || [],
        featured: service.featured || false,
        isActive: service.isActive !== false,
        slug: service.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: service.order || index + 1
      });
      
      await serviceDoc.save();
    }
    
    console.log(`✅ Migrated ${defaultServices.length} services`);
  } catch (error) {
    console.error('❌ Error migrating services:', error);
  }
};

// Migrate Characteristics
const migrateCharacteristics = async () => {
  try {
    console.log('🔄 Migrating characteristics...');
    
    // Clear existing characteristics
    await Characteristic.deleteMany({});
    
    for (const [index, characteristic] of characteristicsData.entries()) {
      // Transform data structure if needed
      const characteristicDoc = new Characteristic({
        title: characteristic.title || 'Untitled Characteristic',
        description: characteristic.description || '',
        shortDescription: characteristic.shortDescription || characteristic.description || '',
        icon: characteristic.icon || '',
        iconClass: characteristic.iconClass || '',
        image: characteristic.image || '',
        category: characteristic.category || 'personal',
        value: characteristic.value || 80,
        unit: characteristic.unit || '%',
        color: characteristic.color || '#007bff',
        link: characteristic.link || '',
        backTitle: characteristic.backTitle || characteristic.title,
        backDescription: characteristic.backDescription || characteristic.shortDescription || characteristic.description,
        tags: characteristic.tags || [],
        featured: characteristic.featured || false,
        isActive: characteristic.isActive !== false,
        slug: characteristic.slug || characteristic.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: characteristic.order || index + 1,
        seoTitle: characteristic.seoTitle || characteristic.title,
        seoDescription: characteristic.seoDescription || characteristic.shortDescription || characteristic.description,
        seoKeywords: characteristic.seoKeywords || []
      });
      
      await characteristicDoc.save();
    }
    
    console.log(`✅ Migrated ${characteristicsData.length} characteristics`);
  } catch (error) {
    console.error('❌ Error migrating characteristics:', error);
  }
};

// Main migration function
const runMigration = async () => {
  try {
    console.log('🚀 Starting data migration...');
    
    await connectDB();
    
    await migrateProjects();
    await migrateBlogs();
    await migrateUserData();
    await migrateTestimonials();
    await migrateCertificates();
    await migrateSkills();
    await migrateEducation();
    await migrateExperience();
    await migrateServices();
    await migrateCharacteristics();
    
    console.log('🎉 Migration completed successfully!');
    
    // Create backup of JSON files
    const backupDir = path.join(__dirname, '../data/backup');
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    fs.copyFileSync(
      path.join(__dirname, '../data/projectsData.json'),
      path.join(backupDir, `projectsData_${timestamp}.json`)
    );
    fs.copyFileSync(
      path.join(__dirname, '../data/blogsData.json'),
      path.join(backupDir, `blogsData_${timestamp}.json`)
    );
    fs.copyFileSync(
      path.join(__dirname, '../data/userData.json'),
      path.join(backupDir, `userData_${timestamp}.json`)
    );
    
    console.log('📦 JSON files backed up to data/backup/');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
};

// Run migration if this file is executed directly
if (require.main === module) {
  runMigration();
}

module.exports = {
  runMigration,
  migrateProjects,
  migrateBlogs,
  migrateUserData,
  migrateTestimonials,
  migrateCertificates,
  migrateSkills,
  migrateEducation,
  migrateExperience,
  migrateServices,
  migrateCharacteristics
};
