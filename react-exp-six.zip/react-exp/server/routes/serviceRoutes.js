const express = require('express');
const router = express.Router();
const {
  getAllServices,
  getServiceBySlug,
  createService,
  updateService,
  deleteService,
  toggleFeatured,
  toggleActive,
  updateServiceOrder,
  getServiceStats
} = require('../controllers/serviceController');

// Get service statistics
router.get('/stats', getServiceStats);

// Get all services
router.get('/', getAllServices);

// Get service by slug
router.get('/:slug', getServiceBySlug);

// Create new service
router.post('/', createService);

// Update service
router.put('/:slug', updateService);

// Delete service
router.delete('/:slug', deleteService);

// Toggle featured status
router.put('/:slug/toggle-featured', toggleFeatured);

// Toggle active status
router.put('/:slug/toggle-active', toggleActive);

// Update service order
router.put('/order/update', updateServiceOrder);

module.exports = router;
