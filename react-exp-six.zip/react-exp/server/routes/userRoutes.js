const express = require('express');
const router = express.Router();
const {
    getUserData,
    updateSection,
    addItem,
    updateItem,
    deleteItem
} = require('../controllers/userController');

// GET all user data
router.get('/', getUserData);

// UPDATE specific section (like /api/user/aboutData or /api/user/educationData)
router.put('/:section', updateSection);

// ADD new item to array sections (like /api/user/educationData/add)
router.post('/:section/add', addItem);

// UPDATE specific item in array sections (like /api/user/educationData/0)
router.put('/:section/:index', updateItem);

// DELETE specific item from array sections (like /api/user/educationData/0)
router.delete('/:section/:index', deleteItem);

module.exports = router;
