const express = require('express');
const router = express.Router();
const {
    getAllTestimonials,
    getTestimonialBySlug,
    createTestimonial,
    updateTestimonial,
    deleteTestimonial,
    updateTestimonialOrder
} = require('../controllers/testimonialController');

// GET all testimonials
router.get('/', getAllTestimonials);

// GET testimonial by slug
router.get('/:slug', getTestimonialBySlug);

// CREATE new testimonial
router.post('/', createTestimonial);

// UPDATE testimonial order (bulk update)
router.put('/order', updateTestimonialOrder);

// UPDATE testimonial by slug
router.put('/:slug', updateTestimonial);

// DELETE testimonial by slug (soft delete)
router.delete('/:slug', deleteTestimonial);

module.exports = router;
