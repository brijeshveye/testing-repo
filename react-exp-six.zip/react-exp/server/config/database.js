const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // MongoDB connection string - replace with your MongoDB URI
    const mongoURI = process.env.MONGODB_URI || 'mongodb+srv://sanjayveye:nsnGBIJHzrzkmZw6@cluster0.czkcxtw.mongodb.net/';
    
    const conn = await mongoose.connect(mongoURI);

    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error('Error connecting to MongoDB:', error.message);
    process.exit(1);
  }
};

module.exports = connectDB;
