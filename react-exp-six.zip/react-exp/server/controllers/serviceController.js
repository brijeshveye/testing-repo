const Service = require('../models/Service');

// Get all services
const getAllServices = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search,
      featured,
      isActive,
      category,
      sortBy = 'order',
      sortOrder = 'asc'
    } = req.query;

    // Build filter object
    const filter = {};
    
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { shortDescription: { $regex: search, $options: 'i' } },
        { category: { $regex: search, $options: 'i' } }
      ];
    }

    if (featured !== undefined) {
      filter.featured = featured === 'true';
    }

    if (isActive !== undefined) {
      filter.isActive = isActive === 'true';
    }

    if (category) {
      filter.category = { $regex: category, $options: 'i' };
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Add secondary sort by order for consistent ordering
    if (sortBy !== 'order') {
      sort.order = 1;
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const services = await Service.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limitNum);

    const total = await Service.countDocuments(filter);

    res.json({
      services,
      pagination: {
        currentPage: pageNum,
        totalPages: Math.ceil(total / limitNum),
        totalItems: total,
        itemsPerPage: limitNum
      }
    });
  } catch (error) {
    console.error('Error fetching services:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get service by slug
const getServiceBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { includeInactive } = req.query;
    
    // Build filter - for admin/edit, we might want to include inactive services
    const filter = { slug };
    if (!includeInactive || includeInactive !== 'true') {
      filter.isActive = true;
    }

    const service = await Service.findOne(filter);

    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    res.json(service);
  } catch (error) {
    console.error('Error fetching service by slug:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Create new service
const createService = async (req, res) => {
  try {
    const service = new Service(req.body);
    await service.save();
    res.status(201).json(service);
  } catch (error) {
    console.error('Error creating service:', error);
    res.status(400).json({ message: 'Error creating service', error: error.message });
  }
};

// Update service
const updateService = async (req, res) => {
  try {
    const { slug } = req.params;
    const service = await Service.findOneAndUpdate(
      { slug },
      req.body,
      { new: true, runValidators: true }
    );

    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    res.json(service);
  } catch (error) {
    console.error('Error updating service:', error);
    res.status(400).json({ message: 'Error updating service', error: error.message });
  }
};

// Delete service
const deleteService = async (req, res) => {
  try {
    const { slug } = req.params;
    const service = await Service.findOneAndDelete({ slug });

    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    res.json({ message: 'Service deleted successfully' });
  } catch (error) {
    console.error('Error deleting service:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Toggle featured status
const toggleFeatured = async (req, res) => {
  try {
    const { slug } = req.params;
    const service = await Service.findOne({ slug });

    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    service.featured = !service.featured;
    await service.save();

    res.json(service);
  } catch (error) {
    console.error('Error toggling featured status:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Toggle active status
const toggleActive = async (req, res) => {
  try {
    const { slug } = req.params;
    const service = await Service.findOne({ slug });

    if (!service) {
      return res.status(404).json({ message: 'Service not found' });
    }

    service.isActive = !service.isActive;
    await service.save();

    res.json(service);
  } catch (error) {
    console.error('Error toggling active status:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update service order
const updateServiceOrder = async (req, res) => {
  try {
    const { services } = req.body;

    // Update order for each service
    const updatePromises = services.map((service, index) => 
      Service.findByIdAndUpdate(service._id, { order: index })
    );

    await Promise.all(updatePromises);

    res.json({ message: 'Service order updated successfully' });
  } catch (error) {
    console.error('Error updating service order:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get service statistics
const getServiceStats = async (req, res) => {
  try {
    const totalServices = await Service.countDocuments();
    const activeServices = await Service.countDocuments({ isActive: true });
    const featuredServices = await Service.countDocuments({ featured: true });

    // Get category distribution
    const categories = await Service.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    // Get pricing model distribution
    const pricingModels = await Service.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$pricing.pricingModel', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      totalServices,
      activeServices,
      featuredServices,
      categories,
      pricingModels
    });
  } catch (error) {
    console.error('Error fetching service stats:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getAllServices,
  getServiceBySlug,
  createService,
  updateService,
  deleteService,
  toggleFeatured,
  toggleActive,
  updateServiceOrder,
  getServiceStats
};
