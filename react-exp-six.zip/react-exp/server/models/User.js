const mongoose = require('mongoose');

// Education Schema
const educationSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  institution: {
    type: String,
    required: true
  },
  year: {
    type: String,
    required: true
  },
  details: {
    type: String,
    default: ''
  }
}, { _id: false });

// Experience Schema
const experienceSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  company: {
    type: String,
    required: true
  },
  duration: {
    type: String,
    required: true
  },
  location: {
    type: String,
    default: ''
  },
  details: {
    type: String,
    default: ''
  }
}, { _id: false });

// Skill Schema
const skillSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  percentage: {
    type: Number,
    min: 0,
    max: 100,
    default: 0
  },
  category: {
    type: String,
    default: 'general'
  }
}, { _id: false });

// Certificate Schema
const certificateSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  issuer: {
    type: String,
    required: true
  },
  year: {
    type: String,
    required: true
  },
  image: {
    type: String,
    default: ''
  },
  url: {
    type: String,
    default: ''
  }
}, { _id: false });

// Testimonial Schema
const testimonialSchema = new mongoose.Schema({
  customerName: {
    type: String,
    required: true
  },
  customerFeedback: {
    type: String,
    required: true
  },
  customerImage: {
    type: String,
    default: ''
  },
  company: {
    type: String,
    default: ''
  },
  designation: {
    type: String,
    default: ''
  },
  rating: {
    type: Number,
    min: 1,
    max: 5,
    default: 5
  }
}, { _id: false });

// About Data Schema
const aboutDataSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    default: ''
  },
  bio: {
    type: String,
    default: ''
  },
  profileImage: {
    type: String,
    default: ''
  },
  location: {
    type: String,
    default: ''
  },
  resume: {
    type: String,
    default: ''
  }
}, { _id: false });

// Service Schema
const serviceSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  icon: {
    type: String,
    default: ''
  },
  image: {
    type: String,
    default: ''
  }
}, { _id: false });

// User Schema (Portfolio Owner)
const userSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true,
    default: 'portfolio_owner'
  },
  aboutData: {
    type: aboutDataSchema,
    default: {}
  },
  educationData: {
    type: [educationSchema],
    default: []
  },
  experienceData: {
    type: [experienceSchema],
    default: []
  },
  skillsData: {
    type: [skillSchema],
    default: []
  },
  certificatesData: {
    type: [certificateSchema],
    default: []
  },
  testimonialsData: {
    type: [testimonialSchema],
    default: []
  },
  servicesData: {
    type: [serviceSchema],
    default: []
  },
  socialLinks: {
    linkedin: { type: String, default: '' },
    github: { type: String, default: '' },
    twitter: { type: String, default: '' },
    instagram: { type: String, default: '' },
    facebook: { type: String, default: '' },
    website: { type: String, default: '' }
  }
}, {
  timestamps: true
});

// Index for the userId
userSchema.index({ userId: 1 });

module.exports = mongoose.model('User', userSchema);
