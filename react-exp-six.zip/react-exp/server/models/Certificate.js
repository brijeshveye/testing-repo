const mongoose = require('mongoose');

const certificateSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true
  },
  issuer: {
    type: String,
    required: true,
    trim: true
  },
  year: {
    type: String,
    required: true
  },
  image: {
    type: String,
    default: ''
  },
  url: {
    type: String,
    default: ''
  },
  category: {
    type: String,
    required: true,
    default: 'General'
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  featured: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  order: {
    type: Number,
    default: 0
  },
  credentialId: {
    type: String,
    default: ''
  },
  expiryDate: {
    type: Date,
    default: null
  },
  skills: [{
    type: String,
    trim: true
  }]
}, {
  timestamps: true
});

// Create slug from title before saving
certificateSchema.pre('save', function(next) {
  if (this.isModified('title') && !this.slug) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }
  next();
});

module.exports = mongoose.model('Certificate', certificateSchema);
