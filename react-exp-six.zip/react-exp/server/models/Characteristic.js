const mongoose = require('mongoose');

const characteristicSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  shortDescription: {
    type: String,
    trim: true
  },
  icon: {
    type: String,
    trim: true
  },
  iconClass: {
    type: String,
    trim: true
  },
  image: {
    type: String,
    trim: true
  },
  color: {
    type: String,
    default: '#007bff',
    trim: true
  },
  category: {
    type: String,
    trim: true,
    default: 'personal'
  },
  value: {
    type: Number,
    min: 0,
    max: 100,
    default: 85
  },
  unit: {
    type: String,
    trim: true,
    default: '%'
  },
  link: {
    type: String,
    trim: true
  },
  backTitle: {
    type: String,
    trim: true
  },
  backDescription: {
    type: String,
    trim: true
  },
  tags: [{
    type: String,
    trim: true
  }],
  featured: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  slug: {
    type: String,
    unique: true,
    trim: true
  },
  order: {
    type: Number,
    default: 0
  },
  seoTitle: {
    type: String,
    trim: true
  },
  seoDescription: {
    type: String,
    trim: true
  },
  seoKeywords: [{
    type: String,
    trim: true
  }]
}, {
  timestamps: true
});

// Create slug before saving
characteristicSchema.pre('save', function(next) {
  if (!this.slug && this.title) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }
  next();
});

// Create indexes
characteristicSchema.index({ slug: 1 });
characteristicSchema.index({ featured: 1, isActive: 1 });
characteristicSchema.index({ category: 1 });
characteristicSchema.index({ order: 1 });

module.exports = mongoose.model('Characteristic', characteristicSchema);
