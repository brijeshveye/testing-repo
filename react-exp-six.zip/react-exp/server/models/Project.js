const mongoose = require('mongoose');

// Widget Schema for dynamic content
const widgetSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['heading', 'paragraph', 'list', 'spacer', 'image', 'youtube']
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  }
}, { _id: false });

// Domain Schema for projects
const domainSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  url: {
    type: String,
    default: '#'
  }
}, { _id: false });

// Project details schema
const projectDetailsSchema = new mongoose.Schema({
  section1: {
    para1: String,
    para2: String
  },
  section2: {
    title: String,
    para: String,
    list: [String]
  },
  section3: {
    title: String,
    para: String
  },
  section4: {
    image1: String,
    image2: String
  }
}, { _id: false });

// Project Schema
const projectSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  bannerImage: {
    type: String,
    default: ''
  },
  image: {
    type: String,
    default: ''
  },
  date: {
    type: String,
    default: ''
  },
  location: {
    type: String,
    default: ''
  },
  client: {
    type: String,
    default: ''
  },
  type: {
    type: String,
    default: ''
  },
  category: {
    type: String,
    default: ''
  },
  techStack: {
    type: [String],
    default: []
  },
  domains: {
    type: [domainSchema],
    default: []
  },
  widgets: {
    type: [widgetSchema],
    default: []
  },
  details: {
    type: projectDetailsSchema,
    default: {}
  }
}, {
  timestamps: true
});

// Index for better search performance
projectSchema.index({ slug: 1 });
projectSchema.index({ category: 1 });
projectSchema.index({ title: 'text', description: 'text' });

module.exports = mongoose.model('Project', projectSchema);
