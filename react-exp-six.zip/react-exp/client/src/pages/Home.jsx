import React, { useEffect } from 'react'
import HeroSection from '../components/home/HeroSection'
import AboutSection from '../components/home/AboutSection'
import SkillsSection from '../components/home/SkillsSection'
import MyExperienceSection from '../components/home/MyExperienceSection'
import CharacteristicsSection from '../components/home/CharacteristicsSection'
import MarqueeSection from '../components/home/MarqueeSection'
import WhatIDoSection from '../components/home/WhatIDoSection'
import MyCertificatesSection from '../components/home/MyCertificatesSection'
import MyProjectsSection from '../components/home/MyProjectsSection'
import TestimonialSection from '../components/home/TestimonialsSection'
import BlogsSection from '../components/home/BlogsSection'
import ContactSection from '../components/home/ContactSection'
import MyEducationSection from '../components/home/MyEducationSection'

import AOS from 'aos';
import 'aos/dist/aos.css';

const Home = () => {
  useEffect(() => {
    AOS.init({
      once: true,
      easing: 'ease-in-out',
    });

  }, []);


  return (
    <>
      <main className='wrapper'>

        <HeroSection />

        <AboutSection />

        <SkillsSection />

        <MyExperienceSection />

        <CharacteristicsSection />

        <MyEducationSection />

        <MarqueeSection />

        <WhatIDoSection />

        <MyCertificatesSection />

        <MyProjectsSection />

        <TestimonialSection />

        <BlogsSection />

        <ContactSection />

      </main>
    </>
  )
}

export default Home