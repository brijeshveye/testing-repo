import React, { useEffect, useState } from 'react'
import BlogTopSection from '../components/blog/BlogTopSection'
import BlogSection from '../components/blog/BlogSection'
import UserDataApi from '../api/UserDataApi';
import { useParams } from 'react-router-dom';


const BlogDetails = () => {
  const [blogData, setBlogData] = useState({});

  const slug = useParams().slug;

  useEffect(() => {
    const fetchBlogDetails = async () => {
      try {
        const blog = await UserDataApi.getBlogDetails(slug);
        setBlogData(blog);
      } catch (error) {
        console.error('Error fetching blog details:', error);
        setBlogData({});
      }
    };

    if (slug) {
      fetchBlogDetails();
    }
  }, [slug]);

  return (
    <>
    <main className='wrapper'>
        <BlogTopSection blogData={blogData} />
        <BlogSection blogData={blogData} />
    </main>
    </>
  )
}

export default BlogDetails