import React from 'react'
import AllProjectsSection from '../components/all-projects/AllProjectsSection';

const AllProjects = () => {
    return (
        <main className='wrapper mt-5'>
            <AllProjectsSection />
        </main>
    )
}

export default AllProjects