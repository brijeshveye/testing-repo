import React from 'react'
import { Route, Routes } from "react-router-dom";
import Home from '../pages/Home';
import ServiceDetails from '../pages/ServiceDetails';
import ProjectDetails from '../pages/ProjectDetails';
import BlogDetails from '../pages/BlogDetails';
import AllBlogs from '../pages/AllBlogs';
import AllProjects from '../pages/AllProjects';
import AllCertificates from '../pages/AllCertificates';
import AllTestimonials from '../pages/AllTestimonials';
import AllSkills from '../pages/AllSkills';
import AllEducation from '../pages/AllEducation';
import AllExperience from '../pages/AllExperience';
import AllServices from '../pages/AllServices';
import AllCharacteristics from '../pages/AllCharacteristics';
import NotFound from '../pages/NotFound';

import ProjectList from '../admin/components/ProjectList';
import ProjectForm from '../admin/components/ProjectForm';

import BlogList from '../admin/components/BlogList';
import BlogForm from '../admin/components/BlogForm';

import TestimonialList from '../admin/components/TestimonialList';
import TestimonialForm from '../admin/components/TestimonialForm';

import CertificateList from '../admin/components/CertificateList';
import CertificateForm from '../admin/components/CertificateForm';

import SkillList from '../admin/components/SkillList';
import SkillForm from '../admin/components/SkillForm';

import EducationList from '../admin/components/EducationList';
import EducationForm from '../admin/components/EducationForm';

import ExperienceList from '../admin/components/ExperienceList';
import ExperienceForm from '../admin/components/ExperienceForm';

import ServiceList from '../admin/components/ServiceList';
import ServiceForm from '../admin/components/ServiceForm';

import CharacteristicList from '../admin/components/CharacteristicList';
import CharacteristicForm from '../admin/components/CharacteristicForm';

import UserDashboard from '../admin/components/UserDashboard';
import EditSectionForm from '../admin/components/EditSectionForm';
import AdminProtectedRoute from '../admin/components/AdminProtectedRoute';
import AdminDashboard from '../admin/components/AdminDashboard';
import ResumeUpload from '../admin/components/ResumeUploadSimple';

const AppRoutes = () => {
  return (
    <Routes>
        <Route path="/" element={ <Home /> } />

        <Route path="blogs" element={ <AllBlogs /> } />
        <Route path="certificates" element={ <AllCertificates /> } />
        <Route path="projects" element={ <AllProjects /> } />
        <Route path="testimonials" element={ <AllTestimonials /> } />
        <Route path="skills" element={ <AllSkills /> } />
        <Route path="education" element={ <AllEducation /> } />
        <Route path="experience" element={ <AllExperience /> } />
        <Route path="services" element={ <AllServices /> } />
        <Route path="characteristics" element={ <AllCharacteristics /> } />

      
        <Route path="blog/details/:slug" element={<BlogDetails />} />
        <Route path="project/details/:slug" element={<ProjectDetails />} />
        <Route path="service/details/:slug" element={<ServiceDetails />} />


        {/* Admin Routes - Protected */}
        <Route path="admin" element={
          <AdminProtectedRoute>
            <AdminDashboard />
          </AdminProtectedRoute>
        } />
        <Route path="admin/user" element={
          <AdminProtectedRoute>
            <UserDashboard />
          </AdminProtectedRoute>
        } />
        <Route path="admin/user/edit/:section" element={
          <AdminProtectedRoute>
            <EditSectionForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/user/upload-resume" element={
          <AdminProtectedRoute>
            <ResumeUpload />
          </AdminProtectedRoute>
        } />

        <Route path="admin/projects" element={
          <AdminProtectedRoute>
            <ProjectList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/projects/create" element={
          <AdminProtectedRoute>
            <ProjectForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/projects/edit/:slug" element={
          <AdminProtectedRoute>
            <ProjectForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/blogs" element={
          <AdminProtectedRoute>
            <BlogList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/blogs/create" element={
          <AdminProtectedRoute>
            <BlogForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/blogs/edit/:slug" element={
          <AdminProtectedRoute>
            <BlogForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/testimonials" element={
          <AdminProtectedRoute>
            <TestimonialList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/testimonials/create" element={
          <AdminProtectedRoute>
            <TestimonialForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/testimonials/edit/:slug" element={
          <AdminProtectedRoute>
            <TestimonialForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/certificates" element={
          <AdminProtectedRoute>
            <CertificateList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/certificates/create" element={
          <AdminProtectedRoute>
            <CertificateForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/certificates/edit/:slug" element={
          <AdminProtectedRoute>
            <CertificateForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/skills" element={
          <AdminProtectedRoute>
            <SkillList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/skills/create" element={
          <AdminProtectedRoute>
            <SkillForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/skills/edit/:slug" element={
          <AdminProtectedRoute>
            <SkillForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/education" element={
          <AdminProtectedRoute>
            <EducationList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/education/create" element={
          <AdminProtectedRoute>
            <EducationForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/education/edit/:slug" element={
          <AdminProtectedRoute>
            <EducationForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/experience" element={
          <AdminProtectedRoute>
            <ExperienceList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/experience/create" element={
          <AdminProtectedRoute>
            <ExperienceForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/experience/edit/:slug" element={
          <AdminProtectedRoute>
            <ExperienceForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/services" element={
          <AdminProtectedRoute>
            <ServiceList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/services/create" element={
          <AdminProtectedRoute>
            <ServiceForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/services/edit/:slug" element={
          <AdminProtectedRoute>
            <ServiceForm />
          </AdminProtectedRoute>
        } />

        <Route path="admin/characteristics" element={
          <AdminProtectedRoute>
            <CharacteristicList />
          </AdminProtectedRoute>
        } />
        <Route path="admin/characteristics/create" element={
          <AdminProtectedRoute>
            <CharacteristicForm />
          </AdminProtectedRoute>
        } />
        <Route path="admin/characteristics/edit/:slug" element={
          <AdminProtectedRoute>
            <CharacteristicForm />
          </AdminProtectedRoute>
        } />
        
        {/* 404 Not Found - Catch all route */}
        <Route path="*" element={<NotFound />} />
    </Routes>
  )
}

export default AppRoutes