import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';

const AdminNavBar = () => {
    const location = useLocation();
    const navigate = useNavigate();

    const handleLogout = () => {
        // Clear admin session/token
        localStorage.removeItem('adminToken');
        localStorage.removeItem('adminSession');
        navigate('/');
    };

    const isActive = (path) => {
        return location.pathname.includes(path) ? 'nav-link active' : 'nav-link';
    };

    return (
        <div className="pt-5">
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mt-5">
                <div className="container-fluid">
                    <Link className="navbar-brand" to="/admin">
                        <i className="fas fa-user-shield me-2"></i>
                        Admin Panel
                    </Link>

                    <button
                        className="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#adminNavbar"
                    >
                        <span className="navbar-toggler-icon"></span>
                    </button>

                    <div className="collapse navbar-collapse" id="adminNavbar">
                        <ul className="navbar-nav me-auto">
                            <li className="nav-item">
                                <Link className={isActive('/admin/user')} to="/admin/user">
                                    <i className="fas fa-user me-1"></i>
                                    User Profile
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className={isActive('/admin/projects')} to="/admin/projects">
                                    <i className="fas fa-project-diagram me-1"></i>
                                    Projects
                                </Link>
                            </li>
                            <li className="nav-item">
                                <Link className={isActive('/admin/blogs')} to="/admin/blogs">
                                    <i className="fas fa-blog me-1"></i>
                                    Blogs
                                </Link>
                            </li>
                        </ul>

                        <ul className="navbar-nav ms-auto">
                            <li className="nav-item dropdown">
                                <a
                                    className="nav-link dropdown-toggle"
                                    href="#"
                                    id="adminDropdown"
                                    role="button"
                                    data-bs-toggle="dropdown"
                                >
                                    <i className="fas fa-user-circle me-1"></i>
                                    Admin
                                </a>
                                <ul className="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <Link className="dropdown-item" to="/">
                                            <i className="fas fa-home me-2"></i>
                                            View Site
                                        </Link>
                                    </li>
                                    <li><hr className="dropdown-divider" /></li>
                                    <li>
                                        <button className="dropdown-item" onClick={handleLogout}>
                                            <i className="fas fa-sign-out-alt me-2"></i>
                                            Logout
                                        </button>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

    );
};

export default AdminNavBar;
