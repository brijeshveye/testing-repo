import React, { useState } from 'react';

// Widget Types
export const WIDGET_TYPES = {
  HEADING: 'heading',
  PARAGRAPH: 'paragraph',
  LIST: 'list',
  SPACER: 'spacer',
  IMAGE: 'image',
  YOUTUBE: 'youtube'
};

// Individual Widget Components
export const HeadingWidget = ({ data, onChange, onDelete, isEditing }) => {
  const [localData, setLocalData] = useState(data || { text: '', level: 'h2' });

  const handleChange = (field, value) => {
    const newData = { ...localData, [field]: value };
    setLocalData(newData);
    onChange(newData);
  };

  if (isEditing) {
    return (
      <div className="widget-editor p-3 border rounded mb-3">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="mb-0">📝 Heading Widget</h6>
          <button type="button" className="btn btn-sm btn-danger" onClick={onDelete}>
            <i className="fas fa-trash"></i>
          </button>
        </div>
        <div className="row">
          <div className="col-md-8">
            <input
              type="text"
              className="form-control"
              placeholder="Enter heading text"
              value={localData.text}
              onChange={(e) => handleChange('text', e.target.value)}
            />
          </div>
          <div className="col-md-4">
            <select
              className="form-select"
              value={localData.level}
              onChange={(e) => handleChange('level', e.target.value)}
            >
              <option value="h1">H1</option>
              <option value="h2">H2</option>
              <option value="h3">H3</option>
              <option value="h4">H4</option>
              <option value="h5">H5</option>
              <option value="h6">H6</option>
            </select>
          </div>
        </div>
      </div>
    );
  }

  const Tag = localData.level || 'h2';
  return <Tag className="dynamic-heading">{localData.text}</Tag>;
};

export const ParagraphWidget = ({ data, onChange, onDelete, isEditing }) => {
  const [localData, setLocalData] = useState(data || { text: '' });

  const handleChange = (value) => {
    const newData = { text: value };
    setLocalData(newData);
    onChange(newData);
  };

  if (isEditing) {
    return (
      <div className="widget-editor p-3 border rounded mb-3">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="mb-0">📄 Paragraph Widget</h6>
          <button type="button" className="btn btn-sm btn-danger" onClick={onDelete}>
            <i className="fas fa-trash"></i>
          </button>
        </div>
        <textarea
          className="form-control"
          rows="4"
          placeholder="Enter paragraph text"
          value={localData.text}
          onChange={(e) => handleChange(e.target.value)}
        />
      </div>
    );
  }

  return <p className="dynamic-paragraph">{localData.text}</p>;
};

export const ListWidget = ({ data, onChange, onDelete, isEditing }) => {
  const [localData, setLocalData] = useState(data || { items: [''], type: 'ul' });

  const handleChange = (field, value) => {
    const newData = { ...localData, [field]: value };
    setLocalData(newData);
    onChange(newData);
  };

  const addItem = () => {
    const newItems = [...localData.items, ''];
    handleChange('items', newItems);
  };

  const removeItem = (index) => {
    const newItems = localData.items.filter((_, i) => i !== index);
    handleChange('items', newItems);
  };

  const updateItem = (index, value) => {
    const newItems = [...localData.items];
    newItems[index] = value;
    handleChange('items', newItems);
  };

  if (isEditing) {
    return (
      <div className="widget-editor p-3 border rounded mb-3">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="mb-0">📋 List Widget</h6>
          <button type="button" className="btn btn-sm btn-danger" onClick={onDelete}>
            <i className="fas fa-trash"></i>
          </button>
        </div>
        <div className="mb-3">
          <select
            className="form-select"
            value={localData.type}
            onChange={(e) => handleChange('type', e.target.value)}
          >
            <option value="ul">Bulleted List</option>
            <option value="ol">Numbered List</option>
          </select>
        </div>
        {localData.items.map((item, index) => (
          <div key={index} className="d-flex mb-2">
            <input
              type="text"
              className="form-control me-2"
              placeholder={`Item ${index + 1}`}
              value={item}
              onChange={(e) => updateItem(index, e.target.value)}
            />
            <button
              type="button"
              className="btn btn-sm btn-outline-danger"
              onClick={() => removeItem(index)}
            >
              <i className="fas fa-minus"></i>
            </button>
          </div>
        ))}
        <button type="button" className="btn btn-sm btn-outline-primary" onClick={addItem}>
          <i className="fas fa-plus me-1"></i>Add Item
        </button>
      </div>
    );
  }

  const Tag = localData.type || 'ul';
  return (
    <Tag className="dynamic-list">
      {localData.items.filter(item => item.trim()).map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </Tag>
  );
};

export const SpacerWidget = ({ data, onChange, onDelete, isEditing }) => {
  const [localData, setLocalData] = useState(data || { height: 20 });

  const handleChange = (value) => {
    const newData = { height: parseInt(value) || 20 };
    setLocalData(newData);
    onChange(newData);
  };

  if (isEditing) {
    return (
      <div className="widget-editor p-3 border rounded mb-3">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="mb-0">📏 Spacer Widget</h6>
          <button type="button" className="btn btn-sm btn-danger" onClick={onDelete}>
            <i className="fas fa-trash"></i>
          </button>
        </div>
        <div className="row align-items-center">
          <div className="col-md-6">
            <label className="form-label">Height (px)</label>
            <input
              type="number"
              className="form-control"
              min="10"
              max="200"
              value={localData.height}
              onChange={(e) => handleChange(e.target.value)}
            />
          </div>
          <div className="col-md-6">
            <div 
              className="spacer-preview bg-light border"
              style={{ height: `${localData.height}px`, width: '100%' }}
            />
          </div>
        </div>
      </div>
    );
  }

  return <div className="dynamic-spacer" style={{ height: `${localData.height}px` }} />;
};

export const ImageWidget = ({ data, onChange, onDelete, isEditing, onImageUpload }) => {
  const [localData, setLocalData] = useState(data || { 
    src: '', 
    alt: '', 
    caption: '', 
    alignment: 'center',
    size: 'medium'
  });

  const handleChange = (field, value) => {
    const newData = { ...localData, [field]: value };
    setLocalData(newData);
    onChange(newData);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (file && onImageUpload) {
      try {
        const uploadedUrl = await onImageUpload(file, 'content');
        handleChange('src', uploadedUrl);
      } catch (error) {
        console.error('Image upload failed:', error);
      }
    }
  };

  if (isEditing) {
    return (
      <div className="widget-editor p-3 border rounded mb-3">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="mb-0">🖼️ Image Widget</h6>
          <button type="button" className="btn btn-sm btn-danger" onClick={onDelete}>
            <i className="fas fa-trash"></i>
          </button>
        </div>
        <div className="mb-3">
          <label className="form-label">Upload Image</label>
          <input
            type="file"
            className="form-control"
            accept="image/*"
            onChange={handleImageUpload}
          />
        </div>
        {localData.src && (
          <div className="mb-3">
            <img 
              src={localData.src} 
              alt="Preview" 
              className="img-thumbnail"
              style={{ maxHeight: '150px' }}
            />
          </div>
        )}
        <div className="row">
          <div className="col-md-6">
            <label className="form-label">Alt Text</label>
            <input
              type="text"
              className="form-control"
              placeholder="Image description"
              value={localData.alt}
              onChange={(e) => handleChange('alt', e.target.value)}
            />
          </div>
          <div className="col-md-6">
            <label className="form-label">Caption</label>
            <input
              type="text"
              className="form-control"
              placeholder="Image caption"
              value={localData.caption}
              onChange={(e) => handleChange('caption', e.target.value)}
            />
          </div>
        </div>
        <div className="row mt-3">
          <div className="col-md-6">
            <label className="form-label">Alignment</label>
            <select
              className="form-select"
              value={localData.alignment}
              onChange={(e) => handleChange('alignment', e.target.value)}
            >
              <option value="left">Left</option>
              <option value="center">Center</option>
              <option value="right">Right</option>
            </select>
          </div>
          <div className="col-md-6">
            <label className="form-label">Size</label>
            <select
              className="form-select"
              value={localData.size}
              onChange={(e) => handleChange('size', e.target.value)}
            >
              <option value="small">Small</option>
              <option value="medium">Medium</option>
              <option value="large">Large</option>
              <option value="full">Full Width</option>
            </select>
          </div>
        </div>
      </div>
    );
  }

  const sizeClasses = {
    small: 'w-25',
    medium: 'w-50',
    large: 'w-75',
    full: 'w-100'
  };

  const alignmentClasses = {
    left: 'text-start',
    center: 'text-center',
    right: 'text-end'
  };

  return (
    <div className={`dynamic-image ${alignmentClasses[localData.alignment]}`}>
      {localData.src && (
        <div className="d-inline-block">
          <img
            src={localData.src}
            alt={localData.alt}
            className={`img-fluid ${sizeClasses[localData.size]}`}
          />
          {localData.caption && (
            <div className="image-caption mt-2 text-muted small">
              {localData.caption}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export const YouTubeWidget = ({ data, onChange, onDelete, isEditing }) => {
  const [localData, setLocalData] = useState(data || { url: '', title: '' });

  const handleChange = (field, value) => {
    const newData = { ...localData, [field]: value };
    setLocalData(newData);
    onChange(newData);
  };

  const getYouTubeEmbedUrl = (url) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11
      ? `https://www.youtube.com/embed/${match[2]}`
      : '';
  };

  if (isEditing) {
    return (
      <div className="widget-editor p-3 border rounded mb-3">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h6 className="mb-0">📺 YouTube Widget</h6>
          <button type="button" className="btn btn-sm btn-danger" onClick={onDelete}>
            <i className="fas fa-trash"></i>
          </button>
        </div>
        <div className="mb-3">
          <label className="form-label">YouTube URL</label>
          <input
            type="url"
            className="form-control"
            placeholder="https://www.youtube.com/watch?v=..."
            value={localData.url}
            onChange={(e) => handleChange('url', e.target.value)}
          />
        </div>
        <div className="mb-3">
          <label className="form-label">Video Title (Optional)</label>
          <input
            type="text"
            className="form-control"
            placeholder="Video title"
            value={localData.title}
            onChange={(e) => handleChange('title', e.target.value)}
          />
        </div>
        {localData.url && getYouTubeEmbedUrl(localData.url) && (
          <div className="ratio ratio-16x9">
            <iframe
              src={getYouTubeEmbedUrl(localData.url)}
              title={localData.title || "YouTube video"}
              allowFullScreen
            />
          </div>
        )}
      </div>
    );
  }

  const embedUrl = getYouTubeEmbedUrl(localData.url);
  if (!embedUrl) return null;

  return (
    <div className="dynamic-youtube">
      {localData.title && <h5>{localData.title}</h5>}
      <div className="ratio ratio-16x9">
        <iframe
          src={embedUrl}
          title={localData.title || "YouTube video"}
          allowFullScreen
        />
      </div>
    </div>
  );
};
