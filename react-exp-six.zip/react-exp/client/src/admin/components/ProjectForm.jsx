import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import WidgetManager from './widgets/WidgetManager';
import { ImageUploader, uploadImage, IMAGE_CATEGORIES } from './ImageUpload';

const ProjectForm = () => {
  const [form, setForm] = useState({
    title: '',
    description: '',
    slug: '',
    date: '',
    location: '',
    client: '',
    type: '',
    category: '',
    bannerImage: '',
    image: '',
    techStack: [],
    domains: [],
    widgets: [], // Dynamic content widgets
    details: {
      section1: { para1: '', para2: '' },
      section2: { title: '', para: '', list: [] },
      section3: { title: '', para: '' },
      section4: { image1: '', image2: '' }
    }
  });
  const [activeTab, setActiveTab] = useState('basic');

  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = !!slug;

  useEffect(() => {
    if (isEdit) {
      axios.get(`/api/projects/${slug}`).then(res => setForm(res.data));
    }
  }, [slug]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleWidgetsChange = (widgets) => {
    setForm(prev => ({ ...prev, widgets }));
  };

  const handleImageUpload = async (file, category) => {
    try {
      return await uploadImage(file, category);
    } catch (error) {
      alert('Image upload failed: ' + error.message);
      throw error;
    }
  };

  const handleBannerImageUpload = (url) => {
    setForm(prev => ({ ...prev, bannerImage: url }));
  };

  const handleMainImageUpload = (url) => {
    setForm(prev => ({ ...prev, image: url }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isEdit) {
      await axios.put(`/api/projects/${slug}`, form);
    } else {
      await axios.post('/api/projects', form);
    }
    navigate('/admin/projects');
  };

  return (
    <div className="container mt-4">
      <h2>{isEdit ? 'Edit Project' : 'Create Project'}</h2>
      
      {/* Tab Navigation */}
      <ul className="nav nav-tabs mb-4">
        <li className="nav-item">
          <button 
            type="button"
            className={`nav-link ${activeTab === 'basic' ? 'active' : ''}`}
            onClick={() => setActiveTab('basic')}
          >
            Basic Info
          </button>
        </li>
        <li className="nav-item">
          <button 
            type="button"
            className={`nav-link ${activeTab === 'images' ? 'active' : ''}`}
            onClick={() => setActiveTab('images')}
          >
            Images
          </button>
        </li>
        <li className="nav-item">
          <button 
            type="button"
            className={`nav-link ${activeTab === 'content' ? 'active' : ''}`}
            onClick={() => setActiveTab('content')}
          >
            Dynamic Content
          </button>
        </li>
      </ul>

      <form onSubmit={handleSubmit}>
        {/* Basic Info Tab */}
        {activeTab === 'basic' && (
          <div>
            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Title *</label>
                  <input 
                    className="form-control" 
                    name="title" 
                    value={form.title} 
                    onChange={handleChange} 
                    required 
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Slug *</label>
                  <input 
                    className="form-control" 
                    name="slug" 
                    value={form.slug} 
                    onChange={handleChange} 
                    required={!isEdit} 
                    disabled={isEdit}
                    placeholder="url-friendly-name"
                  />
                </div>
              </div>
            </div>
            
            <div className="mb-3">
              <label className="form-label">Description</label>
              <textarea 
                className="form-control" 
                name="description" 
                value={form.description} 
                onChange={handleChange}
                rows="3"
              />
            </div>
            
            <div className="row">
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Date</label>
                  <input 
                    type="date" 
                    className="form-control" 
                    name="date" 
                    value={form.date} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Client</label>
                  <input 
                    className="form-control" 
                    name="client" 
                    value={form.client} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Location</label>
                  <input 
                    className="form-control" 
                    name="location" 
                    value={form.location} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
            </div>
            
            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Category</label>
                  <input 
                    className="form-control" 
                    name="category" 
                    value={form.category} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Type</label>
                  <input 
                    className="form-control" 
                    name="type" 
                    value={form.type} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Images Tab */}
        {activeTab === 'images' && (
          <div>
            <div className="row">
              <div className="col-md-6">
                <div className="mb-4">
                  <label className="form-label">Banner Image</label>
                  {form.bannerImage && (
                    <div className="mb-2">
                      <img 
                        src={form.bannerImage} 
                        alt="Banner preview" 
                        className="img-thumbnail"
                        style={{ maxHeight: '200px' }}
                      />
                    </div>
                  )}
                  <ImageUploader
                    onUpload={handleBannerImageUpload}
                    category={IMAGE_CATEGORIES.BANNER}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-4">
                  <label className="form-label">Main Project Image</label>
                  {form.image && (
                    <div className="mb-2">
                      <img 
                        src={form.image} 
                        alt="Main image preview" 
                        className="img-thumbnail"
                        style={{ maxHeight: '200px' }}
                      />
                    </div>
                  )}
                  <ImageUploader
                    onUpload={handleMainImageUpload}
                    category={IMAGE_CATEGORIES.PROJECT}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic Content Tab */}
        {activeTab === 'content' && (
          <div>
            <WidgetManager
              widgets={form.widgets}
              onChange={handleWidgetsChange}
              onImageUpload={handleImageUpload}
            />
          </div>
        )}

        <div className="d-flex justify-content-between mt-4">
          <button 
            type="button" 
            className="btn btn-secondary"
            onClick={() => navigate('/admin/projects')}
          >
            Cancel
          </button>
          <button 
            type="submit" 
            className="btn btn-success"
          >
            {isEdit ? 'Update Project' : 'Create Project'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProjectForm;
