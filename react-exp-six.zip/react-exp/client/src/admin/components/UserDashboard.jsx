import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const UserDashboard = () => {
  const [userData, setUserData] = useState(null);

  const fetchUserData = async () => {
    const res = await axios.get('/api/user');
    setUserData(res.data);
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  if (!userData) return <div className="container mt-5">Loading...</div>;

  return (
    <div className="container mt-4 mb-2">
      <h2>User Profile Dashboard</h2>

      {/* About Section */}
      {
        userData.aboutData && (
          <section className="mb-4">
            <h4>About</h4>
            <p><strong>Name:</strong> {userData.aboutData.name}</p>
            <p><strong>Email:</strong> {userData.aboutData.email}</p>
            <p><strong>Bio:</strong> {userData.aboutData.bio}</p>
            <Link to="/admin/user/edit/aboutData" className="btn btn-sm btn-warning">Edit</Link>
          </section>
        )
      }

      {/* Social Media Section */}
      {
        userData.socialLinks && (
          <section className="mb-4">
            <h4>Social Media</h4>
            <div className="row">
              {userData.socialLinks.linkedin && (
                <div className="col-md-6">
                  <p><strong>LinkedIn:</strong> <a href={userData.socialLinks.linkedin} target="_blank" rel="noopener noreferrer">{userData.socialLinks.linkedin}</a></p>
                </div>
              )}
              {userData.socialLinks.github && (
                <div className="col-md-6">
                  <p><strong>GitHub:</strong> <a href={userData.socialLinks.github} target="_blank" rel="noopener noreferrer">{userData.socialLinks.github}</a></p>
                </div>
              )}
              {userData.socialLinks.twitter && (
                <div className="col-md-6">
                  <p><strong>Twitter:</strong> <a href={userData.socialLinks.twitter} target="_blank" rel="noopener noreferrer">{userData.socialLinks.twitter}</a></p>
                </div>
              )}
              {userData.socialLinks.instagram && (
                <div className="col-md-6">
                  <p><strong>Instagram:</strong> <a href={userData.socialLinks.instagram} target="_blank" rel="noopener noreferrer">{userData.socialLinks.instagram}</a></p>
                </div>
              )}
              {userData.socialLinks.facebook && (
                <div className="col-md-6">
                  <p><strong>Facebook:</strong> <a href={userData.socialLinks.facebook} target="_blank" rel="noopener noreferrer">{userData.socialLinks.facebook}</a></p>
                </div>
              )}
              {userData.socialLinks.website && (
                <div className="col-md-6">
                  <p><strong>Website:</strong> <a href={userData.socialLinks.website} target="_blank" rel="noopener noreferrer">{userData.socialLinks.website}</a></p>
                </div>
              )}
            </div>
            <Link to="/admin/user/edit/socialLinks" className="btn btn-sm btn-warning">Edit Social Media</Link>
          </section>
        )
      }

      {/* Resume Section */}
      {
        userData.aboutData && (
          <section className="mb-4">
            <h4>Resume/CV</h4>
            {userData.aboutData.resume ? (
              <div>
                <p><strong>Current Resume:</strong> <a href={userData.aboutData.resume} target="_blank" rel="noopener noreferrer">View Resume</a></p>
                <small className="text-muted">Upload a new resume to replace the current one</small>
              </div>
            ) : (
              <p className="text-muted">No resume uploaded yet</p>
            )}
            <Link to="/admin/user/upload-resume" className="btn btn-sm btn-success mt-2">Upload Resume</Link>
          </section>
        )
      }

    </div>

  );
};

export default UserDashboard;
