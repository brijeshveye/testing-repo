import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import WidgetManager from './widgets/WidgetManager';
import { ImageUploader, uploadImage, IMAGE_CATEGORIES } from './ImageUpload';

const BlogForm = () => {
  const [form, setForm] = useState({
    title: '',
    description: '',
    slug: '',
    bannerImage: '',
    image: '',
    date: '',
    author: '',
    category: '',
    tags: [],
    widgets: [], // Dynamic content widgets
    details: {
      section1: { para1: '', para2: '' },
      section2: { quote: '', author: '' },
      section3: { para: '' },
      section4: { title: '', image1: '', para1: '', para2: '', list: [] }
    }
  });
  const [activeTab, setActiveTab] = useState('basic');

  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = !!slug;

  useEffect(() => {
    if (isEdit) {
      axios.get(`/api/blogs/${slug}`).then(res => setForm(res.data));
    }
  }, [slug]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleWidgetsChange = (widgets) => {
    setForm(prev => ({ ...prev, widgets }));
  };

  const handleImageUpload = async (file, category) => {
    try {
      return await uploadImage(file, category);
    } catch (error) {
      alert('Image upload failed: ' + error.message);
      throw error;
    }
  };

  const handleBannerImageUpload = (url) => {
    setForm(prev => ({ ...prev, bannerImage: url }));
  };

  const handleMainImageUpload = (url) => {
    setForm(prev => ({ ...prev, image: url }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isEdit) {
      await axios.put(`/api/blogs/${slug}`, form);
    } else {
      await axios.post('/api/blogs', form);
    }
    navigate('/admin/blogs');
  };

  return (
    <div className="container mt-4">
      <h2>{isEdit ? 'Edit Blog' : 'Create Blog'}</h2>
      
      {/* Tab Navigation */}
      <ul className="nav nav-tabs mb-4">
        <li className="nav-item">
          <button 
            type="button"
            className={`nav-link ${activeTab === 'basic' ? 'active' : ''}`}
            onClick={() => setActiveTab('basic')}
          >
            Basic Info
          </button>
        </li>
        <li className="nav-item">
          <button 
            type="button"
            className={`nav-link ${activeTab === 'images' ? 'active' : ''}`}
            onClick={() => setActiveTab('images')}
          >
            Images
          </button>
        </li>
        <li className="nav-item">
          <button 
            type="button"
            className={`nav-link ${activeTab === 'content' ? 'active' : ''}`}
            onClick={() => setActiveTab('content')}
          >
            Dynamic Content
          </button>
        </li>
      </ul>

      <form onSubmit={handleSubmit}>
        {/* Basic Info Tab */}
        {activeTab === 'basic' && (
          <div>
            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Title *</label>
                  <input 
                    className="form-control" 
                    name="title" 
                    value={form.title} 
                    onChange={handleChange} 
                    required 
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Slug *</label>
                  <input 
                    className="form-control" 
                    name="slug" 
                    value={form.slug} 
                    onChange={handleChange} 
                    required={!isEdit} 
                    disabled={isEdit} 
                    placeholder="url-friendly-name"
                  />
                </div>
              </div>
            </div>
            
            <div className="mb-3">
              <label className="form-label">Description</label>
              <textarea 
                className="form-control" 
                name="description" 
                value={form.description} 
                onChange={handleChange}
                rows="3"
              />
            </div>
            
            <div className="row">
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Author</label>
                  <input 
                    className="form-control" 
                    name="author" 
                    value={form.author} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Date</label>
                  <input 
                    type="date" 
                    className="form-control" 
                    name="date" 
                    value={form.date} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Category</label>
                  <input 
                    className="form-control" 
                    name="category" 
                    value={form.category} 
                    onChange={handleChange} 
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Images Tab */}
        {activeTab === 'images' && (
          <div>
            <div className="row">
              <div className="col-md-6">
                <div className="mb-4">
                  <label className="form-label">Banner Image</label>
                  {form.bannerImage && (
                    <div className="mb-2">
                      <img 
                        src={form.bannerImage} 
                        alt="Banner preview" 
                        className="img-thumbnail"
                        style={{ maxHeight: '200px' }}
                      />
                    </div>
                  )}
                  <ImageUploader
                    onUpload={handleBannerImageUpload}
                    category={IMAGE_CATEGORIES.BANNER}
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-4">
                  <label className="form-label">Featured Image</label>
                  {form.image && (
                    <div className="mb-2">
                      <img 
                        src={form.image} 
                        alt="Featured image preview" 
                        className="img-thumbnail"
                        style={{ maxHeight: '200px' }}
                      />
                    </div>
                  )}
                  <ImageUploader
                    onUpload={handleMainImageUpload}
                    category={IMAGE_CATEGORIES.BLOG}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Dynamic Content Tab */}
        {activeTab === 'content' && (
          <div>
            <WidgetManager
              widgets={form.widgets}
              onChange={handleWidgetsChange}
              onImageUpload={handleImageUpload}
            />
          </div>
        )}

        <div className="d-flex justify-content-between mt-4">
          <button 
            type="button" 
            className="btn btn-secondary"
            onClick={() => navigate('/admin/blogs')}
          >
            Cancel
          </button>
          <button 
            type="submit" 
            className="btn btn-success"
          >
            {isEdit ? 'Update Blog' : 'Create Blog'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default BlogForm;
