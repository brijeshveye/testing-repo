import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createService, getService, updateService } from '../../api/ServiceDataApi';

const ServiceForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDescription: '',
    icon: '',
    iconClass: '',
    image: '',
    category: 'general',
    technologies: [],
    features: [],
    pricing: {
      startingPrice: 0,
      currency: 'USD',
      pricingModel: 'custom'
    },
    deliveryTime: '',
    processSteps: [],
    featured: false,
    isActive: true,
    seoTitle: '',
    seoDescription: '',
    seoKeywords: []
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEdit) {
      fetchService();
    }
  }, [slug, isEdit]);

  const fetchService = async () => {
    try {
      setLoading(true);
      const response = await getService(slug, true);
      if (response.success) {
        const serviceData = response.data;
        setFormData({
          title: serviceData.title || '',
          description: serviceData.description || '',
          shortDescription: serviceData.shortDescription || '',
          icon: serviceData.icon || '',
          iconClass: serviceData.iconClass || '',
          image: serviceData.image || '',
          category: serviceData.category || 'general',
          technologies: serviceData.technologies || [],
          features: serviceData.features || [],
          pricing: {
            startingPrice: serviceData.pricing?.startingPrice || 0,
            currency: serviceData.pricing?.currency || 'USD',
            pricingModel: serviceData.pricing?.pricingModel || 'custom'
          },
          deliveryTime: serviceData.deliveryTime || '',
          processSteps: serviceData.processSteps || [],
          featured: serviceData.featured || false,
          isActive: serviceData.isActive !== false,
          seoTitle: serviceData.seoTitle || '',
          seoDescription: serviceData.seoDescription || '',
          seoKeywords: serviceData.seoKeywords || []
        });
      } else {
        setErrors({ general: response.message || 'Failed to fetch service details' });
      }
    } catch (error) {
      console.error('Error fetching service:', error);
      setErrors({ general: 'Failed to fetch service details' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) : value)
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }
  };

  const handleArrayChange = (field, index, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => i === index ? value : item)
    }));
  };

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], '']
    }));
  };

  const removeArrayItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleTechnologiesChange = (e) => {
    const technologies = e.target.value.split(',').map(tech => tech.trim()).filter(tech => tech);
    setFormData(prev => ({ ...prev, technologies }));
  };

  const handleSeoKeywordsChange = (e) => {
    const seoKeywords = e.target.value.split(',').map(keyword => keyword.trim()).filter(keyword => keyword);
    setFormData(prev => ({ ...prev, seoKeywords }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (formData.pricing.startingPrice < 0) {
      newErrors['pricing.startingPrice'] = 'Price cannot be negative';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      let response;

      if (isEdit) {
        response = await updateService(slug, formData);
      } else {
        response = await createService(formData);
      }

      if (response.success) {
        navigate('/admin/services');
      } else {
        setErrors({ general: response.message || 'Failed to save service' });
      }
    } catch (error) {
      console.error('Error saving service:', error);
      setErrors({ general: 'Failed to save service. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">
                {isEdit ? 'Edit Service' : 'Create New Service'}
              </h5>
            </div>
            <div className="card-body">
              {errors.general && (
                <div className="alert alert-danger" role="alert">
                  {errors.general}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                {/* Basic Information */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Basic Information</h6>
                  
                  <div className="mb-3">
                    <label htmlFor="title" className="form-label">Title *</label>
                    <input
                      type="text"
                      className={`form-control ${errors.title ? 'is-invalid' : ''}`}
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      required
                    />
                    {errors.title && <div className="invalid-feedback">{errors.title}</div>}
                  </div>

                  <div className="mb-3">
                    <label htmlFor="description" className="form-label">Description *</label>
                    <textarea
                      className={`form-control ${errors.description ? 'is-invalid' : ''}`}
                      id="description"
                      name="description"
                      rows="4"
                      value={formData.description}
                      onChange={handleChange}
                      required
                    />
                    {errors.description && <div className="invalid-feedback">{errors.description}</div>}
                  </div>

                  <div className="mb-3">
                    <label htmlFor="shortDescription" className="form-label">Short Description</label>
                    <textarea
                      className="form-control"
                      id="shortDescription"
                      name="shortDescription"
                      rows="2"
                      value={formData.shortDescription}
                      onChange={handleChange}
                      placeholder="Brief summary of the service..."
                    />
                  </div>

                  <div className="row">
                    <div className="col-md-6">
                      <label htmlFor="iconClass" className="form-label">Icon Class</label>
                      <input
                        type="text"
                        className="form-control"
                        id="iconClass"
                        name="iconClass"
                        value={formData.iconClass}
                        onChange={handleChange}
                        placeholder="e.g., fas fa-code"
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="category" className="form-label">Category</label>
                      <select
                        className="form-select"
                        id="category"
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                      >
                        <option value="general">General</option>
                        <option value="development">Development</option>
                        <option value="design">Design</option>
                        <option value="consulting">Consulting</option>
                        <option value="marketing">Marketing</option>
                      </select>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label htmlFor="deliveryTime" className="form-label">Delivery Time</label>
                    <input
                      type="text"
                      className="form-control"
                      id="deliveryTime"
                      name="deliveryTime"
                      value={formData.deliveryTime}
                      onChange={handleChange}
                      placeholder="e.g., 2-3 weeks"
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="technologies" className="form-label">Technologies (comma-separated)</label>
                    <input
                      type="text"
                      className="form-control"
                      id="technologies"
                      value={(formData.technologies || []).join(', ')}
                      onChange={handleTechnologiesChange}
                      placeholder="React, Node.js, MongoDB"
                    />
                  </div>

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="featured"
                      name="featured"
                      checked={formData.featured}
                      onChange={handleChange}
                    />
                    <label className="form-check-label" htmlFor="featured">
                      Featured Service
                    </label>
                  </div>

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="isActive"
                      name="isActive"
                      checked={formData.isActive}
                      onChange={handleChange}
                    />
                    <label className="form-check-label" htmlFor="isActive">
                      Active
                    </label>
                  </div>
                </div>

                {/* Features */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Features</h6>
                  
                  {(formData.features || []).map((feature, index) => (
                    <div key={index} className="input-group mb-2">
                      <input
                        type="text"
                        className="form-control"
                        value={feature}
                        onChange={(e) => handleArrayChange('features', index, e.target.value)}
                        placeholder="Service feature..."
                      />
                      <button
                        type="button"
                        className="btn btn-outline-danger"
                        onClick={() => removeArrayItem('features', index)}
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    className="btn btn-outline-primary btn-sm"
                    onClick={() => addArrayItem('features')}
                  >
                    Add Feature
                  </button>
                </div>

                {/* Pricing */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Pricing</h6>
                  
                  <div className="row">
                    <div className="col-md-4">
                      <label htmlFor="pricing.pricingModel" className="form-label">Pricing Model</label>
                      <select
                        className="form-select"
                        id="pricing.pricingModel"
                        name="pricing.pricingModel"
                        value={formData.pricing.pricingModel}
                        onChange={handleChange}
                      >
                        <option value="custom">Custom</option>
                        <option value="fixed">Fixed Price</option>
                        <option value="hourly">Hourly Rate</option>
                        <option value="monthly">Monthly</option>
                      </select>
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="pricing.startingPrice" className="form-label">Starting Price</label>
                      <input
                        type="number"
                        className={`form-control ${errors['pricing.startingPrice'] ? 'is-invalid' : ''}`}
                        id="pricing.startingPrice"
                        name="pricing.startingPrice"
                        value={formData.pricing.startingPrice}
                        onChange={handleChange}
                        min="0"
                        step="0.01"
                      />
                      {errors['pricing.startingPrice'] && <div className="invalid-feedback">{errors['pricing.startingPrice']}</div>}
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="pricing.currency" className="form-label">Currency</label>
                      <select
                        className="form-select"
                        id="pricing.currency"
                        name="pricing.currency"
                        value={formData.pricing.currency}
                        onChange={handleChange}
                      >
                        <option value="USD">USD</option>
                        <option value="EUR">EUR</option>
                        <option value="GBP">GBP</option>
                        <option value="CAD">CAD</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* SEO */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">SEO (Optional)</h6>
                  
                  <div className="mb-3">
                    <label htmlFor="seoTitle" className="form-label">SEO Title</label>
                    <input
                      type="text"
                      className="form-control"
                      id="seoTitle"
                      name="seoTitle"
                      value={formData.seoTitle}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="seoDescription" className="form-label">SEO Description</label>
                    <textarea
                      className="form-control"
                      id="seoDescription"
                      name="seoDescription"
                      rows="2"
                      value={formData.seoDescription}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="seoKeywords" className="form-label">SEO Keywords (comma-separated)</label>
                    <input
                      type="text"
                      className="form-control"
                      id="seoKeywords"
                      value={(formData.seoKeywords || []).join(', ')}
                      onChange={handleSeoKeywordsChange}
                      placeholder="web development, services, consulting"
                    />
                  </div>
                </div>

                {/* Form Actions */}
                <div className="d-flex justify-content-between">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/services')}
                    disabled={loading}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        {isEdit ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      isEdit ? 'Update Service' : 'Create Service'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">Preview</h5>
            </div>
            <div className="card-body">
              <div className="service-preview">
                <div className="text-center mb-3">
                  <div 
                    className="d-inline-flex align-items-center justify-content-center rounded-circle"
                    style={{ 
                      width: '80px', 
                      height: '80px', 
                      backgroundColor: '#007bff',
                      color: 'white'
                    }}
                  >
                    {formData.iconClass ? (
                      <i className={`${formData.iconClass} fa-2x`}></i>
                    ) : (
                      <i className="fas fa-cogs fa-2x"></i>
                    )}
                  </div>
                </div>

                <h6 className="mb-2 text-center">{formData.title || 'Service Title'}</h6>
                <p className="text-muted small mb-3 text-center">
                  {formData.shortDescription || formData.description || 'Service description will appear here...'}
                </p>

                {formData.pricing.startingPrice > 0 && (
                  <div className="text-center mb-3">
                    <span className="h5 text-primary">
                      {formData.pricing.currency} {formData.pricing.startingPrice}
                      {formData.pricing.pricingModel === 'hourly' && '/hr'}
                      {formData.pricing.pricingModel === 'monthly' && '/month'}
                    </span>
                    <div className="small text-muted">{formData.pricing.pricingModel}</div>
                  </div>
                )}

                {formData.deliveryTime && (
                  <div className="text-center mb-3">
                    <small className="text-muted">
                      <i className="fas fa-clock me-1"></i>
                      {formData.deliveryTime}
                    </small>
                  </div>
                )}

                {(formData.technologies || []).length > 0 && (
                  <div className="mb-3">
                    <small className="text-muted d-block mb-1">
                      <strong>Technologies:</strong>
                    </small>
                    <div className="d-flex flex-wrap gap-1">
                      {(formData.technologies || []).slice(0, 3).map((tech, index) => (
                        <span key={index} className="badge bg-light text-dark">
                          {tech}
                        </span>
                      ))}
                      {(formData.technologies || []).length > 3 && (
                        <span className="badge bg-light text-muted">
                          +{(formData.technologies || []).length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {(formData.features || []).length > 0 && (
                  <div className="mb-3">
                    <small className="text-muted d-block mb-1">
                      <strong>Features:</strong>
                    </small>
                    <ul className="list-unstyled small">
                      {(formData.features || []).slice(0, 3).map((feature, index) => (
                        <li key={index} className="mb-1">
                          <i className="fas fa-check text-success me-2"></i>
                          {feature || 'Feature description'}
                        </li>
                      ))}
                      {(formData.features || []).length > 3 && (
                        <li className="text-muted">
                          +{(formData.features || []).length - 3} more features
                        </li>
                      )}
                    </ul>
                  </div>
                )}

                <div className="d-flex justify-content-center gap-2">
                  {formData.featured && (
                    <span className="badge bg-warning text-dark">
                      <i className="fas fa-star me-1"></i>Featured
                    </span>
                  )}
                  <span className={`badge ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                    {formData.isActive ? 'Active' : 'Inactive'}
                  </span>
                  <span className="badge bg-info">
                    {formData.category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceForm;
