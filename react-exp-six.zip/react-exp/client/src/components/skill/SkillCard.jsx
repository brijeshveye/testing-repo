import React from 'react';

const SkillCard = ({ skill, showDetails = true }) => {
  const {
    title,
    description,
    icon = 'fas fa-code',
    color = '#007bff',
    percentage = 50,
    category,
    level,
    yearsOfExperience,
    featured,
    relatedSkills = [],
    projects = [],
    certifications = []
  } = skill;

  const getPercentageColor = (percentage) => {
    if (percentage >= 90) return '#28a745'; // success
    if (percentage >= 70) return '#17a2b8'; // info
    if (percentage >= 50) return '#ffc107'; // warning
    return '#dc3545'; // danger
  };

  const getLevelBadgeColor = (level) => {
    switch (level) {
      case 'Expert': return 'bg-success';
      case 'Advanced': return 'bg-info';
      case 'Intermediate': return 'bg-warning text-dark';
      case 'Beginner': return 'bg-secondary';
      default: return 'bg-primary';
    }
  };

  return (
    <div className={`card h-100 ${featured ? 'border-warning' : ''}`}>
      {featured && (
        <div className="card-header bg-warning text-dark py-1">
          <small className="d-flex align-items-center justify-content-center">
            <i className="fas fa-star me-1"></i>
            Featured Skill
          </small>
        </div>
      )}
      
      <div className="card-body d-flex flex-column">
        <div className="text-center mb-3">
          <div 
            className="skill-icon d-inline-flex align-items-center justify-content-center rounded-circle"
            style={{ 
              width: '60px', 
              height: '60px', 
              backgroundColor: color,
              color: '#fff'
            }}
          >
            <i className={`${icon} fa-lg`}></i>
          </div>
        </div>

        <div className="flex-grow-1">
          <h5 className="card-title text-center mb-2">{title}</h5>
          
          {showDetails && description && (
            <p className="card-text text-muted small mb-3">{description}</p>
          )}

          {/* Progress Bar */}
          <div className="mb-3">
            <div className="d-flex justify-content-between align-items-center mb-1">
              <small className="text-muted">Proficiency</small>
              <small className="fw-bold" style={{ color: getPercentageColor(percentage) }}>
                {percentage}%
              </small>
            </div>
            <div className="progress" style={{ height: '8px' }}>
              <div 
                className="progress-bar"
                role="progressbar"
                style={{ 
                  width: `${percentage}%`,
                  backgroundColor: getPercentageColor(percentage)
                }}
                aria-valuenow={percentage}
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>

          <div className="mb-2">
            <span className={`badge ${
              category === 'Language' ? 'bg-primary' :
              category === 'Frontend' ? 'bg-success' :
              category === 'Backend' ? 'bg-info' :
              category === 'Database' ? 'bg-warning text-dark' :
              category === 'Cloud' ? 'bg-danger' :
              category === 'DevOps' ? 'bg-dark' :
              category === 'Design' ? 'bg-purple' :
              category === 'Mobile' ? 'bg-indigo' :
              'bg-secondary'
            }`}>
              {category}
            </span>
            
            <span className={`badge ms-1 ${getLevelBadgeColor(level)}`}>
              {level}
            </span>
          </div>

          {yearsOfExperience > 0 && (
            <div className="mb-2">
              <small className="text-muted">
                <i className="fas fa-clock me-1"></i>
                {yearsOfExperience} year{yearsOfExperience !== 1 ? 's' : ''} experience
              </small>
            </div>
          )}

          {showDetails && relatedSkills.length > 0 && (
            <div className="mb-2">
              <small className="text-muted d-block mb-1">
                <strong>Related:</strong>
              </small>
              <div className="d-flex flex-wrap gap-1">
                {relatedSkills.slice(0, 3).map((relatedSkill, index) => (
                  <span key={index} className="badge bg-light text-dark">
                    {relatedSkill}
                  </span>
                ))}
                {relatedSkills.length > 3 && (
                  <span className="badge bg-light text-muted">
                    +{relatedSkills.length - 3} more
                  </span>
                )}
              </div>
            </div>
          )}

          {showDetails && projects.length > 0 && (
            <div className="mb-2">
              <small className="text-muted">
                <i className="fas fa-project-diagram me-1"></i>
                Used in {projects.length} project{projects.length !== 1 ? 's' : ''}
              </small>
            </div>
          )}

          {showDetails && certifications.length > 0 && (
            <div className="mb-2">
              <small className="text-muted">
                <i className="fas fa-certificate me-1"></i>
                {certifications.length} certification{certifications.length !== 1 ? 's' : ''}
              </small>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SkillCard;
