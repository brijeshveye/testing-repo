import React from 'react'

const ServiceCardWidget = (props) => {
    return (
        <>
            <div className="col-lg-3 col-md-6 col-xs-12">
                <div className="flipper">
                    <div className="main-box">
                        <div className="box-front height-300 white-bg">
                            <div className="content-wrap">
                                <div className="icon">
                                    <img className="icofont icofont-headphone-alt font-40px dark-color svg_img"
                                        src={props.icon} alt={props.title} />
                                </div>
                                <h3>{props.title}</h3>
                                <p>{props.description}</p>
                            </div>
                        </div>
                        <div className="box-back height-300 gradient-bg">
                            <div className="content-wrap">
                                <h3>{props.backTitle}</h3>
                                <p>{props.backDescription}</p>
                                <a href={props.link} className="btn">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

ServiceCardWidget.propTypes = {
    "title": "My Service",
    "description": "This is a service card widget.",
    "icon": "assets/img/service/1.svg",
    "link": "#",
    "backTitle": "Graphics Design",
    "backDescription": "Develop the Visual Identity of Your Business",
}

export default ServiceCardWidget