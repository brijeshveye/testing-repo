import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import ServiceDataApi from '../../api/ServiceDataApi';
import WhatIDoCardWidget from './widgets/WhatIDoCardWidget';

const WhatIDoSection = () => {

    const [processData, setProcessData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchServicesData();
    }, []);

    const fetchServicesData = async () => {
        try {
            setLoading(true);
            const data = await ServiceDataApi.getServicesForWhatIDo(5); // Get top 5 services
            setProcessData(data);
        } catch (error) {
            console.error('Error fetching services data:', error);
        } finally {
            setLoading(false);
        }
    };

    const generateLink = (slug) => {
        return `/service/details/${slug}`;
    }

    return (
        <>
            <section className="unique__commit bg1-img2 position-relative overflow-hidden">
                <div className="container-fluid p-0">
                    <div className="unique__commitwrap d-flex justify-content-between">
                        {loading ? (
                            <div className="col-12 text-center">
                                <div className="spinner-border text-primary" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        ) : (
                            processData.map((item, index) => (
                                <WhatIDoCardWidget 
                                    key={item._id || index} 
                                    tag={item.tag || 'Service'} 
                                    number={item.number || index + 1} 
                                    title={item.title}
                                    bgText={item.bgText || item.shortDescription || item.description} 
                                    link={generateLink(item.slug)} 
                                    linkText="More Details" 
                                />
                            ))
                        )}
                        
                    </div>
                    
                    {/* View All Services Button */}
                    {/* <div className="container mt-4">
                        <div className="row">
                            <div className="col-12 text-center">
                                <Link to="/services" className="px-btn px-btn-primary">
                                    <span>View All Services</span>
                                    <i className="fas fa-arrow-right ms-2"></i>
                                </Link>
                            </div>
                        </div>
                    </div> */}
                </div>
            </section>
        </>
    )
}

export default WhatIDoSection