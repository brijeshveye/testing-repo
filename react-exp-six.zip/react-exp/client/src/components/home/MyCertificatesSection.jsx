import React, { useEffect, useState } from 'react'
import CertificateCardWidget from './widgets/CertificateCardWidget';

import { motion, AnimatePresence } from 'framer-motion';
import UserDataApi from '../../api/UserDataApi';
import { Link } from 'react-router-dom';

const MyCertificatesSection = () => {
    const [certificatesData, setCertificatesData] = useState([]);
    const [certificateCategories, setCertificateCategories] = useState([]);
    const [activeCategory, setActiveCategory] = useState('all');


    useEffect(() => {
        setCertificateCategories(UserDataApi.getCertificateCategories());
        setCertificatesData(UserDataApi.getCertificatesForHome());
    }, []);

    const filteredCertificates = activeCategory === 'all'
        ? certificatesData
        : certificatesData.filter(cert =>
            cert.category?.toLowerCase() === activeCategory.toLowerCase()
        );

    return (
        <>
            <section className="about__section project__section cmn-thumbs pt-5 pb-5 position-relative overflow-hidden">
                <div className="container position-relative z-1">
                    <div className="project__head text-center">
                        <span className="common__sub white" data-aos="fade-down" data-aos-duration="1000">
                            My Certifications
                        </span>
                        <h2 className="fw-500" data-aos="fade-down" data-aos-duration="2000">
                            Awesome Certificates
                        </h2>
                    </div>
                    <div className="singletab">
                        <div className="this-tabs">
                            <ul className="tablinks" data-aos="fade-up" data-aos-duration="2000">

                                {certificateCategories.map((cat) => (
                                    <li
                                        key={cat}
                                        className={`nav-links ${activeCategory === cat ? 'active' : ''}`}
                                        onClick={() => setActiveCategory(cat)}
                                        style={{ cursor: 'pointer' }} >
                                        <button className="tablink">{cat.toUpperCase()}</button>

                                    </li>
                                ))}
                            </ul>
                            <div className="tabcontent">
                                <div className="tabitem active">
                                    <div className="row g-4">

                                        <AnimatePresence mode="popLayout">
                                            {filteredCertificates.map((certificate, index) => (
                                                <motion.div
                                                    key={certificate.title + index}
                                                    layout
                                                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                                                    animate={{ opacity: 1, scale: 1, y: 0 }}
                                                    exit={{ opacity: 0, scale: 0.9, y: 20 }}
                                                    transition={{ duration: 0.3 }}
                                                    className="col-xl-4 col-lg-4 col-md-6"
                                                >
                                                    <CertificateCardWidget
                                                        title={certificate.title}
                                                        description={certificate.description}
                                                        image={certificate.image}
                                                        year={certificate.year}
                                                        url={certificate.url}
                                                        category={certificate.category}
                                                    />
                                                </motion.div>
                                            ))}
                                        </AnimatePresence>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className="custom__hover">
                        <Link to="/certificates" className="hover__circle mauto" data-aos="zoom-out-down"
                            data-aos-duration="2000">
                            <span className="box">
                                <i className="bi bi-arrow-up-right"></i>
                                <span className="textmore">
                                    Click to See More Certifications
                                </span>
                            </span>
                        </Link>
                    </div>
                </div>
                <img src="assets/img/about/ellip.png" alt="img" className="ellip" />
                <img src="assets/img/about/ellip.png" alt="img" className="ellip2" />
            </section>
        </>
    )
}

export default MyCertificatesSection