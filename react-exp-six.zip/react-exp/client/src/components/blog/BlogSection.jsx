import React, { useEffect, useState } from 'react'
import BlogCommentBoxWidget from './widgets/BlogCommentBoxWidget'
import BlogCategoryCardWidget from './widgets/BlogCategoryCardWidget'
import RecentBlogPostWidget from './widgets/RecentBlogPostWidget'
import UserDataApi from '../../api/UserDataApi'

const BlogSection = ({ blogData }) => {

    const [blogCategoriesData, setBlogCategoriesData] = useState([]);
    const [recentBlogPostsData, setRecentBlogPostsData] = useState([]);
    const [blogTags, setBlogTags] = useState([]);


    useEffect(() => {
        const fetchBlogData = async () => {
            try {
                const categories = await UserDataApi.getBlogCategories();
                const recentPosts = await UserDataApi.getRecentBlogPosts();
                const tags = await UserDataApi.getBlogTags();
                
                setBlogCategoriesData(categories);
                setRecentBlogPostsData(recentPosts);
                setBlogTags(tags);
            } catch (error) {
                console.error('Error fetching blog data:', error);
            }
        };

        fetchBlogData();
    }, []);

    return (
        <>
            <section className="blog__bsection pb-5">
                <div className="container">
                    <div className="row g-4">
                        <div className="col-lg-8">
                            <div className="blog__bleft__wrapper">
                                <div className="blog__bitem" data-aos="fade-up" data-aos-duration="1000">
                                    <a href="#0" className="thumb">
                                        <img src={blogData?.bannerImage} alt="img" />
                                    </a>
                                    <div className="content__two">
                                        <div className="text__box mb-30" data-aos="fade-up" data-aos-duration="1400">
                                            <span className="text__de">
                                                By: {blogData?.author} / {blogData?.category} / Posted on {blogData?.date} / Comments: 0
                                            </span>
                                            {
                                                blogData?.details?.section1 && (
                                                    <>
                                                        <p className="fz-16 pra ttext__one">
                                                            {blogData?.details?.section1?.para1}
                                                        </p>
                                                        <p className="fz-16 pra">
                                                            {blogData?.details?.section1?.para2}
                                                        </p>
                                                    </>
                                                )
                                            }

                                        </div>

                                        {
                                            blogData?.details?.section2 && (
                                                <div className="quite__box mb-30">
                                                    <img src="/assets/img/blog/straight-quotes.png" alt="img" />
                                                    <p>
                                                        {blogData?.details?.section2?.quote}
                                                    </p>
                                                    <a href="#0">
                                                        {blogData?.details?.section2?.author}
                                                    </a>
                                                </div>
                                            )
                                        }

                                        {
                                            blogData?.details?.section3 && (
                                                <p className="fz-16 pra ttext__one mb__cus60">
                                                    {blogData?.details?.section3?.para}
                                                </p>
                                            )
                                        }


                                        <h3 className="white mb-30">
                                            {blogData?.details?.section4?.title}
                                        </h3>
                                        <div className="thumb mb-30">
                                            <img src={blogData?.details?.section4?.image1} alt="img" />
                                        </div>
                                        <p className="fz-16 pra ttext__one mb-30">
                                            {blogData?.details?.section4?.para}
                                        </p>
                                        <div className="text__box mb-30" data-aos="fade-up" data-aos-duration="1600">
                                            <ul className="challenge__list">
                                                {
                                                    blogData?.details?.section4?.list?.map((item, index) => (
                                                        <li key={index}>{item}</li>
                                                    ))
                                                }
                                                
                                            </ul>
                                        </div>
                                        <p className="fz-16 pra ttext__one mb-30">
                                            {blogData?.details?.section4?.para2}
                                        </p>
                                    </div>
                                    <div className="post__in cmn__bg mb__cus60">
                                        <div className="post__left">
                                            <span className="fz-20 fw-500 white">
                                                Posted in :
                                            </span>
                                            {
                                                blogData?.tags?.map((tag, index) => (
                                                    <a href="#0" key={index}>
                                                        {tag}
                                                    </a>
                                                ))
                                            }
                                        </div>
                                        <div className="post__right">
                                            <span className="fz-20 fw-500 white">
                                                Share :
                                            </span>
                                            <ul className="social-cus d-flex align-items-center">
                                                <li>
                                                    <a href="#0">
                                                        <i className="bi bi-facebook"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#0">
                                                        <i className="bi bi-twitter"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#0">
                                                        <i className="bi bi-instagram"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a href="#0">
                                                        <i className="bi bi-linkedin"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <BlogCommentBoxWidget />
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="blog__bright__bar">
                                <div className="scope__item mb__cus60">
                                    <h4 className="scope__title">
                                        Serach
                                    </h4>
                                    <form action="#0" className="d-flex align-content-center justify-content-between">
                                        <input type="text" placeholder="Search" />
                                        <button type="submit">
                                            <i className="bi bi-search"></i>
                                        </button>
                                    </form>
                                </div>
                                <div className="scope__item mb__cus60 position-relative">
                                    <h4 className="scope__title">
                                        Categories
                                    </h4>
                                    <ul className="category">
                                        {
                                            blogCategoriesData.map((category, index) => (
                                                <BlogCategoryCardWidget key={index} categoryLink={category.link} categoryName={category.name} />
                                            ))
                                        }

                                    </ul>
                                </div>
                                <div className="scope__item mb__cus60">
                                    <h4 className="scope__title">
                                        Recent Post
                                    </h4>
                                    <ul className="recent__post">
                                        {
                                            recentBlogPostsData.map((post, index) => (
                                                <RecentBlogPostWidget key={index} imgSrc={post.image} title={post.title} date={post.date} link={post.link} />
                                            ))
                                        }
                                        
                                    </ul>
                                </div>
                                <div className="scope__item">
                                    <h4 className="scope__title">
                                        Tag
                                    </h4>
                                    <ul className="tags">
                                        {
                                            blogTags.map((tag, index) => (
                                                <li key={index}>
                                                    <a href={tag.link}>
                                                        {tag.name}
                                                    </a>
                                                </li>
                                            ))
                                        }

                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default BlogSection