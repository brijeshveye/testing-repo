import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const BlogsDataApi = {
  // Get all blogs from MongoDB backend
  getBlogsData: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/blogs`);
      return response.data;
    } catch (error) {
      console.error('Error fetching blogs:', error);
      return [];
    }
  },

  // Get blogs for home page (with limit)
  getBlogsForHome: async (limit = 4) => {
    try {
      const blogsData = await BlogsDataApi.getBlogsData();
      // Get published blogs first, then sort by date
      const publishedBlogs = blogsData
        .filter(blog => blog.published !== false)
        .sort((a, b) => new Date(b.publishedAt || b.createdAt) - new Date(a.publishedAt || a.createdAt));
      return publishedBlogs.slice(0, limit);
    } catch (error) {
      console.error('Error fetching blogs for home:', error);
      return [];
    }
  },

  // Get blog categories (extract from blogs data)
  getBlogCategories: async () => {
    try {
      const blogsData = await BlogsDataApi.getBlogsData();
      let blogCategories = new Set();
      
      blogsData.forEach(blog => {
        if (blog.category) {
          blogCategories.add(blog.category);
        }
      });

      // Add 'all' category to the set
      blogCategories.add('all');

      return Array.from(blogCategories).sort(); // Return categories as a sorted array
    } catch (error) {
      console.error('Error fetching blog categories:', error);
      return ['all'];
    }
  },

  // Get blog details by slug
  getBlogDetails: async (slug) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/blogs/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching blog details:', error);
      return null;
    }
  },

  // Admin functions for CRUD operations
  createBlog: async (blogData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/blogs`, blogData);
      return response.data;
    } catch (error) {
      console.error('Error creating blog:', error);
      throw error;
    }
  },

  updateBlog: async (slug, blogData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/blogs/${slug}`, blogData);
      return response.data;
    } catch (error) {
      console.error('Error updating blog:', error);
      throw error;
    }
  },

  deleteBlog: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/blogs/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting blog:', error);
      throw error;
    }
  }
};

export default BlogsDataApi;
