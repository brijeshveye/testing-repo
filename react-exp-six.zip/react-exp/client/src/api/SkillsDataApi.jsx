import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const SkillsDataApi = {
  // Fetch all skills from the backend
  getSkillsData: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams(params).toString();
      const url = queryParams ? `${API_BASE_URL}/skills?${queryParams}` : `${API_BASE_URL}/skills`;
      const response = await axios.get(url);
      return response.data;
    } catch (error) {
      console.error('Error fetching skills:', error);
      return [];
    }
  },

  // Get skills for home page with limit
  getSkillsForHome: async (limit = 12) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/skills?isActive=true&limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching skills for home:', error);
      return [];
    }
  },

  // Get featured skills
  getFeaturedSkills: async (limit = 8) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/skills?featured=true&isActive=true&limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching featured skills:', error);
      return [];
    }
  },

  // Get skills by category
  getSkillsByCategory: async (category, limit = null) => {
    try {
      const params = { category, isActive: true };
      if (limit) params.limit = limit;
      
      const response = await axios.get(`${API_BASE_URL}/skills`, { params });
      return response.data;
    } catch (error) {
      console.error('Error fetching skills by category:', error);
      return [];
    }
  },

  // Get skill categories (extract from skills data)
  getSkillCategories: async () => {
    try {
      const skillsData = await SkillsDataApi.getSkillsData({ isActive: true });
      let categories = new Set();
      
      skillsData.forEach(skill => {
        if (skill.category) {
          categories.add(skill.category);
        }
      });

      // Add 'all' category to the set
      categories.add('all');

      return Array.from(categories).sort(); // Return categories as a sorted array
    } catch (error) {
      console.error('Error fetching skill categories:', error);
      return ['all'];
    }
  },

  // Get skill details by slug
  getSkillDetails: async (slug) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/skills/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching skill details:', error);
      return null;
    }
  },

  // Get skill statistics
  getSkillStats: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/skills/stats`);
      return response.data;
    } catch (error) {
      console.error('Error fetching skill stats:', error);
      return null;
    }
  },

  // Create a new skill
  createSkill: async (skillData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/skills`, skillData);
      return response.data;
    } catch (error) {
      console.error('Error creating skill:', error);
      throw error;
    }
  },

  // Update skill
  updateSkill: async (slug, skillData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/skills/${slug}`, skillData);
      return response.data;
    } catch (error) {
      console.error('Error updating skill:', error);
      throw error;
    }
  },

  // Delete skill
  deleteSkill: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/skills/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting skill:', error);
      throw error;
    }
  },

  // Update skills order
  updateSkillsOrder: async (skills) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/skills/order/update`, { skills });
      return response.data;
    } catch (error) {
      console.error('Error updating skills order:', error);
      throw error;
    }
  },

  // Toggle featured status
  toggleFeatured: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/skills/${slug}/toggle-featured`);
      return response.data;
    } catch (error) {
      console.error('Error toggling featured status:', error);
      throw error;
    }
  },

  // Toggle active status
  toggleActive: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/skills/${slug}/toggle-active`);
      return response.data;
    } catch (error) {
      console.error('Error toggling active status:', error);
      throw error;
    }
  }
};

export default SkillsDataApi;
