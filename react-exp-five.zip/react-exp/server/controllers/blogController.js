const { readBlogs, writeBlogs } = require('../models/blogModel');

// GET all blogs
const getAllBlogs = (req, res) => {
    const blogs = readBlogs();
    res.json(blogs);
};

// GET blog by slug
const getBlogBySlug = (req, res) => {
    const blogs = readBlogs();
    const blog = blogs.find(b => b.slug === req.params.slug);
    if (!blog) return res.status(404).json({ message: 'Blog not found' });
    res.json(blog);
};

// CREATE new blog
const createBlog = (req, res) => {
    const blogs = readBlogs();
    const newBlog = req.body;

    if (!newBlog.slug) {
        return res.status(400).json({ message: 'Slug is required' });
    }

    if (blogs.find(b => b.slug === newBlog.slug)) {
        return res.status(409).json({ message: 'Blog with this slug already exists' });
    }

    blogs.push(newBlog);
    writeBlogs(blogs);
    res.status(201).json(newBlog);
};

// UPDATE blog
const updateBlog = (req, res) => {
    const blogs = readBlogs();
    const index = blogs.findIndex(b => b.slug === req.params.slug);

    if (index === -1) {
        return res.status(404).json({ message: 'Blog not found' });
    }

    blogs[index] = { ...blogs[index], ...req.body };
    writeBlogs(blogs);
    res.json(blogs[index]);
};

// DELETE blog
const deleteBlog = (req, res) => {
    const blogs = readBlogs();
    const filtered = blogs.filter(b => b.slug !== req.params.slug);

    if (filtered.length === blogs.length) {
        return res.status(404).json({ message: 'Blog not found' });
    }

    writeBlogs(filtered);
    res.json({ message: 'Blog deleted' });
};

module.exports = {
    getAllBlogs,
    getBlogBySlug,
    createBlog,
    updateBlog,
    deleteBlog
};
