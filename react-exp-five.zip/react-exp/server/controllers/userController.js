const { readUserData, writeUserData } = require('../models/userModel');

// Get full user data
const getUserData = (req, res) => {
    const data = readUserData();
    res.json(data);
};

// Update a specific section like aboutData, educationData, etc.
const updateSection = (req, res) => {
    const section = req.params.section;
    const userData = readUserData();

    if (!userData[section]) {
        return res.status(404).json({ message: `Section '${section}' not found` });
    }

    userData[section] = req.body;
    console.log(`Updating section: ${section}`, userData[section]);
    writeUserData(userData);

    res.json({ message: `Section '${section}' updated successfully`, data: userData[section] });
};

module.exports = {
    getUserData,
    updateSection
};
