const { readProjects, writeProjects } = require('../models/projectModel');

// GET all
const getAllProjects = (req, res) => {
    const projects = readProjects();
    res.json(projects);
};

// GET by slug
const getProjectBySlug = (req, res) => {
    const projects = readProjects();
    const project = projects.find(p => p.slug === req.params.slug);
    if (!project) return res.status(404).json({ message: 'Project not found' });
    res.json(project);
};

// CREATE
const createProject = (req, res) => {
    const projects = readProjects();
    const newProject = req.body;

    if (!newProject.slug) {
        return res.status(400).json({ message: 'Slug is required' });
    }

    if (projects.find(p => p.slug === newProject.slug)) {
        return res.status(409).json({ message: 'Project with this slug already exists' });
    }

    projects.push(newProject);
    writeProjects(projects);
    res.status(201).json(newProject);
};

// UPDATE
const updateProject = (req, res) => {
    const projects = readProjects();
    const index = projects.findIndex(p => p.slug === req.params.slug);

    if (index === -1) {
        return res.status(404).json({ message: 'Project not found' });
    }

    projects[index] = { ...projects[index], ...req.body };
    writeProjects(projects);
    res.json(projects[index]);
};

// DELETE
const deleteProject = (req, res) => {
    const projects = readProjects();
    const filtered = projects.filter(p => p.slug !== req.params.slug);

    if (filtered.length === projects.length) {
        return res.status(404).json({ message: 'Project not found' });
    }

    writeProjects(filtered);
    res.json({ message: 'Project deleted' });
};

module.exports = {
    getAllProjects,
    getProjectBySlug,
    createProject,
    updateProject,
    deleteProject
};
