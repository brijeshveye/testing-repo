const express = require('express');
const path = require('path');
const app = express();

// Routes
const projectRoutes = require('./routes/projectRoutes');
const blogRoutes = require('./routes/blogRoutes');
const userRoutes = require('./routes/userRoutes');


// API route example
app.get('/api', (req, res) => {
  //   const data = require('./data/data.json');
  //   res.json(data);
  res.json({ message: 'Hello world' });
});

app.use('/api/projects', projectRoutes);
app.use('/api/blogs', blogRoutes);
app.use('/api/user', userRoutes);

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../client/build')));

['get', 'post', 'put', 'delete', 'use'].forEach(method => {
  const original = app[method];
  app[method] = function(path, ...args) {
    if (typeof path === 'string') {
      console.log(`Registering ${method.toUpperCase()} route: ${path}`);
    } else {
      console.log(`Registering ${method.toUpperCase()} route with non-string first arg`);
    }
    return original.call(this, path, ...args);
  };
});

// Catch-all to serve React's index.html for any non-API routes
app.get("/", (req, res, next) => {
  // Only serve index.html if request path looks like a relative path
  console.log('Catch-all req.path:', req.path);
  if (req.path.startsWith('/')) {
    res.sendFile(path.join(__dirname, '../client/build/index.html'));
  } else {
    next(); // Pass on invalid paths
  }
});

// Start server
const PORT = process.env.PORT || 5000;

app.listen(PORT, (error) => {
  if (!error) {
    console.log("Server is Successfully Running, and App is listening on port " + PORT);
  }
  else {
    console.log("Error occurred, server can't start", error);
  }

});
