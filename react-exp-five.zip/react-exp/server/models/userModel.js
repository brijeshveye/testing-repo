const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/userData.json');

const readUserData = () => {
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
};

const writeUserData = (data) => {
    fs.writeFileSync(filePath, JSON.stringify(data, null, 4));
};

module.exports = {
    readUserData,
    writeUserData
};
