const express = require('express');
const router = express.Router();
const {
    getUserData,
    updateSection
} = require('../controllers/userController');

// GET all user data
router.get('/', getUserData);

// UPDATE specific section (like /api/user/aboutData or /api/user/educationData)
router.put('/:section', updateSection);

module.exports = router;
