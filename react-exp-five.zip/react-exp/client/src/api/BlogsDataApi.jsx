const BlogsDataApi = {
  getBlogsData: () => {
    let blogsData = [
      {
        "title": "Best way to solve business deal issue",
        "description": "A deep dive into React Hooks and how they can simplify your code.",
        "slug": "best-way-to-solve-business-deal-issue",
        "bannerImage": "/assets/img/blog/bblog1.png",
        "image": "/assets/img/blog/1.jpg",
        "date": "2023-01-15",
        "author": "John Doe",
        "category": "Business",
        "tags": ["React", "Hooks", "JavaScript"],

        "details": {
          "section1": {
            "para1": "In this blog, we explore the best practices for solving business deal issues effectively. We discuss strategies that can help you navigate complex negotiations and reach mutually beneficial agreements.",
            "para2": "From understanding the needs of both parties to effective communication techniques, this blog provides valuable insights for professionals looking to enhance their negotiation skills."
          },
          "section2": {
            "quote": "Effective negotiation is not just about winning; it's about finding a solution that works for everyone involved.",
            "author": "Jane Smith",
          },

          "section3": {
            "para": "In addition to negotiation strategies, we also cover the importance of building strong relationships with clients and partners. Trust and rapport can significantly impact the outcome of any business deal.",
          },

          "section4": {
            "title": "Key Takeaways",
            "image1": "/assets/img/blog/blog-detailsb2.png",
            "para1": "To summarize, successful business deal resolution requires a combination of negotiation skills, relationship building, and effective communication. By applying these principles, you can improve your chances of achieving favorable outcomes in your business dealings.",
            "list": [
              "Understand the needs of both parties",
              "Communicate effectively",
              "Build strong relationships",
              "Be flexible and open to compromise",
            ],
            "para2": "Remember, every business deal is unique, and adapting your approach to the specific situation is crucial for success."
          }
        }
      },
      {
        "title": "31 customer service stats know in 2019",
        "description": "Techniques for creating responsive web applications using CSS Grid and Flexbox.",
        "slug": "31-customer-service-stats-know-in-2019",
        "bannerImage": "/assets/img/blog/bblog2.png",
        "image": "/assets/img/blog/2.jpg",
        "date": "2023-02-20",
        "author": "Jane Smith",
        "category": "Knowledge",
        "tags": ["CSS", "Grid", "Flexbox"],
        "details": {
          "section1": {
            "para1": "In this blog, we explore the latest customer service statistics that every business should know. From response times to customer satisfaction scores, these stats provide valuable insights for improving your customer service strategy.",
            "para2": "By understanding the current landscape of customer service, businesses can make informed decisions and implement best practices to enhance the customer experience."
          },
          "section2": {
            "quote": "Customer service is not a department; it's everyone's job.",
            "author": "Anonymous"
          },
          "section3": {
            "para": "In addition to statistics, we also discuss key trends shaping the future of customer service. From AI-driven support to personalized experiences, staying ahead of the curve is essential for success."
          },
          "section4": {
            "title": "Key Takeaways",
            "image1": "/assets/img/blog/blog-detailsb2.png",
            "para1": "To summarize, understanding customer service statistics is crucial for businesses looking to improve their support efforts. By leveraging data and insights, companies can create more effective strategies and drive better outcomes.",
            "list": [
              "Monitor key performance indicators (KPIs)",
              "Invest in training and development",
              "Embrace technology and automation",
              "Prioritize customer feedback"
            ],
            "para2": "Remember, every business deal is unique, and adapting your approach to the specific situation is crucial for success."
          }
        }
      },
      {
        "title": "Business ideas to grow your business",
        "description": "An overview of the most useful ES6 features for modern JavaScript development.",
        "slug": "best-way-to-solve-business-deal-issue",
        "bannerImage": "/assets/img/blog/bblog3.png",
        "image": "/assets/img/blog/3.jpg",
        "date": "2023-03-10",
        "author": "Alice Johnson",
        "category": "Business",
        "tags": ["JavaScript", "ES6", "Programming"],
        "details": {
          "section1": {
            "para1": "In this blog, we explore various business ideas that can help you grow your business. From innovative marketing strategies to effective customer engagement techniques, these ideas are designed to inspire and motivate entrepreneurs.",
            "para2": "By implementing these strategies, you can create a more dynamic and successful business."
          },
          "section2": {
            "quote": "The best way to predict the future is to create it.",
            "author": "Peter Drucker"
          },
          "section3": {
            "para": "In addition to specific business ideas, we also discuss the importance of adaptability and resilience in today's fast-paced business environment."
          },
          "section4": {
            "title": "Key Takeaways",
            "image1": "/assets/img/blog/blog-detailsb3.png",
            "para1": "To summarize, exploring new business ideas is essential for growth and success. By staying open to innovation and embracing change, you can position your business for long-term success.",
            "list": [
              "Embrace innovation",
              "Focus on customer needs",
              "Leverage technology",
              "Build a strong brand"
            ],
            "para2": "Remember, every business deal is unique, and adapting your approach to the specific situation is crucial for success."
          }
        }
      },
      {
        "title": "JavaScript ES6 Features You Should Know",
        "description": "An overview of the most useful ES6 features for modern JavaScript development.",
        "slug": "javascript-es6-features-you-should-know",
        "bannerImage": "/assets/img/blog/bblog4.png",
        "image": "/assets/img/blog/4.jpg",
        "date": "2023-03-10",
        "author": "Alice Johnson",
        "category": "JavaScript",
        "tags": ["JavaScript", "ES6", "Programming"],
        "details": {
          "section1": {
            "para1": "In this blog, we explore the most useful ES6 features that every JavaScript developer should know. From arrow functions to template literals, these features can significantly enhance your coding experience.",
            "para2": "By leveraging ES6 features, you can write cleaner and more efficient code."
          },
          "section2": {
            "quote": "JavaScript is the world's most misunderstood programming language.",
            "author": "Douglas Crockford"
          },
          "section3": {
            "para": "In addition to specific features, we also discuss best practices for using ES6 in your projects."
          },
          "section4": {
            "title": "Key Takeaways",
            "image1": "/assets/img/blog/blog-detailsb4.png",
            "para1": "To summarize, mastering ES6 features is essential for modern JavaScript development. By staying up-to-date with the latest advancements, you can improve your coding skills and productivity.",
            "list": [
              "Use arrow functions for concise syntax",
              "Leverage template literals for string interpolation",
              "Utilize destructuring for cleaner code",
              "Embrace modules for better organization"
            ],
            "para2": "Remember, every business deal is unique, and adapting your approach to the specific situation is crucial for success."
          }
        }
      }
    ];

    return blogsData;
  },

  getBlogsForHome: (limit = 4) => {
    let blogsData = BlogsDataApi.getBlogsData();
    blogsData = blogsData.sort(() => Math=> Math.random() - 0.5); // Shuffle the blogs
    return blogsData.slice(0, limit);
  },

  getBlogCategories: () => {
    let blogCategories = new Set();
    let blogsData = BlogsDataApi.getBlogsData();
    blogsData.forEach(blog => {
      if (blog.category) {
        blogCategories.add(blog.category);
      }
    });

    let blogCategoriesArray = Array.from(blogCategories).map(category => {
      return { "name": category, "link": "#0" };
    });

    return blogCategoriesArray;
  },

  getRecentBlogs: () => {
    let recentBlogs = [
      {
        "title": "Best way to solve business deal issue",
        "slug": "best-way-to-solve-business-deal-issue",
        "image": "/assets/img/blog/bsmall1.png",
        "date": "2023-01-15",
        
      },
      {
        "title": "31 customer service stats know in 2019",
        "slug": "31-customer-service-stats-know-in-2019",
        "image": "/assets/img/blog/bsmall2.png",
        "date": "2023-02-20",
      },
      {
        "title": "Business ideas to grow your business",
        "slug": "business-ideas-to-grow-your-business",
        "image": "/assets/img/blog/bsmall3.png",
        "date": "2023-03-10",
      }
    ];

    // let recentBlogs = [];
    // let blogsData = BlogsDataApi.getBlogsData();
    // blogsData.forEach(blog => {
    //   if (blog.date) {
    //     recentBlogs.push({
    //       "title": blog.title,
    //       "slug": blog.slug,
    //       "image": blog.image,
    //       "date": blog.date
    //     });
    //   }
    // });

    return recentBlogs;
  },

  getBlogsFromCategory: (category) => {
    let blogsData = BlogsDataApi.getBlogsData();
    return blogsData.filter(blog => blog.category === category);
  },

  getBlogTags: () => {
    // let blogTags = [
    //   { "name": "React", "link": "#0" },
    //   { "name": "JavaScript", "link": "#0" },
    //   { "name": "CSS", "link": "#0" },
    //   { "name": "Web Development", "link": "#0" }
    // ];

    let blogTags = new Set();
    let blogsData = BlogsDataApi.getBlogsData();
    blogsData.forEach(blog => {
      if (blog.tags) {
        blog.tags.forEach(tag => {
          blogTags.add(tag);
        });
      }
    });
    
    blogTags = Array.from(blogTags).map(tag => {
      return { "name": tag, "link": "#0" };
    });

    return blogTags;
  },

  getBlogDetails: (slug) => {
    let blogsData = BlogsDataApi.getBlogsData();
    return blogsData.find(blog => blog.slug === slug);
  }
}

export default BlogsDataApi