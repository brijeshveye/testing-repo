
const ProjectsDataApi = {
    getProjectsData: () => {
        let projectsData = [
            {
                "title": "BonzaMart - Super market",
                "description": "A website showcasing skills and projects.",
                "domains": [
                    { "title": "3D Graphics", "url": "#" },
                    { "title": "Web Design", "url": "#" },
                    { "title": "UI/UX Design", "url": "#" }
                ],
                "bannerImage": "/assets/img/protfolio/prot-detailsbig.png",
                "image": "/assets/img/portfolio/1.jpg",
                "date": "2023-01-01",
                "location": "24 Fifth st.,Los Angeles, USA",
                "client": "Symphony",
                "techStack": ["HTML", "CSS", "JavaScript"],
                "type": "eCommerce",
                "slug": "bronzmart-super-market",
                "category": "graphics",

                "details": {
                    "section1": {
                        "para1": "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.",
                        "para2": "It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc."
                    },
                    "section2": {
                        "title": "Challenge",
                        "para": "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet.",
                        "list": [
                            "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
                            "Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally",
                            "On the other hand, we denounce with righteous indignation and dislike"
                        ]
                    },
                    "section3": {
                        "title": "Solution & Result",
                        "para": "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc."
                    },
                    "section4": {
                        "image1": "/assets/img/protfolio/prot-detials1.png",
                        "image2": "/assets/img/protfolio/prot-detials2.png"
                    }
                },

            },
            {
                "title": "ShowMania - Entertainment",
                "description": "A full-featured e-commerce platform with payment integration.",
                "domains": [
                    { "title": "Web Design", "url": "#" },
                    { "title": "Design", "url": "#" }
                ],
                "image": "/assets/img/portfolio/2.jpg",
                "bannerImage": "/assets/img/portfolio/2.jpg",
                "date": "2022-06-15",
                "client": "Tech Store",
                "techStack": ["React", "Node.js", "MongoDB"],
                "type": "Entertainment",
                "slug": "showmania-entertainment",
                "category": "development",
                "details": {
                    "section1": {
                        "para1": "This project is a full-featured e-commerce platform that allows users to browse products, add them to their cart, and complete purchases securely.",
                        "para2": "The platform includes user authentication, product management, and payment integration."
                    },
                    "section2": {
                        "title": "Challenge",
                        "para": "The main challenge was to create a seamless user experience while ensuring security and scalability.",
                        "list": [
                            "Implementing secure payment gateways",
                            "Ensuring fast load times",
                            "Creating an intuitive user interface"
                        ]
                    },
                    "section3": {
                        "title": "Solution & Result",
                        "para": "By using React for the front-end and Node.js for the back-end, we were able to create a responsive and efficient e-commerce platform. The project was completed on time and received positive feedback from users."
                    },
                    "section4": {
                        "image1": "/assets/img/protfolio/prot-detials1.png",
                        "image2": "assets/img/protfolio/prot-detials2.png"
                    }
                }
            },
            {
                "title": "WorldToday - Portal",
                "description": "A full-featured entertainment platform with video streaming.",
                "domains": [
                    { "title": "Web Design", "url": "#" },
                    { "title": "UI/UX Design", "url": "#" }
                ],
                "image": "/assets/img/portfolio/3.jpg",
                "bannerImage": "/assets/img/portfolio/3.jpg",
                "date": "2022-06-15",
                "client": "Tech Store",
                "techStack": ["React", "Node.js", "Android"],
                "type": "News",
                "slug": "worldtoday-portal",
                "category": "design",
                "details": {
                    "section1": {
                        "para1": "This project is a full-featured entertainment platform that allows users to watch videos, read articles, and engage with content.",
                        "para2": "The platform includes user authentication, content management, and video streaming capabilities."
                    },
                    "section2": {
                        "title": "Challenge",
                        "para": "The main challenge was to create a scalable video streaming service while ensuring high-quality content delivery.",
                        "list": [
                            "Implementing adaptive bitrate streaming",
                            "Ensuring cross-device compatibility",
                            "Creating an engaging user interface"
                        ]
                    },
                    "section3": {
                        "title": "Solution & Result",
                        "para": "By using React for the front-end and Node.js for the back-end, we were able to create a responsive and efficient entertainment platform. The project was completed on time and received positive feedback from users."
                    },
                    "section4": {
                        "image1": "/assets/img/protfolio/prot-detials1.png",
                        "image2": "/assets/img/protfolio/prot-detials2.png"
                    }
                }
            },
            {
                "title": "WorldToday - Portal",
                "description": "A tech news website with real-time updates and articles.",
                "domains": [
                    { "title": "Android", "url": "#" },
                    { "title": "UI/UX Design", "url": "#" }
                ],
                "image": "/assets/img/portfolio/4.jpg",
                "bannerImage": "/assets/img/portfolio/4.jpg",
                "date": "2022-06-15",
                "client": "John Worrior",
                "techStack": ["React", "Node.js", "Android"],
                "type": "News",
                "slug": "worldtoday-portal",
                "category": "design",
                "details": {
                    "section1": {
                        "para1": "This project is a tech news website that provides real-time updates and articles on the latest technology trends.",
                        "para2": "The platform includes user authentication, content management, and a responsive design."
                    },
                    "section2": {
                        "title": "Challenge",
                        "para": "The main challenge was to create a platform that could handle high traffic while delivering real-time updates.",
                        "list": [
                            "Implementing a scalable architecture",
                            "Ensuring fast load times",
                            "Creating an intuitive user interface"
                        ]
                    },
                    "section3": {
                        "title": "Solution & Result",
                        "para": "By using React for the front-end and Node.js for the back-end, we were able to create a responsive and efficient tech news platform. The project was completed on time and received positive feedback from users."
                    },
                    "section4": {
                        "image1": "/assets/img/protfolio/prot-detials1.png",
                        "image2": "/assets/img/protfolio/prot-detials2.png"
                    }
                }
            },
            {
                "title": "Doctory - Health Care",
                "description": "A personal portfolio website showcasing my skills and projects.",
                "domains": [
                    { "title": "Development", "url": "#" },
                    { "title": "Web Design", "url": "#" }
                ],
                "image": "/assets/img/portfolio/5.jpg",
                "bannerImage": "/assets/img/portfolio/5.jpg",
                "date": "2023-01-01",
                "client": "Symphony",
                "techStack": ["PHP", "Mysql", "JavaScript"],
                "type": "Health Care",
                "slug": "doctory-health-care",
                "category": "development",
                "details": {
                    "section1": {
                        "para1": "This project is a personal portfolio website that showcases my skills, projects, and achievements.",
                        "para2": "The website includes sections for my resume, projects, and contact information."
                    },
                    "section2": {
                        "title": "Challenge",
                        "para": "The main challenge was to create a visually appealing and user-friendly portfolio that effectively communicates my skills and experience.",
                        "list": [
                            "Designing a responsive layout",
                            "Ensuring cross-browser compatibility",
                            "Creating engaging content"
                        ]
                    },
                    "section3": {
                        "title": "Solution & Result",
                        "para": "By using HTML, CSS, and JavaScript, I was able to create a modern and responsive portfolio website. The project was completed on time and received positive feedback from peers."
                    },
                    "section4": {
                        "image1": "/assets/img/protfolio/prot-detials1.png",
                        "image2": "/assets/img/protfolio/prot-detials2.png"
                    }
                }
            },
            {
                "title": "ConsultMe",
                "description": "A personal portfolio website showcasing my skills and projects.",
                "domains": [
                    { "title": "3D Graphics", "url": "#" },
                    { "title": "Web Design", "url": "#" },
                    { "title": "UI/UX Design", "url": "#" }
                ],
                "image": "/assets/img/portfolio/6.jpg",
                "bannerImage": "/assets/img/portfolio/6.jpg",
                "date": "2023-01-01",
                "client": "Sizuka Mitsu",
                "techStack": ["HTML", "CSS", "JavaScript"],
                "type": "Consultancy",
                "slug": "consultme",
                "category": "templates",
                "details": {
                    "section1": {
                        "para1": "This project is a personal portfolio website that showcases my skills, projects, and achievements.",
                        "para2": "The website includes sections for my resume, projects, and contact information."
                    },
                    "section2": {
                        "title": "Challenge",
                        "para": "The main challenge was to create a visually appealing and user-friendly portfolio that effectively communicates my skills and experience.",
                        "list": [
                            "Designing a responsive layout",
                            "Ensuring cross-browser compatibility",
                            "Creating engaging content"
                        ]
                    },
                    "section3": {
                        "title": "Solution & Result",
                        "para": "By using HTML, CSS, and JavaScript, I was able to create a modern and responsive portfolio website. The project was completed on time and received positive feedback from peers."
                    },
                    "section4": {
                        "image1": "/assets/img/protfolio/prot-detials1.png",
                        "image2": "/assets/img/protfolio/prot-detials2.png"
                    }
                }
            },
            {
                "title": "BR SSO - A Centralized Single Sign-On Solution",
                "description": "Centralized Single Sign-On (SSO) solution designed to simplify and secure user authentication across multiple web applications.",
                "domains": [
                    { "title": "Single Sign On", "url": "#" },
                    { "title": "IAM", "url": "#" },
                    { "title": "Auth", "url": "#" }
                ],
                "image": "/assets/img/portfolio/6.jpg",
                "bannerImage": "/assets/img/portfolio/6.jpg",
                "date": "2025-04-01",
                "client": "Self",
                "techStack": ["NodeJS", "Fastify", "JavaScript"],
                "type": "Authentication",
                "slug": "consultbr-sso",
                "category": "projects",
                "details": {
                    "section1": {
                        "para1": "OpenSSO is a centralized SSO (Single Sign On) solution designed to simplify and secure user authentication across multiple web applications. Built on OAuth 2.0 and JWT standards (RFC 7519/RFC 9068), it enables one-click access—sign up once, sign in everywhere.",
                        "para2": "The website includes sections for my resume, projects, and contact information."
                    },
                    "section2": {
                        "title": "Challenge",
                        "para": "The main challenge was to create a visually appealing and user-friendly portfolio that effectively communicates my skills and experience.",
                        "list": [
                            "Designing a responsive layout",
                            "Ensuring cross-browser compatibility",
                            "Creating engaging content"
                        ]
                    },
                    "section3": {
                        "title": "Solution & Result",
                        "para": "By using HTML, CSS, and JavaScript, I was able to create a modern and responsive portfolio website. The project was completed on time and received positive feedback from peers."
                    },
                    "section4": {
                        "image1": "/assets/img/protfolio/prot-detials1.png",
                        "image2": "/assets/img/protfolio/prot-detials2.png"
                    }
                }
            }
        ];

        return projectsData;
    },

    getPorjectsForHome: (limit = 6) => {
        let projects = ProjectsDataApi.getProjectsData();
        // Shuffle the projects array to get a random selection
        projects = projects.sort(() => Math.random() - 0.5);
        return projects.slice(0, limit); // Return only the first 4 projects for the home page
    },

    getProjectCategories: () => {
        let projects = ProjectsDataApi.getProjectsData();
        let categories = new Set();
        projects.forEach(project => {
            if (project.category) {
                categories.add(project.category);
            }
        });

        // Append 'all' category to the set
        categories.add('all');

        return Array.from(categories).sort(); // Return categories as a sorted array
    },

    getProjectDetails: (slug) => {
        let projects = ProjectsDataApi.getProjectsData();
        return projects.find(project => project.slug === slug) || null;
    }
}

export default ProjectsDataApi