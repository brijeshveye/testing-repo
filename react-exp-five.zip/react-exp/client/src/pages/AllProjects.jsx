import React, { useEffect, useState } from 'react'
import UserDataApi from '../api/UserDataApi';
import AllProjectsSection from '../components/all-projects/AllProjectsSection';

const AllProjects = () => {
    const [projectsData, setProjectsData] = useState({});

    useEffect(() => {
        setProjectsData(UserDataApi.getMyProjects());
    }, []);

    return (
        <main className='wrapper mt-5'>
            <AllProjectsSection />
        </main>
    )
}

export default AllProjects