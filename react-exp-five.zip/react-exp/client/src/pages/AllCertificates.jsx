import React, { useEffect, useState } from 'react'


import AOS from 'aos';
import 'aos/dist/aos.css';
import AllCertificatesSection from '../components/all-certificates/AllCertificatesSection';
import UserDataApi from '../api/UserDataApi';


const AllCertificates = () => {

    return (
        <main className='wrapper mt-5 pt-5'>
            <AllCertificatesSection />
        </main>
    )
}

export default AllCertificates