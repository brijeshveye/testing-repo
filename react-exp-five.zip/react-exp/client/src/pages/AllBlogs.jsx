import React, { useEffect, useState } from 'react'
import UserDataApi from '../api/UserDataApi';
import AllBlogsSection from '../components/all-blogs/AllBlogsSection';

const AllBlogs = () => {
    const [blogsData, setBlogsData] = useState({});

    useEffect(() => {
        const blogs = UserDataApi.getBlogs();
        setBlogsData(blogs);
    }, []);

    return (
        <main className='wrapper mt-5 pt-5'>
            <AllBlogsSection />
        </main>
    )
}

export default AllBlogs