import React, { useEffect } from 'react'
import UserDataApi from '../../api/UserDataApi';
import TestimonialWidget from './widgets/TestimonialWidget';
import Slider from "react-slick";

const TestimonialsSection = () => {

    const [testimonialsData, setTestimonialsData] = React.useState([]);

    useEffect(() => {
        setTestimonialsData(UserDataApi.getTestimonials());
    }, []);

    const settings = {
        dots: false,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
        arrows: true
    };

    return (
        <>
            <section className="section testimonial-section bg-no-repeat bg-center"
                style={{ backgroundPosition: "center 125%", backgroundImage: `url(assets/img/bg-1.png)` }}>
                <div className="container">
                    <div className="section-heading">
                        <h3>What people say about us?</h3>
                    </div>

                    <Slider {...settings}>
                    {testimonialsData.map((testimonial, index) => (
                        <TestimonialWidget
                            key={index}
                            stars={testimonial.stars}
                            customerName={testimonial.customerName}
                            customerFeedback={testimonial.customerFeedback}
                            customerPosition={testimonial.customerPosition}
                        />
                    ))}
                </Slider>
                </div>
            </section>
        </>
    )
}

export default TestimonialsSection