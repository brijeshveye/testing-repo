import React, { useEffect, useState } from 'react'
import UserDataApi from '../../api/UserDataApi';
import EducationCardWidget from './widgets/EducationCardWidget';

const ExperienceSection = () => {
    const aosDuration = 700;

    const [educationData, setEducationData] = useState([]);

    useEffect(() => {
        setEducationData(UserDataApi.getEducation())
    }, []);

    return (
        <>
            <div className="about-sections bg1-img2 pt-5 pb-5 overflow-hidden">
                <div className="container">
                    <div className="row g-4 align-items-center">
                        <div className="col-lg-12">
                            <h5 className="head-text mtitle mb-5">
                                My Education
                            </h5>
                            <div className="about__onecontent">

                                {
                                    educationData.map((item, index) => (
                                        <EducationCardWidget
                                            key={index}
                                            courseTitle={item.title}
                                            institution={item.institution}
                                            description={item.description}
                                            years={item.years}
                                            aosDuration={aosDuration + 100 * index}
                                            oddEven={index % 2 === 0}
                                        />
                                    ))
                                }

                            </div>
                        </div>
                    </div>
                </div>
                <img src="assets/img/about/ellip.png" alt="img" className="ellip" />
                <img src="assets/img/about/ellip.png" alt="img" className="ellip2" />
            </div>
        </>
    )
}

export default ExperienceSection