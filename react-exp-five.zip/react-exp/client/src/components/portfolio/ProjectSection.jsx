import React, { useEffect, useState } from 'react'
import ProjectInfoWidget from './widgets/ProjectInfoWidget'

const ProjectSection = ({projectData}) => {


    return (
        <>
            <section className="protfolio__details pb-5">
                <div className="container">
                    <div className="details__bigthumb mb-60" data-aos="fade-up" data-aos-duration="1000">
                        <img src={projectData.bannerImage} alt="img" />
                        <div className="prot__detail__contact">
                            <h3>
                                Project Info
                            </h3>
                            <ProjectInfoWidget
                                client={projectData.client}
                                date={projectData.date}
                                category={projectData.category}
                                location={projectData.location}
                            />
                        </div>
                    </div>
                    <div className="details__textwrap">
                        {
                            projectData?.details?.section1 && (
                                <div className="text__box mb__cus60 mt-4" data-aos="fade-up" data-aos-duration="1400">
                                    <p className="fz-16 pra ttext__one">
                                        {projectData.details.section1.para1}
                                    </p>
                                    <p className="fz-16 pra">
                                        {projectData.details.section1.para2}
                                    </p>
                                </div>
                            )
                        }

                        {
                            projectData?.details?.section2 && (
                                <div className="text__box mb__cus60" data-aos="fade-up" data-aos-duration="1600">
                                    <h3 className="text__boxhead">
                                        {projectData.details.section2.title}
                                    </h3>
                                    <p className="fz-16 pra ttext__one">
                                        {projectData.details.section2.para}
                                    </p>
                                    <ul className="challenge__list">
                                        {
                                            projectData.details.section2.list.map((item, index) => (
                                                <li key={index}>{item}</li>
                                            ))
                                        }

                                    </ul>
                                </div>
                            )
                        }

                        {
                            projectData?.details?.section3 && (
                                <div className="text__box mb__cus60" data-aos="fade-up" data-aos-duration="1800">
                                    <h3 className="text__boxhead">
                                        {projectData.details.section3.title}
                                    </h3>
                                    <p className="fz-16 pra">
                                        {projectData.details.section3.para}
                                    </p>
                                </div>
                            )
                        }

                        {
                            projectData?.details?.section4 && (
                                <div className="details__small" data-aos="fade-up" data-aos-duration="2000">
                                    <div className="thumb">
                                        <img src={projectData.details.section4.image1} alt="img" />
                                    </div>
                                    <div className="thumb">
                                        <img src={projectData.details.section4.image2} alt="img" />
                                    </div>
                                </div>
                            )
                        }


                    </div>
                </div>
            </section>
        </>
    )
}

export default ProjectSection