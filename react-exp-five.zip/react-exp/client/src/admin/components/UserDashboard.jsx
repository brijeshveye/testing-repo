import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const UserDashboard = () => {
  const [userData, setUserData] = useState(null);

  const fetchUserData = async () => {
    const res = await axios.get('/api/user');
    setUserData(res.data);
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  if (!userData) return <div className="container mt-5">Loading...</div>;

  return (
    <main className='wrapper m-5 p-5'>
      <div className="container mt-4 mb-2">
        <h2>User Profile Dashboard</h2>

        {/* About Section */}
        {
          userData.aboutData && (
            <section className="mb-4">
              <h4>About</h4>
              <p><strong>Name:</strong> {userData.aboutData.name}</p>
              <p><strong>Email:</strong> {userData.aboutData.email}</p>
              <p><strong>Bio:</strong> {userData.aboutData.bio}</p>
              <Link to="/admin/user/edit/aboutData" className="btn btn-sm btn-warning">Edit</Link>
            </section>
          )
        }


        {/* Education Section */}
        {
          userData.educationData && userData.educationData.length > 0 && (
            <section className="mb-4">
              <h4>Education</h4>
              {userData.educationData.map((edu, index) => (
                <div key={index}>
                  <p><strong>{edu.title}</strong> - {edu.institution} ({edu.year})</p>
                </div>
              ))}
              <Link to="/admin/user/edit/educationData" className="btn btn-sm btn-warning">Edit</Link>
            </section>
          )
        }

        {/* Skills Section */}
        {
          userData.skillsData && userData.skillsData.length > 0 && (
            <section className="mb-4">
              <h4>Skills</h4>
              <ul>
                {userData.skillsData.map((skill, index) => (
                  <li key={index}>{skill}</li>
                ))}
              </ul>
              <Link to="/admin/user/edit/skillsData" className="btn btn-sm btn-warning">Edit</Link>
            </section>
          )
        }

        {/* Experience Section */}
        {
          userData.experienceData && userData.experienceData.length > 0 && (
            <section className="mb-4">
              <h4>Experience</h4>
              {userData.experienceData.map((exp, index) => (
                <div key={index}>
                  <p><strong>{exp.title}</strong> at {exp.company} ({exp.startYear} - {exp.endYear})</p>
                </div>
              ))}
              <Link to="/admin/user/edit/experienceData" className="btn btn-sm btn-warning">Edit</Link>
            </section>
          )
        }
        

        {/* Services Section */}
        {
          userData.servicesData && userData.servicesData.length > 0 && (
            <section className="mb-4">
              <h4>Services</h4>
              {userData.servicesData.map((service, index) => (
                <div key={index}>
                  <p><strong>{service.title}</strong>: {service.description}</p>
                </div>
              ))}
              <Link to="/admin/user/edit/servicesData" className="btn btn-sm btn-warning">Edit</Link>
            </section>
          )
        }

        {
          userData.certificatesData && userData.certificatesData.length > 0 && (
            <section className="mb-4">
              <h4>Certificates</h4>
              {userData.certificatesData.map((cert, index) => (
                <div key={index}>
                  <p><strong>{cert.title}</strong> - {cert.issuer} ({cert.year})</p>
                </div>
              ))}
              <Link to="/admin/user/edit/certificatesData" className="btn btn-sm btn-warning">Edit</Link>
            </section>
          )
        }

        {/* Testimonials Section */}
        {
          userData.testimonialsData && userData.testimonialsData.length > 0 && (
            <section className="mb-4">
              <h4>Testimonials</h4>
              {userData.testimonialsData.map((testimonial, index) => (
                <div key={index}>
                  <p><strong>{testimonial.customerName}</strong>: {testimonial.customerFeedback}</p>
                </div>
              ))}
              <Link to="/admin/user/edit/testimonialsData" className="btn btn-sm btn-warning">Edit</Link>
            </section>
          )
        }

        {/* Certificates and Testimonials can be added similarly */}
      </div>
    </main>

  );
};

export default UserDashboard;
