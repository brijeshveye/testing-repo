import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const EditSectionForm = () => {
  const { section } = useParams(); // e.g. "aboutData"
  const [data, setData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('/api/user').then(res => {
      setData(res.data[section]);
    });
  }, [section]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`/api/user/${section}`, data);
    navigate('/admin/user'); // Redirect to user dashboard after update
  };

  if (!data) return <div className="container mt-4">Loading...</div>;

  return (
    <main className='wrapper m-5 p-5'>
      <div className="container mt-4">
        <h3>Edit Section: {section}</h3>
        <form onSubmit={handleSubmit}>
          {Object.keys(data).map((key, i) => (
            typeof data[key] === 'string' ? (
              <div className="mb-3" key={i}>
                <label>{key}</label>
                <input
                  className="form-control"
                  name={key}
                  value={data[key]}
                  onChange={handleChange}
                />
              </div>
            ) : (
              typeof data[key] === 'object' && !Array.isArray(data[key]) ? (
                Object.keys(data[key]).map((subKey, j) => (
                  <div className="mb-3" key={j}>
                    <label>{subKey}</label>
                    <input
                      className="form-control"
                      name={subKey}
                      value={data[key][subKey]}
                      onChange={handleChange}
                    />
                  </div>
                ))
              ) : null
            )
          ))}

          <button className="btn btn-primary">Update</button>
        </form>
      </div>
    </main>

  );
};

export default EditSectionForm;
