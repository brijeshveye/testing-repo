import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const BlogForm = () => {
  const [form, setForm] = useState({
    title: '',
    description: '',
    slug: '',
    bannerImage: '',
    image: '',
    date: '',
    author: '',
    category: '',
    tags: [],
    details: {
      section1: { para1: '', para2: '' },
      section2: { quote: '', author: '' },
      section3: { para: '' },
      section4: { title: '', image1: '', para1: '', para2: '', list: [] }
    }
  });

  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = !!slug;

  useEffect(() => {
    if (isEdit) {
      axios.get(`/api/blogs/${slug}`).then(res => setForm(res.data));
    }
  }, [slug]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isEdit) {
      await axios.put(`/api/blogs/${slug}`, form);
    } else {
      await axios.post('/api/blogs', form);
    }
    navigate('/');
  };

  return (
    <main className='wrapper m-5 p-5'>
      <div className="container mt-4">
        <h2>{isEdit ? 'Edit Blog' : 'Create Blog'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label>Title</label>
            <input className="form-control" name="title" value={form.title} onChange={handleChange} required />
          </div>
          <div className="mb-3">
            <label>Description</label>
            <input className="form-control" name="description" value={form.description} onChange={handleChange} />
          </div>
          <div className="mb-3">
            <label>Slug</label>
            <input className="form-control" name="slug" value={form.slug} onChange={handleChange} required={!isEdit} disabled={isEdit} />
          </div>
          <div className="mb-3">
            <label>Author</label>
            <input className="form-control" name="author" value={form.author} onChange={handleChange} />
          </div>
          <div className="mb-3">
            <label>Date</label>
            <input type="date" className="form-control" name="date" value={form.date} onChange={handleChange} />
          </div>
          <div className="mb-3">
            <label>Category</label>
            <input className="form-control" name="category" value={form.category} onChange={handleChange} />
          </div>
          <button className="btn btn-success">{isEdit ? 'Update' : 'Create'}</button>
        </form>
      </div>
    </main>

  );
};

export default BlogForm;
