import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const BlogList = () => {
  const [blogs, setBlogs] = useState([]);

  const fetchBlogs = async () => {
    const res = await axios.get('/api/blogs');
    setBlogs(res.data);
  };

  const deleteBlog = async (slug) => {
    if (window.confirm('Are you sure you want to delete this blog?')) {
      await axios.delete(`/api/blogs/${slug}`);
      fetchBlogs(); // refresh list
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  return (
    <main className='wrapper m-5 p-5'>
      <div className="container mt-4">
        <h2>Blog List</h2>
        <Link className="btn btn-primary mb-3" to="/admin/blogs/create">Create New Blog</Link>
        <div className="list-group">
          {blogs.map(blog => (
            <div key={blog.slug} className="list-group-item d-flex justify-content-between align-items-center">
              <div>
                <h5>{blog.title}</h5>
                <p className="mb-1">{blog.description}</p>
                <small>{blog.date} | {blog.author}</small>
              </div>
              <div>
                <Link to={`/admin/blogs/edit/${blog.slug}`} className="btn btn-sm btn-warning me-2">Edit</Link>
                <button className="btn btn-sm btn-danger" onClick={() => deleteBlog(blog.slug)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </main>

  );
};

export default BlogList;
