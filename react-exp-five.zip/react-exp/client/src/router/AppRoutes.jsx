import React from 'react'
import { Route, Routes } from "react-router-dom";
import Home from '../pages/Home';
import ServiceDetails from '../pages/ServiceDetails';
import ProjectDetails from '../pages/ProjectDetails';
import BlogDetails from '../pages/BlogDetails';
import AllBlogs from '../pages/AllBlogs';
import AllProjects from '../pages/AllProjects';
import AllCertificates from '../pages/AllCertificates';

import ProjectList from '../admin/components/ProjectList';
import ProjectForm from '../admin/components/ProjectForm';

import BlogList from '../admin/components/BlogList';
import BlogForm from '../admin/components/BlogForm';

import UserDashboard from '../admin/components/UserDashboard';
import EditSectionForm from '../admin/components/EditSectionForm';

const AppRoutes = () => {
  return (
    <Routes>
        <Route path="/" element={ <Home /> } />

        <Route path="blogs" element={ <AllBlogs /> } />
        <Route path="certificates" element={ <AllCertificates /> } />
        <Route path="projects" element={ <AllProjects /> } />

      
        <Route path="blog/details/:slug" element={<BlogDetails />} />
        <Route path="project/details/:slug" element={<ProjectDetails />} />
        <Route path="service/details/:slug" element={<ServiceDetails />} />


        {/* Admin Routes */}
        <Route path="admin/user" element={<UserDashboard />} />
        <Route path="admin/user/edit/:section" element={<EditSectionForm />} />

        <Route path="admin/projects" element={<ProjectList />} />
        <Route path="admin/projects/create" element={<ProjectForm />} />
        <Route path="admin/projects/edit/:slug" element={<ProjectForm />} />

        <Route path="admin/blogs" element={<BlogList />} />
        <Route path="admin/blogs/create" element={<BlogForm />} />
        <Route path="admin/blogs/edit/:slug" element={<BlogForm />} />
        
        <Route path="*" element={<div>404 Not Found</div>} />
    </Routes>
  )
}

export default AppRoutes