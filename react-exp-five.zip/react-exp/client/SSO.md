# Open SSO (Single Sign On) [NodeJS]
Open SSO is a centralized user management system that using Single Sign On (SSO) for authentication method.
Open SSO follow the JWT standard for Oauth 2.0 as describe in RFC7519 and RFC9068.

# Why I should use this?
If you have multiple application but want a single login authentication
If you want a scalable user management system, JWT made everything stateless
If you want to built microservice architecture starting from user
Saving hours when you have a new project that require user management
Helps other people to have login system to their static websites
Make money online with put some ads, through sso login page

# Features :
Well Online Documentation
Easy Instalation and Configuration
Single Sign On / Same Sign On
Built-in Two/Multi Factor Authentication (2FA/MFA)
Built-in Webhook for broadcasting/event streaming
Enterprise logins: Google, Apple and Microsoft
Social logins: Twitter X, Facebook, Github and Gitlab
First REST API
All basic user management system, signin, signout, forgot/change password. etc
Support multiple databases, PostgreSQL, MySQL, MariaDB, default is SQLite3
Support multiple cache system, memory, file or redis. default is memory.
HTML Minified
Contact page + Mailer
Included Google Analytics
Easy verify Webmaster Tools
Anti Spam with Google reCaptcha v3
Fast, Low Overhead and Asynchronous Designed
Strong in High Traffic with Worker / CPU Cluster
Support Docker and Docker Compose
Light and Dark template

# Specs
Using Fastify v5 – The Fastest NodeJS Framework
Using sequelize to support multiple databases
Using Bootstrap 5 CSS framework
Using ETA Template Engine
Using JS Standard Code Style
Using Reactive UI with ReefJS v12 (no jQuery)

# Security
JWT Standard, RFC7519 and RFC9068
Built-in 2FA/MFA TOTP, RFC6238
Webhook protected with HMAC Signature
HTML auto encode the markup (Safe from XSS Attack)
98.5% Coverage Unit Test