const mongoose = require('mongoose');
const Service = require('../models/Service');

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://sanjayveye:nsnGBIJHzrzkmZw6@cluster0.czkcxtw.mongodb.net/');
    console.log('✅ MongoDB connected for testing');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
};

const testServices = async () => {
  try {
    await connectDB();
    
    // Get services for WhatIDo section (ordered by number field)
    const services = await Service.find({ isActive: true }).sort({ number: 1 }).limit(5);
    
    console.log('\n🛠️ Services for WhatIDo Section:');
    console.log('================================');
    
    services.forEach((service, index) => {
      console.log(`${index + 1}. ${service.title}`);
      console.log(`   Tag: ${service.tag}`);
      console.log(`   Number: ${service.number}`);
      console.log(`   BgText: ${service.bgText}`);
      console.log(`   Category: ${service.category}`);
      console.log(`   Slug: ${service.slug}`);
      console.log(`   Order: ${service.order}`);
      console.log('');
    });
    
    console.log(`📈 Total active services: ${services.length}`);
    
    // Simulate WhatIDo section data format
    console.log('\n🎯 WhatIDo Section Data Format:');
    console.log('===============================');
    
    services.forEach((service) => {
      const whatIdoData = {
        tag: service.tag,
        number: service.number,
        title: service.title,
        bgText: service.bgText || service.shortDescription,
        slug: service.slug
      };
      console.log(JSON.stringify(whatIdoData, null, 2));
    });
    
    mongoose.connection.close();
    console.log('\n✅ Test completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
};

testServices();
