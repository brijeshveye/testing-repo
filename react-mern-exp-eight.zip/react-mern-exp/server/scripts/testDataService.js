const dataService = require('../services/dataService');

/**
 * Test script to verify individual data files work correctly
 */
const testDataService = () => {
    console.log('🧪 Testing Data Service...\n');

    // Check if all data files exist
    console.log('📁 Checking data files...');
    const fileStatus = dataService.checkDataFiles();
    Object.entries(fileStatus).forEach(([section, exists]) => {
        console.log(`  ${section}: ${exists ? '✅' : '❌'}`);
    });
    console.log();

    // Test reading individual sections
    console.log('📖 Testing individual section reads...');
    const sections = ['aboutData', 'educationData', 'experienceData', 'servicesData', 'certificatesData', 'testimonialsData', 'skillsData'];
    
    sections.forEach(section => {
        try {
            const data = dataService.readDataSection(section);
            console.log(`  ${section}: ${data ? '✅' : '❌'} (${Array.isArray(data) ? data.length + ' items' : 'object'})`);
        } catch (error) {
            console.log(`  ${section}: ❌ Error - ${error.message}`);
        }
    });
    console.log();

    // Test reading all data combined
    console.log('📚 Testing combined data read...');
    try {
        const allData = dataService.readAllUserData();
        const sectionCount = Object.keys(allData).length;
        console.log(`  Combined data: ✅ (${sectionCount} sections)`);
        
        // Display structure
        Object.entries(allData).forEach(([section, data]) => {
            const type = Array.isArray(data) ? `array[${data.length}]` : 'object';
            console.log(`    ${section}: ${type}`);
        });
    } catch (error) {
        console.log(`  Combined data: ❌ Error - ${error.message}`);
    }
    console.log();

    // Test specific data access
    console.log('🎯 Testing specific data access...');
    try {
        const aboutData = dataService.readDataSection('aboutData');
        console.log(`  About name: ${aboutData.name || 'Not found'}`);
        
        const education = dataService.readDataSection('educationData');
        console.log(`  Education entries: ${education.length || 0}`);
        
        const certificates = dataService.readDataSection('certificatesData');
        console.log(`  Certificates: ${certificates.length || 0}`);
    } catch (error) {
        console.log(`  Specific access: ❌ Error - ${error.message}`);
    }
    console.log();

    console.log('✅ Data service test completed!');
};

// Run test if this file is executed directly
if (require.main === module) {
    testDataService();
}

module.exports = { testDataService };
