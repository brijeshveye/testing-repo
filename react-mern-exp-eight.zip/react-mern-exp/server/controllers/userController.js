const User = require('../models/User');

// Get full user data
const getUserData = async (req, res) => {
    try {
        let user = await User.findOne({ userId: 'portfolio_owner' });
        
        if (!user) {
            // Create default user if none exists
            user = new User({ userId: 'portfolio_owner' });
            await user.save();
        }
        
        res.json(user);
    } catch (error) {
        console.error('Error fetching user data:', error);
        res.status(500).json({ message: 'Error fetching user data', error: error.message });
    }
};

// Update a specific section like aboutData, educationData, etc.
const updateSection = async (req, res) => {
    try {
        const section = req.params.section;
        
        // Valid sections that can be updated
        const validSections = [
            'aboutData', 
            'educationData', 
            'experienceData', 
            'skillsData', 
            'certificatesData', 
            'testimonialsData', 
            'servicesData', 
            'socialLinks'
        ];
        
        if (!validSections.includes(section)) {
            return res.status(400).json({ message: `Invalid section '${section}'` });
        }

        let user = await User.findOne({ userId: 'portfolio_owner' });
        
        if (!user) {
            // Create new user if none exists
            user = new User({ userId: 'portfolio_owner' });
        }

        // Update the specific section
        user[section] = req.body;
        
        console.log(`Updating section: ${section}`, user[section]);
        
        await user.save();

        res.json({ 
            message: `Section '${section}' updated successfully`, 
            data: user[section] 
        });
    } catch (error) {
        console.error('Error updating section:', error);
        res.status(500).json({ 
            message: 'Error updating section', 
            error: error.message 
        });
    }
};

// Add new item to array sections (education, experience, skills, etc.)
const addItem = async (req, res) => {
    try {
        const section = req.params.section;
        
        // Array sections that support adding items
        const arraySections = [
            'educationData', 
            'experienceData', 
            'skillsData', 
            'certificatesData', 
            'testimonialsData', 
            'servicesData'
        ];
        
        if (!arraySections.includes(section)) {
            return res.status(400).json({ 
                message: `Section '${section}' does not support adding items` 
            });
        }

        let user = await User.findOne({ userId: 'portfolio_owner' });
        
        if (!user) {
            user = new User({ userId: 'portfolio_owner' });
        }

        // Add new item to the array
        user[section].push(req.body);
        
        await user.save();

        res.json({ 
            message: `Item added to '${section}' successfully`, 
            data: user[section] 
        });
    } catch (error) {
        console.error('Error adding item:', error);
        res.status(500).json({ 
            message: 'Error adding item', 
            error: error.message 
        });
    }
};

// Update specific item in array sections
const updateItem = async (req, res) => {
    try {
        const { section, index } = req.params;
        
        const arraySections = [
            'educationData', 
            'experienceData', 
            'skillsData', 
            'certificatesData', 
            'testimonialsData', 
            'servicesData'
        ];
        
        if (!arraySections.includes(section)) {
            return res.status(400).json({ 
                message: `Section '${section}' does not support item updates` 
            });
        }

        const user = await User.findOne({ userId: 'portfolio_owner' });
        
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const itemIndex = parseInt(index);
        if (itemIndex < 0 || itemIndex >= user[section].length) {
            return res.status(400).json({ message: 'Invalid item index' });
        }

        // Update the specific item
        user[section][itemIndex] = req.body;
        
        await user.save();

        res.json({ 
            message: `Item updated in '${section}' successfully`, 
            data: user[section] 
        });
    } catch (error) {
        console.error('Error updating item:', error);
        res.status(500).json({ 
            message: 'Error updating item', 
            error: error.message 
        });
    }
};

// Delete specific item from array sections
const deleteItem = async (req, res) => {
    try {
        const { section, index } = req.params;
        
        const arraySections = [
            'educationData', 
            'experienceData', 
            'skillsData', 
            'certificatesData', 
            'testimonialsData', 
            'servicesData'
        ];
        
        if (!arraySections.includes(section)) {
            return res.status(400).json({ 
                message: `Section '${section}' does not support item deletion` 
            });
        }

        const user = await User.findOne({ userId: 'portfolio_owner' });
        
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }

        const itemIndex = parseInt(index);
        if (itemIndex < 0 || itemIndex >= user[section].length) {
            return res.status(400).json({ message: 'Invalid item index' });
        }

        // Remove the specific item
        user[section].splice(itemIndex, 1);
        
        await user.save();

        res.json({ 
            message: `Item deleted from '${section}' successfully`, 
            data: user[section] 
        });
    } catch (error) {
        console.error('Error deleting item:', error);
        res.status(500).json({ 
            message: 'Error deleting item', 
            error: error.message 
        });
    }
};

module.exports = {
    getUserData,
    updateSection,
    addItem,
    updateItem,
    deleteItem
};
