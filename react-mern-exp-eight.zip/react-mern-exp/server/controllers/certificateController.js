const Certificate = require('../models/Certificate');

// Get all certificates with filtering
const getCertificates = async (req, res) => {
  try {
    const { 
      category, 
      featured, 
      isActive, 
      limit, 
      year,
      issuer,
      search
    } = req.query;

    // Build filter object
    let filter = {};

    if (category && category !== 'all') {
      filter.category = new RegExp(category, 'i');
    }

    if (featured !== undefined) {
      filter.featured = featured === 'true';
    }

    if (isActive !== undefined) {
      filter.isActive = isActive === 'true';
    }

    if (year) {
      filter.year = year;
    }

    if (issuer) {
      filter.issuer = new RegExp(issuer, 'i');
    }

    if (search) {
      filter.$or = [
        { title: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') },
        { issuer: new RegExp(search, 'i') },
        { category: new RegExp(search, 'i') }
      ];
    }

    // Build query
    let query = Certificate.find(filter).sort({ order: 1, createdAt: -1 });

    // Apply limit if specified
    if (limit) {
      query = query.limit(parseInt(limit));
    }

    const certificates = await query;
    res.json(certificates);
  } catch (error) {
    console.error('Error fetching certificates:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get certificate by slug
const getCertificateBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const certificate = await Certificate.findOne({ slug, isActive: true });
    
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }

    res.json(certificate);
  } catch (error) {
    console.error('Error fetching certificate:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Create new certificate
const createCertificate = async (req, res) => {
  try {
    const certificateData = req.body;

    // Generate slug if not provided
    if (!certificateData.slug && certificateData.title) {
      certificateData.slug = certificateData.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
    }

    // Check if slug already exists
    const existingCertificate = await Certificate.findOne({ slug: certificateData.slug });
    if (existingCertificate) {
      certificateData.slug = `${certificateData.slug}-${Date.now()}`;
    }

    const certificate = new Certificate(certificateData);
    await certificate.save();

    res.status(201).json(certificate);
  } catch (error) {
    console.error('Error creating certificate:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update certificate
const updateCertificate = async (req, res) => {
  try {
    const { slug } = req.params;
    const updateData = req.body;

    const certificate = await Certificate.findOneAndUpdate(
      { slug },
      updateData,
      { new: true, runValidators: true }
    );

    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }

    res.json(certificate);
  } catch (error) {
    console.error('Error updating certificate:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Delete certificate
const deleteCertificate = async (req, res) => {
  try {
    const { slug } = req.params;
    
    const certificate = await Certificate.findOneAndDelete({ slug });
    
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }

    res.json({ message: 'Certificate deleted successfully' });
  } catch (error) {
    console.error('Error deleting certificate:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update certificates order
const updateCertificatesOrder = async (req, res) => {
  try {
    const { certificates } = req.body;

    // Update order for each certificate
    const updatePromises = certificates.map((cert, index) => 
      Certificate.findByIdAndUpdate(cert._id, { order: index + 1 })
    );

    await Promise.all(updatePromises);

    res.json({ message: 'Certificate order updated successfully' });
  } catch (error) {
    console.error('Error updating certificates order:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Toggle certificate featured status
const toggleFeatured = async (req, res) => {
  try {
    const { slug } = req.params;
    
    const certificate = await Certificate.findOne({ slug });
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }

    certificate.featured = !certificate.featured;
    await certificate.save();

    res.json(certificate);
  } catch (error) {
    console.error('Error toggling featured status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Toggle certificate active status
const toggleActive = async (req, res) => {
  try {
    const { slug } = req.params;
    
    const certificate = await Certificate.findOne({ slug });
    if (!certificate) {
      return res.status(404).json({ error: 'Certificate not found' });
    }

    certificate.isActive = !certificate.isActive;
    await certificate.save();

    res.json(certificate);
  } catch (error) {
    console.error('Error toggling active status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = {
  getCertificates,
  getCertificateBySlug,
  createCertificate,
  updateCertificate,
  deleteCertificate,
  updateCertificatesOrder,
  toggleFeatured,
  toggleActive
};
