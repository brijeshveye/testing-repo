const Testimonial = require('../models/Testimonial');

// GET all testimonials
const getAllTestimonials = async (req, res) => {
  try {
    const { isActive = true, featured, limit } = req.query;
    
    const filter = {};
    if (isActive !== undefined) filter.isActive = isActive === 'true';
    if (featured !== undefined) filter.featured = featured === 'true';
    
    let query = Testimonial.find(filter).sort({ order: 1, dateReceived: -1 });
    
    if (limit) {
      query = query.limit(parseInt(limit));
    }
    
    const testimonials = await query;
    res.json(testimonials);
  } catch (error) {
    console.error('Error fetching testimonials:', error);
    res.status(500).json({ message: 'Error fetching testimonials', error: error.message });
  }
};

// GET testimonial by slug
const getTestimonialBySlug = async (req, res) => {
  try {
    const testimonial = await Testimonial.findOne({ slug: req.params.slug, isActive: true });
    if (!testimonial) {
      return res.status(404).json({ message: 'Testimonial not found' });
    }
    res.json(testimonial);
  } catch (error) {
    console.error('Error fetching testimonial:', error);
    res.status(500).json({ message: 'Error fetching testimonial', error: error.message });
  }
};

// CREATE new testimonial
const createTestimonial = async (req, res) => {
  try {
    const testimonialData = req.body;
    
    // Check if slug already exists
    if (testimonialData.slug) {
      const existingTestimonial = await Testimonial.findOne({ slug: testimonialData.slug });
      if (existingTestimonial) {
        return res.status(409).json({ message: 'Testimonial with this slug already exists' });
      }
    }

    // Generate slug from customer name and company if not provided
    if (!testimonialData.slug && testimonialData.customerName) {
      const baseSlug = `${testimonialData.customerName}-${testimonialData.company || 'testimonial'}`
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      
      // Ensure uniqueness
      let slug = baseSlug;
      let counter = 1;
      while (await Testimonial.findOne({ slug })) {
        slug = `${baseSlug}-${counter}`;
        counter++;
      }
      testimonialData.slug = slug;
    }

    const testimonial = new Testimonial(testimonialData);
    await testimonial.save();
    
    res.status(201).json(testimonial);
  } catch (error) {
    console.error('Error creating testimonial:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        message: 'Validation error', 
        errors: Object.keys(error.errors).map(key => ({
          field: key,
          message: error.errors[key].message
        }))
      });
    }
    
    res.status(500).json({ message: 'Error creating testimonial', error: error.message });
  }
};

// UPDATE testimonial
const updateTestimonial = async (req, res) => {
  try {
    const { slug } = req.params;
    const updateData = req.body;
    
    // Don't allow updating slug through this endpoint
    delete updateData.slug;
    
    const testimonial = await Testimonial.findOneAndUpdate(
      { slug: slug },
      updateData,
      { new: true, runValidators: true }
    );
    
    if (!testimonial) {
      return res.status(404).json({ message: 'Testimonial not found' });
    }
    
    res.json(testimonial);
  } catch (error) {
    console.error('Error updating testimonial:', error);
    
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        message: 'Validation error', 
        errors: Object.keys(error.errors).map(key => ({
          field: key,
          message: error.errors[key].message
        }))
      });
    }
    
    res.status(500).json({ message: 'Error updating testimonial', error: error.message });
  }
};

// DELETE testimonial (soft delete)
const deleteTestimonial = async (req, res) => {
  try {
    const { slug } = req.params;
    
    const testimonial = await Testimonial.findOneAndUpdate(
      { slug: slug },
      { isActive: false },
      { new: true }
    );
    
    if (!testimonial) {
      return res.status(404).json({ message: 'Testimonial not found' });
    }
    
    res.json({ message: 'Testimonial deleted successfully', testimonial });
  } catch (error) {
    console.error('Error deleting testimonial:', error);
    res.status(500).json({ message: 'Error deleting testimonial', error: error.message });
  }
};

// UPDATE testimonial order
const updateTestimonialOrder = async (req, res) => {
  try {
    const { testimonials } = req.body; // Array of { slug, order }
    
    const updatePromises = testimonials.map(item => 
      Testimonial.findOneAndUpdate(
        { slug: item.slug },
        { order: item.order },
        { new: true }
      )
    );
    
    await Promise.all(updatePromises);
    res.json({ message: 'Testimonial order updated successfully' });
  } catch (error) {
    console.error('Error updating testimonial order:', error);
    res.status(500).json({ message: 'Error updating testimonial order', error: error.message });
  }
};

module.exports = {
  getAllTestimonials,
  getTestimonialBySlug,
  createTestimonial,
  updateTestimonial,
  deleteTestimonial,
  updateTestimonialOrder
};
