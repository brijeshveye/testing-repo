const Characteristic = require('../models/Characteristic');

// Get all characteristics
const getAllCharacteristics = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search,
      featured,
      isActive,
      category,
      sortBy = 'order',
      sortOrder = 'asc'
    } = req.query;

    // Build filter object
    const filter = {};
    
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { shortDescription: { $regex: search, $options: 'i' } },
        { category: { $regex: search, $options: 'i' } }
      ];
    }

    if (featured !== undefined) {
      filter.featured = featured === 'true';
    }

    if (isActive !== undefined) {
      filter.isActive = isActive === 'true';
    }

    if (category) {
      filter.category = { $regex: category, $options: 'i' };
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Add secondary sort by order for consistent ordering
    if (sortBy !== 'order') {
      sort.order = 1;
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    // Execute query
    const characteristics = await Characteristic.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limitNum);

    const total = await Characteristic.countDocuments(filter);

    res.json({
      characteristics,
      pagination: {
        currentPage: pageNum,
        totalPages: Math.ceil(total / limitNum),
        totalItems: total,
        itemsPerPage: limitNum,
        hasNext: pageNum < Math.ceil(total / limitNum),
        hasPrev: pageNum > 1
      }
    });
  } catch (error) {
    console.error('Error fetching characteristics:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get characteristic by slug
const getCharacteristicBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const { includeInactive } = req.query;
    
    // Build filter - for admin/edit, we might want to include inactive characteristics
    const filter = { slug };
    if (!includeInactive || includeInactive !== 'true') {
      filter.isActive = true;
    }

    const characteristic = await Characteristic.findOne(filter);

    if (!characteristic) {
      return res.status(404).json({ message: 'Characteristic not found' });
    }

    res.json(characteristic);
  } catch (error) {
    console.error('Error fetching characteristic by slug:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Create new characteristic
const createCharacteristic = async (req, res) => {
  try {
    const characteristic = new Characteristic(req.body);
    await characteristic.save();
    res.status(201).json({
      success: true,
      message: 'Characteristic created successfully',
      data: characteristic
    });
  } catch (error) {
    console.error('Error creating characteristic:', error);
    if (error.code === 11000) {
      res.status(400).json({ 
        success: false,
        message: 'A characteristic with this slug already exists' 
      });
    } else {
      res.status(500).json({ 
        success: false,
        message: 'Server error', 
        error: error.message 
      });
    }
  }
};

// Update characteristic
const updateCharacteristic = async (req, res) => {
  try {
    const { slug } = req.params;
    const characteristic = await Characteristic.findOneAndUpdate(
      { slug },
      req.body,
      { new: true, runValidators: true }
    );

    if (!characteristic) {
      return res.status(404).json({ 
        success: false,
        message: 'Characteristic not found' 
      });
    }

    res.json({
      success: true,
      message: 'Characteristic updated successfully',
      data: characteristic
    });
  } catch (error) {
    console.error('Error updating characteristic:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

// Delete characteristic
const deleteCharacteristic = async (req, res) => {
  try {
    const { slug } = req.params;
    const characteristic = await Characteristic.findOneAndDelete({ slug });

    if (!characteristic) {
      return res.status(404).json({ 
        success: false,
        message: 'Characteristic not found' 
      });
    }

    res.json({
      success: true,
      message: 'Characteristic deleted successfully'
    });
  } catch (error) {
    console.error('Error deleting characteristic:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

// Toggle featured status
const toggleFeatured = async (req, res) => {
  try {
    const { slug } = req.params;
    const characteristic = await Characteristic.findOne({ slug });

    if (!characteristic) {
      return res.status(404).json({ 
        success: false,
        message: 'Characteristic not found' 
      });
    }

    characteristic.featured = !characteristic.featured;
    await characteristic.save();

    res.json({
      success: true,
      message: `Characteristic ${characteristic.featured ? 'featured' : 'unfeatured'} successfully`,
      data: characteristic
    });
  } catch (error) {
    console.error('Error toggling featured status:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

// Toggle active status
const toggleActive = async (req, res) => {
  try {
    const { slug } = req.params;
    const characteristic = await Characteristic.findOne({ slug });

    if (!characteristic) {
      return res.status(404).json({ 
        success: false,
        message: 'Characteristic not found' 
      });
    }

    characteristic.isActive = !characteristic.isActive;
    await characteristic.save();

    res.json({
      success: true,
      message: `Characteristic ${characteristic.isActive ? 'activated' : 'deactivated'} successfully`,
      data: characteristic
    });
  } catch (error) {
    console.error('Error toggling active status:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

// Update characteristic order
const updateCharacteristicOrder = async (req, res) => {
  try {
    const { characteristics } = req.body;

    if (!Array.isArray(characteristics)) {
      return res.status(400).json({ 
        success: false,
        message: 'Characteristics array is required' 
      });
    }

    // Update each characteristic's order
    const updatePromises = characteristics.map((item, index) => {
      return Characteristic.findOneAndUpdate(
        { slug: item.slug },
        { order: index + 1 },
        { new: true }
      );
    });

    await Promise.all(updatePromises);

    res.json({
      success: true,
      message: 'Characteristic order updated successfully'
    });
  } catch (error) {
    console.error('Error updating characteristic order:', error);
    res.status(500).json({ 
      success: false,
      message: 'Server error', 
      error: error.message 
    });
  }
};

// Get characteristic statistics
const getCharacteristicStats = async (req, res) => {
  try {
    const total = await Characteristic.countDocuments();
    const active = await Characteristic.countDocuments({ isActive: true });
    const featured = await Characteristic.countDocuments({ featured: true });
    const inactive = total - active;

    // Get characteristics by category
    const categoryStats = await Characteristic.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      total,
      active,
      inactive,
      featured,
      categoryStats: categoryStats.map(stat => ({
        category: stat._id || 'Uncategorized',
        count: stat.count
      }))
    });
  } catch (error) {
    console.error('Error fetching characteristic stats:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getAllCharacteristics,
  getCharacteristicBySlug,
  createCharacteristic,
  updateCharacteristic,
  deleteCharacteristic,
  toggleFeatured,
  toggleActive,
  updateCharacteristicOrder,
  getCharacteristicStats
};
