const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const Upload = require('../models/Upload');
const router = express.Router();

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, '../uploads');

if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer for file uploads using memory storage
const storage = multer.memoryStorage();

// File filter for images only
const fileFilter = (req, file, cb) => {
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only JPEG, PNG, GIF, and WebP images are allowed.'), false);
  }
};

const upload = multer({
  storage: storage,
  fileFilter: fileFilter,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  }
});

// Single image upload
router.post('/upload', upload.single('image'), async (req, res) => {
  try {
    console.log('Upload request received');
    console.log('req.body:', req.body);
    console.log('req.file:', req.file ? 'File received' : 'No file');
    
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const category = req.body.category || 'general';
    console.log(`Category received: "${category}"`);
    
    const categoryDir = path.join(uploadsDir, category);
    console.log(`Category directory: ${categoryDir}`);
    
    // Create category directory if it doesn't exist
    if (!fs.existsSync(categoryDir)) {
      fs.mkdirSync(categoryDir, { recursive: true });
      console.log(`Created directory: ${categoryDir}`);
    } else {
      console.log(`Directory already exists: ${categoryDir}`);
    }
    
    // Generate unique filename
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(req.file.originalname);
    const baseName = path.basename(req.file.originalname, ext).replace(/[^a-zA-Z0-9]/g, '_');
    const filename = baseName + '_' + uniqueSuffix + ext;
    
    // Save file to correct directory
    const filePath = path.join(categoryDir, filename);
    console.log(`Saving file to: ${filePath}`);
    fs.writeFileSync(filePath, req.file.buffer);
    console.log(`File saved successfully: ${filename}`);
    
    const fileUrl = `/uploads/${category}/${filename}`;
    
    // Save upload info to MongoDB
    const uploadDoc = new Upload({
      filename: filename,
      originalName: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      category: category,
      url: fileUrl,
      uploadedBy: req.body.uploadedBy || 'admin'
    });
    
    await uploadDoc.save();
    
    console.log(`File uploaded: ${filename} to category: ${category}`);
    
    res.json({
      success: true,
      url: fileUrl,
      filename: filename,
      originalName: req.file.originalname,
      size: req.file.size,
      category: category,
      uploadId: uploadDoc._id
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'File upload failed' });
  }
});

// Multiple images upload
router.post('/upload-multiple', upload.array('images', 10), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    const category = req.body.category || 'general';
    const categoryDir = path.join(uploadsDir, category);
    
    // Create category directory if it doesn't exist
    if (!fs.existsSync(categoryDir)) {
      fs.mkdirSync(categoryDir, { recursive: true });
    }
    
    const uploadedFiles = [];
    const uploadDocs = [];
    
    // Process each file and save to MongoDB
    for (const file of req.files) {
      // Generate unique filename
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const ext = path.extname(file.originalname);
      const baseName = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9]/g, '_');
      const filename = baseName + '_' + uniqueSuffix + ext;
      
      // Save file to correct directory
      const filePath = path.join(categoryDir, filename);
      fs.writeFileSync(filePath, file.buffer);
      
      const fileUrl = `/uploads/${category}/${filename}`;
      
      const uploadDoc = new Upload({
        filename: filename,
        originalName: file.originalname,
        mimetype: file.mimetype,
        size: file.size,
        category: category,
        url: fileUrl,
        uploadedBy: req.body.uploadedBy || 'admin'
      });
      
      uploadDocs.push(uploadDoc);
      uploadedFiles.push({
        url: fileUrl,
        filename: filename,
        originalName: file.originalname,
        size: file.size,
        uploadId: uploadDoc._id
      });
    }
    
    // Save all upload documents
    await Upload.insertMany(uploadDocs);
    
    console.log(`${req.files.length} files uploaded to category: ${category}`);
    
    res.json({
      success: true,
      files: uploadedFiles,
      category: category
    });
  } catch (error) {
    console.error('Multiple upload error:', error);
    res.status(500).json({ error: 'File upload failed' });
  }
});

// Delete image
router.delete('/delete/:category/:filename', async (req, res) => {
  try {
    const { category, filename } = req.params;
    const filePath = path.join(uploadsDir, category, filename);
    
    // Delete file from filesystem
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      
      // Mark as inactive in MongoDB (soft delete)
      await Upload.findOneAndUpdate(
        { filename, category },
        { isActive: false },
        { new: true }
      );
      
      res.json({ success: true, message: 'File deleted successfully' });
    } else {
      res.status(404).json({ error: 'File not found' });
    }
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ error: 'File deletion failed' });
  }
});

// List images in category
router.get('/list/:category', async (req, res) => {
  try {
    const category = req.params.category || 'general';
    
    // Get files from MongoDB
    const uploads = await Upload.find({ 
      category, 
      isActive: true 
    }).sort({ createdAt: -1 });
    
    const files = uploads.map(upload => ({
      filename: upload.filename,
      url: upload.url,
      size: upload.size,
      uploadDate: upload.createdAt,
      category: upload.category,
      originalName: upload.originalName,
      uploadId: upload._id
    }));
    
    res.json({ files });
  } catch (error) {
    console.error('List error:', error);
    res.status(500).json({ error: 'Failed to list files' });
  }
});

// Get all uploads (admin route)
router.get('/all', async (req, res) => {
  try {
    const { category, isActive = true } = req.query;
    const filter = { isActive: isActive === 'true' };
    
    if (category) {
      filter.category = category;
    }
    
    const uploads = await Upload.find(filter)
      .sort({ createdAt: -1 })
      .limit(100); // Limit for performance
    
    res.json({ uploads });
  } catch (error) {
    console.error('Get all uploads error:', error);
    res.status(500).json({ error: 'Failed to fetch uploads' });
  }
});

// Test route to verify category parameter
router.post('/test-category', upload.none(), (req, res) => {
  console.log('Test route - req.body:', req.body);
  res.json({
    received_category: req.body.category,
    all_body_params: req.body
  });
});

// Resume upload route (PDF files only)
const resumeFilter = (req, file, cb) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Only PDF files are allowed for resumes.'), false);
  }
};

const resumeUpload = multer({
  storage: storage,
  fileFilter: resumeFilter,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit for resumes
  }
});

router.post('/resume', resumeUpload.single('file'), async (req, res) => {
  try {
    console.log('Resume upload request received');
    console.log('File details:', req.file ? `${req.file.originalname} (${req.file.size} bytes)` : 'No file');
    
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const category = 'resume';
    const categoryDir = path.join(uploadsDir, category);
    
    console.log('Upload directory:', uploadsDir);
    console.log('Category directory:', categoryDir);
    
    // Create category directory if it doesn't exist
    if (!fs.existsSync(categoryDir)) {
      console.log('Creating resume directory...');
      fs.mkdirSync(categoryDir, { recursive: true });
      console.log('Resume directory created');
    } else {
      console.log('Resume directory already exists');
    }

    // Generate unique filename for resume
    const timestamp = Date.now();
    const filename = `resume_${timestamp}.pdf`;
    
    // Save file to resume directory
    const filePath = path.join(categoryDir, filename);
    console.log('Saving file to:', filePath);
    
    fs.writeFileSync(filePath, req.file.buffer);
    
    // Verify file was created
    if (fs.existsSync(filePath)) {
      const stats = fs.statSync(filePath);
      console.log(`File saved successfully: ${filename} (${stats.size} bytes)`);
    } else {
      console.error('File was not created!');
      return res.status(500).json({ error: 'Failed to save file' });
    }
    
    const fileUrl = `/uploads/${category}/${filename}`;
    console.log('File URL:', fileUrl);
    
    // Save upload info to MongoDB
    const uploadDoc = new Upload({
      filename: filename,
      originalName: req.file.originalname,
      mimetype: req.file.mimetype,
      size: req.file.size,
      category: category,
      url: fileUrl,
      uploadedBy: req.body.uploadedBy || 'admin'
    });
    
    await uploadDoc.save();
    
    console.log(`Resume uploaded successfully: ${filename}`);
    
    res.json({
      success: true,
      url: fileUrl,
      filename: filename,
      originalName: req.file.originalname,
      size: req.file.size,
      uploadId: uploadDoc._id
    });
  } catch (error) {
    console.error('Resume upload error:', error);
    res.status(500).json({ error: 'Resume upload failed: ' + error.message });
  }
});

// Test route to check static file serving
router.get('/test-static', (req, res) => {
  const uploadsPath = path.join(__dirname, '../uploads');
  const resumePath = path.join(uploadsPath, 'resume');
  
  console.log('Uploads directory:', uploadsPath);
  console.log('Resume directory:', resumePath);
  
  const uploadsExists = fs.existsSync(uploadsPath);
  const resumeExists = fs.existsSync(resumePath);
  
  let resumeFiles = [];
  if (resumeExists) {
    try {
      resumeFiles = fs.readdirSync(resumePath);
    } catch (error) {
      console.error('Error reading resume directory:', error);
    }
  }
  
  res.json({
    uploadsPath,
    resumePath,
    uploadsExists,
    resumeExists,
    resumeFiles,
    staticServing: 'Static files should be served from /uploads'
  });
});

module.exports = router;
