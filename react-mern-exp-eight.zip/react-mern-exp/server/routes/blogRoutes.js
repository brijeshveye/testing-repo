const express = require('express');
const router = express.Router();
const {
    getAllBlogs,
    getBlogBySlug,
    createBlog,
    updateBlog,
    deleteBlog
} = require('../controllers/blogController');

router.get('/', getAllBlogs);
router.get('/:slug', getBlogBySlug);
router.post('/', createBlog);
router.put('/:slug', updateBlog);
router.delete('/:slug', deleteBlog);

module.exports = router;
