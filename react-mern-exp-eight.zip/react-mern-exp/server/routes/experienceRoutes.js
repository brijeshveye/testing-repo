const express = require('express');
const router = express.Router();
const {
  getAllExperience,
  getExperienceBySlug,
  createExperience,
  updateExperience,
  deleteExperience,
  toggleFeatured,
  toggleActive,
  updateExperienceOrder,
  getExperienceStats
} = require('../controllers/experienceController');

// Get experience statistics
router.get('/stats', getExperienceStats);

// Get all experience records
router.get('/', getAllExperience);

// Get experience by slug
router.get('/:slug', getExperienceBySlug);

// Create new experience record
router.post('/', createExperience);

// Update experience record
router.put('/:slug', updateExperience);

// Delete experience record
router.delete('/:slug', deleteExperience);

// Toggle featured status
router.put('/:slug/toggle-featured', toggleFeatured);

// Toggle active status
router.put('/:slug/toggle-active', toggleActive);

// Update experience order
router.put('/order/update', updateExperienceOrder);

module.exports = router;
