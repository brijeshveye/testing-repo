const mongoose = require('mongoose');

// About Data Schema
const aboutDataSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  phone: {
    type: String,
    default: ''
  },
  address: {
    type: String,
    default: ''
  },
  bio: {
    type: String,
    default: ''
  },
  afterBio: {
    type: String,
    default: ''
  },
  tagline: {
    type: String,
    default: ''
  },
  birthday: {
    type: String,
    default: ''
  },
  age: {
    type: String,
    default: ''
  },
  location: {
    type: String,
    default: ''
  },
  profileImage: {
    type: String,
    default: ''
  },
  resume: {
    type: String,
    default: ''
  },
  skype: {
    type: String,
    default: ''
  }
}, { _id: false });

// User Schema (Portfolio Owner)
const userSchema = new mongoose.Schema({
  userId: {
    type: String,
    required: true,
    unique: true,
    default: 'portfolio_owner'
  },
  aboutData: {
    type: aboutDataSchema,
    default: {}
  },
  socialLinks: {
    linkedin: { type: String, default: '' },
    github: { type: String, default: '' },
    twitter: { type: String, default: '' },
    instagram: { type: String, default: '' },
    facebook: { type: String, default: '' },
    website: { type: String, default: '' }
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('User', userSchema);
