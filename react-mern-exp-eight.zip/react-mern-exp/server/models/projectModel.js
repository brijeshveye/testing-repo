const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/projectsData.json');

const readProjects = () => {
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
};

const writeProjects = (projects) => {
    fs.writeFileSync(filePath, JSON.stringify(projects, null, 4));
};

module.exports = {
    readProjects,
    writeProjects
};
