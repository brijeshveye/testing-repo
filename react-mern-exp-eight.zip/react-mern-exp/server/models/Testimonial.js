const mongoose = require('mongoose');

const testimonialSchema = new mongoose.Schema({
  customerName: {
    type: String,
    required: true,
    trim: true
  },
  customerFeedback: {
    type: String,
    required: true,
    trim: true
  },
  customerImage: {
    type: String,
    default: ''
  },
  company: {
    type: String,
    default: '',
    trim: true
  },
  designation: {
    type: String,
    default: '',
    trim: true
  },
  rating: {
    type: Number,
    min: 1,
    max: 5,
    default: 5
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  featured: {
    type: Boolean,
    default: false
  },
  projectRelated: {
    type: String, // Project slug if testimonial is related to a specific project
    default: ''
  },
  dateReceived: {
    type: Date,
    default: Date.now
  },
  order: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Index for better query performance
testimonialSchema.index({ isActive: 1, featured: 1 });
testimonialSchema.index({ order: 1, dateReceived: -1 });

// Generate slug from customer name and company before saving
testimonialSchema.pre('save', function(next) {
  if (!this.slug) {
    const baseSlug = `${this.customerName}-${this.company || 'testimonial'}`
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
    this.slug = baseSlug;
  }
  next();
});

module.exports = mongoose.model('Testimonial', testimonialSchema);
