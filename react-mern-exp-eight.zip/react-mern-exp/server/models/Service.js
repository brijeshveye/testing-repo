const mongoose = require('mongoose');

// Widget Schema for dynamic content (reusable)
const widgetSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['heading', 'paragraph', 'list', 'spacer', 'image', 'youtube', 'video']
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  }
}, { _id: false });

// Service details schema
const serviceDetailsSchema = new mongoose.Schema({
  section1: {
    para1: String,
    para2: String
  },
  section2: {
    image1: String,
    image2: String,
    image3: String,
    image4: String
  },
  section3: {
    title: String,
    para: String
  },
  section4: {
    image1: String,
    video: String
  }
}, { _id: false });

// FAQ Schema
const faqSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  }
}, { _id: false });

const serviceSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  },
  shortDescription: {
    type: String,
    trim: true
  },
  icon: {
    type: String,
    trim: true
  },
  iconClass: {
    type: String,
    trim: true
  },
  image: {
    type: String,
    trim: true
  },
  bannerImage: {
    type: String,
    trim: true
  },
  widgets: {
    type: [widgetSchema],
    default: []
  },
  details: {
    type: serviceDetailsSchema,
    default: {}
  },
  faqs: {
    type: [faqSchema],
    default: []
  },
  category: {
    type: String,
    trim: true,
    default: 'general'
  },
  tag: {
    type: String,
    trim: true,
    default: 'Service'
  },
  number: {
    type: Number,
    default: 1
  },
  bgText: {
    type: String,
    trim: true
  },
  technologies: [{
    type: String,
    trim: true
  }],
  features: [{
    type: String,
    trim: true
  }],
  pricing: {
    startingPrice: {
      type: Number,
      min: 0
    },
    currency: {
      type: String,
      default: 'USD'
    },
    pricingModel: {
      type: String,
      enum: ['hourly', 'fixed', 'monthly', 'custom'],
      default: 'custom'
    }
  },
  deliveryTime: {
    type: String,
    trim: true
  },
  portfolio: [{
    title: String,
    image: String,
    url: String
  }],
  testimonials: [{
    clientName: String,
    feedback: String,
    rating: {
      type: Number,
      min: 1,
      max: 5
    }
  }],
  link: {
    type: String,
    trim: true
  },
  backTitle: {
    type: String,
    trim: true
  },
  backDescription: {
    type: String,
    trim: true
  },
  processSteps: [{
    step: Number,
    title: String,
    description: String
  }],
  featured: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  slug: {
    type: String,
    unique: true,
    trim: true
  },
  order: {
    type: Number,
    default: 0
  },
  seoTitle: {
    type: String,
    trim: true
  },
  seoDescription: {
    type: String,
    trim: true
  },
  seoKeywords: [{
    type: String,
    trim: true
  }]
}, {
  timestamps: true
});

// Create slug before saving
serviceSchema.pre('save', function(next) {
  if (!this.slug && this.title) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }
  next();
});

// Create indexes
serviceSchema.index({ featured: 1, isActive: 1 });
serviceSchema.index({ category: 1 });
serviceSchema.index({ order: 1 });

module.exports = mongoose.model('Service', serviceSchema);
