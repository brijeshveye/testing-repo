const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    // MongoDB connection string - replace with your MongoDB URI
    const mongoURI = process.env.MONGODB_URI || '';
    const mongoDatabase = process.env.MONGODB_DATABASE || 'br-portfolio';

    const conn = await mongoose.connect(mongoURI, {
      dbName: mongoDatabase,
    });

    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error('Error connecting to MongoDB:', error.message);
    process.exit(1);
  }
};

module.exports = connectDB;
