const fs = require('fs');
const path = require('path');

// File paths for individual data files
const dataFilePaths = {
    aboutData: path.join(__dirname, '../data/aboutData.json'),
    educationData: path.join(__dirname, '../data/educationData.json'),
    experienceData: path.join(__dirname, '../data/experienceData.json'),
    servicesData: path.join(__dirname, '../data/servicesData.json'),
    processData: path.join(__dirname, '../data/processData.json'),
    certificatesData: path.join(__dirname, '../data/certificatesData.json'),
    testimonialsData: path.join(__dirname, '../data/testimonialsData.json'),
    skillsData: path.join(__dirname, '../data/skillsData.json')
};

/**
 * Read a specific data section from its individual JSON file
 * @param {string} section - The section name (e.g., 'aboutData', 'educationData')
 * @returns {object|array} The data from the JSON file
 */
const readDataSection = (section) => {
    try {
        const filePath = dataFilePaths[section];
        if (!filePath || !fs.existsSync(filePath)) {
            console.warn(`Data file not found for section: ${section}`);
            return section === 'aboutData' ? {} : [];
        }
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error(`Error reading ${section}:`, error);
        return section === 'aboutData' ? {} : [];
    }
};

/**
 * Write data to a specific section's JSON file
 * @param {string} section - The section name
 * @param {object|array} data - The data to write
 */
const writeDataSection = (section, data) => {
    try {
        const filePath = dataFilePaths[section];
        if (!filePath) {
            throw new Error(`Invalid section: ${section}`);
        }
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    } catch (error) {
        console.error(`Error writing ${section}:`, error);
        throw error;
    }
};

/**
 * Read all user data from individual files and combine into one object
 * @returns {object} Combined user data object
 */
const readAllUserData = () => {
    try {
        const userData = {};
        
        Object.keys(dataFilePaths).forEach(section => {
            userData[section] = readDataSection(section);
        });
        
        return userData;
    } catch (error) {
        console.error('Error reading all user data:', error);
        return {};
    }
};

/**
 * Write complete user data by splitting it into individual files
 * @param {object} userData - Complete user data object
 */
const writeAllUserData = (userData) => {
    try {
        Object.keys(dataFilePaths).forEach(section => {
            if (userData[section] !== undefined) {
                writeDataSection(section, userData[section]);
            }
        });
    } catch (error) {
        console.error('Error writing all user data:', error);
        throw error;
    }
};

/**
 * Check if all data files exist
 * @returns {object} Status of each file
 */
const checkDataFiles = () => {
    const status = {};
    Object.keys(dataFilePaths).forEach(section => {
        status[section] = fs.existsSync(dataFilePaths[section]);
    });
    return status;
};

module.exports = {
    readDataSection,
    writeDataSection,
    readAllUserData,
    writeAllUserData,
    checkDataFiles,
    dataFilePaths
};
