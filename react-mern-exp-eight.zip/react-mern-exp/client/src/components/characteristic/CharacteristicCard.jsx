import React from 'react';
import { Link } from 'react-router-dom';

const CharacteristicCard = ({ characteristic, featured = false }) => {
  const {
    title,
    description,
    shortDescription,
    iconClass,
    icon,
    image,
    category,
    value,
    unit,
    color,
    slug,
    tags,
    backTitle,
    backDescription
  } = characteristic;

  return (
    <div className={`col-lg-4 col-md-6 mb-4 ${featured ? 'featured-characteristic' : ''}`}>
      <div className="card h-100 characteristic-card shadow-sm">
        {featured && (
          <div className="featured-badge">
            <i className="fas fa-star"></i>
            <span>Featured</span>
          </div>
        )}
        
        <div className="card-body text-center">
          {/* Icon/Image */}
          <div className="characteristic-icon mb-3">
            {image ? (
              <img 
                src={image} 
                alt={title}
                className="img-fluid rounded-circle"
                style={{ width: '80px', height: '80px', objectFit: 'cover' }}
              />
            ) : (
              <div 
                className="icon-wrapper d-inline-flex align-items-center justify-content-center rounded-circle"
                style={{ 
                  width: '80px', 
                  height: '80px', 
                  backgroundColor: color || '#007bff',
                  color: 'white'
                }}
              >
                {iconClass ? (
                  <i className={`${iconClass} fa-2x`}></i>
                ) : icon ? (
                  <img src={icon} alt={title} style={{ width: '40px', height: '40px' }} />
                ) : (
                  <i className="fas fa-star fa-2x"></i>
                )}
              </div>
            )}
          </div>

          {/* Title */}
          <h5 className="card-title mb-2">{title}</h5>

          {/* Description */}
          <p className="card-text text-muted mb-3">
            {shortDescription || description}
          </p>

          {/* Value/Progress */}
          {value !== undefined && (
            <div className="characteristic-value mb-3">
              <div className="d-flex justify-content-between align-items-center mb-1">
                <span className="small text-muted">Level</span>
                <span className="small font-weight-bold">{value}{unit}</span>
              </div>
              <div className="progress" style={{ height: '8px' }}>
                <div 
                  className="progress-bar" 
                  role="progressbar" 
                  style={{ 
                    width: `${value}%`,
                    backgroundColor: color || '#007bff'
                  }}
                  aria-valuenow={value} 
                  aria-valuemin="0" 
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          )}

          {/* Category */}
          {category && (
            <div className="mb-2">
              <span className="badge bg-light text-dark">
                {category}
              </span>
            </div>
          )}

          {/* Tags */}
          {tags && tags.length > 0 && (
            <div className="characteristic-tags mb-3">
              {tags.slice(0, 3).map((tag, index) => (
                <span key={index} className="badge bg-outline-secondary me-1 mb-1">
                  {tag}
                </span>
              ))}
              {tags.length > 3 && (
                <span className="badge bg-outline-muted">
                  +{tags.length - 3} more
                </span>
              )}
            </div>
          )}

          {/* Action Button */}
          <div className="card-actions">
            <Link 
              to={`/characteristics/${slug}`} 
              className="btn btn-outline-primary btn-sm"
            >
              Learn More
            </Link>
          </div>
        </div>

        {/* Back side content for flip effect (optional) */}
        {(backTitle || backDescription) && (
          <div className="card-back">
            <div className="card-body text-center">
              <h6 className="mb-2">{backTitle || title}</h6>
              <p className="small text-muted">
                {backDescription || description}
              </p>
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        .characteristic-card {
          transition: transform 0.3s ease, box-shadow 0.3s ease;
          position: relative;
          overflow: hidden;
        }

        .characteristic-card:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
        }

        .featured-characteristic .characteristic-card {
          border: 2px solid #ffc107;
        }

        .featured-badge {
          position: absolute;
          top: 10px;
          right: 10px;
          background: linear-gradient(45deg, #ffc107, #ffb300);
          color: white;
          padding: 5px 10px;
          border-radius: 15px;
          font-size: 0.75rem;
          z-index: 1;
        }

        .featured-badge i {
          margin-right: 5px;
        }

        .icon-wrapper {
          transition: transform 0.3s ease;
        }

        .characteristic-card:hover .icon-wrapper {
          transform: scale(1.1);
        }

        .progress-bar {
          transition: width 0.5s ease;
        }

        .characteristic-tags .badge {
          font-size: 0.7rem;
        }

        .card-back {
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: white;
          opacity: 0;
          transform: rotateY(180deg);
          transition: opacity 0.3s ease, transform 0.3s ease;
        }

        .characteristic-card:hover .card-back {
          opacity: 1;
          transform: rotateY(0deg);
        }
      `}</style>
    </div>
  );
};

export default CharacteristicCard;
