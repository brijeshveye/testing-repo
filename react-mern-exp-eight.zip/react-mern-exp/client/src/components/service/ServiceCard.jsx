import React from 'react';

const ServiceCard = ({ service, onEdit, onDelete, onToggleFeatured, onToggleActive, showActions = true }) => {
  const formatPrice = (pricing) => {
    if (!pricing || !pricing.startingPrice) return 'Contact for pricing';
    
    const { startingPrice, currency, pricingModel } = pricing;
    const currencySymbol = currency === 'USD' ? '$' : currency;
    
    switch (pricingModel) {
      case 'hourly':
        return `${currencySymbol}${startingPrice}/hour`;
      case 'monthly':
        return `${currencySymbol}${startingPrice}/month`;
      case 'fixed':
        return `Starting at ${currencySymbol}${startingPrice}`;
      default:
        return 'Contact for pricing';
    }
  };

  return (
    <div className="col-md-6 col-lg-4 mb-4">
      <div className="card h-100 shadow-sm">
        {service.image && (
          <div className="card-img-top" style={{ height: '200px', overflow: 'hidden' }}>
            <img 
              src={service.image} 
              alt={service.title}
              className="img-fluid w-100 h-100"
              style={{ objectFit: 'cover' }}
            />
          </div>
        )}
        
        <div className="card-body d-flex flex-column">
          <div className="d-flex justify-content-between align-items-start mb-2">
            <h5 className="card-title text-primary mb-0">{service.title}</h5>
            <div className="d-flex gap-1">
              {service.featured && (
                <span className="badge bg-warning text-dark">
                  <i className="fas fa-star"></i>
                </span>
              )}
              {!service.isActive && (
                <span className="badge bg-secondary">
                  <i className="fas fa-eye-slash"></i> Hidden
                </span>
              )}
            </div>
          </div>

          {service.category && (
            <div className="mb-2">
              <span className="badge bg-light text-dark">{service.category}</span>
            </div>
          )}

          {service.iconClass && (
            <div className="mb-3 text-center">
              <i className={`${service.iconClass} fa-3x text-primary`}></i>
            </div>
          )}
          
          <p className="card-text">
            {service.shortDescription || service.description}
          </p>

          {service.technologies && service.technologies.length > 0 && (
            <div className="mb-3">
              <small className="text-muted">Technologies:</small>
              <div className="d-flex flex-wrap gap-1 mt-1">
                {service.technologies.slice(0, 4).map((tech, index) => (
                  <span key={index} className="badge bg-primary">
                    {tech}
                  </span>
                ))}
                {service.technologies.length > 4 && (
                  <span className="badge bg-secondary">
                    +{service.technologies.length - 4} more
                  </span>
                )}
              </div>
            </div>
          )}

          {service.features && service.features.length > 0 && (
            <div className="mb-3">
              <small className="text-muted">Key Features:</small>
              <ul className="list-unstyled mt-1">
                {service.features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="small">
                    <i className="fas fa-check text-success me-1"></i>
                    {feature}
                  </li>
                ))}
                {service.features.length > 3 && (
                  <li className="small text-muted">
                    +{service.features.length - 3} more features...
                  </li>
                )}
              </ul>
            </div>
          )}

          <div className="mt-auto">
            {service.pricing && (
              <div className="mb-3">
                <div className="h6 text-success">{formatPrice(service.pricing)}</div>
                {service.deliveryTime && (
                  <small className="text-muted">
                    <i className="fas fa-clock me-1"></i>
                    Delivery: {service.deliveryTime}
                  </small>
                )}
              </div>
            )}

            {showActions && (
              <div className="pt-3 border-top">
                <div className="d-flex justify-content-between align-items-center">
                  <div className="btn-group" role="group">
                    <button
                      className="btn btn-outline-primary btn-sm"
                      onClick={() => onEdit(service)}
                      title="Edit Service"
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                    <button
                      className={`btn btn-sm ${service.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                      onClick={() => onToggleFeatured(service.slug)}
                      title="Toggle Featured"
                    >
                      <i className="fas fa-star"></i>
                    </button>
                    <button
                      className={`btn btn-sm ${service.isActive ? 'btn-success' : 'btn-outline-success'}`}
                      onClick={() => onToggleActive(service.slug)}
                      title="Toggle Visibility"
                    >
                      <i className={`fas ${service.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                    </button>
                  </div>
                  <button
                    className="btn btn-outline-danger btn-sm"
                    onClick={() => onDelete(service)}
                    title="Delete Service"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
