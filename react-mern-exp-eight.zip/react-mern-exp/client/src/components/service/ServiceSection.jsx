import React, { useEffect, useState } from 'react'
import ServiceFaqCardWidget from './widgets/ServiceFaqCardWidget'
import ServiceWidgets from './widgets/ServiceWidgets'
import ServiceDataApi from '../../api/ServiceDataApi';

const ServiceSection = ({ serviceData }) => {
    const [serviceListData, setServiceListData] = useState([]);
    const [loading, setLoading] = useState(true);

    // Function to render widgets dynamically
    const renderWidget = (widget, index) => {
        const WidgetComponent = ServiceWidgets[widget.type];
        if (!WidgetComponent) {
            console.warn(`Unknown widget type: ${widget.type}`);
            return null;
        }
        return <WidgetComponent key={widget.id || index} data={widget.data} />;
    };

    // Function to render legacy content if widgets are not available
    const renderLegacyContent = () => {
        return (
            <>
                <div className="text__box mb__cus60" data-aos="fade-up" data-aos-duration="1400">
                    <h3 className="textt36 d-block">
                        About {serviceData.title}
                    </h3>
                    {serviceData?.details?.section1 && (
                        <>
                            <p className="fz-16 pra ttext__one">
                                {serviceData?.details?.section1?.para1}
                            </p>
                            <p className="fz-16 pra">
                                {serviceData?.details?.section1?.para2}
                            </p>
                        </>
                    )}
                </div>

                {serviceData?.details?.section2 && (
                    <div className="row g-2 mb__cus60">
                        <div className="col-lg-6 col-md-6 col-sm-6">
                            <div className="w-100">
                                <img src={serviceData?.details?.section2?.image1} alt="img" className="w-100" />
                            </div>
                        </div>
                        <div className="col-lg-6 col-md-6 col-sm-6">
                            <div className="w-100">
                                <img src={serviceData?.details?.section2?.image2} alt="img" className="w-100" />
                            </div>
                        </div>
                        <div className="col-lg-6 col-md-6 col-sm-6">
                            <div className="w-100">
                                <img src={serviceData?.details?.section2?.image3} alt="img" className="w-100" />
                            </div>
                        </div>
                        <div className="col-lg-6 col-md-6 col-sm-6">
                            <div className="w-100">
                                <img src={serviceData?.details?.section2?.image4} alt="img" className="w-100" />
                            </div>
                        </div>
                    </div>
                )}

                {serviceData?.details?.section3 && (
                    <div className="text__box mb__cus60" data-aos="fade-up" data-aos-duration="800">
                        <h3 className="textt36 d-block">
                            {serviceData?.details?.section3?.title}
                        </h3>
                        <p className="fz-16 pra">
                            {serviceData?.details?.section3?.para}
                        </p>
                    </div>
                )}

                {serviceData?.details?.section4 && (
                    <div className="paythumb position-relative">
                        <img src={serviceData?.details?.section4?.image1} alt="img" />
                        <a href={serviceData?.details?.section4?.video} className="video__80 video-btn">
                            <i className="bi bi-play-fill"></i>
                        </a>
                    </div>
                )}
            </>
        );
    };

    useEffect(() => {
        fetchServiceList();
    }, []);

    const fetchServiceList = async () => {
        try {
            setLoading(true);
            const data = await ServiceDataApi.getServiceList();
            setServiceListData(data);
        } catch (error) {
            console.error('Error fetching service list:', error);
            setServiceListData([]);
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <section className="service__details pb-5">
                <div className="container">
                    <div className="row g-4">
                        <div className="col-lg-8">
                            <div className="ser__left__details">
                                <div className="thumb">
                                    <img src={serviceData.bannerImage} alt="img" />
                                </div>
                                
                                {/* Dynamic Widget Rendering for Service Content */}
                                {serviceData?.widgets && serviceData.widgets.length > 0 ? (
                                    serviceData.widgets.map((widget, index) => renderWidget(widget, index))
                                ) : (
                                    renderLegacyContent()
                                )}

                                {serviceData?.faqs && serviceData?.faqs.length > 0 && (
                                    <div className="ser__components">
                                        <h2 className="whites mb-5">
                                            Questions ? You're Covered
                                        </h2>
                                        <div className="accordion" id="accordionExample">
                                            {serviceData?.faqs?.map((faq, index) => (
                                                <ServiceFaqCardWidget key={index} title={faq.title} description={faq.description} id={index} />
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                        <div className="col-lg-4">
                            <div className="service__right__wrap">
                                <div className="service__rightbox mb-4">
                                    <form action="#0" className="w-100">
                                        <h3>
                                            Search
                                        </h3>
                                        <div className="d-flex searchbox align-items-center">
                                            <input type="text" placeholder="Search Here" />
                                            <i className="bi bi-search"></i>
                                        </div>
                                    </form>
                                </div>
                                <div className="service__rightbox mb-3">
                                    <h3>
                                        Service List
                                    </h3>
                                    {loading ? (
                                        <div className="text-center py-3">
                                            <div className="spinner-border spinner-border-sm" role="status">
                                                <span className="visually-hidden">Loading...</span>
                                            </div>
                                        </div>
                                    ) : (
                                        Array.isArray(serviceListData) && serviceListData.map((service, index) => (
                                            <a href={service.link} className="link__box mb-2" key={index}>
                                                {service.title}
                                                <i className="bi bi-chevron-right"></i>
                                            </a>
                                        ))
                                    )}

                                </div>
                                <div className="service__rightbox">
                                    <div className="thumb">
                                        <img src="/assets/img/contact/ser-detialcontact.png" alt="img" />
                                        <a href="#0" className="cmn--btn">
                                            <span className="text-white">
                                                Contact Me
                                            </span>
                                            <span>
                                                <i className="bi bi-arrow-right"></i>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default ServiceSection