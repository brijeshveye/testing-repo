import React, { useEffect, useState } from 'react'
import ProjectInfoWidget from './widgets/ProjectInfoWidget'
import ProjectWidgets from './widgets/ProjectWidgets'

const ProjectSection = ({projectData}) => {

    // Function to render widgets dynamically
    const renderWidget = (widget, index) => {
        const WidgetComponent = ProjectWidgets[widget.type];
        if (!WidgetComponent) {
            console.warn(`Unknown widget type: ${widget.type}`);
            return null;
        }
        return <WidgetComponent key={widget.id || index} data={widget.data} />;
    };

    // Function to render legacy content if widgets are not available
    const renderLegacyContent = () => {
        return (
            <>
                {projectData?.details?.section1 && (
                    <div className="text__box mb__cus60 mt-4" data-aos="fade-up" data-aos-duration="1400">
                        <p className="fz-16 pra ttext__one">
                            {projectData.details.section1.para1}
                        </p>
                        <p className="fz-16 pra">
                            {projectData.details.section1.para2}
                        </p>
                    </div>
                )}

                {projectData?.details?.section2 && (
                    <div className="text__box mb__cus60" data-aos="fade-up" data-aos-duration="1600">
                        <h3 className="text__boxhead">
                            {projectData.details.section2.title}
                        </h3>
                        <p className="fz-16 pra ttext__one">
                            {projectData.details.section2.para}
                        </p>
                        <ul className="challenge__list">
                            {projectData.details.section2.list.map((item, index) => (
                                <li key={index}>{item}</li>
                            ))}
                        </ul>
                    </div>
                )}

                {projectData?.details?.section3 && (
                    <div className="text__box mb__cus60" data-aos="fade-up" data-aos-duration="1800">
                        <h3 className="text__boxhead">
                            {projectData.details.section3.title}
                        </h3>
                        <p className="fz-16 pra">
                            {projectData.details.section3.para}
                        </p>
                    </div>
                )}

                {projectData?.details?.section4 && (
                    <div className="details__small" data-aos="fade-up" data-aos-duration="2000">
                        <div className="thumb">
                            <img src={projectData.details.section4.image1} alt="img" />
                        </div>
                        <div className="thumb">
                            <img src={projectData.details.section4.image2} alt="img" />
                        </div>
                    </div>
                )}
            </>
        );
    };

    return (
        <>
            <section className="protfolio__details pb-5">
                <div className="container">
                    <div className="details__bigthumb mb-60" data-aos="fade-up" data-aos-duration="1000">
                        <img src={projectData.bannerImage} alt="img" />
                        <div className="prot__detail__contact">
                            <h3>
                                Project Info
                            </h3>
                            <ProjectInfoWidget
                                client={projectData.client}
                                date={projectData.date}
                                category={projectData.category}
                                location={projectData.location}
                            />
                        </div>
                    </div>
                    <div className="details__textwrap">
                        {/* Dynamic Widget Rendering */}
                        {projectData?.widgets && projectData.widgets.length > 0 ? (
                            projectData.widgets.map((widget, index) => renderWidget(widget, index))
                        ) : (
                            renderLegacyContent()
                        )}
                    </div>
                </div>
            </section>
        </>
    )
}

export default ProjectSection