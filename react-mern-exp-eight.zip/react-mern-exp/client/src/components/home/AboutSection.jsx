import React, { useEffect, useState } from 'react'
import axios from 'axios';

const AboutSection = () => {

    const [aboutData, setAboutData] = useState({});

    useEffect(() => {
        const fetchAboutData = async () => {
            try {
                const response = await axios.get('/api/user');
                setAboutData(response.data.aboutData || {});
            } catch (error) {
                console.error('Error fetching about data:', error);
                setAboutData({});
            }
        };
        
        fetchAboutData();
    }, []);

    return (
        <>
            <section id="about" data-scroll-index="1" className="section about-section">
                <div className="container">
                    <div className="section-heading">
                        <h3>About Me</h3>
                    </div>
                    <div className="row align-items-center gy-4">
                        <div className="col-lg-6">
                            <img src="assets/img/about-me.png" title="" alt="" />
                        </div>
                        <div className="col-lg-6 ps-xl-5">
                            <div className="about-intro">
                                <h6>MY INTRO</h6>
                                <h2>I am <span>{aboutData.name}</span></h2>
                                <h5>{aboutData.tagline}</h5>
                                <div className="text">
                                    <p>{aboutData.bio}</p>
                                    <p>{aboutData.afterBio}</p>
                                </div>
                                <div className="row">
                                    <div className="col-sm-6">
                                        <ul>
                                            {
                                                aboutData.birthday && (
                                                    <li>
                                                        <span>Birthday :</span> <label>{aboutData.birthday ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                            {
                                                aboutData.age && (
                                                    <li>
                                                        <span>Age :</span> <label>{aboutData.age ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                            <li>
                                                <span>Address :</span> <label>{aboutData.address ?? 'N/A'}</label>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="col-sm-6">
                                        <ul>
                                            {
                                                aboutData.phone && (
                                                    <li>
                                                        <span>Phone :</span> <label>{aboutData.phone ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                            <li>
                                                <span>Email :</span> <label>{aboutData.email ?? 'N/A'}</label>
                                            </li>
                                            {
                                                aboutData.skype && (
                                                    <li>
                                                        <span>Skype :</span> <label>{aboutData.skype ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                        </ul>
                                    </div>
                                </div>
                                <div className="btn-bar">
                                    {aboutData.resume ? (
                                        <a href={aboutData.resume} target="_blank" rel="noopener noreferrer" className="px-btn px-btn-primary">
                                            <i className="fas fa-file-pdf me-2"></i>VIEW RESUME
                                        </a>
                                    ) : (
                                        <span className="px-btn px-btn-secondary disabled">
                                            <i className="fas fa-file-pdf me-2"></i>NO RESUME AVAILABLE
                                        </span>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default AboutSection