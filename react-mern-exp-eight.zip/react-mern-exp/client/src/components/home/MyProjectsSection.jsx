import React, { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom';
import UserDataApi from '../../api/UserDataApi';
import ProjectCardWidget from './widgets/ProjectCardWidget';

import { motion, AnimatePresence } from 'framer-motion';

const MyProjectsSection = () => {
    const [projectsData, setProjectsData] = useState([]);
    const [projectCategories, setProjectCategories] = useState([]);
    const [activeCategory, setActiveCategory] = useState('all');


    useEffect(() => {
        const fetchProjectData = async () => {
            try {
                const categories = await UserDataApi.getProjectCategories();
                const projects = await UserDataApi.getProjectsForHome();
                
                setProjectCategories(categories);
                setProjectsData(projects);
            } catch (error) {
                console.error('Error fetching project data:', error);
                setProjectCategories(['all']);
                setProjectsData([]);
            }
        };

        fetchProjectData();
    }, []);

    const filteredProjects =
        activeCategory === 'all'
            ? projectsData
            : projectsData.filter((proj) =>
                proj.category?.toLowerCase()?.includes(activeCategory)
            );

    const generateLink = (slug) => {
        return `/project/details/${slug}`;
    }

    return (
        <>
            <section id="portfolio" className="br-portfolio padding-tb-80">
                <div className="container">
                    <div className="section-title">
                        <h2>My <span>Projects</span></h2>
                        <span className="ligh-title">My Work</span>
                    </div>
                    <div className="row m-b-minus-24px">
                        <div className="br-portfolio-content">
                            <div>
                                <div className="row">
                                    <div className="col-sm-12">
                                        <div className="portfolio-tabs">
                                            <ul>
                                                {projectCategories.map((cat) => (
                                                    <li
                                                        key={cat}
                                                        className={`filter ${activeCategory === cat ? 'active' : ''}`}
                                                        onClick={() => setActiveCategory(cat)}
                                                        style={{ cursor: 'pointer' }}
                                                    >
                                                        {cat.toUpperCase()}
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="col-md-12 col-sm-12">
                                        <div className="portfolio-content-items">
                                            <div className="row m-b-minus-30px">

                                                <AnimatePresence mode="popLayout">
                                                    {filteredProjects.map((project, index) => (
                                                        <motion.div
                                                            key={project.title + index}
                                                            layout
                                                            initial={{ opacity: 0, scale: 0.9, y: 20 }}
                                                            animate={{ opacity: 1, scale: 1, y: 0 }}
                                                            exit={{ opacity: 0, scale: 0.9, y: 20 }}
                                                            transition={{ duration: 0.3 }}
                                                            className="col-lg-6 col-md-6 col-sm-12 mb-4"
                                                        >
                                                            <ProjectCardWidget
                                                                key={project.title + index}
                                                                title={project.title}
                                                                description={project.description}
                                                                domains={project.domains}
                                                                image={project.image}
                                                                date={project.date}
                                                                client={project.client}
                                                                techStack={project.techStack}
                                                                type={project.type}
                                                                url={generateLink(project.slug)}
                                                                category={project.category}
                                                            />
                                                        </motion.div>
                                                    ))}
                                                </AnimatePresence>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    {/* View All Projects Button */}
                    <div className="row mt-4">
                        <div className="col-12 text-center">
                            <Link to="/projects" className="px-btn px-btn-primary">
                                <span>View All Projects</span>
                                <i className="fas fa-arrow-right ms-2"></i>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default MyProjectsSection