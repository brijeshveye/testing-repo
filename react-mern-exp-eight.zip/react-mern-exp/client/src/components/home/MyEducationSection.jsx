import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import EducationDataApi from '../../api/EducationDataApi';
import EducationCardWidget from './widgets/EducationCardWidget';

const MyEducationSection = () => {
    const aosDuration = 700;

    const [educationData, setEducationData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchEducationData();
    }, []);

    const fetchEducationData = async () => {
        try {
            setLoading(true);
            const data = await EducationDataApi.getEducationForHome(4); // Get top 4 for home
            setEducationData(data);
        } catch (error) {
            console.error('Error fetching education data:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="about-sections bg1-img2 pt-5 pb-5 overflow-hidden">
                <div className="container">
                    <div className="row g-4 align-items-center">
                        <div className="col-lg-12">
                            <h5 className="head-text mtitle mb-5">
                                My Education
                            </h5>
                            <div className="text-center">
                                <div className="spinner-border text-primary" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <>
            <div className="about-sections bg1-img2 pt-5 pb-5 overflow-hidden">
                <div className="container">
                    <div className="row g-4 align-items-center">
                        <div className="col-lg-12">
                            <h5 className="head-text mtitle mb-5">
                                My Education
                            </h5>
                            <div className="about__onecontent">

                                {
                                    educationData.map((item, index) => (
                                        <EducationCardWidget
                                            key={item._id || index}
                                            courseTitle={item.title}
                                            institution={item.institution}
                                            description={item.description}
                                            years={`${new Date(item.startDate).getFullYear()} - ${item.current ? 'Present' : new Date(item.endDate).getFullYear()}`}
                                            aosDuration={aosDuration + 100 * index}
                                            oddEven={index % 2 === 0}
                                        />
                                    ))
                                }

                            </div>
                            
                            {/* View All Education Link */}
                            {educationData.length > 0 && (
                                <div className="text-center mt-4">
                                    <Link to="/education" className="px-btn px-btn-primary">
                                        <span>View All Education</span>
                                        <i className="fas fa-arrow-right ms-2"></i>
                                    </Link>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
                <img src="assets/img/about/ellip.png" alt="img" className="ellip" />
                <img src="assets/img/about/ellip.png" alt="img" className="ellip2" />
            </div>
        </>
    )
}

export default MyEducationSection