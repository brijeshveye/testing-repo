import React from 'react'

const ExperienceCardWidget = (props) => {
    return (
        <>
            <li className="timeline-item" data-aos="fade-up" data-aos-duration="1000"
                data-aos-delay={props.aosDelay}>
                <div className="timeline-info">
                    <span>{props.duration}</span>
                </div>
                <div className="timeline-content">
                    <h5 className="timeline-title">{props.company}<span className="sub">- {props.role}</span></h5>
                    <p>{props.description}</p>
                </div>
            </li>
        </>
    )
}

ExperienceCardWidget.propTypes = {
    duration: "from - to",
    company: "Company Name",
    role: "Role Title",
    description: "Job description goes here.",
    aosDelay: "500"
}

export default ExperienceCardWidget