import React from 'react';
import {
  WIDGET_TYPES,
  HeadingWidget,
  ParagraphWidget,
  ListWidget,
  SpacerWidget,
  ImageWidget,
  YouTubeWidget
} from '../admin/components/widgets/DynamicWidgets';

const ContentRenderer = ({ widgets = [] }) => {
  if (!widgets || widgets.length === 0) {
    return null;
  }

  const renderWidget = (widget, index) => {
    const commonProps = {
      data: widget.data,
      isEditing: false // Always false for frontend display
    };

    let WidgetComponent;
    switch (widget.type) {
      case WIDGET_TYPES.HEADING:
        WidgetComponent = HeadingWidget;
        break;
      case WIDGET_TYPES.PARAGRAPH:
        WidgetComponent = ParagraphWidget;
        break;
      case WIDGET_TYPES.LIST:
        WidgetComponent = ListWidget;
        break;
      case WIDGET_TYPES.SPACER:
        WidgetComponent = SpacerWidget;
        break;
      case WIDGET_TYPES.IMAGE:
        WidgetComponent = ImageWidget;
        break;
      case WIDGET_TYPES.YOUTUBE:
        WidgetComponent = YouTubeWidget;
        break;
      default:
        return null;
    }

    return (
      <div key={widget.id || index} className="dynamic-content-widget">
        <WidgetComponent {...commonProps} />
      </div>
    );
  };

  return (
    <div className="dynamic-content-container">
      {widgets.map((widget, index) => renderWidget(widget, index))}
    </div>
  );
};

export default ContentRenderer;
