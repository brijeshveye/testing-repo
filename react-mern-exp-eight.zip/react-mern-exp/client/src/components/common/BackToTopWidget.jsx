import React, { useEffect, useState } from 'react'

const BackToTopWidget = () => {
    const [visible, setVisible] = useState(false);

    const scrollToTop = (e) => {
        e.preventDefault();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    useEffect(() => {
        const handleScroll = () => {
            setVisible(window.scrollY > 300);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    return (
        <>
            <a href="#" id="back_to_top" className={`back-to-top ${visible ? 'visible' : 'hidden'}`} onClick={scrollToTop} aria-label="Back to top" title="Back to top" style={{ display: visible ? 'inline-flex' : 'none' }}>
                <img src="/assets/img/arrow.svg" title="" alt="" />
            </a>
        </>
    )
}

export default BackToTopWidget