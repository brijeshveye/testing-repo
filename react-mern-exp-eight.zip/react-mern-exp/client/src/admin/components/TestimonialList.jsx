import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import TestimonialsDataApi from '../../api/TestimonialsDataApi';

const TestimonialList = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('active');

  useEffect(() => {
    fetchTestimonials();
  }, [filter]);

  const fetchTestimonials = async () => {
    try {
      setLoading(true);
      const params = {};
      if (filter === 'active') params.isActive = true;
      if (filter === 'inactive') params.isActive = false;
      if (filter === 'featured') params.featured = true;
      
      const data = await TestimonialsDataApi.getTestimonialsData(params);
      setTestimonials(data);
    } catch (error) {
      console.error('Error fetching testimonials:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (slug) => {
    if (window.confirm('Are you sure you want to delete this testimonial?')) {
      try {
        await TestimonialsDataApi.deleteTestimonial(slug);
        fetchTestimonials();
      } catch (error) {
        console.error('Error deleting testimonial:', error);
        alert('Error deleting testimonial');
      }
    }
  };

  const toggleFeatured = async (slug, currentFeatured) => {
    try {
      await TestimonialsDataApi.updateTestimonial(slug, { featured: !currentFeatured });
      fetchTestimonials();
    } catch (error) {
      console.error('Error updating testimonial:', error);
      alert('Error updating testimonial');
    }
  };

  const renderStars = (rating) => {
    return '★'.repeat(rating) + '☆'.repeat(5 - rating);
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>Testimonials Management</h2>
        <Link to="/admin/testimonials/create" className="btn btn-primary">
          <i className="fas fa-plus me-2"></i>Add New Testimonial
        </Link>
      </div>

      {/* Filter Buttons */}
      <div className="mb-4">
        <div className="btn-group" role="group">
          <button
            type="button"
            className={`btn ${filter === 'all' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFilter('all')}
          >
            All
          </button>
          <button
            type="button"
            className={`btn ${filter === 'active' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFilter('active')}
          >
            Active
          </button>
          <button
            type="button"
            className={`btn ${filter === 'inactive' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFilter('inactive')}
          >
            Inactive
          </button>
          <button
            type="button"
            className={`btn ${filter === 'featured' ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setFilter('featured')}
          >
            Featured
          </button>
        </div>
      </div>

      {/* Testimonials Table */}
      <div className="table-responsive">
        <table className="table table-striped">
          <thead>
            <tr>
              <th>Customer</th>
              <th>Company</th>
              <th>Rating</th>
              <th>Feedback (Preview)</th>
              <th>Status</th>
              <th>Featured</th>
              <th>Date</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {testimonials.length === 0 ? (
              <tr>
                <td colSpan="8" className="text-center">
                  No testimonials found.
                </td>
              </tr>
            ) : (
              testimonials.map((testimonial) => (
                <tr key={testimonial._id}>
                  <td>
                    <div className="d-flex align-items-center">
                      {testimonial.customerImage && (
                        <img
                          src={testimonial.customerImage}
                          alt={testimonial.customerName}
                          className="rounded-circle me-2"
                          style={{ width: '40px', height: '40px', objectFit: 'cover' }}
                        />
                      )}
                      <div>
                        <strong>{testimonial.customerName}</strong>
                        {testimonial.designation && (
                          <div className="small text-muted">{testimonial.designation}</div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td>{testimonial.company || '-'}</td>
                  <td>
                    <span className="text-warning">
                      {renderStars(testimonial.rating)}
                    </span>
                    <small className="text-muted ms-1">({testimonial.rating})</small>
                  </td>
                  <td>
                    <div style={{ maxWidth: '300px' }}>
                      {testimonial.customerFeedback.length > 100
                        ? `${testimonial.customerFeedback.substring(0, 100)}...`
                        : testimonial.customerFeedback}
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${testimonial.isActive ? 'bg-success' : 'bg-secondary'}`}>
                      {testimonial.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td>
                    <button
                      type="button"
                      className={`btn btn-sm ${testimonial.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                      onClick={() => toggleFeatured(testimonial.slug, testimonial.featured)}
                      title={testimonial.featured ? 'Remove from featured' : 'Mark as featured'}
                    >
                      <i className={`fas fa-star ${!testimonial.featured ? 'text-muted' : ''}`}></i>
                    </button>
                  </td>
                  <td>
                    <small>{new Date(testimonial.dateReceived).toLocaleDateString()}</small>
                  </td>
                  <td>
                    <div className="btn-group" role="group">
                      <Link
                        to={`/admin/testimonials/edit/${testimonial.slug}`}
                        className="btn btn-sm btn-outline-primary"
                        title="Edit"
                      >
                        <i className="fas fa-edit"></i>
                      </Link>
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-danger"
                        onClick={() => handleDelete(testimonial.slug)}
                        title="Delete"
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Summary Stats */}
      <div className="mt-4">
        <div className="row">
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title">{testimonials.length}</h5>
                <p className="card-text text-muted">Total Testimonials</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title">
                  {testimonials.filter(t => t.isActive).length}
                </h5>
                <p className="card-text text-muted">Active</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title">
                  {testimonials.filter(t => t.featured).length}
                </h5>
                <p className="card-text text-muted">Featured</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title">
                  {testimonials.length > 0 
                    ? (testimonials.reduce((sum, t) => sum + t.rating, 0) / testimonials.length).toFixed(1)
                    : '0'
                  }
                </h5>
                <p className="card-text text-muted">Avg Rating</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestimonialList;
