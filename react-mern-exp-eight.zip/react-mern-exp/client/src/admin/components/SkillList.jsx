import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import SkillsDataApi from '../../api/SkillsDataApi';

const SkillList = () => {
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    category: 'all',
    level: 'all',
    featured: 'all',
    status: 'all',
    search: ''
  });

  useEffect(() => {
    fetchSkills();
    fetchStats();
  }, [filters]);

  const fetchSkills = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.category !== 'all') params.category = filters.category;
      if (filters.level !== 'all') params.level = filters.level;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.search) params.search = filters.search;

      const data = await SkillsDataApi.getSkillsData(params);
      setSkills(data);
    } catch (err) {
      setError('Failed to fetch skills');
      console.error('Error fetching skills:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await SkillsDataApi.getSkillStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await SkillsDataApi.deleteSkill(slug);
        fetchSkills(); // Refresh the list
      } catch (err) {
        setError('Failed to delete skill');
        console.error('Error deleting skill:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await SkillsDataApi.toggleFeatured(slug);
      fetchSkills(); // Refresh the list
    } catch (err) {
      setError('Failed to update featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await SkillsDataApi.toggleActive(slug);
      fetchSkills(); // Refresh the list
    } catch (err) {
      setError('Failed to update active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const getSkillIcon = (skill) => {
    return skill.icon || 'fas fa-code';
  };

  const getSkillColor = (skill) => {
    return skill.color || '#007bff';
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>Manage Skills</h1>
            <Link to="/admin/skills/create" className="btn btn-primary">
              <i className="fas fa-plus me-2"></i>Add New Skill
            </Link>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger">
          <i className="fas fa-exclamation-triangle me-2"></i>
          {error}
        </div>
      )}

      {/* Stats Cards */}
      {stats && (
        <div className="row mb-4">
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-primary">{stats.totalSkills}</h5>
                <p className="card-text">Total Skills</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-success">{stats.activeSkills}</h5>
                <p className="card-text">Active Skills</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-warning">{stats.featuredSkills}</h5>
                <p className="card-text">Featured Skills</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-info">{stats.categoryStats?.length || 0}</h5>
                <p className="card-text">Categories</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-3">
              <label className="form-label">Search</label>
              <input
                type="text"
                className="form-control"
                name="search"
                placeholder="Search skills..."
                value={filters.search}
                onChange={handleFilterChange}
              />
            </div>
            
            <div className="col-md-2">
              <label className="form-label">Category</label>
              <select
                className="form-select"
                name="category"
                value={filters.category}
                onChange={handleFilterChange}
              >
                <option value="all">All Categories</option>
                <option value="Language">Language</option>
                <option value="Frontend">Frontend</option>
                <option value="Backend">Backend</option>
                <option value="Database">Database</option>
                <option value="Cloud">Cloud</option>
                <option value="DevOps">DevOps</option>
                <option value="Design">Design</option>
                <option value="Mobile">Mobile</option>
              </select>
            </div>
            
            <div className="col-md-2">
              <label className="form-label">Level</label>
              <select
                className="form-select"
                name="level"
                value={filters.level}
                onChange={handleFilterChange}
              >
                <option value="all">All Levels</option>
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Advanced">Advanced</option>
                <option value="Expert">Expert</option>
              </select>
            </div>
            
            <div className="col-md-2">
              <label className="form-label">Featured</label>
              <select
                className="form-select"
                name="featured"
                value={filters.featured}
                onChange={handleFilterChange}
              >
                <option value="all">All</option>
                <option value="true">Featured</option>
                <option value="false">Not Featured</option>
              </select>
            </div>
            
            <div className="col-md-3">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
              >
                <option value="all">All</option>
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Skills List */}
      <div className="card">
        <div className="card-body">
          {skills.length === 0 ? (
            <div className="text-center py-5">
              <i className="fas fa-code fa-3x text-muted mb-3"></i>
              <h5>No skills found</h5>
              <p className="text-muted">
                {filters.search || filters.category !== 'all' || filters.level !== 'all' || filters.featured !== 'all' || filters.status !== 'all'
                  ? 'Try adjusting your filters or search terms.'
                  : 'Start by creating your first skill.'}
              </p>
              <Link to="/admin/skills/create" className="btn btn-primary">
                <i className="fas fa-plus me-2"></i>Create Skill
              </Link>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Skill</th>
                    <th>Category</th>
                    <th>Level</th>
                    <th>Proficiency</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {skills.map((skill) => (
                    <tr key={skill._id}>
                      <td>
                        <div className="d-flex align-items-center">
                          <div 
                            className="skill-icon d-inline-flex align-items-center justify-content-center rounded me-3"
                            style={{ 
                              width: '40px', 
                              height: '40px', 
                              backgroundColor: getSkillColor(skill),
                              color: '#fff'
                            }}
                          >
                            <i className={getSkillIcon(skill)}></i>
                          </div>
                          <div>
                            <h6 className="mb-0">{skill.title}</h6>
                            {skill.description && (
                              <small className="text-muted">
                                {skill.description.substring(0, 50)}
                                {skill.description.length > 50 && '...'}
                              </small>
                            )}
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className={`badge ${
                          skill.category === 'Language' ? 'bg-primary' :
                          skill.category === 'Frontend' ? 'bg-success' :
                          skill.category === 'Backend' ? 'bg-info' :
                          skill.category === 'Database' ? 'bg-warning text-dark' :
                          skill.category === 'Cloud' ? 'bg-danger' :
                          skill.category === 'DevOps' ? 'bg-dark' :
                          skill.category === 'Design' ? 'bg-purple' :
                          skill.category === 'Mobile' ? 'bg-indigo' :
                          'bg-secondary'
                        }`}>
                          {skill.category}
                        </span>
                      </td>
                      <td>
                        <span className={`badge ${
                          skill.level === 'Expert' ? 'bg-success' :
                          skill.level === 'Advanced' ? 'bg-info' :
                          skill.level === 'Intermediate' ? 'bg-warning text-dark' :
                          'bg-secondary'
                        }`}>
                          {skill.level}
                        </span>
                      </td>
                      <td>
                        <div className="d-flex align-items-center">
                          <div className="progress me-2" style={{ width: '80px', height: '8px' }}>
                            <div 
                              className="progress-bar"
                              role="progressbar"
                              style={{ width: `${skill.percentage}%` }}
                            ></div>
                          </div>
                          <small className="text-muted">{skill.percentage}%</small>
                        </div>
                      </td>
                      <td>
                        <div className="d-flex gap-1">
                          <span className={`badge ${skill.isActive ? 'bg-success' : 'bg-secondary'}`}>
                            {skill.isActive ? 'Active' : 'Inactive'}
                          </span>
                          {skill.featured && (
                            <span className="badge bg-warning text-dark">
                              <i className="fas fa-star me-1"></i>Featured
                            </span>
                          )}
                        </div>
                      </td>
                      <td>
                        <div className="btn-group" role="group">
                          <Link 
                            to={`/admin/skills/edit/${skill.slug}`}
                            className="btn btn-sm btn-outline-primary"
                            title="Edit"
                          >
                            <i className="fas fa-edit"></i>
                          </Link>
                          
                          <button
                            onClick={() => handleToggleFeatured(skill.slug)}
                            className={`btn btn-sm ${skill.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                            title={skill.featured ? 'Remove from featured' : 'Add to featured'}
                          >
                            <i className="fas fa-star"></i>
                          </button>
                          
                          <button
                            onClick={() => handleToggleActive(skill.slug)}
                            className={`btn btn-sm ${skill.isActive ? 'btn-success' : 'btn-outline-success'}`}
                            title={skill.isActive ? 'Deactivate' : 'Activate'}
                          >
                            <i className={`fas ${skill.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                          </button>
                          
                          <button
                            onClick={() => handleDelete(skill.slug, skill.title)}
                            className="btn btn-sm btn-outline-danger"
                            title="Delete"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="mt-4">
        <Link to="/admin" className="btn btn-secondary">
          <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
        </Link>
      </div>
    </div>
  );
};

export default SkillList;
