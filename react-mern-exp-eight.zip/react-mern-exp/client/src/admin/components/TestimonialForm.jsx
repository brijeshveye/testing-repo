import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import TestimonialsDataApi from '../../api/TestimonialsDataApi';
import { ImageUploader } from './ImageUpload';

const TestimonialForm = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(slug);
  
  const [formData, setFormData] = useState({
    customerName: '',
    customerFeedback: '',
    customerPosition: '',
    customerImage: '',
    stars: 5,
    featured: false,
    isActive: true
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (isEdit) {
      fetchTestimonial();
    }
  }, [slug, isEdit]);

  const fetchTestimonial = async () => {
    try {
      setLoading(true);
      const testimonial = await TestimonialsDataApi.getTestimonialDetails(slug);
      if (testimonial) {
        setFormData({
          customerName: testimonial.customerName || '',
          customerFeedback: testimonial.customerFeedback || '',
          customerPosition: testimonial.customerPosition || '',
          customerImage: testimonial.customerImage || '',
          stars: testimonial.stars || 5,
          featured: testimonial.featured || false,
          isActive: testimonial.isActive !== false
        });
      } else {
        setError('Testimonial not found');
      }
    } catch (err) {
      setError('Failed to load testimonial');
      console.error('Error fetching testimonial:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear messages when user starts typing
    if (error) setError('');
    if (success) setSuccess('');
  };

  const handleImageUpload = (imageUrl) => {
    setFormData(prev => ({
      ...prev,
      customerImage: imageUrl
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.customerName.trim()) {
      setError('Customer name is required');
      return;
    }
    if (!formData.customerFeedback.trim()) {
      setError('Customer feedback is required');
      return;
    }
    if (!formData.customerPosition.trim()) {
      setError('Customer position is required');
      return;
    }

    try {
      setLoading(true);
      setError('');

      if (isEdit) {
        await TestimonialsDataApi.updateTestimonial(slug, formData);
        setSuccess('Testimonial updated successfully!');
      } else {
        await TestimonialsDataApi.createTestimonial(formData);
        setSuccess('Testimonial created successfully!');
      }

      // Redirect after a short delay
      setTimeout(() => {
        navigate('/admin/testimonials');
      }, 1500);

    } catch (err) {
      setError(err.response?.data?.message || `Failed to ${isEdit ? 'update' : 'create'} testimonial`);
      console.error('Error saving testimonial:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>{isEdit ? 'Edit Testimonial' : 'Create New Testimonial'}</h1>
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => navigate('/admin/testimonials')}
            >
              <i className="fas fa-arrow-left me-2"></i>Back to List
            </button>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-body">
              {error && (
                <div className="alert alert-danger">
                  <i className="fas fa-exclamation-triangle me-2"></i>
                  {error}
                </div>
              )}
              
              {success && (
                <div className="alert alert-success">
                  <i className="fas fa-check-circle me-2"></i>
                  {success}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label htmlFor="customerName" className="form-label">
                      Customer Name <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="customerName"
                      name="customerName"
                      value={formData.customerName}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  
                  <div className="col-md-6 mb-3">
                    <label htmlFor="customerPosition" className="form-label">
                      Position/Title <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="customerPosition"
                      name="customerPosition"
                      value={formData.customerPosition}
                      onChange={handleChange}
                      placeholder="e.g., CEO, Company Name"
                      required
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label htmlFor="customerFeedback" className="form-label">
                    Testimonial Feedback <span className="text-danger">*</span>
                  </label>
                  <textarea
                    className="form-control"
                    id="customerFeedback"
                    name="customerFeedback"
                    rows="4"
                    value={formData.customerFeedback}
                    onChange={handleChange}
                    placeholder="Enter the customer's testimonial feedback..."
                    required
                  ></textarea>
                  <div className="form-text">
                    {formData.customerFeedback.length}/500 characters
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-4 mb-3">
                    <label htmlFor="stars" className="form-label">Rating</label>
                    <select
                      className="form-select"
                      id="stars"
                      name="stars"
                      value={formData.stars}
                      onChange={handleChange}
                    >
                      <option value={1}>1 Star</option>
                      <option value={2}>2 Stars</option>
                      <option value={3}>3 Stars</option>
                      <option value={4}>4 Stars</option>
                      <option value={5}>5 Stars</option>
                    </select>
                  </div>
                  
                  <div className="col-md-4 mb-3">
                    <div className="form-check mt-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="featured"
                        name="featured"
                        checked={formData.featured}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="featured">
                        Featured Testimonial
                      </label>
                    </div>
                  </div>
                  
                  <div className="col-md-4 mb-3">
                    <div className="form-check mt-4">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="isActive"
                        name="isActive"
                        checked={formData.isActive}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="isActive">
                        Active/Published
                      </label>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="form-label">Customer Image</label>
                  <ImageUploader 
                    onUpload={handleImageUpload}
                    currentImage={formData.customerImage}
                    category="testimonials"
                  />
                </div>

                <div className="d-flex gap-2">
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        {isEdit ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      <>
                        <i className="fas fa-save me-2"></i>
                        {isEdit ? 'Update Testimonial' : 'Create Testimonial'}
                      </>
                    )}
                  </button>
                  
                  <button 
                    type="button" 
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/testimonials')}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">Preview</h5>
            </div>
            <div className="card-body">
              <div className="testimonial-preview">
                <div className="text-center mb-3">
                  {formData.customerImage ? (
                    <img 
                      src={formData.customerImage} 
                      alt="Customer"
                      className="rounded-circle"
                      style={{ width: '60px', height: '60px', objectFit: 'cover' }}
                    />
                  ) : (
                    <div 
                      className="rounded-circle bg-secondary text-white d-flex align-items-center justify-content-center mx-auto"
                      style={{ width: '60px', height: '60px' }}
                    >
                      <i className="fas fa-user"></i>
                    </div>
                  )}
                  
                  <div className="d-flex justify-content-center mt-2">
                    {[...Array(5)].map((_, index) => (
                      <i 
                        key={index} 
                        className={`bi ${index < formData.stars ? 'bi-star-fill text-warning' : 'bi-star text-muted'}`}
                      ></i>
                    ))}
                  </div>
                </div>

                <blockquote className="text-center">
                  <p className="text-muted fst-italic">
                    "{formData.customerFeedback || 'Customer feedback will appear here...'}"
                  </p>
                  <footer className="blockquote-footer">
                    <strong>{formData.customerName || 'Customer Name'}</strong>
                    <br />
                    <small className="text-muted">
                      {formData.customerPosition || 'Position, Company'}
                    </small>
                  </footer>
                </blockquote>

                {formData.featured && (
                  <div className="text-center mt-2">
                    <span className="badge bg-primary">
                      <i className="fas fa-star me-1"></i>Featured
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestimonialForm;
