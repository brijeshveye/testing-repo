import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const ProjectList = () => {
  const [projects, setProjects] = useState([]);

  const fetchProjects = async () => {
    const res = await axios.get('/api/projects');
    setProjects(res.data);
  };

  const deleteProject = async (slug) => {
    if (window.confirm('Are you sure you want to delete this project?')) {
      await axios.delete(`/api/projects/${slug}`);
      fetchProjects();
    }
  };

  useEffect(() => {
    fetchProjects();
  }, []);

  return (
    <div className="container mt-4">
      <h2>Projects</h2>
      <Link className="btn btn-primary mb-3" to="/admin/projects/create">Create New Project</Link>
      <div className="list-group">
        {projects.map(project => (
          <div key={project.slug} className="list-group-item d-flex justify-content-between align-items-center">
            <div>
              <h5>{project.title}</h5>
              <p className="mb-1">{project.description}</p>
              <small>{project.date} | {project.client}</small>
            </div>
            <div>
              <Link to={`/admin/projects/edit/${project.slug}`} className="btn btn-sm btn-warning me-2">Edit</Link>
              <button className="btn btn-sm btn-danger" onClick={() => deleteProject(project.slug)}>Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>

  );
};

export default ProjectList;
