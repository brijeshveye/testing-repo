import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  getAllCharacteristics, 
  deleteCharacteristic, 
  toggleCharacteristicFeatured, 
  toggleCharacteristicActive,
  getCharacteristicStats
} from '../../api/CharacteristicsDataApi';

const CharacteristicList = () => {
  const [characteristics, setCharacteristics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [sortBy, setSortBy] = useState('order');
  const [sortOrder, setSortOrder] = useState('asc');
  const [stats, setStats] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pagination, setPagination] = useState(null);

  useEffect(() => {
    fetchCharacteristics();
    fetchStats();
  }, [searchTerm, filterCategory, filterStatus, sortBy, sortOrder, currentPage]);

  const fetchCharacteristics = async () => {
    try {
      setLoading(true);
      const params = {
        page: currentPage,
        limit: 10,
        sortBy,
        sortOrder
      };

      if (searchTerm) params.search = searchTerm;
      if (filterCategory) params.category = filterCategory;
      if (filterStatus) {
        if (filterStatus === 'active') params.isActive = 'true';
        if (filterStatus === 'inactive') params.isActive = 'false';
        if (filterStatus === 'featured') params.featured = 'true';
      }

      const response = await getAllCharacteristics(params);
      setCharacteristics(response.characteristics || response);
      setPagination(response.pagination);
    } catch (error) {
      console.error('Error fetching characteristics:', error);
      setError('Failed to load characteristics');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await getCharacteristicStats();
      setStats(statsData);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await deleteCharacteristic(slug);
        fetchCharacteristics();
        fetchStats();
      } catch (error) {
        console.error('Error deleting characteristic:', error);
        alert('Failed to delete characteristic');
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await toggleCharacteristicFeatured(slug);
      fetchCharacteristics();
      fetchStats();
    } catch (error) {
      console.error('Error toggling featured:', error);
      alert('Failed to update featured status');
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await toggleCharacteristicActive(slug);
      fetchCharacteristics();
      fetchStats();
    } catch (error) {
      console.error('Error toggling active:', error);
      alert('Failed to update active status');
    }
  };

  const getUniqueCategories = () => {
    const categories = characteristics.map(char => char.category).filter(Boolean);
    return [...new Set(categories)];
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>Manage Characteristics</h1>
            <Link to="/admin/characteristics/create" className="btn btn-primary">
              <i className="fas fa-plus me-2"></i>Add New Characteristic
            </Link>
          </div>

          {/* Stats Cards */}
          {stats && (
            <div className="row mb-4">
              <div className="col-md-3">
                <div className="card bg-primary text-white">
                  <div className="card-body">
                    <div className="d-flex justify-content-between">
                      <div>
                        <h4>{stats.total}</h4>
                        <p className="mb-0">Total</p>
                      </div>
                      <div className="align-self-center">
                        <i className="fas fa-star fa-2x"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card bg-success text-white">
                  <div className="card-body">
                    <div className="d-flex justify-content-between">
                      <div>
                        <h4>{stats.active}</h4>
                        <p className="mb-0">Active</p>
                      </div>
                      <div className="align-self-center">
                        <i className="fas fa-check-circle fa-2x"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card bg-warning text-white">
                  <div className="card-body">
                    <div className="d-flex justify-content-between">
                      <div>
                        <h4>{stats.featured}</h4>
                        <p className="mb-0">Featured</p>
                      </div>
                      <div className="align-self-center">
                        <i className="fas fa-star fa-2x"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3">
                <div className="card bg-secondary text-white">
                  <div className="card-body">
                    <div className="d-flex justify-content-between">
                      <div>
                        <h4>{stats.inactive}</h4>
                        <p className="mb-0">Inactive</p>
                      </div>
                      <div className="align-self-center">
                        <i className="fas fa-times-circle fa-2x"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Filters */}
          <div className="card mb-4">
            <div className="card-body">
              <div className="row">
                <div className="col-md-3">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search characteristics..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="col-md-2">
                  <select
                    className="form-select"
                    value={filterCategory}
                    onChange={(e) => setFilterCategory(e.target.value)}
                  >
                    <option value="">All Categories</option>
                    {getUniqueCategories().map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                </div>
                <div className="col-md-2">
                  <select
                    className="form-select"
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e.target.value)}
                  >
                    <option value="">All Status</option>
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                    <option value="featured">Featured</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <select
                    className="form-select"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                  >
                    <option value="order">Order</option>
                    <option value="title">Title</option>
                    <option value="category">Category</option>
                    <option value="createdAt">Created Date</option>
                  </select>
                </div>
                <div className="col-md-2">
                  <select
                    className="form-select"
                    value={sortOrder}
                    onChange={(e) => setSortOrder(e.target.value)}
                  >
                    <option value="asc">Ascending</option>
                    <option value="desc">Descending</option>
                  </select>
                </div>
                <div className="col-md-1">
                  <button
                    className="btn btn-outline-secondary"
                    onClick={() => {
                      setSearchTerm('');
                      setFilterCategory('');
                      setFilterStatus('');
                      setSortBy('order');
                      setSortOrder('asc');
                    }}
                  >
                    Clear
                  </button>
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="alert alert-danger" role="alert">
              {error}
            </div>
          )}

          {/* Characteristics Table */}
          <div className="card">
            <div className="card-body">
              {characteristics.length === 0 ? (
                <div className="text-center py-4">
                  <i className="fas fa-star fa-3x text-muted mb-3"></i>
                  <h5>No characteristics found</h5>
                  <p className="text-muted">Create your first characteristic to get started.</p>
                  <Link to="/admin/characteristics/create" className="btn btn-primary">
                    Create Characteristic
                  </Link>
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-hover">
                    <thead>
                      <tr>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Value</th>
                        <th>Status</th>
                        <th>Featured</th>
                        <th>Order</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {characteristics.map((characteristic) => (
                        <tr key={characteristic._id}>
                          <td>
                            <div className="d-flex align-items-center">
                              {characteristic.iconClass && (
                                <i className={`${characteristic.iconClass} me-2`} style={{color: characteristic.color}}></i>
                              )}
                              <div>
                                <strong>{characteristic.title}</strong>
                                <br />
                                <small className="text-muted">
                                  {characteristic.description?.substring(0, 60)}...
                                </small>
                              </div>
                            </div>
                          </td>
                          <td>
                            <span className="badge bg-light text-dark">
                              {characteristic.category || 'Uncategorized'}
                            </span>
                          </td>
                          <td>
                            {characteristic.value !== undefined ? (
                              <span>{characteristic.value}{characteristic.unit}</span>
                            ) : (
                              '-'
                            )}
                          </td>
                          <td>
                            <button
                              className={`btn btn-sm ${characteristic.isActive ? 'btn-success' : 'btn-secondary'}`}
                              onClick={() => handleToggleActive(characteristic.slug)}
                            >
                              {characteristic.isActive ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                          <td>
                            <button
                              className={`btn btn-sm ${characteristic.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                              onClick={() => handleToggleFeatured(characteristic.slug)}
                            >
                              <i className="fas fa-star"></i>
                            </button>
                          </td>
                          <td>{characteristic.order}</td>
                          <td>
                            <div className="btn-group" role="group">
                              <Link
                                to={`/admin/characteristics/edit/${characteristic.slug}`}
                                className="btn btn-sm btn-outline-primary"
                              >
                                <i className="fas fa-edit"></i>
                              </Link>
                              <button
                                className="btn btn-sm btn-outline-danger"
                                onClick={() => handleDelete(characteristic.slug, characteristic.title)}
                              >
                                <i className="fas fa-trash"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {/* Pagination */}
              {pagination && pagination.totalPages > 1 && (
                <nav aria-label="Characteristics pagination">
                  <ul className="pagination justify-content-center mt-4">
                    <li className={`page-item ${!pagination.hasPrev ? 'disabled' : ''}`}>
                      <button
                        className="page-link"
                        onClick={() => setCurrentPage(currentPage - 1)}
                        disabled={!pagination.hasPrev}
                      >
                        Previous
                      </button>
                    </li>
                    {[...Array(pagination.totalPages)].map((_, index) => (
                      <li
                        key={index + 1}
                        className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                      >
                        <button
                          className="page-link"
                          onClick={() => setCurrentPage(index + 1)}
                        >
                          {index + 1}
                        </button>
                      </li>
                    ))}
                    <li className={`page-item ${!pagination.hasNext ? 'disabled' : ''}`}>
                      <button
                        className="page-link"
                        onClick={() => setCurrentPage(currentPage + 1)}
                        disabled={!pagination.hasNext}
                      >
                        Next
                      </button>
                    </li>
                  </ul>
                </nav>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacteristicList;
