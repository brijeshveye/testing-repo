import React, { useState, useEffect } from 'react';
import './AdminPinAuth.css';

const AdminPinAuth = ({ onSuccess }) => {
  const [pin, setPin] = useState(['', '', '', '']);
  const [timeLeft, setTimeLeft] = useState(0);
  const [error, setError] = useState('');
  const [isLocked, setIsLocked] = useState(false);

  useEffect(() => {
    checkDeviceSession();
  }, []);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && isLocked) {
      clearDeviceSession();
      setIsLocked(false);
    }
  }, [timeLeft, isLocked]);

  const checkDeviceSession = () => {
    const deviceInfo = getDeviceInfo();
    const sessionKey = `adminSession_${deviceInfo}`;
    const sessionData = localStorage.getItem(sessionKey);
    
    if (sessionData) {
      const { timestamp, expiresAt } = JSON.parse(sessionData);
      const now = Date.now();
      
      if (now < expiresAt) {
        // Session is still valid
        const remaining = Math.floor((expiresAt - now) / 1000);
        setTimeLeft(remaining);
        setIsLocked(true);
        onSuccess();
        return;
      } else {
        // Session expired
        localStorage.removeItem(sessionKey);
      }
    }
  };

  const getDeviceInfo = () => {
    // Create a unique device fingerprint
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('Device fingerprint', 2, 2);
    
    const fingerprint = canvas.toDataURL() + 
                       navigator.userAgent + 
                       navigator.language + 
                       window.screen.width + 'x' + window.screen.height;
    
    return btoa(fingerprint).slice(0, 32);
  };

  const handlePinChange = (index, value) => {
    if (value.length > 1) return;
    if (!/^\d*$/.test(value)) return;

    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);
    setError('');

    // Auto focus next input
    if (value && index < 3) {
      const nextInput = document.querySelector(`input[data-index="${index + 1}"]`);
      if (nextInput) nextInput.focus();
    }

    // Check if PIN is complete
    if (newPin.every(digit => digit !== '') && newPin.join('').length === 4) {
      validatePin(newPin.join(''));
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      const prevInput = document.querySelector(`input[data-index="${index - 1}"]`);
      if (prevInput) prevInput.focus();
    }
  };

  const validatePin = (enteredPin) => {
    // You can customize this PIN or fetch from server
    const correctPin = '1234'; // Default admin PIN
    
    if (enteredPin === correctPin) {
      createDeviceSession();
      onSuccess();
    } else {
      setError('Invalid PIN. Please try again.');
      setPin(['', '', '', '']);
      // Focus first input
      const firstInput = document.querySelector('input[data-index="0"]');
      if (firstInput) firstInput.focus();
    }
  };

  const createDeviceSession = () => {
    const deviceInfo = getDeviceInfo();
    const sessionKey = `adminSession_${deviceInfo}`;
    const now = Date.now();
    const expiresAt = now + (2 * 60 * 60 * 1000); // 2 hours
    
    const sessionData = {
      timestamp: now,
      expiresAt: expiresAt,
      deviceInfo: deviceInfo
    };
    
    localStorage.setItem(sessionKey, JSON.stringify(sessionData));
    localStorage.setItem('adminToken', 'authenticated');
    
    setTimeLeft(2 * 60 * 60); // 2 hours in seconds
    setIsLocked(true);
  };

  const clearDeviceSession = () => {
    const deviceInfo = getDeviceInfo();
    const sessionKey = `adminSession_${deviceInfo}`;
    localStorage.removeItem(sessionKey);
    localStorage.removeItem('adminToken');
    setIsLocked(false);
    setTimeLeft(0);
  };

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (isLocked && timeLeft > 0) {
    return (
      <div className="admin-pin-success">
        <div className="pin-container">
          <div className="success-icon">
            <i className="fas fa-check-circle"></i>
          </div>
          <h3>Access Granted</h3>
          <p>Session expires in: <strong>{formatTime(timeLeft)}</strong></p>
          <button onClick={clearDeviceSession} className="btn btn-outline-danger btn-sm">
            End Session
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-pin-auth">
      <div className="pin-container">
        <div className="pin-header">
          <i className="fas fa-shield-alt pin-icon"></i>
          <h2>Admin Access</h2>
          <p>Enter your 4-digit PIN to continue</p>
        </div>
        
        <div className="pin-inputs">
          {pin.map((digit, index) => (
            <input
              key={index}
              type="text"
              value={digit}
              onChange={(e) => handlePinChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              data-index={index}
              className="pin-input"
              maxLength="1"
              autoComplete="off"
            />
          ))}
        </div>
        
        {error && (
          <div className="pin-error">
            <i className="fas fa-exclamation-triangle"></i>
            {error}
          </div>
        )}
        
        <div className="pin-info">
          <p><i className="fas fa-info-circle"></i> This session will be valid for 2 hours on this device</p>
        </div>
      </div>
    </div>
  );
};

export default AdminPinAuth;
