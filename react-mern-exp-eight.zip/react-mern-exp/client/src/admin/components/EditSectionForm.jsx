import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const EditSectionForm = () => {
  const { section } = useParams(); // e.g. "aboutData"
  const [data, setData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('/api/user').then(res => {
      setData(res.data[section]);
    });
  }, [section]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Check if we're dealing with a nested object (like socialLinks)
    if (typeof data === 'object' && data !== null && !Array.isArray(data)) {
      // If all values in data are strings (flat object like socialLinks)
      const isFlat = Object.values(data).every(val => typeof val === 'string' || val === null || val === undefined);
      
      if (isFlat) {
        setData(prev => ({ ...prev, [name]: value }));
      } else {
        // Handle other nested structures if needed
        setData(prev => ({ ...prev, [name]: value }));
      }
    } else {
      setData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`/api/user/${section}`, data);
    navigate('/admin/user'); // Redirect to user dashboard after update
  };

  if (!data) return <div className="container mt-4">Loading...</div>;

  return (
    <div className="container mt-4">
      <h3>Edit Section: {section}</h3>
        <form onSubmit={handleSubmit}>
          {Object.keys(data).map((key, i) => (
            <div className="mb-3" key={i}>
              <label htmlFor={key} className="form-label">
                {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
              </label>
              <input
                id={key}
                className="form-control"
                name={key}
                value={data[key] || ''}
                onChange={handleChange}
                type={key.includes('email') ? 'email' : key.includes('phone') ? 'tel' : 'text'}
                placeholder={`Enter ${key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}`}
              />
            </div>
          ))}
      <button type="submit" className="btn btn-primary me-2">Update</button>
      <button type="button" className="btn btn-secondary" onClick={() => navigate('/admin/user')}>
        Cancel
      </button>
      </form>
    </div>
  );
};

export default EditSectionForm;
