import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createCharacteristic, getCharacteristic, updateCharacteristic } from '../../api/CharacteristicsDataApi';

const CharacteristicForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDescription: '',
    icon: '',
    iconClass: '',
    image: '',
    category: 'personal',
    value: 85,
    unit: '%',
    color: '#007bff',
    link: '',
    backTitle: '',
    backDescription: '',
    tags: [],
    featured: false,
    isActive: true,
    seoTitle: '',
    seoDescription: '',
    seoKeywords: []
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEdit) {
      fetchCharacteristic();
    }
  }, [slug, isEdit]);

  const fetchCharacteristic = async () => {
    try {
      setLoading(true);
      const response = await getCharacteristic(slug, true);
      if (response.success) {
        const characteristicData = response.data;
        setFormData({
          title: characteristicData.title || '',
          description: characteristicData.description || '',
          shortDescription: characteristicData.shortDescription || '',
          icon: characteristicData.icon || '',
          iconClass: characteristicData.iconClass || '',
          image: characteristicData.image || '',
          category: characteristicData.category || 'personal',
          value: characteristicData.value || 85,
          unit: characteristicData.unit || '%',
          color: characteristicData.color || '#007bff',
          link: characteristicData.link || '',
          backTitle: characteristicData.backTitle || '',
          backDescription: characteristicData.backDescription || '',
          tags: characteristicData.tags || [],
          featured: characteristicData.featured || false,
          isActive: characteristicData.isActive !== false,
          seoTitle: characteristicData.seoTitle || '',
          seoDescription: characteristicData.seoDescription || '',
          seoKeywords: characteristicData.seoKeywords || []
        });
      } else {
        setErrors({ general: response.message || 'Failed to fetch characteristic details' });
      }
    } catch (error) {
      console.error('Error fetching characteristic:', error);
      setErrors({ general: 'Failed to fetch characteristic details' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) : value)
    }));
  };

  const handleTagsChange = (e) => {
    const tags = e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag);
    setFormData(prev => ({ ...prev, tags }));
  };

  const handleSeoKeywordsChange = (e) => {
    const seoKeywords = e.target.value.split(',').map(keyword => keyword.trim()).filter(keyword => keyword);
    setFormData(prev => ({ ...prev, seoKeywords }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (formData.value < 0 || formData.value > 100) {
      newErrors.value = 'Value must be between 0 and 100';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      let response;

      if (isEdit) {
        response = await updateCharacteristic(slug, formData);
      } else {
        response = await createCharacteristic(formData);
      }

      if (response.success) {
        navigate('/admin/characteristics');
      } else {
        setErrors({ general: response.message || 'Failed to save characteristic' });
      }
    } catch (error) {
      console.error('Error saving characteristic:', error);
      setErrors({ general: 'Failed to save characteristic. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">
                {isEdit ? 'Edit Characteristic' : 'Create New Characteristic'}
              </h5>
            </div>
            <div className="card-body">
              {errors.general && (
                <div className="alert alert-danger" role="alert">
                  {errors.general}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                {/* Basic Information */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Basic Information</h6>
                  
                  <div className="mb-3">
                    <label htmlFor="title" className="form-label">Title *</label>
                    <input
                      type="text"
                      className={`form-control ${errors.title ? 'is-invalid' : ''}`}
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      required
                    />
                    {errors.title && <div className="invalid-feedback">{errors.title}</div>}
                  </div>

                  <div className="mb-3">
                    <label htmlFor="description" className="form-label">Description *</label>
                    <textarea
                      className={`form-control ${errors.description ? 'is-invalid' : ''}`}
                      id="description"
                      name="description"
                      rows="4"
                      value={formData.description}
                      onChange={handleChange}
                      required
                    />
                    {errors.description && <div className="invalid-feedback">{errors.description}</div>}
                  </div>

                  <div className="mb-3">
                    <label htmlFor="shortDescription" className="form-label">Short Description</label>
                    <textarea
                      className="form-control"
                      id="shortDescription"
                      name="shortDescription"
                      rows="2"
                      value={formData.shortDescription}
                      onChange={handleChange}
                      placeholder="Brief summary for cards..."
                    />
                  </div>

                  <div className="row">
                    <div className="col-md-6">
                      <label htmlFor="iconClass" className="form-label">Icon Class</label>
                      <input
                        type="text"
                        className="form-control"
                        id="iconClass"
                        name="iconClass"
                        value={formData.iconClass}
                        onChange={handleChange}
                        placeholder="e.g., fas fa-star"
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="color" className="form-label">Color</label>
                      <input
                        type="color"
                        className="form-control form-control-color"
                        id="color"
                        name="color"
                        value={formData.color}
                        onChange={handleChange}
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <label htmlFor="category" className="form-label">Category</label>
                    <select
                      className="form-select"
                      id="category"
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                    >
                      <option value="personal">Personal</option>
                      <option value="professional">Professional</option>
                      <option value="technical">Technical</option>
                      <option value="creative">Creative</option>
                      <option value="leadership">Leadership</option>
                      <option value="communication">Communication</option>
                    </select>
                  </div>

                  <div className="row">
                    <div className="col-md-8">
                      <label htmlFor="value" className="form-label">Value/Level</label>
                      <input
                        type="number"
                        className={`form-control ${errors.value ? 'is-invalid' : ''}`}
                        id="value"
                        name="value"
                        value={formData.value}
                        onChange={handleChange}
                        min="0"
                        max="100"
                      />
                      {errors.value && <div className="invalid-feedback">{errors.value}</div>}
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="unit" className="form-label">Unit</label>
                      <select
                        className="form-select"
                        id="unit"
                        name="unit"
                        value={formData.unit}
                        onChange={handleChange}
                      >
                        <option value="%">%</option>
                        <option value="/10">/10</option>
                        <option value="/5">/5</option>
                        <option value="years">years</option>
                        <option value="level">level</option>
                      </select>
                    </div>
                  </div>

                  <div className="mb-3">
                    <label htmlFor="tags" className="form-label">Tags (comma-separated)</label>
                    <input
                      type="text"
                      className="form-control"
                      id="tags"
                      value={(formData.tags || []).join(', ')}
                      onChange={handleTagsChange}
                      placeholder="leadership, communication, teamwork"
                    />
                  </div>

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="featured"
                      name="featured"
                      checked={formData.featured}
                      onChange={handleChange}
                    />
                    <label className="form-check-label" htmlFor="featured">
                      Featured Characteristic
                    </label>
                  </div>

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="isActive"
                      name="isActive"
                      checked={formData.isActive}
                      onChange={handleChange}
                    />
                    <label className="form-check-label" htmlFor="isActive">
                      Active
                    </label>
                  </div>
                </div>

                {/* Additional Details */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Additional Details</h6>
                  
                  <div className="mb-3">
                    <label htmlFor="backTitle" className="form-label">Back Title</label>
                    <input
                      type="text"
                      className="form-control"
                      id="backTitle"
                      name="backTitle"
                      value={formData.backTitle}
                      onChange={handleChange}
                      placeholder="Title for card back/hover"
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="backDescription" className="form-label">Back Description</label>
                    <textarea
                      className="form-control"
                      id="backDescription"
                      name="backDescription"
                      rows="3"
                      value={formData.backDescription}
                      onChange={handleChange}
                      placeholder="Description for card back/hover"
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="link" className="form-label">Custom Link</label>
                    <input
                      type="url"
                      className="form-control"
                      id="link"
                      name="link"
                      value={formData.link}
                      onChange={handleChange}
                      placeholder="https://example.com"
                    />
                  </div>
                </div>

                {/* SEO */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">SEO (Optional)</h6>
                  
                  <div className="mb-3">
                    <label htmlFor="seoTitle" className="form-label">SEO Title</label>
                    <input
                      type="text"
                      className="form-control"
                      id="seoTitle"
                      name="seoTitle"
                      value={formData.seoTitle}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="seoDescription" className="form-label">SEO Description</label>
                    <textarea
                      className="form-control"
                      id="seoDescription"
                      name="seoDescription"
                      rows="2"
                      value={formData.seoDescription}
                      onChange={handleChange}
                    />
                  </div>

                  <div className="mb-3">
                    <label htmlFor="seoKeywords" className="form-label">SEO Keywords (comma-separated)</label>
                    <input
                      type="text"
                      className="form-control"
                      id="seoKeywords"
                      value={(formData.seoKeywords || []).join(', ')}
                      onChange={handleSeoKeywordsChange}
                      placeholder="leadership, skills, personality"
                    />
                  </div>
                </div>

                {/* Form Actions */}
                <div className="d-flex justify-content-between">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/characteristics')}
                    disabled={loading}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        {isEdit ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      isEdit ? 'Update Characteristic' : 'Create Characteristic'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">Preview</h5>
            </div>
            <div className="card-body">
              <div className="characteristic-preview">
                <div className="text-center mb-3">
                  <div 
                    className="d-inline-flex align-items-center justify-content-center rounded-circle"
                    style={{ 
                      width: '80px', 
                      height: '80px', 
                      backgroundColor: formData.color || '#007bff',
                      color: 'white'
                    }}
                  >
                    {formData.iconClass ? (
                      <i className={`${formData.iconClass} fa-2x`}></i>
                    ) : (
                      <i className="fas fa-star fa-2x"></i>
                    )}
                  </div>
                </div>

                <h6 className="mb-2 text-center">{formData.title || 'Characteristic Title'}</h6>
                <p className="text-muted small mb-3 text-center">
                  {formData.shortDescription || formData.description || 'Characteristic description will appear here...'}
                </p>

                {formData.value !== undefined && (
                  <div className="mb-3">
                    <div className="d-flex justify-content-between align-items-center mb-1">
                      <span className="small text-muted">Level</span>
                      <span className="small font-weight-bold">{formData.value}{formData.unit}</span>
                    </div>
                    <div className="progress" style={{ height: '8px' }}>
                      <div 
                        className="progress-bar" 
                        role="progressbar" 
                        style={{ 
                          width: `${formData.value}%`,
                          backgroundColor: formData.color || '#007bff'
                        }}
                        aria-valuenow={formData.value} 
                        aria-valuemin="0" 
                        aria-valuemax="100"
                      ></div>
                    </div>
                  </div>
                )}

                {(formData.tags || []).length > 0 && (
                  <div className="mb-3">
                    <small className="text-muted d-block mb-1">
                      <strong>Tags:</strong>
                    </small>
                    <div className="d-flex flex-wrap gap-1">
                      {(formData.tags || []).slice(0, 3).map((tag, index) => (
                        <span key={index} className="badge bg-light text-dark">
                          {tag}
                        </span>
                      ))}
                      {(formData.tags || []).length > 3 && (
                        <span className="badge bg-light text-muted">
                          +{(formData.tags || []).length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                <div className="d-flex justify-content-center gap-2">
                  {formData.featured && (
                    <span className="badge bg-warning text-dark">
                      <i className="fas fa-star me-1"></i>Featured
                    </span>
                  )}
                  <span className={`badge ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                    {formData.isActive ? 'Active' : 'Inactive'}
                  </span>
                  <span className="badge bg-info">
                    {formData.category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacteristicForm;
