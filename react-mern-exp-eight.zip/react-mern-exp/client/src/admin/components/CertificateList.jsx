import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import CertificatesDataApi from '../../api/CertificatesDataApi';

const CertificateList = () => {
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({
    category: 'all',
    featured: 'all',
    status: 'all',
    search: ''
  });

  useEffect(() => {
    fetchCertificates();
  }, [filters]);

  const fetchCertificates = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.category !== 'all') params.category = filters.category;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.search) params.search = filters.search;

      const data = await CertificatesDataApi.getCertificatesData(params);
      setCertificates(data);
    } catch (err) {
      setError('Failed to fetch certificates');
      console.error('Error fetching certificates:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await CertificatesDataApi.deleteCertificate(slug);
        fetchCertificates(); // Refresh the list
      } catch (err) {
        setError('Failed to delete certificate');
        console.error('Error deleting certificate:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await CertificatesDataApi.toggleFeatured(slug);
      fetchCertificates(); // Refresh the list
    } catch (err) {
      setError('Failed to update featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await CertificatesDataApi.toggleActive(slug);
      fetchCertificates(); // Refresh the list
    } catch (err) {
      setError('Failed to update active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>Manage Certificates</h1>
            <Link to="/admin/certificates/create" className="btn btn-primary">
              <i className="fas fa-plus me-2"></i>Add New Certificate
            </Link>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger">
          <i className="fas fa-exclamation-triangle me-2"></i>
          {error}
        </div>
      )}

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-3">
              <label className="form-label">Search</label>
              <input
                type="text"
                className="form-control"
                name="search"
                placeholder="Search certificates..."
                value={filters.search}
                onChange={handleFilterChange}
              />
            </div>
            
            <div className="col-md-3">
              <label className="form-label">Category</label>
              <select
                className="form-select"
                name="category"
                value={filters.category}
                onChange={handleFilterChange}
              >
                <option value="all">All Categories</option>
                <option value="Web Development">Web Development</option>
                <option value="Programming">Programming</option>
                <option value="Frameworks">Frameworks</option>
                <option value="Cloud Computing">Cloud Computing</option>
                <option value="General">General</option>
              </select>
            </div>
            
            <div className="col-md-3">
              <label className="form-label">Featured</label>
              <select
                className="form-select"
                name="featured"
                value={filters.featured}
                onChange={handleFilterChange}
              >
                <option value="all">All</option>
                <option value="true">Featured</option>
                <option value="false">Not Featured</option>
              </select>
            </div>
            
            <div className="col-md-3">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
              >
                <option value="all">All</option>
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Certificates List */}
      <div className="card">
        <div className="card-body">
          {certificates.length === 0 ? (
            <div className="text-center py-5">
              <i className="fas fa-certificate fa-3x text-muted mb-3"></i>
              <h5>No certificates found</h5>
              <p className="text-muted">
                {filters.search || filters.category !== 'all' || filters.featured !== 'all' || filters.status !== 'all'
                  ? 'Try adjusting your filters or search terms.'
                  : 'Start by creating your first certificate.'}
              </p>
              <Link to="/admin/certificates/create" className="btn btn-primary">
                <i className="fas fa-plus me-2"></i>Create Certificate
              </Link>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Certificate</th>
                    <th>Issuer</th>
                    <th>Year</th>
                    <th>Category</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {certificates.map((certificate) => (
                    <tr key={certificate._id}>
                      <td>
                        <div className="d-flex align-items-center">
                          {certificate.image && (
                            <img 
                              src={certificate.image} 
                              alt={certificate.title}
                              className="rounded me-3"
                              style={{ width: '40px', height: '40px', objectFit: 'cover' }}
                            />
                          )}
                          <div>
                            <h6 className="mb-0">{certificate.title}</h6>
                            <small className="text-muted">
                              {certificate.description?.substring(0, 60)}
                              {certificate.description?.length > 60 && '...'}
                            </small>
                          </div>
                        </div>
                      </td>
                      <td>{certificate.issuer}</td>
                      <td>{certificate.year}</td>
                      <td>
                        <span className={`badge ${
                          certificate.category === 'Web Development' ? 'bg-primary' :
                          certificate.category === 'Programming' ? 'bg-success' :
                          certificate.category === 'Frameworks' ? 'bg-info' :
                          certificate.category === 'Cloud Computing' ? 'bg-warning text-dark' :
                          'bg-secondary'
                        }`}>
                          {certificate.category}
                        </span>
                      </td>
                      <td>
                        <div className="d-flex gap-1">
                          <span className={`badge ${certificate.isActive ? 'bg-success' : 'bg-secondary'}`}>
                            {certificate.isActive ? 'Active' : 'Inactive'}
                          </span>
                          {certificate.featured && (
                            <span className="badge bg-warning text-dark">
                              <i className="fas fa-star me-1"></i>Featured
                            </span>
                          )}
                        </div>
                      </td>
                      <td>
                        <div className="btn-group" role="group">
                          <Link 
                            to={`/admin/certificates/edit/${certificate.slug}`}
                            className="btn btn-sm btn-outline-primary"
                            title="Edit"
                          >
                            <i className="fas fa-edit"></i>
                          </Link>
                          
                          <button
                            onClick={() => handleToggleFeatured(certificate.slug)}
                            className={`btn btn-sm ${certificate.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                            title={certificate.featured ? 'Remove from featured' : 'Add to featured'}
                          >
                            <i className="fas fa-star"></i>
                          </button>
                          
                          <button
                            onClick={() => handleToggleActive(certificate.slug)}
                            className={`btn btn-sm ${certificate.isActive ? 'btn-success' : 'btn-outline-success'}`}
                            title={certificate.isActive ? 'Deactivate' : 'Activate'}
                          >
                            <i className={`fas ${certificate.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                          </button>
                          
                          <button
                            onClick={() => handleDelete(certificate.slug, certificate.title)}
                            className="btn btn-sm btn-outline-danger"
                            title="Delete"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="mt-4">
        <Link to="/admin" className="btn btn-secondary">
          <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
        </Link>
      </div>
    </div>
  );
};

export default CertificateList;
