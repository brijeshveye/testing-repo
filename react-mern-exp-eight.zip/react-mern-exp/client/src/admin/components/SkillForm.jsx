import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import SkillsDataApi from '../../api/SkillsDataApi';

const SkillForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Language',
    level: 'Intermediate',
    percentage: 50,
    icon: 'fas fa-code',
    color: '#007bff',
    yearsExperience: 1,
    certifications: [],
    projects: [],
    featured: false,
    isActive: true,
    order: 0,
    customIcon: false
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Predefined options
  const categories = [
    'Language', 'Frontend', 'Backend', 'Database', 'Cloud', 
    'DevOps', 'Design', 'Mobile', 'Testing', 'Other'
  ];

  const levels = [
    'Beginner', 'Intermediate', 'Advanced', 'Expert'
  ];

  const commonIcons = [
    'fas fa-code', 'fab fa-js-square', 'fab fa-react', 'fab fa-node-js',
    'fab fa-python', 'fab fa-java', 'fab fa-php', 'fab fa-html5',
    'fab fa-css3-alt', 'fab fa-sass', 'fab fa-angular', 'fab fa-vue',
    'fab fa-bootstrap', 'fab fa-git-alt', 'fab fa-github', 'fab fa-docker',
    'fab fa-aws', 'fab fa-google', 'fas fa-database', 'fas fa-server',
    'fas fa-mobile-alt', 'fas fa-palette', 'fas fa-cogs', 'fas fa-chart-bar',
    'fab fa-laravel', 'fab fa-symfony', 'fab fa-wordpress', 'fab fa-drupal',
    'fab fa-figma', 'fab fa-sketch', 'fab fa-adobe', 'fab fa-microsoft',
    'fas fa-cloud', 'fas fa-lock', 'fas fa-shield-alt', 'fas fa-tools',
    'fas fa-laptop-code', 'fas fa-terminal', 'fas fa-bug', 'fas fa-rocket',
    'fab fa-android', 'fab fa-apple', 'fab fa-linux', 'fab fa-windows',
    'fab fa-unity', 'fab fa-unity', 'fas fa-gamepad', 'fas fa-video'
  ];

  const commonColors = [
    '#007bff', '#28a745', '#ffc107', '#dc3545', '#6f42c1', '#fd7e14',
    '#20c997', '#6c757d', '#e83e8c', '#17a2b8', '#343a40', '#f8f9fa'
  ];

  useEffect(() => {
    if (isEdit) {
      fetchSkillData();
    }
  }, [isEdit, slug]);

  const fetchSkillData = async () => {
    try {
      setLoading(true);
      const data = await SkillsDataApi.getSkillDetails(slug);
      if (data) {
        const isCustomIcon = !commonIcons.includes(data.icon || 'fas fa-code');
        setFormData({
          title: data.title || '',
          description: data.description || '',
          category: data.category || 'Language',
          level: data.level || 'Intermediate',
          percentage: data.percentage || 50,
          icon: data.icon || 'fas fa-code',
          color: data.color || '#007bff',
          yearsExperience: data.yearsExperience || 1,
          certifications: data.certifications || [],
          projects: data.projects || [],
          featured: data.featured || false,
          isActive: data.isActive !== undefined ? data.isActive : true,
          order: data.order || 0,
          customIcon: isCustomIcon
        });
      }
    } catch (err) {
      setError('Failed to fetch skill data');
      console.error('Error fetching skill:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleArrayChange = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => 
        i === index ? value : item
      )
    }));
  };

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], '']
    }));
  };

  const removeArrayItem = (index, field) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Clean up empty array items and remove UI-only fields
      const cleanedData = {
        ...formData,
        certifications: formData.certifications.filter(cert => cert.trim()),
        projects: formData.projects.filter(project => project.trim()),
        percentage: parseInt(formData.percentage),
        yearsExperience: parseInt(formData.yearsExperience),
        order: parseInt(formData.order)
      };
      
      // Remove UI-only fields
      delete cleanedData.customIcon;

      if (isEdit) {
        await SkillsDataApi.updateSkill(slug, cleanedData);
        setSuccess('Skill updated successfully!');
      } else {
        await SkillsDataApi.createSkill(cleanedData);
        setSuccess('Skill created successfully!');
      }

      setTimeout(() => {
        navigate('/admin/skills');
      }, 1500);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save skill');
      console.error('Error saving skill:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>{isEdit ? 'Edit Skill' : 'Create New Skill'}</h1>
            <Link to="/admin/skills" className="btn btn-secondary">
              <i className="fas fa-arrow-left me-2"></i>Back to List
            </Link>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger">
          <i className="fas fa-exclamation-triangle me-2"></i>
          {error}
        </div>
      )}

      {success && (
        <div className="alert alert-success">
          <i className="fas fa-check-circle me-2"></i>
          {success}
        </div>
      )}

      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                {/* Basic Information */}
                <div className="row mb-3">
                  <div className="col-md-6">
                    <label className="form-label">Skill Title *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      required
                      placeholder="e.g., JavaScript, React, Node.js"
                    />
                  </div>
                  <div className="col-md-3">
                    <label className="form-label">Category *</label>
                    <select
                      className="form-select"
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                      required
                    >
                      {categories.map(category => (
                        <option key={category} value={category}>
                          {category}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-md-3">
                    <label className="form-label">Level *</label>
                    <select
                      className="form-select"
                      name="level"
                      value={formData.level}
                      onChange={handleChange}
                      required
                    >
                      {levels.map(level => (
                        <option key={level} value={level}>
                          {level}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Description</label>
                  <textarea
                    className="form-control"
                    name="description"
                    rows="3"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Brief description of your skill and experience..."
                  />
                </div>

                {/* Proficiency and Experience */}
                <div className="row mb-3">
                  <div className="col-md-4">
                    <label className="form-label">Proficiency Percentage</label>
                    <div className="input-group">
                      <input
                        type="number"
                        className="form-control"
                        name="percentage"
                        value={formData.percentage}
                        onChange={handleChange}
                        min="0"
                        max="100"
                      />
                      <span className="input-group-text">%</span>
                    </div>
                    <div className="progress mt-2" style={{ height: '8px' }}>
                      <div
                        className="progress-bar"
                        role="progressbar"
                        style={{ width: `${formData.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <label className="form-label">Years of Experience</label>
                    <input
                      type="number"
                      className="form-control"
                      name="yearsExperience"
                      value={formData.yearsExperience}
                      onChange={handleChange}
                      min="0"
                      step="0.5"
                    />
                  </div>
                  <div className="col-md-4">
                    <label className="form-label">Display Order</label>
                    <input
                      type="number"
                      className="form-control"
                      name="order"
                      value={formData.order}
                      onChange={handleChange}
                      min="0"
                    />
                  </div>
                </div>

                {/* Visual Customization */}
                <div className="row mb-3">
                  <div className="col-md-6">
                    <label className="form-label">Icon</label>
                    <div className="mb-2">
                      <div className="btn-group w-100" role="group">
                        <input 
                          type="radio" 
                          className="btn-check" 
                          name="iconInputType" 
                          id="iconSelect" 
                          checked={!formData.customIcon} 
                          onChange={() => setFormData(prev => ({ ...prev, customIcon: false }))} 
                        />
                        <label className="btn btn-outline-primary" htmlFor="iconSelect">
                          Select from List
                        </label>
                        
                        <input 
                          type="radio" 
                          className="btn-check" 
                          name="iconInputType" 
                          id="iconCustom" 
                          checked={formData.customIcon} 
                          onChange={() => setFormData(prev => ({ ...prev, customIcon: true }))} 
                        />
                        <label className="btn btn-outline-primary" htmlFor="iconCustom">
                          Custom Icon
                        </label>
                      </div>
                    </div>
                    
                    {!formData.customIcon ? (
                      <select
                        className="form-select"
                        name="icon"
                        value={formData.icon}
                        onChange={handleChange}
                      >
                        {commonIcons.map(icon => (
                          <option key={icon} value={icon}>
                            {icon}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <div>
                        <input
                          type="text"
                          className="form-control"
                          name="icon"
                          value={formData.icon}
                          onChange={handleChange}
                          placeholder="e.g., fas fa-code, fab fa-react, etc."
                        />
                        <small className="form-text text-muted">
                          Enter FontAwesome class names. Visit <a href="https://fontawesome.com/icons" target="_blank" rel="noopener noreferrer">FontAwesome</a> for icon classes.
                        </small>
                      </div>
                    )}
                    
                    <div className="mt-3 p-3 bg-light rounded">
                      <div className="d-flex align-items-center">
                        <span className="me-3"><strong>Preview:</strong></span>
                        <div 
                          className="icon-preview d-inline-flex align-items-center justify-content-center rounded"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: formData.color,
                            color: 'white'
                          }}
                        >
                          <i className={formData.icon} style={{ fontSize: '20px' }}></i>
                        </div>
                        <span className="ms-3 text-muted small">
                          Icon: <code>{formData.icon}</code>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Color</label>
                    <div className="row g-2">
                      <div className="col-8">
                        <input
                          type="color"
                          className="form-control form-control-color"
                          name="color"
                          value={formData.color}
                          onChange={handleChange}
                        />
                      </div>
                      <div className="col-4">
                        <input
                          type="text"
                          className="form-control"
                          name="color"
                          value={formData.color}
                          onChange={handleChange}
                          placeholder="#007bff"
                        />
                      </div>
                    </div>
                    <div className="mt-2">
                      {commonColors.map(color => (
                        <button
                          key={color}
                          type="button"
                          className="btn btn-sm me-1 mb-1"
                          style={{ 
                            backgroundColor: color, 
                            width: '30px', 
                            height: '30px',
                            border: formData.color === color ? '3px solid #000' : '1px solid #ccc'
                          }}
                          onClick={() => setFormData(prev => ({ ...prev, color }))}
                        ></button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Certifications */}
                <div className="mb-3">
                  <label className="form-label">Certifications</label>
                  {formData.certifications.map((cert, index) => (
                    <div key={index} className="input-group mb-2">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Certificate name or link"
                        value={cert}
                        onChange={(e) => handleArrayChange(index, 'certifications', e.target.value)}
                      />
                      <button
                        type="button"
                        className="btn btn-outline-danger"
                        onClick={() => removeArrayItem(index, 'certifications')}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    onClick={() => addArrayItem('certifications')}
                  >
                    <i className="fas fa-plus me-2"></i>Add Certification
                  </button>
                </div>

                {/* Related Projects */}
                <div className="mb-3">
                  <label className="form-label">Related Projects</label>
                  {formData.projects.map((project, index) => (
                    <div key={index} className="input-group mb-2">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Project name or description"
                        value={project}
                        onChange={(e) => handleArrayChange(index, 'projects', e.target.value)}
                      />
                      <button
                        type="button"
                        className="btn btn-outline-danger"
                        onClick={() => removeArrayItem(index, 'projects')}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    onClick={() => addArrayItem('projects')}
                  >
                    <i className="fas fa-plus me-2"></i>Add Project
                  </button>
                </div>

                {/* Status Options */}
                <div className="row mb-4">
                  <div className="col-md-6">
                    <div className="form-check form-switch">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        name="featured"
                        id="featured"
                        checked={formData.featured}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="featured">
                        <i className="fas fa-star text-warning me-2"></i>
                        Featured Skill
                      </label>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-check form-switch">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        name="isActive"
                        id="isActive"
                        checked={formData.isActive}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="isActive">
                        <i className="fas fa-eye text-success me-2"></i>
                        Active/Visible
                      </label>
                    </div>
                  </div>
                </div>

                {/* Submit Buttons */}
                <div className="d-flex gap-2">
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        {isEdit ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      <>
                        <i className={`fas ${isEdit ? 'fa-save' : 'fa-plus'} me-2`}></i>
                        {isEdit ? 'Update Skill' : 'Create Skill'}
                      </>
                    )}
                  </button>
                  <Link to="/admin/skills" className="btn btn-secondary">
                    Cancel
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* Preview Card */}
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">
                <i className="fas fa-eye me-2"></i>Preview
              </h5>
            </div>
            <div className="card-body">
              <div className="text-center">
                <div
                  className="skill-icon d-inline-flex align-items-center justify-content-center rounded mb-3"
                  style={{
                    width: '60px',
                    height: '60px',
                    backgroundColor: formData.color,
                    color: '#fff'
                  }}
                >
                  <i className={formData.icon} style={{ fontSize: '24px' }}></i>
                </div>
                <h5>{formData.title || 'Skill Title'}</h5>
                <p className="text-muted small">
                  {formData.description || 'Skill description will appear here...'}
                </p>
                
                <div className="mb-2">
                  <span className={`badge ${
                    formData.category === 'Language' ? 'bg-primary' :
                    formData.category === 'Frontend' ? 'bg-success' :
                    formData.category === 'Backend' ? 'bg-info' :
                    formData.category === 'Database' ? 'bg-warning text-dark' :
                    'bg-secondary'
                  }`}>
                    {formData.category}
                  </span>
                  <span className={`badge ms-1 ${
                    formData.level === 'Expert' ? 'bg-success' :
                    formData.level === 'Advanced' ? 'bg-info' :
                    formData.level === 'Intermediate' ? 'bg-warning text-dark' :
                    'bg-secondary'
                  }`}>
                    {formData.level}
                  </span>
                </div>

                <div className="mb-2">
                  <div className="progress" style={{ height: '8px' }}>
                    <div
                      className="progress-bar"
                      role="progressbar"
                      style={{ width: `${formData.percentage}%` }}
                    ></div>
                  </div>
                  <small className="text-muted">{formData.percentage}% Proficiency</small>
                </div>

                <div className="d-flex justify-content-center gap-1 mt-2">
                  {formData.featured && (
                    <span className="badge bg-warning text-dark">
                      <i className="fas fa-star me-1"></i>Featured
                    </span>
                  )}
                  <span className={`badge ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                    {formData.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SkillForm;
