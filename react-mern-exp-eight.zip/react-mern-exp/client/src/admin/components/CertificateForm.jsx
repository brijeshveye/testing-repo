import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import CertificatesDataApi from '../../api/CertificatesDataApi';
import { ImageUploader } from './ImageUpload';

const CertificateForm = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(slug);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    issuer: '',
    year: new Date().getFullYear().toString(),
    image: '',
    url: '',
    category: 'General',
    credentialId: '',
    expiryDate: '',
    skills: [],
    featured: false,
    isActive: true
  });
  
  const [skillInput, setSkillInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const categories = [
    'General',
    'Web Development',
    'Programming',
    'Frameworks',
    'Cloud Computing',
    'Data Science',
    'Mobile Development',
    'UI/UX Design',
    'DevOps',
    'Cybersecurity',
    'Database',
    'Project Management'
  ];

  useEffect(() => {
    if (isEdit) {
      fetchCertificate();
    }
    
    // Cleanup function to prevent DOM issues
    return () => {
      setError('');
      setSuccess('');
    };
  }, [slug, isEdit]);

  const fetchCertificate = async () => {
    try {
      setLoading(true);
      const certificate = await CertificatesDataApi.getCertificateDetails(slug);
      if (certificate) {
        setFormData({
          title: certificate.title || '',
          description: certificate.description || '',
          issuer: certificate.issuer || '',
          year: certificate.year || new Date().getFullYear().toString(),
          image: certificate.image || '',
          url: certificate.url || '',
          category: certificate.category || 'General',
          credentialId: certificate.credentialId || '',
          expiryDate: certificate.expiryDate ? new Date(certificate.expiryDate).toISOString().split('T')[0] : '',
          skills: certificate.skills || [],
          featured: certificate.featured || false,
          isActive: certificate.isActive !== false
        });
      } else {
        setError('Certificate not found');
      }
    } catch (err) {
      setError('Failed to load certificate');
      console.error('Error fetching certificate:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear messages when user starts typing
    if (error) setError('');
    if (success) setSuccess('');
  };

  const handleImageUpload = (imageUrl) => {
    setFormData(prev => ({
      ...prev,
      image: imageUrl
    }));
  };

  const handleAddSkill = () => {
    if (skillInput.trim() && !formData.skills.includes(skillInput.trim())) {
      setFormData(prev => ({
        ...prev,
        skills: [...prev.skills, skillInput.trim()]
      }));
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill !== skillToRemove)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.title.trim()) {
      setError('Certificate title is required');
      return;
    }
    if (!formData.description.trim()) {
      setError('Certificate description is required');
      return;
    }
    if (!formData.issuer.trim()) {
      setError('Issuer is required');
      return;
    }
    if (!formData.year.trim()) {
      setError('Year is required');
      return;
    }

    try {
      setLoading(true);
      setError('');

      const submitData = {
        ...formData,
        expiryDate: formData.expiryDate ? new Date(formData.expiryDate) : null
      };

      if (isEdit) {
        await CertificatesDataApi.updateCertificate(slug, submitData);
        setSuccess('Certificate updated successfully!');
      } else {
        await CertificatesDataApi.createCertificate(submitData);
        setSuccess('Certificate created successfully!');
      }

      // Redirect after a short delay
      setTimeout(() => {
        navigate('/admin/certificates');
      }, 1500);

    } catch (err) {
      setError(err.response?.data?.message || `Failed to ${isEdit ? 'update' : 'create'} certificate`);
      console.error('Error saving certificate:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>{isEdit ? 'Edit Certificate' : 'Create New Certificate'}</h1>
            <button 
              type="button" 
              className="btn btn-secondary"
              onClick={() => navigate('/admin/certificates')}
            >
              <i className="fas fa-arrow-left me-2"></i>Back to List
            </button>
          </div>
        </div>
      </div>

      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-body">
              {error && (
                <div className="alert alert-danger">
                  <i className="fas fa-exclamation-triangle me-2"></i>
                  {error}
                </div>
              )}
              
              {success && (
                <div className="alert alert-success">
                  <i className="fas fa-check-circle me-2"></i>
                  {success}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-md-8 mb-3">
                    <label htmlFor="title" className="form-label">
                      Certificate Title <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  
                  <div className="col-md-4 mb-3">
                    <label htmlFor="year" className="form-label">
                      Year <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="year"
                      name="year"
                      value={formData.year}
                      onChange={handleChange}
                      placeholder="2024"
                      required
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label htmlFor="description" className="form-label">
                    Description <span className="text-danger">*</span>
                  </label>
                  <textarea
                    className="form-control"
                    id="description"
                    name="description"
                    rows="3"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Brief description of the certificate..."
                    required
                  ></textarea>
                </div>

                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label htmlFor="issuer" className="form-label">
                      Issuing Organization <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="issuer"
                      name="issuer"
                      value={formData.issuer}
                      onChange={handleChange}
                      placeholder="e.g., Google, Microsoft, AWS"
                      required
                    />
                  </div>
                  
                  <div className="col-md-6 mb-3">
                    <label htmlFor="category" className="form-label">Category</label>
                    <select
                      className="form-select"
                      id="category"
                      name="category"
                      value={formData.category}
                      onChange={handleChange}
                    >
                      {categories.map(category => (
                        <option key={category} value={category}>{category}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label htmlFor="url" className="form-label">Certificate URL</label>
                    <input
                      type="url"
                      className="form-control"
                      id="url"
                      name="url"
                      value={formData.url}
                      onChange={handleChange}
                      placeholder="https://example.com/certificate/123"
                    />
                  </div>
                  
                  <div className="col-md-6 mb-3">
                    <label htmlFor="credentialId" className="form-label">Credential ID</label>
                    <input
                      type="text"
                      className="form-control"
                      id="credentialId"
                      name="credentialId"
                      value={formData.credentialId}
                      onChange={handleChange}
                      placeholder="Certificate ID or verification code"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label htmlFor="expiryDate" className="form-label">Expiry Date (Optional)</label>
                  <input
                    type="date"
                    className="form-control"
                    id="expiryDate"
                    name="expiryDate"
                    value={formData.expiryDate}
                    onChange={handleChange}
                  />
                  <div className="form-text">Leave empty if the certificate doesn't expire</div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Skills (Optional)</label>
                  <div className="input-group mb-2">
                    <input
                      type="text"
                      className="form-control"
                      value={skillInput}
                      onChange={(e) => setSkillInput(e.target.value)}
                      placeholder="Add a skill..."
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                    />
                    <button
                      type="button"
                      className="btn btn-outline-secondary"
                      onClick={handleAddSkill}
                    >
                      Add
                    </button>
                  </div>
                  
                  {formData.skills.length > 0 && (
                    <div className="d-flex flex-wrap gap-1">
                      {formData.skills.map((skill, index) => (
                        <span key={`skill-${index}-${skill}`} className="badge bg-primary">
                          {skill}
                          <button
                            type="button"
                            className="btn-close btn-close-white ms-1"
                            onClick={() => handleRemoveSkill(skill)}
                            style={{ fontSize: '0.7em' }}
                            aria-label={`Remove ${skill}`}
                          ></button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="row">
                  <div className="col-md-6 mb-3">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="featured"
                        name="featured"
                        checked={formData.featured}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="featured">
                        Featured Certificate
                      </label>
                    </div>
                  </div>
                  
                  <div className="col-md-6 mb-3">
                    <div className="form-check">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id="isActive"
                        name="isActive"
                        checked={formData.isActive}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="isActive">
                        Active/Published
                      </label>
                    </div>
                  </div>
                </div>

                <div className="mb-4">
                  <label className="form-label">Certificate Image</label>
                  {formData.image && (
                    <div className="mb-3">
                      <div className="position-relative d-inline-block">
                        <img 
                          src={formData.image} 
                          alt="Certificate preview" 
                          className="img-thumbnail"
                          style={{ maxHeight: '200px', maxWidth: '100%' }}
                        />
                        <button
                          type="button"
                          className="btn btn-danger btn-sm position-absolute top-0 end-0 m-1"
                          onClick={() => setFormData(prev => ({ ...prev, image: '' }))}
                          title="Remove image"
                        >
                          <i className="fas fa-times"></i>
                        </button>
                      </div>
                      <div className="mt-1">
                        <small className="text-muted">Current certificate image</small>
                      </div>
                    </div>
                  )}
                  <ImageUploader 
                    onUpload={handleImageUpload}
                    category="certificates"
                  />
                  {!formData.image && (
                    <div className="form-text">
                      Upload an image for the certificate. Recommended size: 400x300px or larger.
                    </div>
                  )}
                </div>

                <div className="d-flex gap-2">
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        {isEdit ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      <>
                        <i className="fas fa-save me-2"></i>
                        {isEdit ? 'Update Certificate' : 'Create Certificate'}
                      </>
                    )}
                  </button>
                  
                  <button 
                    type="button" 
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/certificates')}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">Preview</h5>
            </div>
            <div className="card-body">
              <div className="certificate-preview">
                <div className="text-center mb-3">
                  {formData.image ? (
                    <img 
                      src={formData.image} 
                      alt="Certificate"
                      className="img-fluid rounded"
                      style={{ maxHeight: '120px', objectFit: 'cover' }}
                    />
                  ) : (
                    <div 
                      className="bg-primary text-white d-flex align-items-center justify-content-center rounded"
                      style={{ height: '120px' }}
                    >
                      <i className="fas fa-certificate fa-3x"></i>
                    </div>
                  )}
                </div>

                <h6 className="mb-2">{formData.title || 'Certificate Title'}</h6>
                <p className="text-muted small mb-2">
                  {formData.description || 'Certificate description will appear here...'}
                </p>
                
                <div className="mb-2">
                  <small className="text-muted">
                    <strong>Issued by:</strong> {formData.issuer || 'Issuing Organization'}
                  </small>
                </div>
                
                <div className="mb-2">
                  <small className="text-muted">
                    <strong>Year:</strong> {formData.year || 'YYYY'}
                  </small>
                </div>

                <div className="mb-2">
                  <span className={`badge ${
                    formData.category === 'Web Development' ? 'bg-primary' :
                    formData.category === 'Programming' ? 'bg-success' :
                    formData.category === 'Frameworks' ? 'bg-info' :
                    formData.category === 'Cloud Computing' ? 'bg-warning text-dark' :
                    'bg-secondary'
                  }`}>
                    {formData.category}
                  </span>
                </div>

                {formData.skills.length > 0 && (
                  <div className="mb-2">
                    <small className="text-muted d-block mb-1">
                      <strong>Skills:</strong>
                    </small>
                    <div className="d-flex flex-wrap gap-1">
                      {formData.skills.slice(0, 3).map((skill, index) => (
                        <span key={`preview-skill-${index}-${skill}`} className="badge bg-light text-dark">
                          {skill}
                        </span>
                      ))}
                      {formData.skills.length > 3 && (
                        <span className="badge bg-light text-muted">
                          +{formData.skills.length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {formData.featured && (
                  <div className="text-center mt-2">
                    <span className="badge bg-warning text-dark">
                      <i className="fas fa-star me-1"></i>Featured
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CertificateForm;
