import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import EducationDataApi from '../../api/EducationDataApi';

const EducationList = () => {
  const [education, setEducation] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    degree: 'all',
    institution: '',
    featured: 'all',
    status: 'all',
    current: 'all',
    search: ''
  });

  useEffect(() => {
    fetchEducation();
    fetchStats();
  }, [filters]);

  const fetchEducation = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.degree !== 'all') params.degree = filters.degree;
      if (filters.institution) params.institution = filters.institution;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.current !== 'all') params.current = filters.current;
      if (filters.search) params.search = filters.search;

      const data = await EducationDataApi.getEducationData(params);
      setEducation(data);
    } catch (err) {
      setError('Failed to fetch education records');
      console.error('Error fetching education:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await EducationDataApi.getEducationStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await EducationDataApi.deleteEducation(slug);
        fetchEducation(); // Refresh the list
      } catch (err) {
        setError('Failed to delete education record');
        console.error('Error deleting education:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await EducationDataApi.toggleFeatured(slug);
      fetchEducation(); // Refresh the list
    } catch (err) {
      setError('Failed to update featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await EducationDataApi.toggleActive(slug);
      fetchEducation(); // Refresh the list
    } catch (err) {
      setError('Failed to update active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const formatDate = (date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short'
    });
  };

  const getDuration = (startDate, endDate, current) => {
    const start = formatDate(startDate);
    const end = current ? 'Present' : formatDate(endDate);
    return `${start} - ${end}`;
  };

  if (loading) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>Manage Education</h1>
            <Link to="/admin/education/create" className="btn btn-primary">
              <i className="fas fa-plus me-2"></i>Add New Education
            </Link>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger">
          <i className="fas fa-exclamation-triangle me-2"></i>
          {error}
        </div>
      )}

      {/* Stats Cards */}
      {stats && (
        <div className="row mb-4">
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-primary">{stats.totalEducation}</h5>
                <p className="card-text">Total Records</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-success">{stats.activeEducation}</h5>
                <p className="card-text">Active Records</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-warning">{stats.featuredEducation}</h5>
                <p className="card-text">Featured</p>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card text-center">
              <div className="card-body">
                <h5 className="card-title text-info">{stats.currentEducation}</h5>
                <p className="card-text">Current Studies</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-body">
          <div className="row g-3">
            <div className="col-md-3">
              <label className="form-label">Search</label>
              <input
                type="text"
                className="form-control"
                name="search"
                placeholder="Search education..."
                value={filters.search}
                onChange={handleFilterChange}
              />
            </div>
            
            <div className="col-md-2">
              <label className="form-label">Degree</label>
              <select
                className="form-select"
                name="degree"
                value={filters.degree}
                onChange={handleFilterChange}
              >
                <option value="all">All Degrees</option>
                <option value="Bachelor">Bachelor</option>
                <option value="Master">Master</option>
                <option value="PhD">PhD</option>
                <option value="Diploma">Diploma</option>
                <option value="Certificate">Certificate</option>
              </select>
            </div>
            
            <div className="col-md-2">
              <label className="form-label">Institution</label>
              <input
                type="text"
                className="form-control"
                name="institution"
                placeholder="Institution..."
                value={filters.institution}
                onChange={handleFilterChange}
              />
            </div>
            
            <div className="col-md-2">
              <label className="form-label">Featured</label>
              <select
                className="form-select"
                name="featured"
                value={filters.featured}
                onChange={handleFilterChange}
              >
                <option value="all">All</option>
                <option value="true">Featured</option>
                <option value="false">Not Featured</option>
              </select>
            </div>
            
            <div className="col-md-2">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                name="status"
                value={filters.status}
                onChange={handleFilterChange}
              >
                <option value="all">All</option>
                <option value="true">Active</option>
                <option value="false">Inactive</option>
              </select>
            </div>
            
            <div className="col-md-1">
              <label className="form-label">Current</label>
              <select
                className="form-select"
                name="current"
                value={filters.current}
                onChange={handleFilterChange}
              >
                <option value="all">All</option>
                <option value="true">Current</option>
                <option value="false">Completed</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Education List */}
      <div className="card">
        <div className="card-body">
          {education.length === 0 ? (
            <div className="text-center py-5">
              <i className="fas fa-graduation-cap fa-3x text-muted mb-3"></i>
              <h5>No education records found</h5>
              <p className="text-muted">
                {filters.search || filters.degree !== 'all' || filters.institution || filters.featured !== 'all' || filters.status !== 'all' || filters.current !== 'all'
                  ? 'Try adjusting your filters or search terms.'
                  : 'Start by creating your first education record.'}
              </p>
              <Link to="/admin/education/create" className="btn btn-primary">
                <i className="fas fa-plus me-2"></i>Create Education Record
              </Link>
            </div>
          ) : (
            <div className="table-responsive">
              <table className="table table-hover">
                <thead>
                  <tr>
                    <th>Education</th>
                    <th>Institution</th>
                    <th>Duration</th>
                    <th>Degree</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {education.map((edu) => (
                    <tr key={edu._id}>
                      <td>
                        <div>
                          <h6 className="mb-0">{edu.title}</h6>
                          {edu.fieldOfStudy && (
                            <small className="text-muted">{edu.fieldOfStudy}</small>
                          )}
                          {edu.grade && (
                            <div>
                              <small className="text-success">Grade: {edu.grade}</small>
                            </div>
                          )}
                        </div>
                      </td>
                      <td>
                        <div>
                          <strong>{edu.institution}</strong>
                          {edu.location && (
                            <div>
                              <small className="text-muted">
                                <i className="fas fa-map-marker-alt me-1"></i>
                                {edu.location}
                              </small>
                            </div>
                          )}
                        </div>
                      </td>
                      <td>
                        <div>
                          <small>{getDuration(edu.startDate, edu.endDate, edu.current)}</small>
                          {edu.current && (
                            <div>
                              <span className="badge bg-success badge-sm">Current</span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td>
                        {edu.degree && (
                          <span className="badge bg-primary">{edu.degree}</span>
                        )}
                      </td>
                      <td>
                        <div className="d-flex gap-1 flex-wrap">
                          <span className={`badge ${edu.isActive ? 'bg-success' : 'bg-secondary'}`}>
                            {edu.isActive ? 'Active' : 'Inactive'}
                          </span>
                          {edu.featured && (
                            <span className="badge bg-warning text-dark">
                              <i className="fas fa-star me-1"></i>Featured
                            </span>
                          )}
                        </div>
                      </td>
                      <td>
                        <div className="btn-group" role="group">
                          <Link 
                            to={`/admin/education/edit/${edu.slug}`}
                            className="btn btn-sm btn-outline-primary"
                            title="Edit"
                          >
                            <i className="fas fa-edit"></i>
                          </Link>
                          
                          <button
                            onClick={() => handleToggleFeatured(edu.slug)}
                            className={`btn btn-sm ${edu.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                            title={edu.featured ? 'Remove from featured' : 'Add to featured'}
                          >
                            <i className="fas fa-star"></i>
                          </button>
                          
                          <button
                            onClick={() => handleToggleActive(edu.slug)}
                            className={`btn btn-sm ${edu.isActive ? 'btn-success' : 'btn-outline-success'}`}
                            title={edu.isActive ? 'Deactivate' : 'Activate'}
                          >
                            <i className={`fas ${edu.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                          </button>
                          
                          <button
                            onClick={() => handleDelete(edu.slug, edu.title)}
                            className="btn btn-sm btn-outline-danger"
                            title="Delete"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="mt-4">
        <Link to="/admin" className="btn btn-secondary">
          <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
        </Link>
      </div>
    </div>
  );
};

export default EducationList;
