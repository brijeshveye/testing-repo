import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ServiceDataApi from '../../api/ServiceDataApi';
import ServiceCard from '../../components/service/ServiceCard';

const ServiceList = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    category: '',
    featured: 'all',
    status: 'all',
    search: ''
  });

  useEffect(() => {
    fetchServices();
    fetchStats();
  }, [filters]);

  const fetchServices = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.category) params.category = filters.category;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.search) params.search = filters.search;

      const data = await ServiceDataApi.getServiceData(params);
      setServices(data);
    } catch (err) {
      setError('Failed to fetch services');
      console.error('Error fetching services:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await ServiceDataApi.getServiceStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleEdit = (service) => {
    window.location.href = `/admin/services/edit/${service.slug}`;
  };

  const handleDelete = async (service) => {
    if (window.confirm(`Are you sure you want to delete "${service.title}"?`)) {
      try {
        await ServiceDataApi.deleteService(service.slug);
        fetchServices();
        fetchStats();
      } catch (err) {
        alert('Failed to delete service');
        console.error('Error deleting service:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await ServiceDataApi.toggleFeatured(slug);
      fetchServices();
      fetchStats();
    } catch (err) {
      alert('Failed to toggle featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await ServiceDataApi.toggleActive(slug);
      fetchServices();
      fetchStats();
    } catch (err) {
      alert('Failed to toggle active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  if (loading && services.length === 0) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1>Service Management</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/admin">Admin</Link></li>
              <li className="breadcrumb-item active">Services</li>
            </ol>
          </nav>
        </div>
        <Link to="/admin/services/create" className="btn btn-primary">
          <i className="fas fa-plus me-2"></i>Add New Service
        </Link>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="row mb-4">
          <div className="col-md-4">
            <div className="card bg-primary text-white">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <div>
                    <h6 className="card-title">Total Services</h6>
                    <h3 className="mb-0">{stats.totalServices}</h3>
                  </div>
                  <div>
                    <i className="fas fa-cogs fa-2x opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card bg-success text-white">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <div>
                    <h6 className="card-title">Active</h6>
                    <h3 className="mb-0">{stats.activeServices}</h3>
                  </div>
                  <div>
                    <i className="fas fa-eye fa-2x opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-4">
            <div className="card bg-warning text-dark">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <div>
                    <h6 className="card-title">Featured</h6>
                    <h3 className="mb-0">{stats.featuredServices}</h3>
                  </div>
                  <div>
                    <i className="fas fa-star fa-2x opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title">Filters</h5>
          <div className="row g-3">
            <div className="col-md-4">
              <label className="form-label">Search</label>
              <input
                type="text"
                className="form-control"
                placeholder="Search services..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
              />
            </div>
            <div className="col-md-3">
              <label className="form-label">Category</label>
              <input
                type="text"
                className="form-control"
                placeholder="Category..."
                value={filters.category}
                onChange={(e) => handleFilterChange('category', e.target.value)}
              />
            </div>
            <div className="col-md-2">
              <label className="form-label">Featured</label>
              <select
                className="form-select"
                value={filters.featured}
                onChange={(e) => handleFilterChange('featured', e.target.value)}
              >
                <option value="all">All</option>
                <option value="true">Featured</option>
                <option value="false">Not Featured</option>
              </select>
            </div>
            <div className="col-md-3">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
              >
                <option value="all">All</option>
                <option value="true">Active</option>
                <option value="false">Hidden</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}

      {/* Services Grid */}
      {services.length === 0 ? (
        <div className="text-center py-5">
          <i className="fas fa-cogs fa-3x text-muted mb-3"></i>
          <h3 className="text-muted">No Services Found</h3>
          <p className="text-muted">Start by adding your first service offering.</p>
          <Link to="/admin/services/create" className="btn btn-primary">
            <i className="fas fa-plus me-2"></i>Add Service
          </Link>
        </div>
      ) : (
        <div className="row">
          {services.map((service) => (
            <ServiceCard
              key={service._id}
              service={service}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onToggleFeatured={handleToggleFeatured}
              onToggleActive={handleToggleActive}
            />
          ))}
        </div>
      )}

      {/* Loading Overlay */}
      {loading && services.length > 0 && (
        <div className="text-center py-3">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceList;
