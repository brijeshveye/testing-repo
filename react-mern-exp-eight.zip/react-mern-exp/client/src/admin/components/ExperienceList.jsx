import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ExperienceDataApi from '../../api/ExperienceDataApi';
import ExperienceCard from '../../components/experience/ExperienceCard';

const ExperienceList = () => {
  const [experience, setExperience] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    company: '',
    employmentType: 'all',
    featured: 'all',
    status: 'all',
    current: 'all',
    search: ''
  });

  useEffect(() => {
    fetchExperience();
    fetchStats();
  }, [filters]);

  const fetchExperience = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.company) params.company = filters.company;
      if (filters.employmentType !== 'all') params.employmentType = filters.employmentType;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.current !== 'all') params.current = filters.current;
      if (filters.search) params.search = filters.search;

      const data = await ExperienceDataApi.getExperienceData(params);
      setExperience(data);
    } catch (err) {
      setError('Failed to fetch experience records');
      console.error('Error fetching experience:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await ExperienceDataApi.getExperienceStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleEdit = (experienceItem) => {
    window.location.href = `/admin/experience/edit/${experienceItem.slug}`;
  };

  const handleDelete = async (experienceItem) => {
    if (window.confirm(`Are you sure you want to delete "${experienceItem.title}" at ${experienceItem.company}?`)) {
      try {
        await ExperienceDataApi.deleteExperience(experienceItem.slug);
        fetchExperience();
        fetchStats();
      } catch (err) {
        alert('Failed to delete experience record');
        console.error('Error deleting experience:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await ExperienceDataApi.toggleFeatured(slug);
      fetchExperience();
      fetchStats();
    } catch (err) {
      alert('Failed to toggle featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await ExperienceDataApi.toggleActive(slug);
      fetchExperience();
      fetchStats();
    } catch (err) {
      alert('Failed to toggle active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  if (loading && experience.length === 0) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1>Experience Management</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/admin">Admin</Link></li>
              <li className="breadcrumb-item active">Experience</li>
            </ol>
          </nav>
        </div>
        <Link to="/admin/experience/create" className="btn btn-primary">
          <i className="fas fa-plus me-2"></i>Add New Experience
        </Link>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="row mb-4">
          <div className="col-md-3">
            <div className="card bg-primary text-white">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <div>
                    <h6 className="card-title">Total Experience</h6>
                    <h3 className="mb-0">{stats.totalExperience}</h3>
                  </div>
                  <div>
                    <i className="fas fa-briefcase fa-2x opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card bg-success text-white">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <div>
                    <h6 className="card-title">Active</h6>
                    <h3 className="mb-0">{stats.activeExperience}</h3>
                  </div>
                  <div>
                    <i className="fas fa-eye fa-2x opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card bg-warning text-dark">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <div>
                    <h6 className="card-title">Featured</h6>
                    <h3 className="mb-0">{stats.featuredExperience}</h3>
                  </div>
                  <div>
                    <i className="fas fa-star fa-2x opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div className="card bg-info text-white">
              <div className="card-body">
                <div className="d-flex justify-content-between">
                  <div>
                    <h6 className="card-title">Current</h6>
                    <h3 className="mb-0">{stats.currentExperience}</h3>
                  </div>
                  <div>
                    <i className="fas fa-play fa-2x opacity-50"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="card mb-4">
        <div className="card-body">
          <h5 className="card-title">Filters</h5>
          <div className="row g-3">
            <div className="col-md-3">
              <label className="form-label">Search</label>
              <input
                type="text"
                className="form-control"
                placeholder="Search experience..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
              />
            </div>
            <div className="col-md-2">
              <label className="form-label">Company</label>
              <input
                type="text"
                className="form-control"
                placeholder="Company name..."
                value={filters.company}
                onChange={(e) => handleFilterChange('company', e.target.value)}
              />
            </div>
            <div className="col-md-2">
              <label className="form-label">Employment Type</label>
              <select
                className="form-select"
                value={filters.employmentType}
                onChange={(e) => handleFilterChange('employmentType', e.target.value)}
              >
                <option value="all">All Types</option>
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Contract">Contract</option>
                <option value="Internship">Internship</option>
                <option value="Freelance">Freelance</option>
                <option value="Volunteer">Volunteer</option>
              </select>
            </div>
            <div className="col-md-2">
              <label className="form-label">Featured</label>
              <select
                className="form-select"
                value={filters.featured}
                onChange={(e) => handleFilterChange('featured', e.target.value)}
              >
                <option value="all">All</option>
                <option value="true">Featured</option>
                <option value="false">Not Featured</option>
              </select>
            </div>
            <div className="col-md-2">
              <label className="form-label">Status</label>
              <select
                className="form-select"
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
              >
                <option value="all">All</option>
                <option value="true">Active</option>
                <option value="false">Hidden</option>
              </select>
            </div>
            <div className="col-md-1">
              <label className="form-label">Current</label>
              <select
                className="form-select"
                value={filters.current}
                onChange={(e) => handleFilterChange('current', e.target.value)}
              >
                <option value="all">All</option>
                <option value="true">Current</option>
                <option value="false">Past</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}

      {/* Experience Grid */}
      {experience.length === 0 ? (
        <div className="text-center py-5">
          <i className="fas fa-briefcase fa-3x text-muted mb-3"></i>
          <h3 className="text-muted">No Experience Records Found</h3>
          <p className="text-muted">Start by adding your first work experience.</p>
          <Link to="/admin/experience/create" className="btn btn-primary">
            <i className="fas fa-plus me-2"></i>Add Experience
          </Link>
        </div>
      ) : (
        <div className="row">
          {experience.map((exp) => (
            <ExperienceCard
              key={exp._id}
              experience={exp}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onToggleFeatured={handleToggleFeatured}
              onToggleActive={handleToggleActive}
            />
          ))}
        </div>
      )}

      {/* Loading Overlay */}
      {loading && experience.length > 0 && (
        <div className="text-center py-3">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExperienceList;
