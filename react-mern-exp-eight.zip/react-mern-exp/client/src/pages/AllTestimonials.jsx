import React, { useState, useEffect } from 'react';
import Layout from '../layouts/Layout';
import TestimonialsDataApi from '../api/TestimonialsDataApi';
import TestimonialCard from '../components/testimonial/TestimonialCard';

const AllTestimonials = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchTestimonials();
  }, []);

  const fetchTestimonials = async () => {
    try {
      setLoading(true);
      const data = await TestimonialsDataApi.getTestimonialsData({ isActive: true });
      setTestimonials(data);
    } catch (err) {
      setError('Failed to load testimonials');
      console.error('Error fetching testimonials:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Layout>
        <div className="container py-5">
          <div className="text-center">
            <div className="spinner-border" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        </div>
      </Layout>
    );
  }

  if (error) {
    return (
      <Layout>
        <div className="container py-5">
          <div className="alert alert-danger text-center">
            {error}
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container py-5">
        <div className="row">
          <div className="col-12">
            <div className="section-heading text-center mb-5">
              <h1>What Our Clients Say</h1>
              <p className="text-muted">
                Read testimonials from our satisfied clients about their experience working with us.
              </p>
            </div>
          </div>
        </div>

        {testimonials.length === 0 ? (
          <div className="row">
            <div className="col-12">
              <div className="text-center py-5">
                <h4>No testimonials available at the moment.</h4>
                <p className="text-muted">Check back later for client feedback.</p>
              </div>
            </div>
          </div>
        ) : (
          <div className="row g-4">
            {testimonials.map((testimonial) => (
              <div key={testimonial._id} className="col-lg-4 col-md-6">
                <TestimonialCard testimonial={testimonial} />
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
};

export default AllTestimonials;
