import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const ServiceDataApi = {
  // Fetch all services from the backend
  getServiceData: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams(params).toString();
      const url = queryParams ? `${API_BASE_URL}/services?${queryParams}` : `${API_BASE_URL}/services`;
      const response = await axios.get(url);
      return response.data.services || response.data;
    } catch (error) {
      console.error('Error fetching services:', error);
      return [];
    }
  },

  // Get services for home page with limit
  getServicesForHome: async (limit = 6) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/services?isActive=true&limit=${limit}&sortBy=order&sortOrder=asc`);
      return response.data.services || response.data;
    } catch (error) {
      console.error('Error fetching services for home:', error);
      return [];
    }
  },

  // Get featured services
  getFeaturedServices: async (limit = 3) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/services?featured=true&isActive=true&limit=${limit}&sortBy=order&sortOrder=asc`);
      return response.data.services || response.data;
    } catch (error) {
      console.error('Error fetching featured services:', error);
      return [];
    }
  },

  // Get services by category
  getServicesByCategory: async (category, limit = null) => {
    try {
      const params = { category, isActive: true };
      if (limit) params.limit = limit;
      
      const response = await axios.get(`${API_BASE_URL}/services`, { params });
      return response.data.services || response.data;
    } catch (error) {
      console.error('Error fetching services by category:', error);
      return [];
    }
  },

  // Get categories (extract from service data)
  getCategories: async () => {
    try {
      const serviceData = await ServiceDataApi.getServiceData({ isActive: true });
      let categories = new Set();
      
      serviceData.forEach(service => {
        if (service.category) {
          categories.add(service.category);
        }
      });

      return Array.from(categories).sort();
    } catch (error) {
      console.error('Error fetching categories:', error);
      return [];
    }
  },

  // Get service details by slug
  getServiceDetails: async (slug, includeInactive = false) => {
    try {
      const params = includeInactive ? '?includeInactive=true' : '';
      const response = await axios.get(`${API_BASE_URL}/services/${slug}${params}`);
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      console.error('Error fetching service details:', error);
      return {
        success: false,
        message: error.response?.data?.message || 'Failed to fetch service details'
      };
    }
  },

  // Get service statistics
  getServiceStats: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/services/stats`);
      return response.data;
    } catch (error) {
      console.error('Error fetching service stats:', error);
      return null;
    }
  },

  // Create a new service
  createService: async (serviceData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/services`, serviceData);
      return response.data;
    } catch (error) {
      console.error('Error creating service:', error);
      throw error;
    }
  },

  // Update service
  updateService: async (slug, serviceData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/services/${slug}`, serviceData);
      return response.data;
    } catch (error) {
      console.error('Error updating service:', error);
      throw error;
    }
  },

  // Delete service
  deleteService: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/services/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting service:', error);
      throw error;
    }
  },

  // Update service order
  updateServiceOrder: async (services) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/services/order/update`, { services });
      return response.data;
    } catch (error) {
      console.error('Error updating service order:', error);
      throw error;
    }
  },

  // Toggle featured status
  toggleFeatured: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/services/${slug}/toggle-featured`);
      return response.data;
    } catch (error) {
      console.error('Error toggling featured status:', error);
      throw error;
    }
  },

  // Toggle active status
  toggleActive: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/services/${slug}/toggle-active`);
      return response.data;
    } catch (error) {
      console.error('Error toggling active status:', error);
      throw error;
    }
  },

  // Get services for WhatIDo section (ordered by number field)
  getServicesForWhatIDo: async (limit = 5) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/services?isActive=true&limit=${limit}&sortBy=number&sortOrder=asc`);
      return response.data.services || response.data;
    } catch (error) {
      console.error('Error fetching services for WhatIDo section:', error);
      return [];
    }
  },

  // Legacy support methods (for backward compatibility)
  getServices: async () => {
    return await ServiceDataApi.getServiceData({ isActive: true });
  },

  getServiceList: async () => {
    try {
      const services = await ServiceDataApi.getServiceData({ isActive: true });
      return services.map(service => ({
        title: service.title,
        link: `/service/details/${service.slug}`
      }));
    } catch (error) {
      console.error('Error fetching service list:', error);
      return [];
    }
  }
};

// Named exports for convenience
export const getAllServices = ServiceDataApi.getServiceData;
export const getService = (slug, includeInactive = false) => ServiceDataApi.getServiceDetails(slug, includeInactive);
export const createService = ServiceDataApi.createService;
export const updateService = ServiceDataApi.updateService;
export const deleteService = ServiceDataApi.deleteService;
export const getServiceStats = ServiceDataApi.getServiceStats;
export const toggleServiceFeatured = ServiceDataApi.toggleFeatured;
export const toggleServiceActive = ServiceDataApi.toggleActive;
export const updateServiceOrder = ServiceDataApi.updateServiceOrder;

export default ServiceDataApi;