import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const ExperienceDataApi = {
  // Fetch all experience records from the backend
  getExperienceData: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams(params).toString();
      const url = queryParams ? `${API_BASE_URL}/experience?${queryParams}` : `${API_BASE_URL}/experience`;
      const response = await axios.get(url);
      return response.data.experience || response.data;
    } catch (error) {
      console.error('Error fetching experience:', error);
      return [];
    }
  },

  // Get experience for home page with limit
  getExperienceForHome: async (limit = 3) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/experience?isActive=true&limit=${limit}&sortBy=startDate&sortOrder=desc`);
      return response.data.experience || response.data;
    } catch (error) {
      console.error('Error fetching experience for home:', error);
      return [];
    }
  },

  // Get featured experience
  getFeaturedExperience: async (limit = 3) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/experience?featured=true&isActive=true&limit=${limit}&sortBy=startDate&sortOrder=desc`);
      return response.data.experience || response.data;
    } catch (error) {
      console.error('Error fetching featured experience:', error);
      return [];
    }
  },

  // Get current experience (ongoing jobs)
  getCurrentExperience: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/experience?current=true&isActive=true`);
      return response.data.experience || response.data;
    } catch (error) {
      console.error('Error fetching current experience:', error);
      return [];
    }
  },

  // Get experience by company
  getExperienceByCompany: async (company, limit = null) => {
    try {
      const params = { company, isActive: true };
      if (limit) params.limit = limit;
      
      const response = await axios.get(`${API_BASE_URL}/experience`, { params });
      return response.data.experience || response.data;
    } catch (error) {
      console.error('Error fetching experience by company:', error);
      return [];
    }
  },

  // Get experience by employment type
  getExperienceByType: async (employmentType, limit = null) => {
    try {
      const params = { employmentType, isActive: true };
      if (limit) params.limit = limit;
      
      const response = await axios.get(`${API_BASE_URL}/experience`, { params });
      return response.data.experience || response.data;
    } catch (error) {
      console.error('Error fetching experience by type:', error);
      return [];
    }
  },

  // Get companies (extract from experience data)
  getCompanies: async () => {
    try {
      const experienceData = await ExperienceDataApi.getExperienceData({ isActive: true });
      let companies = new Set();
      
      experienceData.forEach(exp => {
        if (exp.company) {
          companies.add(exp.company);
        }
      });

      return Array.from(companies).sort();
    } catch (error) {
      console.error('Error fetching companies:', error);
      return [];
    }
  },

  // Get employment types (extract from experience data)
  getEmploymentTypes: async () => {
    try {
      const experienceData = await ExperienceDataApi.getExperienceData({ isActive: true });
      let types = new Set();
      
      experienceData.forEach(exp => {
        if (exp.employmentType) {
          types.add(exp.employmentType);
        }
      });

      return Array.from(types).sort();
    } catch (error) {
      console.error('Error fetching employment types:', error);
      return [];
    }
  },

  // Get experience details by slug
  getExperienceDetails: async (slug) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/experience/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching experience details:', error);
      return null;
    }
  },

  // Get experience statistics
  getExperienceStats: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/experience/stats`);
      return response.data;
    } catch (error) {
      console.error('Error fetching experience stats:', error);
      return null;
    }
  },

  // Create a new experience record
  createExperience: async (experienceData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/experience`, experienceData);
      return response.data;
    } catch (error) {
      console.error('Error creating experience:', error);
      throw error;
    }
  },

  // Update experience record
  updateExperience: async (slug, experienceData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/experience/${slug}`, experienceData);
      return response.data;
    } catch (error) {
      console.error('Error updating experience:', error);
      throw error;
    }
  },

  // Delete experience record
  deleteExperience: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/experience/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting experience:', error);
      throw error;
    }
  },

  // Update experience order
  updateExperienceOrder: async (experience) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/experience/order/update`, { experience });
      return response.data;
    } catch (error) {
      console.error('Error updating experience order:', error);
      throw error;
    }
  },

  // Toggle featured status
  toggleFeatured: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/experience/${slug}/toggle-featured`);
      return response.data;
    } catch (error) {
      console.error('Error toggling featured status:', error);
      throw error;
    }
  },

  // Toggle active status
  toggleActive: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/experience/${slug}/toggle-active`);
      return response.data;
    } catch (error) {
      console.error('Error toggling active status:', error);
      throw error;
    }
  }
};

export default ExperienceDataApi;
