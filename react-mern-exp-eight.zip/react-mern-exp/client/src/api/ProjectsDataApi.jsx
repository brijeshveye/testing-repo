
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const ProjectsDataApi = {
    getProjectsData: async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}/projects`);
            return response.data;
        } catch (error) {
            console.error('Error fetching projects:', error);
            return [];
        }
    },
    getPorjectsForHome: async (limit = 6) => {
        try {
            const projects = await ProjectsDataApi.getProjectsData();
            // Shuffle the projects array to get a random selection
            const shuffled = projects.sort(() => Math.random() - 0.5);
            return shuffled.slice(0, limit);
        } catch (error) {
            console.error('Error fetching projects for home:', error);
            return [];
        }
    },

    getProjectCategories: async () => {
        try {
            const projects = await ProjectsDataApi.getProjectsData();
            let categories = new Set(['all']); // Start with 'all' category
            
            if (Array.isArray(projects)) {
                projects.forEach(project => {
                    if (project.category) {
                        categories.add(project.category.toLowerCase());
                    }
                });
            }

            return Array.from(categories).sort(); // Return categories as a sorted array
        } catch (error) {
            console.error('Error fetching project categories:', error);
            return ['all'];
        }
    },

    getProjectDetails: async (slug) => {
        try {
            const response = await axios.get(`${API_BASE_URL}/projects/${slug}`);
            return response.data;
        } catch (error) {
            console.error('Error fetching project details:', error);
            return null;
        }
    },

    // Admin functions for CRUD operations
    createProject: async (projectData) => {
        try {
            const response = await axios.post(`${API_BASE_URL}/projects`, projectData);
            return response.data;
        } catch (error) {
            console.error('Error creating project:', error);
            throw error;
        }
    },

    updateProject: async (slug, projectData) => {
        try {
            const response = await axios.put(`${API_BASE_URL}/projects/${slug}`, projectData);
            return response.data;
        } catch (error) {
            console.error('Error updating project:', error);
            throw error;
        }
    },

    deleteProject: async (slug) => {
        try {
            const response = await axios.delete(`${API_BASE_URL}/projects/${slug}`);
            return response.data;
        } catch (error) {
            console.error('Error deleting project:', error);
            throw error;
        }
    }
}

export default ProjectsDataApi