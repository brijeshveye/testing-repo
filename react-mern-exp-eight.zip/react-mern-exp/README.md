# BR MERN Portfolio

A full-stack MERN (MongoDB, Express.js, React.js, Node.js) portfolio application showcasing professional work and personal projects.

## 🚀 Features

- **Modern React Frontend**: Built with React 19.1.0 and modern hooks
- **Responsive Design**: Bootstrap 5.3.6 for mobile-first responsive design
- **Smooth Animations**: Framer Motion and AOS for elegant animations
- **Express.js Backend**: RESTful API server with Express 5.1.0
- **Development Ready**: Hot-reload development environment with concurrently
- **Image Gallery**: Personal photo collection and project showcase
- **Modal Components**: Interactive modals for detailed project views
- **Routing**: React Router DOM for seamless navigation
- **🔐 PIN Authentication**: Static PIN login system with 2-hour session management
- **Session Management**: Automatic session expiration and renewal
- **Admin Panel**: Built-in admin panel for session monitoring and management

## 🛠️ Tech Stack

### Frontend
- **React** 19.1.0 - Modern JavaScript library for building user interfaces
- **React Router DOM** 7.6.2 - Declarative routing for React
- **Bootstrap** 5.3.6 - CSS framework for responsive design
- **Framer Motion** 12.18.1 - Production-ready motion library for React
- **AOS** 2.3.4 - Animate On Scroll library
- **Axios** 1.3.5 - Promise-based HTTP client
- **React Modal** 3.16.3 - Accessible modal dialog component

### Backend
- **Node.js** - JavaScript runtime environment
- **Express.js** 5.1.0 - Fast, unopinionated web framework
- **RESTful API** - Clean API architecture

### Development Tools
- **Concurrently** 7.6.0 - Run multiple commands concurrently
- **React Scripts** 5.0.1 - Configuration and scripts for Create React App

## 📁 Project Structure

```
br-mern-portfolio/
├── client/                 # React frontend application
│   ├── public/            # Static assets
│   ├── src/               # React source code
│   └── package.json       # Frontend dependencies
├── server/                # Express.js backend
│   ├── controllers/       # Route controllers
│   ├── data/             # Data files
│   ├── models/           # Data models
│   ├── routes/           # API routes
│   └── server.js         # Main server file
├── brijesh/              # Personal photos and documents
└── package.json          # Root package configuration
```

## 🚦 Getting Started

### Prerequisites

- **Node.js** (v14 or higher)
- **npm** or **yarn**

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/br-mern-portfolio.git
   cd br-mern-portfolio
   ```

2. **Install root dependencies**
   ```bash
   npm install
   ```

3. **Install client dependencies**
   ```bash
   cd client
   npm install
   cd ..
   ```

4. **Install server dependencies**
   ```bash
   cd server
   npm install
   cd ..
   ```

### Running the Application

#### Development Mode (Recommended)
Run both frontend and backend concurrently:
```bash
npm run dev
```

#### Individual Services
**Frontend only:**
```bash
npm run client
```

**Backend only:**
```bash
npm start
```

### Access Points
- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:5000

## 📝 Available Scripts

### Root Level Scripts
- `npm start` - Start the Express server
- `npm run client` - Start the React development server
- `npm run dev` - Run both frontend and backend concurrently

### Client Scripts
- `npm start` - Start React development server
- `npm run build` - Build React app for production
- `npm test` - Run React tests
- `npm run eject` - Eject from Create React App

## 🎨 Customization

### Adding New Components
1. Create component files in `client/src/components/`
2. Import and use in your pages
3. Add routing in `client/src/App.js` if needed

### API Development
1. Add new routes in `server/routes/`
2. Create controllers in `server/controllers/`
3. Define models in `server/models/`

### Styling
- Bootstrap classes for quick styling
- Custom CSS for unique designs
- Framer Motion for animations

## � Security & Authentication

### PIN Authentication System
The portfolio includes a secure PIN-based authentication system:

- **Static PIN**: Default PIN is `1234` (should be changed in production)
- **Session Duration**: 2-hour automatic session management
- **Local Storage**: Session data persists across browser refresh
- **Auto Logout**: Automatic logout when session expires
- **Session Status**: Real-time session timer with warnings
- **Admin Panel**: Built-in admin interface for session management

### Security Features
- PIN input with animated keypad interface
- Session timeout warnings (10 minutes before expiry)
- Secure session validation on every app load
- Manual logout functionality
- Protected routes that require authentication
- Session progress tracking

### Customization
To customize the authentication system:

1. **Change PIN**: Modify `STATIC_PIN` in `AuthContext.jsx`
2. **Session Duration**: Adjust `SESSION_DURATION` (default: 2 hours)
3. **Warning Time**: Modify warning threshold in `SessionStatus.jsx`
4. **Styling**: Customize PIN login interface via `PinLogin.css`

## �🔧 Configuration

### Environment Variables
Create `.env` files in both client and server directories:

**Client (.env)**
```
REACT_APP_API_URL=http://localhost:5000
```

**Server (.env)**
```
PORT=5000
NODE_ENV=development
```

## 📱 Responsive Design

The application is built with mobile-first approach using Bootstrap:
- **Mobile**: < 576px
- **Tablet**: 576px - 768px
- **Desktop**: 768px - 992px
- **Large Desktop**: > 992px

## 🎯 Future Enhancements

- [ ] Database integration (MongoDB)
- [ ] User authentication
- [ ] Content management system
- [ ] Blog functionality
- [ ] Contact form with email integration
- [ ] SEO optimization
- [ ] Performance optimization
- [ ] Docker containerization

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 👨‍💻 Author

**Brijesh Chauhan**
- Portfolio: itsbrijesh.me
- GitHub: (https://github.com/brijeshrajput)
- LinkedIn: -
- Email: hello@itsbrijesh.me

⭐ Don't forget to star this repository if you found it helpful!