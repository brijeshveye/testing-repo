# Installation & Setup Instructions

## Quick Start

### 1. Install Server Dependencies
```bash
cd server
npm install multer
```

### 2. Start the Application
```bash
# Terminal 1 - Start server
cd server
node server.js

# Terminal 2 - Start client
cd client
npm start
```

### 3. Access Admin Panel
1. Open browser to `http://localhost:3000`
2. Click the gear icon (⚙️) in top-right corner
3. Enter PIN: **1234**
4. Access granted for 2 hours

## What's Been Implemented

### ✅ Dynamic Widget System
- **6 Widget Types**: Heading, Paragraph, List, Spacer, Image, YouTube
- **CRUD Operations**: Create, edit, delete, reorder widgets
- **Live Preview**: Toggle between edit and preview modes
- **Responsive Design**: Works on desktop and mobile

### ✅ Image Upload System
- **Server Integration**: Real file upload with multer
- **Category Organization**: Organized by content type
- **File Validation**: Type and size checking (5MB limit)
- **Drag & Drop Interface**: Modern upload experience

### ✅ Enhanced Admin Forms
- **Tabbed Interface**: Basic Info, Images, Dynamic Content
- **Image Management**: Separate upload areas for banners and main images
- **Widget Integration**: Full widget management in content tab
- **Form Validation**: Required fields and error handling

### ✅ Content Rendering
- **Frontend Display**: ContentRenderer component for public pages
- **Data Persistence**: Widgets save with project/blog data
- **Performance**: Optimized rendering with proper React patterns

## File Locations

### New Components Created:
```
client/src/admin/components/
├── widgets/
│   ├── DynamicWidgets.jsx      ✅ Individual widget components
│   ├── WidgetManager.jsx       ✅ Main widget management
│   └── WidgetStyles.css        ✅ Widget styling
├── ImageUpload.jsx             ✅ Image upload utilities
├── AdminDashboard.jsx          ✅ Admin dashboard
├── AdminNavBar.jsx             ✅ Admin navigation
├── AdminPinAuth.jsx            ✅ PIN authentication
├── AdminPinAuth.css            ✅ PIN auth styling
└── AdminProtectedRoute.jsx     ✅ Route protection

client/src/components/common/
└── ContentRenderer.jsx         ✅ Frontend content display

server/routes/
└── uploadRoutes.js             ✅ Image upload endpoints
```

### Updated Files:
```
client/src/admin/components/
├── ProjectForm.jsx             ✅ Enhanced with widgets & images
├── BlogForm.jsx                ✅ Enhanced with widgets & images
├── ProjectList.jsx             ✅ Updated styling
├── BlogList.jsx                ✅ Updated styling
├── UserDashboard.jsx           ✅ Updated styling
└── EditSectionForm.jsx         ✅ Updated styling

client/src/router/
└── AppRoutes.jsx               ✅ Added protected routes

client/src/layouts/
└── Header.jsx                  ✅ Added admin access

client/src/
└── App.css                     ✅ Added widget styles

server/
└── server.js                   ✅ Added upload routes & middleware
```

## Testing the Features

### 1. Test Dynamic Widgets
1. Go to Admin → Projects → Create New
2. Navigate to "Dynamic Content" tab
3. Add different widget types:
   - Heading widget with different levels
   - Paragraph with sample text
   - List with multiple items
   - Spacer with different heights
   - Image widget (upload test image)
   - YouTube widget with video URL
4. Use Edit/Preview toggle to see results
5. Save and verify data persistence

### 2. Test Image Upload
1. In Projects/Blogs → Images tab
2. Test drag & drop upload
3. Test file browser upload
4. Verify image categorization
5. Check uploaded files in `server/uploads/` directory

### 3. Test Admin Security
1. Try accessing `/admin` routes directly
2. Verify PIN protection is working
3. Test 2-hour session timeout
4. Test device-specific sessions

## Data Structure Examples

### Project with Widgets:
```json
{
  "title": "My Project",
  "slug": "my-project",
  "widgets": [
    {
      "id": "1640995200000",
      "type": "heading",
      "data": { "text": "Overview", "level": "h2" }
    },
    {
      "id": "1640995300000",
      "type": "paragraph",
      "data": { "text": "This project demonstrates..." }
    },
    {
      "id": "1640995400000",
      "type": "image",
      "data": {
        "src": "/uploads/project/screenshot_123456.jpg",
        "alt": "Screenshot",
        "alignment": "center",
        "size": "large"
      }
    }
  ]
}
```

## Next Steps

### To Use in Frontend:
```jsx
import ContentRenderer from '../components/common/ContentRenderer';

// In your project/blog detail pages:
function ProjectDetails({ project }) {
  return (
    <div>
      <h1>{project.title}</h1>
      <p>{project.description}</p>
      
      {/* Render dynamic content */}
      <ContentRenderer widgets={project.widgets} />
    </div>
  );
}
```

### To Extend the System:
1. Add new widget types in `DynamicWidgets.jsx`
2. Update `WIDGET_TYPES` constant
3. Add corresponding cases in `WidgetManager.jsx`
4. Style new widgets in `WidgetStyles.css`

## Security Notes

- ✅ PIN protection for admin access
- ✅ Device fingerprinting for sessions
- ✅ File type validation for uploads
- ✅ File size limits (5MB)
- ✅ Path sanitization for security
- ✅ Category-based file organization

## Support

For issues or questions:
1. Check browser console for errors
2. Check server logs for upload issues
3. Verify file permissions in `server/uploads/`
4. Ensure all dependencies are installed

The system is now fully functional and ready for content creation! 🎉
