# 🚀 Deploying Multiple GitHub Repositories with SSH on Same Server

If you're deploying multiple GitHub repositories on the same server (e.g., Express.js projects via CI/CD) and `ssh -T git@github.com` always connects to the same GitHub account/repo, it's likely because your server is using a **default SSH key**.

To fix this, use multiple SSH keys and configure them correctly. Here's a step-by-step guide.

---

## 📁 Step 1: Generate a New SSH Key

```bash
ssh-keygen -t rsa -b 4096 -C "your_email@example.com"
```

When prompted:

```
Enter file in which to save the key (/home/ubuntu/.ssh/id_rsa): /home/ubuntu/.ssh/id_rsa_newproject
```

This creates:
- `~/.ssh/id_rsa_newproject`
- `~/.ssh/id_rsa_newproject.pub`

---

## 🔑 Step 2: Add the New Key to `ssh-agent`

```bash
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_rsa_newproject
```

---

## 🐙 Step 3: Add the Public Key to GitHub

Get the public key:

```bash
cat ~/.ssh/id_rsa_newproject.pub
```

Then go to:

> GitHub → Settings → SSH and GPG keys → **New SSH key**

- Title: `Server Key - New Project`
- Paste the public key content

---

## ⚙️ Step 4: Configure `~/.ssh/config`

Edit (or create) the SSH config file:

```bash
nano ~/.ssh/config
```

Add entries like this:

```ssh
# Old repo config
Host github-old
    HostName github.com
    User git
    IdentityFile ~/.ssh/id_rsa_oldproject

# New repo config
Host github-new
    HostName github.com
    User git
    IdentityFile ~/.ssh/id_rsa_newproject
```

> You can add as many `Host` entries as needed for different projects or accounts.

---

## 🔁 Step 5: Update Git Remote URLs

### For the new project:

```bash
git remote set-url origin git@github-new:yourusername/new-repo.git
```

### For the old project:

```bash
git remote set-url origin git@github-old:yourusername/old-repo.git
```

Replace `yourusername`, `new-repo`, and `old-repo` as appropriate.

---

## ✅ Step 6: Test SSH Connections

```bash
ssh -T github-new
ssh -T github-old
```

Expected outputs:

- `Hi yourusername! You've successfully authenticated...` for both.

---

## ⚙️ Optional Tips

- Each project should have its own **deployment script**, **webhook**, or **CI/CD workflow**.
- Ensure permissions for SSH files are correctly set:

```bash
chmod 600 ~/.ssh/id_rsa*
chmod 644 ~/.ssh/id_rsa*.pub
chmod 600 ~/.ssh/config
```

---

## 📦 Example SSH Directory Structure

```
~/.ssh/
├── id_rsa_oldproject
├── id_rsa_oldproject.pub
├── id_rsa_newproject
├── id_rsa_newproject.pub
└── config
```

---

## 📝 Summary

| Project     | SSH Host      | Identity File             | Git Remote Example                                  |
|-------------|---------------|---------------------------|------------------------------------------------------|
| Old Repo    | `github-old`  | `~/.ssh/id_rsa_oldproject`| `git@github-old:username/old-repo.git`              |
| New Repo    | `github-new`  | `~/.ssh/id_rsa_newproject`| `git@github-new:username/new-repo.git`              |

---

## 🔒 Security Note

Never share your **private keys** (`id_rsa*`) with anyone or commit them to any Git repository.

---
