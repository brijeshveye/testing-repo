const backupService = require('../services/backupService');
const multer = require('multer');

// Configure multer for file uploads
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

// Generic backup/restore/reset functions generator
const createBackupFunctions = (Model, modelName) => {
  return {
    backup: async (req, res) => {
      try {
        const backup = await backupService.exportData(Model, modelName);
        
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="${backup.filename}"`);
        res.send(backup.data);
      } catch (error) {
        console.error(`Error creating ${modelName} backup:`, error);
        res.status(500).json({ message: `Error creating ${modelName} backup`, error: error.message });
      }
    },

    restore: async (req, res) => {
      try {
        if (!req.file) {
          return res.status(400).json({ message: 'No file uploaded' });
        }

        const jsonData = req.file.buffer.toString('utf8');
        const result = await backupService.importData(Model, jsonData, modelName);
        
        res.json(result);
      } catch (error) {
        console.error(`Error restoring ${modelName}:`, error);
        res.status(500).json({ message: `Error restoring ${modelName}`, error: error.message });
      }
    },

    reset: async (req, res) => {
      try {
        const result = await backupService.resetData(Model, modelName);
        res.json(result);
      } catch (error) {
        console.error(`Error resetting ${modelName}:`, error);
        res.status(500).json({ message: `Error resetting ${modelName}`, error: error.message });
      }
    },

    upload
  };
};

module.exports = createBackupFunctions;
