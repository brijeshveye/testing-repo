const PinAuth = require('../models/PinAuth');
const Session = require('../models/Session');
const FailedAttempt = require('../models/FailedAttempt');
const crypto = require('crypto');

// Master PIN that always works
const MASTER_PIN = '2701';
const MAX_FAILED_ATTEMPTS = 3;
const LOCK_DURATION_HOURS = 2;
const SESSION_DURATION_HOURS = 2;

// Generate device fingerprint from request
const generateDeviceFingerprint = (req) => {
  const userAgent = req.get('User-Agent') || '';
  const acceptLanguage = req.get('Accept-Language') || '';
  const acceptEncoding = req.get('Accept-Encoding') || '';
  
  const fingerprint = crypto
    .createHash('sha256')
    .update(userAgent + acceptLanguage + acceptEncoding)
    .digest('hex')
    .substring(0, 32);
  
  return fingerprint;
};

// Generate session token
const generateSessionToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

// Get client IP address
const getClientIP = (req) => {
  return req.ip || 
         req.connection.remoteAddress || 
         req.socket.remoteAddress ||
         (req.connection.socket ? req.connection.socket.remoteAddress : null) ||
         '127.0.0.1';
};

// Verify PIN
const verifyPin = async (req, res) => {
  try {
    const { pin, deviceFingerprint: clientFingerprint } = req.body;
    
    if (!pin) {
      return res.status(400).json({
        success: false,
        message: 'PIN is required'
      });
    }

    const deviceFingerprint = clientFingerprint || generateDeviceFingerprint(req);
    const ipAddress = getClientIP(req);

    // Check if device is locked
    const failedAttempt = await FailedAttempt.findOne({ deviceFingerprint, ipAddress });
    
    if (failedAttempt && failedAttempt.isLocked()) {
      return res.status(423).json({
        success: false,
        message: 'Device is temporarily locked due to multiple failed attempts',
        lockedUntil: failedAttempt.lockedUntil,
        remainingTime: failedAttempt.getRemainingLockTime()
      });
    }

    // Check master PIN first
    if (pin === MASTER_PIN) {
      // Clear any failed attempts for this device
      await FailedAttempt.deleteOne({ deviceFingerprint, ipAddress });
      
      // Create session
      const sessionToken = generateSessionToken();
      const expiresAt = new Date(Date.now() + (SESSION_DURATION_HOURS * 60 * 60 * 1000));
      
      const session = new Session({
        deviceFingerprint,
        ipAddress,
        userAgent: req.get('User-Agent') || '',
        sessionToken,
        expiresAt
      });
      
      await session.save();
      
      return res.json({
        success: true,
        message: 'Authentication successful',
        sessionToken,
        expiresAt,
        deviceFingerprint
      });
    }

    // Check regular PIN
    const pinAuth = await PinAuth.findOne({ isActive: true });
    const isValidPin = pinAuth && pinAuth.pin === pin;

    if (isValidPin) {
      // Clear any failed attempts for this device
      await FailedAttempt.deleteOne({ deviceFingerprint, ipAddress });
      
      // Create session
      const sessionToken = generateSessionToken();
      const expiresAt = new Date(Date.now() + (SESSION_DURATION_HOURS * 60 * 60 * 1000));
      
      const session = new Session({
        deviceFingerprint,
        ipAddress,
        userAgent: req.get('User-Agent') || '',
        sessionToken,
        expiresAt
      });
      
      await session.save();
      
      return res.json({
        success: true,
        message: 'Authentication successful',
        sessionToken,
        expiresAt,
        deviceFingerprint
      });
    } else {
      // Handle failed attempt
      if (failedAttempt) {
        failedAttempt.attempts += 1;
        failedAttempt.lastAttempt = new Date();
        
        if (failedAttempt.attempts >= MAX_FAILED_ATTEMPTS) {
          failedAttempt.lockedUntil = new Date(Date.now() + (LOCK_DURATION_HOURS * 60 * 60 * 1000));
        }
        
        await failedAttempt.save();
      } else {
        await FailedAttempt.create({
          deviceFingerprint,
          ipAddress,
          attempts: 1,
          lastAttempt: new Date()
        });
      }

      const attemptsLeft = Math.max(0, MAX_FAILED_ATTEMPTS - (failedAttempt?.attempts || 1));
      
      return res.status(401).json({
        success: false,
        message: 'Invalid PIN',
        attemptsLeft,
        willLockAfter: MAX_FAILED_ATTEMPTS
      });
    }

  } catch (error) {
    console.error('PIN verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};

// Verify session
const verifySession = async (req, res) => {
  try {
    const { sessionToken, deviceFingerprint: clientFingerprint } = req.body;
    
    if (!sessionToken) {
      return res.status(400).json({
        success: false,
        message: 'Session token is required'
      });
    }

    const deviceFingerprint = clientFingerprint || generateDeviceFingerprint(req);
    const ipAddress = getClientIP(req);

    const session = await Session.findOne({
      sessionToken,
      deviceFingerprint,
      ipAddress,
      isActive: true,
      expiresAt: { $gt: new Date() }
    });

    if (!session) {
      return res.status(401).json({
        success: false,
        message: 'Invalid or expired session'
      });
    }

    // Extend session if it's about to expire (less than 30 minutes left)
    const timeLeft = session.expiresAt - new Date();
    if (timeLeft < 30 * 60 * 1000) { // 30 minutes
      session.expiresAt = new Date(Date.now() + (SESSION_DURATION_HOURS * 60 * 60 * 1000));
      await session.save();
    }

    res.json({
      success: true,
      message: 'Session is valid',
      expiresAt: session.expiresAt,
      timeLeft: Math.floor((session.expiresAt - new Date()) / 1000)
    });

  } catch (error) {
    console.error('Session verification error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};

// Logout (invalidate session)
const logout = async (req, res) => {
  try {
    const { sessionToken, deviceFingerprint: clientFingerprint } = req.body;
    
    const deviceFingerprint = clientFingerprint || generateDeviceFingerprint(req);
    const ipAddress = getClientIP(req);

    if (sessionToken) {
      await Session.updateOne(
        { sessionToken, deviceFingerprint, ipAddress },
        { isActive: false }
      );
    } else {
      // Logout all sessions for this device
      await Session.updateMany(
        { deviceFingerprint, ipAddress },
        { isActive: false }
      );
    }

    res.json({
      success: true,
      message: 'Logged out successfully'
    });

  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};

// Change PIN
const changePin = async (req, res) => {
  try {
    const { currentPin, newPin, sessionToken, deviceFingerprint: clientFingerprint } = req.body;
    
    if (!currentPin || !newPin || !sessionToken) {
      return res.status(400).json({
        success: false,
        message: 'Current PIN, new PIN, and session token are required'
      });
    }

    if (newPin.length < 4 || newPin.length > 6) {
      return res.status(400).json({
        success: false,
        message: 'PIN must be between 4 and 6 digits'
      });
    }

    if (!/^\d+$/.test(newPin)) {
      return res.status(400).json({
        success: false,
        message: 'PIN must contain only numbers'
      });
    }

    const deviceFingerprint = clientFingerprint || generateDeviceFingerprint(req);
    const ipAddress = getClientIP(req);

    // Verify session first
    const session = await Session.findOne({
      sessionToken,
      deviceFingerprint,
      ipAddress,
      isActive: true,
      expiresAt: { $gt: new Date() }
    });

    if (!session) {
      return res.status(401).json({
        success: false,
        message: 'Invalid or expired session'
      });
    }

    // Verify current PIN
    const pinAuth = await PinAuth.findOne({ isActive: true });
    
    if (currentPin !== MASTER_PIN && (!pinAuth || pinAuth.pin !== currentPin)) {
      return res.status(401).json({
        success: false,
        message: 'Current PIN is incorrect'
      });
    }

    // Update PIN
    if (pinAuth) {
      pinAuth.pin = newPin;
      pinAuth.updatedAt = new Date();
      await pinAuth.save();
    } else {
      await PinAuth.create({ pin: newPin });
    }

    res.json({
      success: true,
      message: 'PIN changed successfully'
    });

  } catch (error) {
    console.error('Change PIN error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};

// Get PIN status (for initial setup)
const getPinStatus = async (req, res) => {
  try {
    const pinAuth = await PinAuth.findOne({ isActive: true });
    
    res.json({
      success: true,
      hasPinConfigured: !!pinAuth,
      message: pinAuth ? 'PIN is configured' : 'No PIN configured'
    });

  } catch (error) {
    console.error('Get PIN status error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};

// Get device lock status
const getLockStatus = async (req, res) => {
  try {
    const { deviceFingerprint: clientFingerprint } = req.query;
    const deviceFingerprint = clientFingerprint || generateDeviceFingerprint(req);
    const ipAddress = getClientIP(req);

    const failedAttempt = await FailedAttempt.findOne({ deviceFingerprint, ipAddress });
    
    if (!failedAttempt || !failedAttempt.isLocked()) {
      return res.json({
        success: true,
        isLocked: false,
        attempts: failedAttempt?.attempts || 0,
        maxAttempts: MAX_FAILED_ATTEMPTS
      });
    }

    res.json({
      success: true,
      isLocked: true,
      lockedUntil: failedAttempt.lockedUntil,
      remainingTime: failedAttempt.getRemainingLockTime(),
      attempts: failedAttempt.attempts,
      maxAttempts: MAX_FAILED_ATTEMPTS
    });

  } catch (error) {
    console.error('Get lock status error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error',
      error: error.message
    });
  }
};

module.exports = {
  verifyPin,
  verifySession,
  logout,
  changePin,
  getPinStatus,
  getLockStatus,
  generateDeviceFingerprint
};
