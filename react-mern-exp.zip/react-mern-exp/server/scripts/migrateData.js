const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

// Import models
const Project = require('../models/Project');
const Blog = require('../models/Blog');
const User = require('../models/User');
const Testimonial = require('../models/Testimonial');
const Certificate = require('../models/Certificate');
const Skill = require('../models/Skill');
const Education = require('../models/Education');
const Experience = require('../models/Experience');
const Service = require('../models/Service');
const Characteristic = require('../models/Characteristic');

// Import JSON data
const projectsData = require('../data/projectsData.json');
const blogsData = require('../data/blogsData.json');
const characteristicsData = require('../data/characteristicsData.json');

// Import individual user data files
const aboutData = require('../data/aboutData.json');
const educationData = require('../data/educationData.json');
const experienceData = require('../data/experienceData.json');
const servicesData = require('../data/servicesData.json');
const processData = require('../data/processData.json');
const certificatesData = require('../data/certificatesData.json');
const testimonialsData = require('../data/testimonialsData.json');
const skillsData = require('../data/skillsData.json');

require('dotenv').config();

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || '', {
      dbName: process.env.MONGODB_DATABASE || 'br-portfolio',
    });
    console.log('✅ MongoDB connected for migration');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
};

// Migrate Projects
const migrateProjects = async () => {
  try {
    console.log('🔄 Migrating projects...');
    
    // Clear existing projects
    await Project.deleteMany({});
    
    for (const project of projectsData) {
      // Transform data structure if needed
      const projectDoc = new Project({
        title: project.title || 'Untitled Project',
        description: project.description || '',
        shortDescription: project.shortDescription || project.description || '',
        slug: project.slug || project.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        image: project.image || '',
        images: project.images || [],
        technologies: project.technologies || [],
        liveUrl: project.liveUrl || '',
        githubUrl: project.githubUrl || '',
        category: project.category || 'web',
        status: project.status || 'completed',
        featured: project.featured || false,
        startDate: project.startDate ? new Date(project.startDate) : new Date(),
        endDate: project.endDate ? new Date(project.endDate) : null,
        widgets: project.widgets || [],
        domains: project.domains || [],
        details: project.details || {}
      });
      
      await projectDoc.save();
      console.log(`✅ Migrated project: ${project.title}`);
    }
    
    console.log(`✅ Successfully migrated ${projectsData.length} projects`);
  } catch (error) {
    console.error('❌ Error migrating projects:', error);
  }
};

// Migrate Blogs
const migrateBlogs = async () => {
  try {
    console.log('🔄 Migrating blogs...');
    
    // Clear existing blogs
    await Blog.deleteMany({});
    
    for (const blog of blogsData) {
      const blogDoc = new Blog({
        title: blog.title || 'Untitled Blog',
        content: blog.content || '',
        excerpt: blog.excerpt || blog.content?.substring(0, 200) || '',
        slug: blog.slug || blog.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        featuredImage: blog.featuredImage || blog.image || '',
        images: blog.images || [],
        tags: blog.tags || [],
        category: blog.category || 'general',
        author: blog.author || 'Admin',
        published: blog.published !== false,
        featured: blog.featured || false,
        readTime: blog.readTime || 5,
        publishedAt: blog.publishedAt ? new Date(blog.publishedAt) : new Date(),
        widgets: blog.widgets || [],
        seo: blog.seo || {},
        details: blog.details || {}
      });
      
      await blogDoc.save();
      console.log(`✅ Migrated blog: ${blog.title}`);
    }
    
    console.log(`✅ Successfully migrated ${blogsData.length} blogs`);
  } catch (error) {
    console.error('❌ Error migrating blogs:', error);
  }
};

// Migrate User Data
const migrateUserData = async () => {
  try {
    console.log('🔄 Migrating user data...');
    
    // Clear existing user data
    await User.deleteMany({});
    
    const userDoc = new User({
      userId: 'portfolio_owner',
      aboutData: aboutData || {},
      educationData: educationData || [],
      experienceData: experienceData || [],
      // skillsData: skillsData || [],
      certificatesData: certificatesData || [],
      testimonialsData: testimonialsData || [],
      servicesData: servicesData || [],
      socialLinks: {} // Will be added separately if exists
    });
    
    await userDoc.save();
    console.log('✅ Migrated user data');
  } catch (error) {
    console.error('❌ Error migrating user data:', error);
  }
};

// Migrate Testimonials from User Data
const migrateTestimonials = async () => {
  try {
    console.log('🔄 Migrating testimonials...');
    
    // Clear existing testimonials
    await Testimonial.deleteMany({});
    
    // Get testimonials from user data if exists
    const testimonialsFromUser = testimonialsData || [];
    
    // Default testimonials if none exist in user data
    const defaultTestimonials = [];
    
    const testimonialsToMigrate = testimonialsFromUser.length > 0 ? testimonialsFromUser : defaultTestimonials;
    
    for (const [index, testimonial] of testimonialsToMigrate.entries()) {
      const testimonialDoc = new Testimonial({
        customerName: testimonial.customerName,
        customerFeedback: testimonial.customerFeedback,
        designation: testimonial.customerPosition || testimonial.designation || '',
        company: testimonial.company || '',
        customerImage: testimonial.customerImage || '',
        rating: testimonial.stars || testimonial.rating || 5,
        featured: testimonial.featured || (index === 0), // Make first one featured by default
        isActive: testimonial.isActive !== false,
        slug: testimonial.customerName?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-testimonial',
        order: index + 1
      });
      
      await testimonialDoc.save();
    }
    
    console.log(`✅ Migrated ${testimonialsToMigrate.length} testimonials`);
  } catch (error) {
    console.error('❌ Error migrating testimonials:', error);
  }
};

// Migrate Certificates from User Data
const migrateCertificates = async () => {
  try {
    console.log('🔄 Migrating certificates...');
    
    // Clear existing certificates
    await Certificate.deleteMany({});
    
    // Get certificates from user data if exists
    const certificatesFromUser = certificatesData || [];
    
    // Default certificates if none exist in user data
    const defaultCertificates = [];
    
    const certificatesToMigrate = certificatesFromUser.length > 0 ? certificatesFromUser : defaultCertificates;
    
    for (const [index, certificate] of certificatesToMigrate.entries()) {
      const certificateDoc = new Certificate({
        title: certificate.title,
        description: certificate.description,
        issuer: certificate.issuer,
        year: certificate.year,
        image: certificate.image || '',
        url: certificate.url || '',
        category: certificate.category || 'General',
        credentialId: certificate.credentialId || '',
        featured: certificate.featured || (index === 0), // Make first one featured by default
        isActive: certificate.isActive !== false,
        slug: certificate.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') + '-certificate',
        order: index + 1,
        skills: certificate.skills || []
      });
      
      await certificateDoc.save();
    }
    
    console.log(`✅ Migrated ${certificatesToMigrate.length} certificates`);
  } catch (error) {
    console.error('❌ Error migrating certificates:', error);
  }
};

// Migrate Skills from User Data  
const migrateSkills = async () => {
  try {
    console.log('🔄 Migrating skills...');
    
    // Clear existing skills
    await Skill.deleteMany({});
    
    // Get skills from user data if exists
    const skillsFromUser = skillsData || [];
    
    // Default skills if none exist in user data
    const defaultSkills = [];
    
    const skillsToMigrate = skillsFromUser.length > 0 ? skillsFromUser : defaultSkills;
    
    for (const [index, skill] of skillsToMigrate.entries()) {
      const skillDoc = new Skill({
        title: skill.title,
        description: skill.description || `Professional experience with ${skill.title}`,
        icon: skill.icon || 'fas fa-code',
        color: skill.color || '#007bff',
        percentage: skill.percentage || 50,
        category: skill.category || 'Other',
        level: skill.level || 'Intermediate',
        yearsExperience: skill.yearsExperience || 1,
        certifications: skill.certifications || [],
        projects: skill.projects || [],
        featured: skill.featured || false,
        isActive: skill.isActive !== false,
        slug: skill.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: index + 1
      });
      
      await skillDoc.save();
    }
    
    console.log(`✅ Migrated ${skillsToMigrate.length} skills`);
  } catch (error) {
    console.error('❌ Error migrating skills:', error);
  }
};

// Migrate Education from User Data  
const migrateEducation = async () => {
  try {
    console.log('🔄 Migrating education...');
    
    // Clear existing education
    await Education.deleteMany({});
    
    // Get education from user data if exists
    const educationFromUser = educationData || [];
    
    // Default education if none exist in user data
    const defaultEducation = [];
    
    const educationToMigrate = educationFromUser.length > 0 ? educationFromUser : defaultEducation;
    
    for (const [index, education] of educationToMigrate.entries()) {
      const educationDoc = new Education({
        title: education.title,
        institution: education.institution,
        degree: education.degree || '',
        fieldOfStudy: education.fieldOfStudy || '',
        startDate: education.startDate ? new Date(education.startDate) : new Date(),
        endDate: education.endDate ? new Date(education.endDate) : null,
        current: education.current || false,
        grade: education.grade || '',
        description: education.description || '',
        activities: education.activities || [],
        achievements: education.achievements || [],
        skills: education.skills || [],
        location: education.location || '',
        image: education.image || '',
        certificateUrl: education.certificateUrl || '',
        transcriptUrl: education.transcriptUrl || '',
        featured: education.featured || false,
        isActive: education.isActive !== false,
        slug: `${education.title}-${education.institution}`.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: index + 1
      });
      
      await educationDoc.save();
    }
    
    console.log(`✅ Migrated ${educationToMigrate.length} education records`);
  } catch (error) {
    console.error('❌ Error migrating education:', error);
  }
};

// Migrate Experience
const migrateExperience = async () => {
  try {
    console.log('🔄 Migrating experience...');
    
    // Clear existing experience
    await Experience.deleteMany({});
    
    // Get experience from user data if exists
    const experienceFromUser = experienceData || [];
    
    // Default experience if none exist in user data
    const defaultExperience = [];
    
    const experienceToMigrate = experienceFromUser.length > 0 ? experienceFromUser : defaultExperience;
    
    for (const [index, experience] of experienceToMigrate.entries()) {
      const experienceDoc = new Experience({
        title: experience.title,
        company: experience.company,
        location: experience.location || '',
        startDate: experience.startDate ? new Date(experience.startDate) : new Date(),
        endDate: experience.endDate ? new Date(experience.endDate) : null,
        current: experience.current || false,
        employmentType: experience.employmentType || 'Full-time',
        description: experience.description || '',
        responsibilities: experience.responsibilities || [],
        achievements: experience.achievements || [],
        skills: experience.skills || [],
        technologies: experience.technologies || [],
        companyLogo: experience.companyLogo || '',
        companyWebsite: experience.companyWebsite || '',
        industry: experience.industry || '',
        featured: experience.featured || false,
        isActive: experience.isActive !== false,
        slug: `${experience.title}-${experience.company}`.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: index + 1
      });
      
      await experienceDoc.save();
    }
    
    console.log(`✅ Migrated ${experienceToMigrate.length} experience records`);
  } catch (error) {
    console.error('❌ Error migrating experience:', error);
  }
};

// Migrate Services
const migrateServices = async () => {
  try {
    console.log('🔄 Migrating services...');
    
    // Clear existing services
    await Service.deleteMany({});
    
    // Default services since there's no existing service data in user profile
    const defaultServices = [];
    
    for (const [index, service] of defaultServices.entries()) {
      const serviceDoc = new Service({
        title: service.title,
        description: service.description,
        shortDescription: service.shortDescription,
        iconClass: service.iconClass,
        category: service.category,
        tag: service.tag || 'Service',
        number: service.number || index + 1,
        bgText: service.bgText || service.shortDescription,
        technologies: service.technologies || [],
        features: service.features || [],
        pricing: service.pricing,
        deliveryTime: service.deliveryTime,
        processSteps: service.processSteps || [],
        featured: service.featured || false,
        isActive: service.isActive !== false,
        slug: service.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: service.order || index + 1
      });
      
      await serviceDoc.save();
    }
    
    console.log(`✅ Migrated ${defaultServices.length} services`);
  } catch (error) {
    console.error('❌ Error migrating services:', error);
  }
};

// Migrate Characteristics
const migrateCharacteristics = async () => {
  try {
    console.log('🔄 Migrating characteristics...');
    
    // Clear existing characteristics
    await Characteristic.deleteMany({});
    
    for (const [index, characteristic] of characteristicsData.entries()) {
      // Transform data structure if needed
      const characteristicDoc = new Characteristic({
        title: characteristic.title || 'Untitled Characteristic',
        description: characteristic.description || '',
        shortDescription: characteristic.shortDescription || characteristic.description || '',
        icon: characteristic.icon || '',
        iconClass: characteristic.iconClass || '',
        image: characteristic.image || '',
        category: characteristic.category || 'personal',
        value: characteristic.value || 80,
        unit: characteristic.unit || '%',
        color: characteristic.color || '#007bff',
        link: characteristic.link || '',
        backTitle: characteristic.backTitle || characteristic.title,
        backDescription: characteristic.backDescription || characteristic.shortDescription || characteristic.description,
        tags: characteristic.tags || [],
        featured: characteristic.featured || false,
        isActive: characteristic.isActive !== false,
        slug: characteristic.slug || characteristic.title?.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        order: characteristic.order || index + 1,
        seoTitle: characteristic.seoTitle || characteristic.title,
        seoDescription: characteristic.seoDescription || characteristic.shortDescription || characteristic.description,
        seoKeywords: characteristic.seoKeywords || []
      });
      
      await characteristicDoc.save();
    }
    
    console.log(`✅ Migrated ${characteristicsData.length} characteristics`);
  } catch (error) {
    console.error('❌ Error migrating characteristics:', error);
  }
};

// Main migration function
const runMigration = async () => {
  try {
    console.log('🚀 Starting data migration...');
    
    await connectDB();
    
    await migrateProjects();
    await migrateBlogs();
    await migrateUserData();
    await migrateTestimonials();
    await migrateCertificates();
    await migrateSkills();
    await migrateEducation();
    await migrateExperience();
    await migrateServices();
    await migrateCharacteristics();
    
    console.log('🎉 Migration completed successfully!');
    
    // Create backup of JSON files
    const backupDir = path.join(__dirname, '../data/backup');
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    fs.copyFileSync(
      path.join(__dirname, '../data/projectsData.json'),
      path.join(backupDir, `projectsData_${timestamp}.json`)
    );
    fs.copyFileSync(
      path.join(__dirname, '../data/blogsData.json'),
      path.join(backupDir, `blogsData_${timestamp}.json`)
    );
    
    // Backup individual data files
    const dataFiles = [
      'aboutData.json',
      'educationData.json', 
      'experienceData.json',
      'servicesData.json',
      'processData.json',
      'certificatesData.json',
      'testimonialsData.json',
      'skillsData.json'
    ];
    
    dataFiles.forEach(file => {
      const sourcePath = path.join(__dirname, '../data/', file);
      const backupPath = path.join(backupDir, `${file.replace('.json', '')}_${timestamp}.json`);
      if (fs.existsSync(sourcePath)) {
        fs.copyFileSync(sourcePath, backupPath);
      }
    });
    
    console.log('📦 JSON files backed up to data/backup/');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Migration failed:', error);
    process.exit(1);
  }
};

// Run migration if this file is executed directly
if (require.main === module) {
  runMigration();
}

module.exports = {
  runMigration,
  migrateProjects,
  migrateBlogs,
  migrateUserData,
  migrateTestimonials,
  migrateCertificates,
  migrateSkills,
  migrateEducation,
  migrateExperience,
  migrateServices,
  migrateCharacteristics
};
