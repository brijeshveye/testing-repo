const axios = require('axios');

// Base URL for the API
const BASE_URL = 'http://localhost:5000/api';

// Test data
const testProject = {
  title: 'Test MongoDB Project',
  description: 'A test project to verify MongoDB integration',
  shortDescription: 'Test project for MongoDB',
  slug: 'test-mongodb-project',
  technologies: ['Node.js', 'MongoDB', 'Express'],
  category: 'web',
  status: 'completed',
  featured: true,
  widgets: [
    {
      type: 'text',
      content: 'This is a test project created during MongoDB migration.',
      order: 1
    }
  ]
};

const testBlog = {
  title: 'MongoDB Migration Blog Post',
  content: 'This blog post discusses the migration from JSON to MongoDB.',
  excerpt: 'Learn about our MongoDB migration process.',
  slug: 'mongodb-migration-blog',
  tags: ['mongodb', 'migration', 'database'],
  category: 'technology',
  published: true,
  featured: false,
  widgets: [
    {
      type: 'text',
      content: 'MongoDB provides better scalability than JSON files.',
      order: 1
    }
  ]
};

const testUserSection = {
  aboutData: {
    name: 'Test User',
    email: 'test@example.com',
    bio: 'A test user created during MongoDB migration testing.',
    location: 'Test City'
  }
};

// Helper function to make API calls
const apiCall = async (method, endpoint, data = null) => {
  try {
    const config = {
      method,
      url: `${BASE_URL}${endpoint}`,
      headers: {
        'Content-Type': 'application/json'
      }
    };
    
    if (data) {
      config.data = data;
    }
    
    const response = await axios(config);
    return { success: true, data: response.data, status: response.status };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data || error.message, 
      status: error.response?.status 
    };
  }
};

// Test functions
const testProjects = async () => {
  console.log('\n🔄 Testing Projects API...');
  
  // Test GET all projects
  console.log('📝 GET /api/projects');
  const getProjects = await apiCall('GET', '/projects');
  console.log('Result:', getProjects.success ? '✅ Success' : '❌ Failed', getProjects);
  
  // Test CREATE project
  console.log('📝 POST /api/projects');
  const createProject = await apiCall('POST', '/projects', testProject);
  console.log('Result:', createProject.success ? '✅ Success' : '❌ Failed', createProject);
  
  if (createProject.success) {
    const projectSlug = createProject.data.slug;
    
    // Test GET project by slug
    console.log(`📝 GET /api/projects/${projectSlug}`);
    const getProject = await apiCall('GET', `/projects/${projectSlug}`);
    console.log('Result:', getProject.success ? '✅ Success' : '❌ Failed', getProject);
    
    // Test UPDATE project
    console.log(`📝 PUT /api/projects/${projectSlug}`);
    const updateData = { ...testProject, description: 'Updated description for MongoDB test' };
    const updateProject = await apiCall('PUT', `/projects/${projectSlug}`, updateData);
    console.log('Result:', updateProject.success ? '✅ Success' : '❌ Failed', updateProject);
    
    // Test DELETE project (optional - comment out to keep test data)
    // console.log(`📝 DELETE /api/projects/${projectSlug}`);
    // const deleteProject = await apiCall('DELETE', `/projects/${projectSlug}`);
    // console.log('Result:', deleteProject.success ? '✅ Success' : '❌ Failed', deleteProject);
  }
};

const testBlogs = async () => {
  console.log('\n🔄 Testing Blogs API...');
  
  // Test GET all blogs
  console.log('📝 GET /api/blogs');
  const getBlogs = await apiCall('GET', '/blogs');
  console.log('Result:', getBlogs.success ? '✅ Success' : '❌ Failed', getBlogs);
  
  // Test CREATE blog
  console.log('📝 POST /api/blogs');
  const createBlog = await apiCall('POST', '/blogs', testBlog);
  console.log('Result:', createBlog.success ? '✅ Success' : '❌ Failed', createBlog);
  
  if (createBlog.success) {
    const blogSlug = createBlog.data.slug;
    
    // Test GET blog by slug
    console.log(`📝 GET /api/blogs/${blogSlug}`);
    const getBlog = await apiCall('GET', `/blogs/${blogSlug}`);
    console.log('Result:', getBlog.success ? '✅ Success' : '❌ Failed', getBlog);
    
    // Test UPDATE blog
    console.log(`📝 PUT /api/blogs/${blogSlug}`);
    const updateData = { ...testBlog, content: 'Updated content for MongoDB blog test' };
    const updateBlog = await apiCall('PUT', `/blogs/${blogSlug}`, updateData);
    console.log('Result:', updateBlog.success ? '✅ Success' : '❌ Failed', updateBlog);
  }
};

const testUser = async () => {
  console.log('\n🔄 Testing User API...');
  
  // Test GET user data
  console.log('📝 GET /api/user');
  const getUser = await apiCall('GET', '/user');
  console.log('Result:', getUser.success ? '✅ Success' : '❌ Failed', getUser);
  
  // Test UPDATE user section
  console.log('📝 PUT /api/user/aboutData');
  const updateSection = await apiCall('PUT', '/user/aboutData', testUserSection.aboutData);
  console.log('Result:', updateSection.success ? '✅ Success' : '❌ Failed', updateSection);
  
  // Test ADD item to array section
  console.log('📝 POST /api/user/skillsData/add');
  const newSkill = { name: 'MongoDB', percentage: 85, category: 'database' };
  const addSkill = await apiCall('POST', '/user/skillsData/add', newSkill);
  console.log('Result:', addSkill.success ? '✅ Success' : '❌ Failed', addSkill);
};

const testUploads = async () => {
  console.log('\n🔄 Testing Uploads API...');
  
  // Test GET uploads list
  console.log('📝 GET /api/upload/list/general');
  const getUploads = await apiCall('GET', '/upload/list/general');
  console.log('Result:', getUploads.success ? '✅ Success' : '❌ Failed', getUploads);
  
  // Test GET all uploads
  console.log('📝 GET /api/upload/all');
  const getAllUploads = await apiCall('GET', '/upload/all');
  console.log('Result:', getAllUploads.success ? '✅ Success' : '❌ Failed', getAllUploads);
};

const testServerHealth = async () => {
  console.log('\n🔄 Testing Server Health...');
  
  // Test basic API endpoint
  console.log('📝 GET /api');
  const healthCheck = await apiCall('GET', '');
  console.log('Result:', healthCheck.success ? '✅ Success' : '❌ Failed', healthCheck);
};

// Main test runner
const runTests = async () => {
  console.log('🚀 Starting MongoDB API Tests...');
  console.log('⚠️  Make sure the server is running on http://localhost:5000');
  
  try {
    await testServerHealth();
    await testProjects();
    await testBlogs();
    await testUser();
    await testUploads();
    
    console.log('\n🎉 All tests completed!');
    console.log('Check the results above to verify MongoDB integration.');
    
  } catch (error) {
    console.error('❌ Test runner error:', error);
  }
};

// Export for use as module or run directly
if (require.main === module) {
  runTests();
}

module.exports = {
  runTests,
  testProjects,
  testBlogs,
  testUser,
  testUploads,
  testServerHealth
};
