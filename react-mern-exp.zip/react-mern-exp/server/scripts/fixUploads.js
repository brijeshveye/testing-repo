const fs = require('fs');
const path = require('path');
const mongoose = require('mongoose');

// Connect to MongoDB
const mongoURI = process.env.MONGODB_URI || 'mongodb+srv://sanjayveye:nsnGBIJHzrzkmZw6@cluster0.czkcxtw.mongodb.net/';
mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const Upload = require('../models/Upload');

const fixUploads = async () => {
  try {
    console.log('Starting upload directory fix...');
    
    const uploadsDir = path.join(__dirname, '../uploads');
    const generalDir = path.join(uploadsDir, 'general');
    
    // Get all upload records from database
    const uploads = await Upload.find({});
    console.log(`Found ${uploads.length} upload records in database`);
    
    for (const upload of uploads) {
      const currentFilePath = path.join(generalDir, upload.filename);
      const correctCategoryDir = path.join(uploadsDir, upload.category);
      const correctFilePath = path.join(correctCategoryDir, upload.filename);
      
      // Check if file exists in general directory
      if (fs.existsSync(currentFilePath)) {
        // Create category directory if it doesn't exist
        if (!fs.existsSync(correctCategoryDir)) {
          fs.mkdirSync(correctCategoryDir, { recursive: true });
          console.log(`Created directory: ${upload.category}`);
        }
        
        // Move file to correct directory
        if (!fs.existsSync(correctFilePath)) {
          fs.renameSync(currentFilePath, correctFilePath);
          console.log(`Moved ${upload.filename} from general to ${upload.category}`);
        } else {
          console.log(`File ${upload.filename} already exists in ${upload.category}`);
        }
      } else {
        console.log(`File ${upload.filename} not found in general directory`);
      }
    }
    
    // Check if general directory is empty and remove if so
    if (fs.existsSync(generalDir)) {
      const remainingFiles = fs.readdirSync(generalDir);
      if (remainingFiles.length === 0) {
        fs.rmdirSync(generalDir);
        console.log('Removed empty general directory');
      } else {
        console.log(`General directory still contains ${remainingFiles.length} files`);
      }
    }
    
    console.log('Upload directory fix completed!');
    process.exit(0);
  } catch (error) {
    console.error('Error fixing uploads:', error);
    process.exit(1);
  }
};

fixUploads();
