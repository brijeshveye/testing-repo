const fs = require('fs');
const path = require('path');

/**
 * Script to split userData.json into individual JSON files
 */
const splitUserData = () => {
    console.log('🔄 Splitting userData.json into individual files...\n');

    const userDataPath = path.join(__dirname, '../data/userData.json');
    
    // Check if userData.json exists
    if (!fs.existsSync(userDataPath)) {
        console.log('❌ userData.json not found');
        return;
    }

    try {
        // Read the original userData.json
        const userData = JSON.parse(fs.readFileSync(userDataPath, 'utf8'));
        console.log('📖 Read userData.json successfully');

        // Define the sections to split
        const sections = {
            aboutData: userData.aboutData || {},
            educationData: userData.educationData || [],
            experienceData: userData.experienceData || [],
            servicesData: userData.servicesData || [],
            processData: userData.processData || [],
            certificatesData: userData.certificatesData || [],
            testimonialsData: userData.testimonialsData || [],
            skillsData: userData.skillsData || []
        };

        // Create individual files
        const dataDir = path.join(__dirname, '../data');
        let filesCreated = 0;

        Object.entries(sections).forEach(([sectionName, sectionData]) => {
            const filePath = path.join(dataDir, `${sectionName}.json`);
            
            try {
                fs.writeFileSync(filePath, JSON.stringify(sectionData, null, 2));
                console.log(`✅ Created: ${sectionName}.json`);
                filesCreated++;
            } catch (error) {
                console.log(`❌ Failed to create ${sectionName}.json:`, error.message);
            }
        });

        console.log(`\n🎉 Successfully created ${filesCreated} individual data files!`);

        // Create backup of original file
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupPath = path.join(dataDir, 'backup', `userData_original_${timestamp}.json`);
        
        // Ensure backup directory exists
        const backupDir = path.dirname(backupPath);
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }
        
        fs.copyFileSync(userDataPath, backupPath);
        console.log(`📦 Original file backed up to: ${path.basename(backupPath)}`);

        // Optionally remove original file (commented out for safety)
        // fs.unlinkSync(userDataPath);
        // console.log('🗑️  Original userData.json removed');

        console.log('\n📝 Note: Original userData.json has been kept for backward compatibility.');
        console.log('You can safely remove it after verifying everything works correctly.');

    } catch (error) {
        console.error('❌ Error splitting userData.json:', error.message);
    }
};

// Run if this file is executed directly
if (require.main === module) {
    splitUserData();
}

module.exports = { splitUserData };
