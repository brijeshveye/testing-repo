// Test script to verify PIN authentication system
const testPinSystem = async () => {
  const API_BASE = 'http://localhost:5000/api/pin';
  
  try {
    console.log('🔧 Testing PIN Authentication System...\n');
    
    // Test 1: Check PIN status
    console.log('1. Testing PIN status...');
    const statusResponse = await fetch(`${API_BASE}/status`);
    const statusData = await statusResponse.json();
    console.log('PIN Status:', statusData);
    
    // Test 2: Check lock status
    console.log('\n2. Testing lock status...');
    const lockResponse = await fetch(`${API_BASE}/lock-status?deviceFingerprint=test-device`);
    const lockData = await lockResponse.json();
    console.log('Lock Status:', lockData);
    
    // Test 3: Try invalid PIN
    console.log('\n3. Testing invalid PIN...');
    const invalidPinResponse = await fetch(`${API_BASE}/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pin: '0000',
        deviceFingerprint: 'test-device'
      })
    });
    const invalidPinData = await invalidPinResponse.json();
    console.log('Invalid PIN Result:', invalidPinData);
    
    // Test 4: Try master PIN
    console.log('\n4. Testing master PIN...');
    const masterPinResponse = await fetch(`${API_BASE}/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        pin: '2701',
        deviceFingerprint: 'test-device'
      })
    });
    const masterPinData = await masterPinResponse.json();
    console.log('Master PIN Result:', masterPinData);
    
    if (masterPinData.success) {
      // Test 5: Verify session
      console.log('\n5. Testing session verification...');
      const sessionResponse = await fetch(`${API_BASE}/verify-session`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionToken: masterPinData.sessionToken,
          deviceFingerprint: 'test-device'
        })
      });
      const sessionData = await sessionResponse.json();
      console.log('Session Verification:', sessionData);
      
      // Test 6: Test PIN change
      console.log('\n6. Testing PIN change...');
      const changeResponse = await fetch(`${API_BASE}/change`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentPin: '2701',
          newPin: '1234',
          sessionToken: masterPinData.sessionToken,
          deviceFingerprint: 'test-device'
        })
      });
      const changeData = await changeResponse.json();
      console.log('PIN Change Result:', changeData);
      
      // Test 7: Logout
      console.log('\n7. Testing logout...');
      const logoutResponse = await fetch(`${API_BASE}/logout`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionToken: masterPinData.sessionToken,
          deviceFingerprint: 'test-device'
        })
      });
      const logoutData = await logoutResponse.json();
      console.log('Logout Result:', logoutData);
    }
    
    console.log('\n✅ PIN Authentication System Tests Completed!');
    
  } catch (error) {
    console.error('❌ Test Error:', error);
  }
};

// Run the test
testPinSystem();
