const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

class BackupService {
  constructor() {
    this.backupDir = path.join(__dirname, '../data/backups');
    this.ensureBackupDir();
  }

  ensureBackupDir() {
    if (!fs.existsSync(this.backupDir)) {
      fs.mkdirSync(this.backupDir, { recursive: true });
    }
  }

  async exportData(model, modelName) {
    try {
      const data = await model.find({}).lean();
      const timestamp = new Date().toISOString().split('T')[0];
      const filename = `${modelName}_backup_${timestamp}.json`;
      
      return {
        filename,
        data: JSON.stringify(data, null, 2),
        timestamp
      };
    } catch (error) {
      throw new Error(`Failed to export ${modelName}: ${error.message}`);
    }
  }

  async importData(model, jsonData, modelName) {
    try {
      const data = JSON.parse(jsonData);
      
      if (!Array.isArray(data)) {
        throw new Error('Invalid data format. Expected an array.');
      }

      // Clear existing data
      await model.deleteMany({});
      
      // Insert new data
      if (data.length > 0) {
        await model.insertMany(data);
      }

      return {
        success: true,
        message: `Successfully imported ${data.length} ${modelName} records`,
        count: data.length
      };
    } catch (error) {
      throw new Error(`Failed to import ${modelName}: ${error.message}`);
    }
  }

  async resetData(model, modelName) {
    try {
      const result = await model.deleteMany({});
      return {
        success: true,
        message: `Successfully reset ${modelName} data`,
        deletedCount: result.deletedCount
      };
    } catch (error) {
      throw new Error(`Failed to reset ${modelName}: ${error.message}`);
    }
  }

  async createBulkBackup(models) {
    try {
      const timestamp = new Date().toISOString().split('T')[0];
      const zipFilename = `portfolio_backup_${timestamp}.zip`;
      const zipPath = path.join(this.backupDir, zipFilename);

      const output = fs.createWriteStream(zipPath);
      const archive = archiver('zip', {
        zlib: { level: 9 }
      });

      archive.pipe(output);

      for (const { model, name } of models) {
        const data = await model.find({}).lean();
        const jsonData = JSON.stringify(data, null, 2);
        archive.append(jsonData, { name: `${name}.json` });
      }

      await archive.finalize();

      return new Promise((resolve, reject) => {
        output.on('close', () => {
          resolve({
            filename: zipFilename,
            path: zipPath,
            size: archive.pointer()
          });
        });

        output.on('error', reject);
        archive.on('error', reject);
      });
    } catch (error) {
      throw new Error(`Failed to create bulk backup: ${error.message}`);
    }
  }
}

module.exports = new BackupService();
