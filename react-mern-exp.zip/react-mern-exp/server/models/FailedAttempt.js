const mongoose = require('mongoose');

const failedAttemptSchema = new mongoose.Schema({
  deviceFingerprint: {
    type: String,
    required: true,
    index: true
  },
  ipAddress: {
    type: String,
    required: true,
    index: true
  },
  attempts: {
    type: Number,
    default: 1
  },
  lockedUntil: {
    type: Date,
    default: null,
    index: { expireAfterSeconds: 0, sparse: true }
  },
  lastAttempt: {
    type: Date,
    default: Date.now
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create compound index for device and IP tracking
failedAttemptSchema.index({ deviceFingerprint: 1, ipAddress: 1 }, { unique: true });

// Method to check if device is locked
failedAttemptSchema.methods.isLocked = function() {
  return this.lockedUntil && this.lockedUntil > new Date();
};

// Method to get remaining lock time in seconds
failedAttemptSchema.methods.getRemainingLockTime = function() {
  if (!this.isLocked()) return 0;
  return Math.ceil((this.lockedUntil - new Date()) / 1000);
};

module.exports = mongoose.model('FailedAttempt', failedAttemptSchema);
