const mongoose = require('mongoose');

const pinAuthSchema = new mongoose.Schema({
  pin: {
    type: String,
    required: true,
    minlength: 4,
    maxlength: 6
  },
  isActive: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field before saving
pinAuthSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('PinAuth', pinAuthSchema);
