const dataService = require('../services/dataService');

/**
 * Read user data - reads from individual files and combines them
 * @returns {object} Combined user data object
 */
const readUserData = () => {
    try {
        return dataService.readAllUserData();
    } catch (error) {
        console.error('Error reading user data:', error);
        return {};
    }
};

/**
 * Write user data - writes to individual files
 * @param {object} data - User data object
 */
const writeUserData = (data) => {
    try {
        dataService.writeAllUserData(data);
    } catch (error) {
        console.error('Error writing user data:', error);
        throw error;
    }
};

module.exports = {
    readUserData,
    writeUserData,
    // Export individual data service methods for direct access
    readDataSection: dataService.readDataSection,
    writeDataSection: dataService.writeDataSection,
    checkDataFiles: dataService.checkDataFiles
};
