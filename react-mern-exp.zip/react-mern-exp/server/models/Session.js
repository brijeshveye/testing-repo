const mongoose = require('mongoose');

const sessionSchema = new mongoose.Schema({
  deviceFingerprint: {
    type: String,
    required: true,
    index: true
  },
  ipAddress: {
    type: String,
    required: true,
    index: true
  },
  userAgent: {
    type: String,
    required: true
  },
  isActive: {
    type: Boolean,
    default: true
  },
  sessionToken: {
    type: String,
    required: true,
    unique: true
  },
  expiresAt: {
    type: Date,
    required: true,
    index: { expireAfterSeconds: 0 }
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Create compound index for device and IP tracking
sessionSchema.index({ deviceFingerprint: 1, ipAddress: 1 });

module.exports = mongoose.model('Session', sessionSchema);
