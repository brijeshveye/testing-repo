const express = require('express');
const router = express.Router();
const archiver = require('archiver');
const fs = require('fs');
const path = require('path');

// Import all models
const Project = require('../models/Project');
const Blog = require('../models/Blog');
const Certificate = require('../models/Certificate');
const Skill = require('../models/Skill');
const Experience = require('../models/Experience');
const Education = require('../models/Education');
const Service = require('../models/Service');
const Testimonial = require('../models/Testimonial');
const Characteristic = require('../models/Characteristic');
const User = require('../models/User');

// Bulk backup all data
router.get('/all', async (req, res) => {
  try {
    console.log('Starting bulk backup...');
    
    // Create archive
    const archive = archiver('zip', {
      zlib: { level: 9 } // Set compression level
    });

    // Set response headers
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="portfolio_backup_${new Date().toISOString().split('T')[0]}.zip"`);

    // Pipe archive to response
    archive.pipe(res);

    // Helper function to add data to archive
    const addDataToArchive = async (model, filename) => {
      try {
        const data = await model.find({}).lean();
        const jsonData = JSON.stringify(data, null, 2);
        archive.append(jsonData, { name: filename });
        console.log(`Added ${filename} to archive (${data.length} records)`);
      } catch (error) {
        console.error(`Error backing up ${filename}:`, error);
        // Add empty array if there's an error
        archive.append('[]', { name: filename });
      }
    };

    // Add all collections to archive
    await addDataToArchive(Project, 'projects.json');
    await addDataToArchive(Blog, 'blogs.json');
    await addDataToArchive(Certificate, 'certificates.json');
    await addDataToArchive(Skill, 'skills.json');
    await addDataToArchive(Experience, 'experience.json');
    await addDataToArchive(Education, 'education.json');
    await addDataToArchive(Service, 'services.json');
    await addDataToArchive(Testimonial, 'testimonials.json');
    await addDataToArchive(Characteristic, 'characteristics.json');
    await addDataToArchive(User, 'user.json');

    // Add metadata
    const metadata = {
      timestamp: new Date().toISOString(),
      version: '1.0',
      description: 'Complete portfolio backup',
      collections: [
        'projects', 'blogs', 'certificates', 'skills', 'experience', 
        'education', 'services', 'testimonials', 'characteristics', 'user'
      ]
    };
    archive.append(JSON.stringify(metadata, null, 2), { name: 'metadata.json' });

    // Finalize the archive
    archive.finalize();

    console.log('Bulk backup completed successfully');

  } catch (error) {
    console.error('Bulk backup error:', error);
    
    // If headers haven't been sent, send error response
    if (!res.headersSent) {
      res.status(500).json({
        success: false,
        message: 'Failed to create bulk backup',
        error: error.message
      });
    }
  }
});

// Bulk backup status (optional endpoint for checking progress)
router.get('/status', async (req, res) => {
  try {
    const counts = {};
    
    // Get record counts for all collections
    counts.projects = await Project.countDocuments();
    counts.blogs = await Blog.countDocuments();
    counts.certificates = await Certificate.countDocuments();
    counts.skills = await Skill.countDocuments();
    counts.experience = await Experience.countDocuments();
    counts.education = await Education.countDocuments();
    counts.services = await Service.countDocuments();
    counts.testimonials = await Testimonial.countDocuments();
    counts.characteristics = await Characteristic.countDocuments();
    counts.user = await User.countDocuments();
    
    const totalRecords = Object.values(counts).reduce((sum, count) => sum + count, 0);
    
    res.json({
      success: true,
      message: 'Backup system is operational',
      totalRecords,
      collections: counts,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Backup status error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get backup status',
      error: error.message
    });
  }
});

module.exports = router;
