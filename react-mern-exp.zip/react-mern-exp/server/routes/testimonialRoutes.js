const express = require('express');
const router = express.Router();
const {
    getAllTestimonials,
    getTestimonialBySlug,
    createTestimonial,
    updateTestimonial,
    deleteTestimonial,
    updateTestimonialOrder,
    backupTestimonials,
    restoreTestimonials,
    resetTestimonials,
    upload
} = require('../controllers/testimonialController');

// GET all testimonials
router.get('/', getAllTestimonials);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupTestimonials);
router.post('/restore', upload.single('file'), restoreTestimonials);
router.delete('/reset', resetTestimonials);

// GET testimonial by slug
router.get('/:slug', getTestimonialBySlug);

// CREATE new testimonial
router.post('/', createTestimonial);

// UPDATE testimonial order (bulk update)
router.put('/order', updateTestimonialOrder);

// UPDATE testimonial by slug
router.put('/:slug', updateTestimonial);

// DELETE testimonial by slug (soft delete)
router.delete('/:slug', deleteTestimonial);

module.exports = router;
