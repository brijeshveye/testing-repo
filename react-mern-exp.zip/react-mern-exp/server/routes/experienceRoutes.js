const express = require('express');
const router = express.Router();
const {
  getAllExperience,
  getExperienceBySlug,
  createExperience,
  updateExperience,
  deleteExperience,
  toggleFeatured,
  toggleActive,
  updateExperienceOrder,
  getExperienceStats,
  backupExperience,
  restoreExperience,
  resetExperience,
  upload
} = require('../controllers/experienceController');

// Get experience statistics
router.get('/stats', getExperienceStats);

// Get all experience records
router.get('/', getAllExperience);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupExperience);
router.post('/restore', upload.single('file'), restoreExperience);
router.delete('/reset', resetExperience);

// Get experience by slug
router.get('/:slug', getExperienceBySlug);

// Create new experience record
router.post('/', createExperience);

// Update experience record
router.put('/:slug', updateExperience);

// Delete experience record
router.delete('/:slug', deleteExperience);

// Toggle featured status
router.put('/:slug/toggle-featured', toggleFeatured);

// Toggle active status
router.put('/:slug/toggle-active', toggleActive);

// Update experience order
router.put('/order/update', updateExperienceOrder);

module.exports = router;
