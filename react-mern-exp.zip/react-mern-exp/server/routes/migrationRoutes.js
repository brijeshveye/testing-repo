const express = require('express');
const router = express.Router();
const { exec } = require('child_process');
const path = require('path');

// Migration endpoint
router.post('/sample-data', async (req, res) => {
  try {
    console.log('🔄 Starting sample data migration...');
    
    const scriptPath = path.join(__dirname, '../scripts/migrateData.js');
    
    // Execute the migration script
    exec(`node "${scriptPath}"`, (error, stdout, stderr) => {
      if (error) {
        console.error('❌ Migration error:', error);
        return res.status(500).json({
          success: false,
          message: 'Failed to migrate sample data',
          error: error.message
        });
      }
      
      if (stderr) {
        console.error('❌ Migration stderr:', stderr);
        return res.status(500).json({
          success: false,
          message: 'Migration completed with warnings',
          error: stderr
        });
      }
      
      console.log('✅ Migration completed successfully');
      console.log('Migration output:', stdout);
      
      res.json({
        success: true,
        message: 'Sample data migrated successfully!',
        output: stdout
      });
    });
    
  } catch (error) {
    console.error('❌ Migration endpoint error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to start migration process',
      error: error.message
    });
  }
});

// Get migration status
router.get('/status', async (req, res) => {
  try {
    // You can implement logic to check migration status
    // For now, just return a simple status
    res.json({
      success: true,
      message: 'Migration endpoint is available',
      available: true
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Failed to get migration status',
      error: error.message
    });
  }
});

module.exports = router;
