const express = require('express');
const router = express.Router();
const {
    getUserData,
    updateSection,
    addItem,
    updateItem,
    deleteItem,
    backupUser,
    restoreUser,
    resetUser,
    upload
} = require('../controllers/userController');

// GET all user data
router.get('/', getUserData);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupUser);
router.post('/restore', upload.single('file'), restoreUser);
router.delete('/reset', resetUser);

// UPDATE specific section (like /api/user/aboutData or /api/user/educationData)
router.put('/:section', updateSection);

// ADD new item to array sections (like /api/user/educationData/add)
router.post('/:section/add', addItem);

// UPDATE specific item in array sections (like /api/user/educationData/0)
router.put('/:section/:index', updateItem);

// DELETE specific item from array sections (like /api/user/educationData/0)
router.delete('/:section/:index', deleteItem);

module.exports = router;
