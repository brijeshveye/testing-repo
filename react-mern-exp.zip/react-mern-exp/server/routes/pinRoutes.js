const express = require('express');
const router = express.Router();
const {
  verifyPin,
  verifySession,
  logout,
  changePin,
  getPinStatus,
  getLockStatus
} = require('../controllers/pinController');

// Public routes
router.post('/verify', verifyPin);
router.post('/verify-session', verifySession);
router.get('/status', getPinStatus);
router.get('/lock-status', getLockStatus);

// Protected routes (require valid session)
router.post('/logout', logout);
router.post('/change', changePin);

module.exports = router;
