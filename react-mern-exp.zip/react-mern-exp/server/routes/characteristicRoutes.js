const express = require('express');
const router = express.Router();
const {
  getAllCharacteristics,
  getCharacteristicBySlug,
  createCharacteristic,
  updateCharacteristic,
  deleteCharacteristic,
  toggleFeatured,
  toggleActive,
  updateCharacteristicOrder,
  getCharacteristicStats,
  backupCharacteristics,
  restoreCharacteristics,
  resetCharacteristics,
  upload
} = require('../controllers/characteristicController');

// Get characteristic statistics
router.get('/stats', getCharacteristicStats);

// Get all characteristics
router.get('/', getAllCharacteristics);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupCharacteristics);
router.post('/restore', upload.single('file'), restoreCharacteristics);
router.delete('/reset', resetCharacteristics);

// Get characteristic by slug
router.get('/:slug', getCharacteristicBySlug);

// Create new characteristic
router.post('/', createCharacteristic);

// Update characteristic
router.put('/:slug', updateCharacteristic);

// Delete characteristic
router.delete('/:slug', deleteCharacteristic);

// Toggle featured status
router.put('/:slug/toggle-featured', toggleFeatured);

// Toggle active status
router.put('/:slug/toggle-active', toggleActive);

// Update order
router.put('/order/update', updateCharacteristicOrder);

module.exports = router;
