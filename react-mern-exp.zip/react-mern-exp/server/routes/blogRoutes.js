const express = require('express');
const router = express.Router();
const {
    getAllBlogs,
    getBlogBySlug,
    createBlog,
    updateBlog,
    deleteBlog,
    backupBlogs,
    restoreBlogs,
    resetBlogs,
    upload
} = require('../controllers/blogController');

router.get('/', getAllBlogs);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupBlogs);
router.post('/restore', upload.single('file'), restoreBlogs);
router.delete('/reset', resetBlogs);

// Parameterized routes
router.get('/:slug', getBlogBySlug);
router.post('/', createBlog);
router.put('/:slug', updateBlog);
router.delete('/:slug', deleteBlog);

module.exports = router;
