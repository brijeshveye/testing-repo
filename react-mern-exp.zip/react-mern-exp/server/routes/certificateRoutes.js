const express = require('express');
const router = express.Router();
const {
  getCertificates,
  getCertificateBySlug,
  createCertificate,
  updateCertificate,
  deleteCertificate,
  updateCertificatesOrder,
  toggleFeatured,
  toggleActive,
  backupCertificates,
  restoreCertificates,
  resetCertificates,
  upload
} = require('../controllers/certificateController');

// Public routes
router.get('/', getCertificates);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupCertificates);
router.post('/restore', upload.single('file'), restoreCertificates);
router.delete('/reset', resetCertificates);

// Admin routes (in production, add authentication middleware)
router.post('/', createCertificate);
router.put('/order/update', updateCertificatesOrder);

// Parameterized routes
router.get('/:slug', getCertificateBySlug);
router.put('/:slug', updateCertificate);
router.delete('/:slug', deleteCertificate);
router.put('/:slug/toggle-featured', toggleFeatured);
router.put('/:slug/toggle-active', toggleActive);

module.exports = router;
