const express = require('express');
const router = express.Router();
const {
    getAllProjects,
    getProjectBySlug,
    createProject,
    updateProject,
    deleteProject,
    backupProjects,
    restoreProjects,
    resetProjects,
    upload
} = require('../controllers/projectController');

router.get('/', getAllProjects);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupProjects);
router.post('/restore', upload.single('file'), restoreProjects);
router.delete('/reset', resetProjects);

// Parameterized routes
router.get('/:slug', getProjectBySlug);
router.post('/', createProject);
router.put('/:slug', updateProject);
router.delete('/:slug', deleteProject);

module.exports = router;
