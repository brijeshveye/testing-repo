const express = require('express');
const router = express.Router();
const {
  getSkills,
  getSkillBySlug,
  createSkill,
  updateSkill,
  deleteSkill,
  updateSkillsOrder,
  toggleFeatured,
  toggleActive,
  getSkillStats,
  backupSkills,
  restoreSkills,
  resetSkills,
  upload
} = require('../controllers/skillController');

// Public routes
router.get('/', getSkills);
router.get('/stats', getSkillStats);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupSkills);
router.post('/restore', upload.single('file'), restoreSkills);
router.delete('/reset', resetSkills);

// Admin routes (in production, add authentication middleware)
router.post('/', createSkill);
router.put('/order/update', updateSkillsOrder);

// Parameterized routes
router.get('/:slug', getSkillBySlug);
router.put('/:slug', updateSkill);
router.delete('/:slug', deleteSkill);
router.put('/:slug/toggle-featured', toggleFeatured);
router.put('/:slug/toggle-active', toggleActive);

module.exports = router;
