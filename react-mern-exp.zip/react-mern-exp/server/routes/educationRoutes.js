const express = require('express');
const router = express.Router();
const {
  getAllEducation,
  getEducationBySlug,
  createEducation,
  updateEducation,
  deleteEducation,
  toggleFeatured,
  toggleActive,
  updateEducationOrder,
  getEducationStats,
  backupEducation,
  restoreEducation,
  resetEducation,
  upload
} = require('../controllers/educationController');

// Get education statistics
router.get('/stats', getEducationStats);

// Get all education records
router.get('/', getAllEducation);

// Backup, Restore, Reset routes - these must come before the parameterized routes
router.get('/backup', backupEducation);
router.post('/restore', upload.single('file'), restoreEducation);
router.delete('/reset', resetEducation);

// Get education by slug
router.get('/:slug', getEducationBySlug);

// Create new education record
router.post('/', createEducation);

// Update education record
router.put('/:slug', updateEducation);

// Delete education record
router.delete('/:slug', deleteEducation);

// Toggle featured status
router.put('/:slug/toggle-featured', toggleFeatured);

// Toggle active status
router.put('/:slug/toggle-active', toggleActive);

// Update education order
router.put('/order/update', updateEducationOrder);

module.exports = router;
