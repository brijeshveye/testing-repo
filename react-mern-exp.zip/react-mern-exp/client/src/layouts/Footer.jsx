import React, { useState } from 'react'
import { showSuccess, showError } from '../utils/toastUtils';

const Footer = () => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });
    const [submitting, setSubmitting] = useState(false);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Validate form
        if (!formData.name.trim() || !formData.email.trim() || !formData.subject.trim() || !formData.message.trim()) {
            showError('Please fill in all fields');
            return;
        }

        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            showError('Please enter a valid email address');
            return;
        }

        setSubmitting(true);

        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (result.success) {
                showSuccess(result.message);
                // Reset form
                setFormData({
                    name: '',
                    email: '',
                    subject: '',
                    message: ''
                });
            } else {
                showError(result.message || 'Failed to send message');
            }
        } catch (error) {
            console.error('Error sending message:', error);
            showError('Failed to send message. Please try again later.');
        } finally {
            setSubmitting(false);
        }
    };
    return (
        <>
            <footer className="footer__section" id="fott">

                <div className="marquee-wrapper text-slider">
                    <div className="marquee-inner to-left">
                        <ul className="marqee-list d-flex">
                            <li className="marquee-item">
                                <span>Thanks for Scrolling</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Scrolled. Seen. Inspired?</span> <span className="base">*</span>
                                <span>Where Creativity Compiles</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Stay Curious</span> <span className="base">*</span>
                                <span>Keep Coding</span> <span className="basee">*</span> <span className="stroke-text"></span>
                                <span>Fast. Focused. Functional</span> <span className="base">*</span>
                                <span>Duniya Code Se</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>From Logic To Launch</span> <span className="base">*</span>
                                <span>Code With Clarity</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Site Ends</span> <span className="base">*</span>
                                <span>Passion Doesn’t</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div className="container">
                    <div className="footer__top pt-5 pb-2">
                        <div className="row g-4 justify-content-between">
                            <div className="col-lg-4 col-md-6">
                                <div className="footer-widget">
                                    <a href="index.html" className="flogo">
                                        <img src="/assets/img/logo.png" height="130px" alt="img" />
                                    </a>
                                    <p className="iam">
                                        Hi, I’m Brijesh, a developer passionate about turning ideas into impactful digital solutions
                                    </p>
                                    <span className="common__subs white" style={{ fontFamily: "Caveat, cursive", fontSize: "1.3rem" }}>
                                        Always open to new ideas and conversations.
                                    </span>
                                </div>
                            </div>
                            <div className="col-lg-2 col-md-6">
                                <div className="footer-widget">
                                    <h4 className="fhead-title">
                                        Quick Link
                                    </h4>
                                    <ul className="quick-link">
                                        <li>
                                            <a href="#0" className="pra">
                                                Service
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Project
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Blog
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Faqs
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Contact
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-6">
                                <div className="footer-widget">
                                    <h4 className="fhead-title">
                                        Address
                                    </h4>
                                    <ul className="address-link">
                                        <li className="d-flex align-items-center gap-3">
                                            <div className="icons">
                                                <i className="bi bi-geo-alt"></i>
                                            </div>
                                            <a href="#0" className="cont">
                                                Meerut, Uttar Pradesh, India
                                            </a>
                                        </li>
                                        <li className="d-flex align-items-center gap-3">
                                            <div className="icons">
                                                <i className="bi bi-chat-left-dots"></i>
                                            </div>
                                            <div className="box">
                                                <a href="#0" className="cont d-block">
                                                    hello@itsbrijesh.me
                                                </a>
                                                <a href="#0" className="cont">
                                                    brijeshch027@gmail.com
                                                </a>
                                            </div>
                                        </li>
                                        <li className="d-flex align-items-center gap-3">
                                            <div className="icons">
                                                <i className="bi bi-geo-alt"></i>
                                            </div>
                                            <div className="box">
                                                <a href="tel:+917017442328" className="cont d-block">
                                                    +91 7017 442 328
                                                </a>
                                                <a href="tel:+918650876100" className="cont">
                                                    +91 8650 876 100
                                                </a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-6">
                                <div className="footer-widget">
                                    <div className="contact-wrap">
                                        <form method="POST" onSubmit={handleSubmit} className="contactForm">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <div className="form-group">
                                                        <input 
                                                            type="text" 
                                                            className="form-control" 
                                                            name="name" 
                                                            id="footer_name"
                                                            value={formData.name}
                                                            onChange={handleInputChange}
                                                            placeholder="Name"
                                                            required
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-12">
                                                    <div className="form-group">
                                                        <input 
                                                            type="email" 
                                                            className="form-control" 
                                                            name="email" 
                                                            id="footer_email"
                                                            value={formData.email}
                                                            onChange={handleInputChange}
                                                            placeholder="Email"
                                                            required
                                                        />
                                                    </div>
                                                </div>
                                                <div className="col-md-12">
                                                    <input 
                                                        type="text" 
                                                        className="form-control" 
                                                        name="subject" 
                                                        id="footer_subject"
                                                        value={formData.subject}
                                                        onChange={handleInputChange}
                                                        placeholder="Subject"
                                                        required
                                                    />
                                                </div>
                                            </div>
                                            <div className="col-md-12">
                                                <div className="form-group">
                                                    <textarea 
                                                        name="message" 
                                                        className="form-control" 
                                                        id="footer_message" 
                                                        cols="30"
                                                        rows="4" 
                                                        value={formData.message}
                                                        onChange={handleInputChange}
                                                        placeholder="Message"
                                                        required
                                                    ></textarea>
                                                </div>
                                            </div>
                                            <div className="col-md-12">
                                                <div className="form-group">
                                                    <input 
                                                        type="submit" 
                                                        value={submitting ? "Sending..." : "Send Message"} 
                                                        className="cmn--btn base"
                                                        disabled={submitting}
                                                    />
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="footer__bottom">
                    <div className="container">
                        <div className="copyright">
                            <p className="white"> Copyright © 2025 <a href="index.html" className="base">Brijesh.</a> All rights reserved.
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        </>
    )
}

export default Footer