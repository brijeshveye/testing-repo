import React, { useContext } from 'react'
import { RootContext } from '../App';
import LoadingBar from 'react-top-loading-bar'
import Header from './Header';
import Footer from './Footer';
import BackToTopWidget from '../components/common/BackToTopWidget';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Layout = ({ children }) => {
    const rootContext = useContext(RootContext);
    const { progress, setProgress } = rootContext;


    return (
        <div className="layout-wrapper layout-content-navbar">
            <div className="layout-container">
                <div className="layout-page ">
                    <Header />
                    <LoadingBar color='#279EFF' progress={progress} onLoaderFinished={() => setProgress(0)} />
                    <div className="content-wrapper">
                        <div className="container-fluid flex-grow-1 container-p-y">
                            {children}
                        </div>
                        <Footer />
                        <BackToTopWidget />
                    </div>
                </div>
                <div className="layout-overlay layout-menu-toggle"></div>
            </div>
            <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
                theme="light"
            />
        </div>
    )
}


export default Layout;