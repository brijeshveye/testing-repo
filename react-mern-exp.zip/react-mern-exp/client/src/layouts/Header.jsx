import React, { useEffect, useState } from 'react'
import Collapse from 'bootstrap/js/dist/collapse';

const Header = () => {
    const [activeSection, setActiveSection] = useState('home');

    // Highlight active nav link on scroll
    useEffect(() => {
        const sections = document.querySelectorAll('section[id]');

        const handleScroll = () => {
            const scrollPosition = window.scrollY + 100; // Adjust for fixed header offset

            sections.forEach((section) => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.offsetHeight;

                if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                    const currentId = section.getAttribute('id');
                    setActiveSection(currentId);
                }
            });
        };

        window.addEventListener('scroll', handleScroll);

        return () => window.removeEventListener('scroll', handleScroll);
    }, []);

    // Apply .active class to correct nav link
    useEffect(() => {
        const navLinks = document.querySelectorAll('.navbar-nav a');
        navLinks.forEach((link) => {
            const href = link.getAttribute('href').replace('#', '');
            if (href === activeSection) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }, [activeSection]);


    // Collapse navbar on mobile after clicking a nav link & handle fixed header
    useEffect(() => {
        // collapse on nav click (mobile)
        const navLinks = document.querySelectorAll('.navbar-nav a');
        const navbarToggler = document.querySelector('.navbar-toggler');
        const collapseElement = document.getElementById('navbar-collapse-toggle');

        let bsCollapse = null;
        if (collapseElement) {
            bsCollapse = new Collapse(collapseElement, { toggle: false });
        }

        const handleNavClick = () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                if (collapseElement?.classList.contains('show')) {
                    bsCollapse?.hide();
                }
            }
        };

        navLinks.forEach(link => link.addEventListener('click', handleNavClick));

        // fixed header
        const handleScroll = () => {
            if (window.scrollY >= 100) {
                document.body.classList.add('fixed-header');
            } else {
                document.body.classList.remove('fixed-header');
            }
        };

        window.addEventListener('scroll', handleScroll);

        return () => {
            navLinks.forEach(link => link.removeEventListener('click', handleNavClick));
            window.removeEventListener('scroll', handleScroll);
        };
    }, []);

    // Scroll to section on link click
    const handleSmoothScroll = (e, id) => {
        e.preventDefault();
        const el = document.getElementById(id);
        if (el) {
            const y = el.getBoundingClientRect().top + window.scrollY - 70; // Adjust header offset
            window.scrollTo({ top: y, behavior: 'smooth' });
        }
    };

    const handleToggle = () => {
        const collapseElement = document.getElementById('navbar-collapse-toggle');
        if (collapseElement) {
            const bsCollapse = new Collapse(collapseElement, { toggle: false });
            if (collapseElement.classList.contains('show')) {
                bsCollapse.hide();
            } else {
                bsCollapse.show();
            }
        }
    };

    return (
        <>
            <header className="main-header">
                <nav className="navbar navbar-expand-lg one-page-nav">
                    <div className="container">
                        <a className="navbar-brand" href="#" onClick={(e) => handleSmoothScroll(e, 'home')}>
                            <img src="/assets/img/logo.png" height="50px" title="Logo" alt="Logo" />
                        </a>
                        <button className="navbar-toggler" type="button" aria-controls="navbar-collapse-toggle"
                            aria-expanded="false" aria-label="Toggle navigation"
                            onClick={handleToggle}>
                            <span></span>
                            <span></span>
                            <span></span>
                        </button>
                        <div className="collapse navbar-collapse justify-content-end" id="navbar-collapse-toggle">
                            <ul className="navbar-nav mx-auto">
                                {['home', 'about', 'services', 'work', 'blog', 'contact'].map((id, i) => (
                                <li className="nav-item" key={i}>
                                    <a
                                        className="nav-link"
                                        href={`#${id}`}
                                        data-scroll-nav={i}
                                        onClick={(e) => handleSmoothScroll(e, id)}
                                    >
                                        <span>{id.charAt(0).toUpperCase() + id.slice(1)}</span>
                                    </a>
                                </li>
                            ))}
                            </ul>
                        </div>
                        <div className="ms-auto d-lg-block d-none">
                            <a href="#contact" data-scroll-nav="6" className="px-btn px-btn-primary me-2" onClick={(e) => handleSmoothScroll(e, 'contact')}>Contact</a>
                            <a href="/admin" className="px-btn px-btn-dark" title="Admin Access">
                                <i className="fas fa-cog"></i>
                            </a>
                        </div>
                    </div>
                </nav>
            </header>
        </>
    )
}

export default Header