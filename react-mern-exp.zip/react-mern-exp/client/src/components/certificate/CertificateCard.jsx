import React from 'react';

const CertificateCard = ({ certificate }) => {
  const {
    title,
    description,
    issuer,
    year,
    image,
    url,
    category,
    featured,
    credentialId,
    expiryDate,
    skills = []
  } = certificate;

  const handleViewCertificate = () => {
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  const isExpired = expiryDate && new Date(expiryDate) < new Date();

  return (
    <div className={`card h-100 ${featured ? 'border-warning' : ''} ${isExpired ? 'opacity-75' : ''}`}>
      {featured && (
        <div className="card-header bg-warning text-dark py-1">
          <small className="d-flex align-items-center justify-content-center">
            <i className="fas fa-star me-1"></i>
            Featured Certificate
          </small>
        </div>
      )}
      
      <div className="card-body d-flex flex-column">
        <div className="text-center mb-3">
          {image ? (
            <img 
              src={image || '/assets/img/placeholder.png' } 
              alt={title}
              className="img-fluid rounded"
              style={{ maxHeight: '120px', objectFit: 'cover' }}
            />
          ) : (
            <div 
              className="bg-primary text-white d-flex align-items-center justify-content-center rounded"
              style={{ height: '120px' }}
            >
              <i className="fas fa-certificate fa-3x"></i>
            </div>
          )}
        </div>

        <div className="flex-grow-1">
          <h5 className="card-title">{title}</h5>
          <p className="card-text text-muted">{description}</p>
          
          <div className="mb-2">
            <small className="text-muted">
              <i className="fas fa-building me-1"></i>
              <strong>Issued by:</strong> {issuer}
            </small>
          </div>
          
          <div className="mb-2">
            <small className="text-muted">
              <i className="fas fa-calendar me-1"></i>
              <strong>Year:</strong> {year}
            </small>
          </div>

          {credentialId && (
            <div className="mb-2">
              <small className="text-muted">
                <i className="fas fa-id-card me-1"></i>
                <strong>Credential ID:</strong> {credentialId}
              </small>
            </div>
          )}

          {expiryDate && (
            <div className="mb-2">
              <small className={`${isExpired ? 'text-danger' : 'text-muted'}`}>
                <i className="fas fa-clock me-1"></i>
                <strong>Expires:</strong> {new Date(expiryDate).toLocaleDateString()}
                {isExpired && <span className="ms-1">(Expired)</span>}
              </small>
            </div>
          )}

          <div className="mb-2">
            <span className={`badge ${
              category === 'Web Development' ? 'bg-primary' :
              category === 'Programming' ? 'bg-success' :
              category === 'Frameworks' ? 'bg-info' :
              category === 'Cloud Computing' ? 'bg-warning text-dark' :
              'bg-secondary'
            }`}>
              {category}
            </span>
          </div>

          {skills.length > 0 && (
            <div className="mb-3">
              <small className="text-muted d-block mb-1">
                <strong>Skills:</strong>
              </small>
              <div className="d-flex flex-wrap gap-1">
                {skills.slice(0, 3).map((skill, index) => (
                  <span key={index} className="badge bg-light text-dark">
                    {skill}
                  </span>
                ))}
                {skills.length > 3 && (
                  <span className="badge bg-light text-muted">
                    +{skills.length - 3} more
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {url && (
          <div className="mt-auto">
            <button 
              onClick={handleViewCertificate}
              className="btn btn-outline-primary btn-sm w-100"
            >
              <i className="fas fa-external-link-alt me-1"></i>
              View Certificate
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default CertificateCard;
