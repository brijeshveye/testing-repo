import React, { useEffect, useState } from 'react'
import { showSuccess, showError } from '../../utils/toastUtils';

const ContactSection = () => {
    const [contactData, setContactData] = useState({});
    const [loading, setLoading] = useState(true);
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });
    const [submitting, setSubmitting] = useState(false);

    useEffect(() => {
        fetchContactData();
    }, []);

    const fetchContactData = async () => {
        try {
            setLoading(true);
            const response = await fetch('/api/user');
            const userData = await response.json();
            
            if (userData && userData.aboutData) {
                setContactData({
                    email: userData.aboutData.email || userData.aboutData.professionalEmail || userData.aboutData.secondaryEmail,
                    phone: userData.aboutData.phone || userData.aboutData.secondaryPhone,
                    professionalEmail: userData.aboutData.professionalEmail,
                    secondaryEmail: userData.aboutData.secondaryEmail,
                    secondaryPhone: userData.aboutData.secondaryPhone
                });
            }
        } catch (error) {
            console.error('Error fetching contact data:', error);
            // Fallback to default values
            setContactData({
                email: "hello@itsbrijesh.me",
                phone: "+91 7017 442 328"
            });
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Validate form
        if (!formData.name.trim() || !formData.email.trim() || !formData.subject.trim() || !formData.message.trim()) {
            showError('Please fill in all fields');
            return;
        }

        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            showError('Please enter a valid email address');
            return;
        }

        setSubmitting(true);

        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (result.success) {
                showSuccess(result.message);
                // Reset form
                setFormData({
                    name: '',
                    email: '',
                    subject: '',
                    message: ''
                });
            } else {
                showError(result.message || 'Failed to send message');
            }
        } catch (error) {
            console.error('Error sending message:', error);
            showError('Failed to send message. Please try again later.');
        } finally {
            setSubmitting(false);
        }
    };

  return (
    <>
    <section id="contact" data-scroll-index="6" className="section contact-section">
            <div className="container">
                <div className="section-heading">
                    <h3>Take a Coffee & chat with me</h3>
                </div>
                <div className="row justify-content-center">
                    <div className="col-xl-8 col-lg-10">
                        <div className="row contact-info">
                            <div className="col-md-6">
                                <a className="email" href={contactData.email ? `mailto:${contactData.email}` : "#"}>
                                    <img src="assets/img/email.png" title="" alt="" />
                                    <span>
                                        {loading ? "Loading..." : (contactData.professionalEmail || "hello@itsbrijesh.me")}
                                    </span>
                                </a>
                            </div>
                            <div className="col-md-6">
                                <a className="phone" href={contactData.phone ? `tel:${contactData.phone}` : "#"}>
                                    <img src="assets/img/phone.png" title="" alt="" />
                                    <span>
                                        {loading ? "Loading..." : (contactData.phone || "+91 7017 442 328")}
                                    </span>
                                </a>
                            </div>
                        </div>
                        <div className="contact-form">
                            <form onSubmit={handleSubmit}>
                                <div className="row">
                                    <div className="col-md-6">
                                        <div className="form-floating">
                                            <input 
                                                type="text" 
                                                className="form-control" 
                                                id="you_name"
                                                name="name"
                                                value={formData.name}
                                                onChange={handleInputChange}
                                                placeholder="Your Name"
                                                required
                                            />
                                            <label htmlFor="you_name">Your Name</label>
                                        </div>
                                    </div>
                                    <div className="col-md-6">
                                        <div className="form-floating">
                                            <input 
                                                type="email" 
                                                className="form-control" 
                                                id="your_email"
                                                name="email"
                                                value={formData.email}
                                                onChange={handleInputChange}
                                                placeholder="name@example.com"
                                                required
                                            />
                                            <label htmlFor="your_email">Email Address</label>
                                        </div>
                                    </div>
                                    <div className="col-12">
                                        <div className="form-floating">
                                            <input 
                                                type="text" 
                                                className="form-control" 
                                                id="your_subject"
                                                name="subject"
                                                value={formData.subject}
                                                onChange={handleInputChange}
                                                placeholder="Subject"
                                                required
                                            />
                                            <label htmlFor="your_subject">Subject</label>
                                        </div>
                                    </div>
                                    <div className="col-12">
                                        <div className="form-floating">
                                            <textarea 
                                                className="form-control" 
                                                placeholder="Leave a comment here"
                                                id="your_message" 
                                                name="message"
                                                value={formData.message}
                                                onChange={handleInputChange}
                                                style={{ height: "150px" }}
                                                required
                                            ></textarea>
                                            <label htmlFor="your_message">Your Message here</label>
                                        </div>
                                    </div>
                                    <div className="col-12 btn-bar text-center">
                                        <button 
                                            type="submit" 
                                            className="px-btn px-btn-primary"
                                            disabled={submitting}
                                        >
                                            {submitting ? 'SENDING...' : 'SEND INQUIRY'}
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </>
  )
}

export default ContactSection