import React from 'react'

const CertificateCardWidget = (props) => {
    return (
        <>
            <div className="col-12">
                <div className="project__item project-item-v2">
                    <div className="thumb position-relative">
                        <a href={props.image ? props.image : "assets/img/project/pro1.png"} className="thumb mb-30 imgc">
                            <img src={props.image ? props.image : "/assets/img/placeholder.png"} alt="img" />
                        </a>
                        <div
                            className="content d-flex align-items-center justify-content-between gap-2">
                            <a href="protfolio-details.html" className="left__cont">
                                <span className="base mb-2 mb-xxl-3 d-block text-uppercase">
                                    {props.title ? props.title : "My Certificate"}
                                </span>
                                <h3>
                                    {props.description ? props.description : "My Certificate Description"}
                                </h3>
                            </a>
                            <a href={props.image ? props.image : "/assets/img/project/pro1.png"} className="common__icon imgc">
                                <i className="bi bi-arrow-up-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

CertificateCardWidget.propTypes = {
    "title": "My Certificate",
    "description": "My Certificate Description",
    "image": "assets/img/project/pro1.png",
    "year": "2025",
    "url": "protfolio-details.html",
    "category": "Web Development"
}

export default CertificateCardWidget