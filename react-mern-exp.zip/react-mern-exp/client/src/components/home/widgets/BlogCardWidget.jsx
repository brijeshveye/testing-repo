import React from 'react'
import { Link } from 'react-router-dom'

const BlogCardWidget = (props) => {

    return (
        <div className="br-item">
            <div className="news-info">
                <figure className="news-img">
                    <Link to={props.link}>
                    <img src={props.image || '/assets/img/placeholder.png'} alt="news imag" />
                    </Link>
                    {/* <a href="#">
                        <img src={props.image} alt="news imag" />
                    </a> */}
                </figure>
                <div className="detail">
                    <label>{props.date} - <a href="#">{props.category}</a></label>
                    <h3><Link to={props.link}> {props.title} </Link>
                    {/* <a href="#">{props.title}</a> */}
                    </h3>
                    <div className="more-info">
                        {/* <a href="#">{props.readMoreLink ?? 'Read More'}<span></span></a> */}
                        <Link to={props.link}>{props.readMoreLink ?? 'Read More'}<span></span></Link>
                    </div>
                </div>
            </div>
        </div>
    )
}

BlogCardWidget.defaultProps = {
    title: 'Blog Card Widget',
    description: 'This is a blog card widget component that displays a blog post with an image, title, date, and a link to read more.',
    image: 'assets/img/blog/5.jpg',
    date: 'July 30, 2025',
    category: 'Marketing',
    readMoreLink: 'Read More',
    link: '#'
}

export default BlogCardWidget