import React from 'react'

const TestimonialWidget = (props) => {
    const starCount = Math.max(1, Math.min(5, parseInt(props.stars) || 5)); // Ensure stars is between 1-5
    
    return (
        <>
            <div className="testimonial-box">
                <div className="icon">
                    <i className="fas fa-quote-left"></i>
                </div>
                <div className="testimonial-text">
                    <div className="d-flex star-box">
                        {[...Array(starCount)].map((_, index) => (
                            <i key={index} className="bi bi-star-fill text-warning"></i>
                        ))}
                        {/* Show empty stars for remaining */}
                        {[...Array(5 - starCount)].map((_, index) => (
                            <i key={`empty-${index}`} className="bi bi-star text-muted"></i>
                        ))}
                    </div>
                    <h6>{props.customerPosition}</h6>
                    <p>{props.customerFeedback}</p>
                    <div className="d-flex align-items-center justify-content-center gap-3 mt-3">
                        {props.customerImage && (
                            <img 
                                src={props.customerImage || '/assets/img/placeholder.png' } 
                                alt={props.customerName}
                                className="rounded-circle"
                                style={{ width: '40px', height: '40px', objectFit: 'cover' }}
                            />
                        )}
                        <h5 className="mb-0">{props.customerName}</h5>
                    </div>
                </div>
            </div>
        </>
    )
}

TestimonialWidget.defaultProps = {
    stars: 5,
    customerName: 'pxdraft',
    customerFeedback: 'This is an amazing product! I highly recommend it to everyone.',
    customerPosition: 'CEO, Company Name',
    customerImage: null
}

export default TestimonialWidget