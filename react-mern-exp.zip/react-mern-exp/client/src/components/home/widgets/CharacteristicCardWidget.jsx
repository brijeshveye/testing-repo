import React, { useState } from 'react'

const CharacteristicCardWidget = (props) => {
    const [imageError, setImageError] = useState(false);
    
    return (
        <>
            <div className="col-lg-3 col-md-6 col-xs-12">
                <div className="flipper">
                    <div className="main-box">
                        <div className="box-front height-300 white-bg">
                            <div className="content-wrap">
                                <div className="icon br-icon">
                                    {/* Support both image/SVG uploads and icon classes */}
                                    {props.image && !imageError ? (
                                        <img 
                                            className="icofont icofont-headphone-alt font-40px dark-color svg_img" 
                                            src={props.image} 
                                            alt={props.title}
                                            style={{
                                                width: '40px',
                                                height: '40px',
                                                objectFit: 'contain'
                                            }}
                                            onError={() => {
                                                console.warn('Image failed to load for characteristic:', props.title);
                                                setImageError(true);
                                            }}
                                            onLoad={() => setImageError(false)}
                                        />
                                    ) : props.image && imageError ? (
                                        <i className="fas fa-image font-40px dark-color" title="Image failed to load"></i>
                                    ) : props.icon ? (
                                        <i className={`${props.icon} font-40px dark-color`}></i>
                                    ) : (
                                        <i className="fas fa-star font-40px dark-color"></i>
                                    )}
                                </div>
                                <h3>{props.title}</h3>
                                <p>{props.description}</p>
                            </div>
                        </div>
                        <div className="box-back height-300 gradient-bg">
                            <div className="content-wrap">
                                <h3>{props.backTitle}</h3>
                                <p>{props.backDescription}</p>
                                <a href={props.link} className="btn">Read more</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

CharacteristicCardWidget.propTypes = {
    "title": "My Service",
    "description": "This is a service card widget.",
    "icon": "fas fa-star", // Icon class (FontAwesome, Bootstrap Icons, etc.)
    "image": "/uploads/characteristics/icon.svg", // Image/SVG upload URL
    "link": "#",
    "backTitle": "Graphics Design",
    "backDescription": "Develop the Visual Identity of Your Business",
}

export default CharacteristicCardWidget