import React from 'react'
import { Link } from 'react-router-dom'

const ProjectCardWidget = (props) => {
    return (
        <>
            <div className={`col-lg-12 mix ${props.category}`}>
                <div className="br-project-box">
                    <Link to={props.url} className="br-project-title">
                        <h3>{props.title}</h3>
                    </Link>
                    <div className="links">
                        {
                             (props.domains.length === 1) ? (
                                <a href={props.domains[0].url} key={props.domains[0].title}>
                                    {props.domains[0].title}
                                </a>
                            ) : (props.domains.length > 1) ? (
                                props.domains.map((domain, index) => (
                                    <React.Fragment key={`${domain.title}-${index}`}>
                                        {index > 0 && " | "}
                                        <a href={domain.url}>
                                            {domain.title}
                                        </a>
                                    </React.Fragment>
                                ))
                            ) : null
                        }
                    </div>
                    <p>
                        {props.description}
                        <Link to={props.url} className="read-more">
                            Read more
                        </Link>
                    </p>
                    <div className="br-info">
                        <div className="portfolio-img">
                            <a className="" data-fancybox="gallery"
                                href={props.image}
                                style={{ backgroundImage: `url(${props.image})` }}>
                                <span className="overlay">+</span>
                            </a>
                        </div>
                        <div className="br-detail">
                            <ul>
                                <li>Date : {props.date}</li>
                                <li>Client : {props.client}</li>
                                <li>Tech : {
                                    props.techStack.map((tech, index) => (
                                        <span key={index} className="tech-item">{tech}, </span>
                                    ))
                                    }
                                </li>
                                <li>Type : {props.type}</li>
                                <li>URL : <Link to={props.url} className="click-here">Click Here</Link></li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

ProjectCardWidget.defaultProps = {
    title: 'Project Card Widget',
    description: 'This is a project card widget component that displays a project with details such as title, description, and links.',
    domains: [
        { title: 'Design', url: '#' }
    ],
    image: 'assets/img/portfolio/2.jpg',
    date: 'March 15, 2022',
    client: 'BR Media',
    techStack: 'React, Nodejs, Android',
    type: 'Entertainment',
    url: 'www.your-project-url.com',
    category: 'design'
}

export default ProjectCardWidget