import React from 'react'

const MarqueeSection = () => {
    return (
        <>
            <div className="marquee-wrapper text-slider" id="sers">
                <div className="marquee-inner to-left">
                    <ul className="marqee-list d-flex">
                        <li className="marquee-item">
                            <span>Soch Se SoftwareTak</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Code Flow</span> <span className="base">*</span>
                            <span>Freelance Fuel</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Tech Vibes</span> <span className="base">*</span>
                            <span>Live To Debug</span> <span className="basee">*</span> <span className="stroke-text">
                                </span><span>Design. Code. Repeat</span> <span className="base">*</span>
                            <span>From Mind to Machine</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Deploy The Dream </span> <span className="base">*</span>
                            <span>Syntax & Soul</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Code You Can Feel</span> <span className="base">*</span>
                            <span>Debug & Deliver</span> <span className="basee">*</span> <span
                                className="stroke-text"></span><span>Live To Debug </span> <span className="base">*</span>
                        </li>
                    </ul>
                </div>
            </div>
        </>
    )
}

export default MarqueeSection