import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import ExperienceDataApi from '../../api/ExperienceDataApi';
import ExperienceCardWidget from './widgets/ExperienceCardWidget';

const MyExperienceSection = () => {

    const aosDelay = 200;
    const [experienceData, setExperienceData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchExperienceData();
    }, []);

    const fetchExperienceData = async () => {
        try {
            setLoading(true);
            const data = await ExperienceDataApi.getExperienceForHome(4); // Get top 4 for home
            setExperienceData(data);
        } catch (error) {
            console.error('Error fetching experience data:', error);
        } finally {
            setLoading(false);
        }
    };

    const formatDuration = (startDate, endDate, current) => {
        if (!startDate) return 'Duration not specified';
        
        const start = new Date(startDate);
        const startMonth = start.toLocaleDateString('en-US', { month: 'short' });
        const startYear = start.getFullYear();
        
        if (current) {
            return `${startMonth} ${startYear} - Present`;
        }
        
        if (!endDate) {
            return `${startMonth} ${startYear} - Present`;
        }
        
        const end = new Date(endDate);
        const endMonth = end.toLocaleDateString('en-US', { month: 'short' });
        const endYear = end.getFullYear();
        
        return `${startMonth} ${startYear} - ${endMonth} ${endYear}`;
    };

    return (
        <>
            <section id="experience" className="br-experience padding-tb-80 br-bg1-img">
                <div className="container">
                    <div className="row">
                        <div className="section-title">
                            <h2>My <span>Corporate Journey</span></h2>
                            <span className="ligh-title">Driven by Growth</span>
                        </div>
                        <div className="col-lg-6 col-md-12 col-sm-12">
                            <div className="education br-ex-box m-b-991">
                                <div className="about__onethumb aos-init aos-animate" data-aos="zoom-out-down" data-aos-duration="1000">
                                    <img alt="img" src="assets/img/cart/t4.png" />
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 col-md-12 col-sm-12">
                            <div className="experiense br-ex-box">
                                <h4>Experience</h4>
                                {loading ? (
                                    <div className="text-center">
                                        <div className="spinner-border text-primary" role="status">
                                            <span className="visually-hidden">Loading...</span>
                                        </div>
                                    </div>
                                ) : (
                                    <ul className="timeline">
                                        {experienceData.map((item, index) => (
                                            <ExperienceCardWidget
                                                key={item._id || index}
                                                duration={formatDuration(item.startDate, item.endDate, item.current)}
                                                company={item.company}
                                                role={item.title}
                                                description={item.description || `${item.title} at ${item.company}`}
                                                aosDelay={aosDelay + (index * aosDelay)}
                                            />
                                        ))}
                                    </ul>
                                )}
                            </div>
                            
                            {/* View All Experience Button */}
                            {experienceData.length > 0 && (
                                <div className="text-center mt-4">
                                    <Link to="/experience" className="px-btn px-btn-primary">
                                        <span>View All Experience</span>
                                        <i className="fas fa-arrow-right ms-2"></i>
                                    </Link>
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </section>
        </>
    )
}

export default MyExperienceSection