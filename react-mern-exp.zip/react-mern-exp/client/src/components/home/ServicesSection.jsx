import React, { useEffect, useState } from 'react'
import ServiceCardWidget from './widgets/ServiceCardWidget';
import UserDataApi from '../../api/UserDataApi';

const ServicesSection = () => {
    const [serviceData, setServiceData] = useState([]);

    useEffect(() => {
        setServiceData(UserDataApi.getCharacteristics());

    }, []);


    return (
        <>
            <section id="service" className="br-service padding-tb-80 sec-bg">
                <div className="container">
                    <div className="section-title d-none">
                        <h2>My<span> service</span></h2>
                        <span className="ligh-title">service</span>
                    </div>
                    <div className="row service-box m-tb-minus-15px">

                        {
                            serviceData.map((service, index) => (
                                <ServiceCardWidget
                                    key={index}
                                    title={service.title}
                                    description={service.description}
                                    icon={service.icon}
                                    link={service.link}
                                    backTitle={service.backTitle}
                                    backDescription={service.backDescription}
                                />
                            ))
                        }


                    </div>
                </div>
            </section>
        </>
    )
}

export default ServicesSection