import React, { useEffect } from 'react'
import { Link } from 'react-router-dom';
import TestimonialsDataApi from '../../api/TestimonialsDataApi';
import TestimonialWidget from './widgets/TestimonialWidget';
import Slider from "react-slick";

const TestimonialsSection = () => {

    const [testimonialsData, setTestimonialsData] = React.useState([]);
    const [loading, setLoading] = React.useState(true);

    useEffect(() => {
        fetchTestimonials();
    }, []);

    const fetchTestimonials = async () => {
        try {
            const data = await TestimonialsDataApi.getTestimonialsForHome(5);
            setTestimonialsData(data);
        } catch (error) {
            console.error('Error fetching testimonials:', error);
        } finally {
            setLoading(false);
        }
    };

    const settings = {
        dots: false,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 5000,
        arrows: true
    };

    return (
        <>
            <section className="section testimonial-section bg-no-repeat bg-center"
                style={{ backgroundPosition: "center 125%", backgroundImage: `url(assets/img/bg-1.png)` }}>
                <div className="container">
                    <div className="section-heading">
                        <h3>What people say about me?</h3>
                    </div>

                    {loading ? (
                        <div className="text-center py-5">
                            <div className="spinner-border" role="status">
                                <span className="visually-hidden">Loading...</span>
                            </div>
                        </div>
                    ) : testimonialsData.length > 0 ? (
                        <Slider {...settings}>
                            {testimonialsData.map((testimonial, index) => (
                                <TestimonialWidget
                                    key={testimonial._id || index}
                                    stars={testimonial.rating || testimonial.stars || 5}
                                    customerName={testimonial.customerName}
                                    customerFeedback={testimonial.customerFeedback}
                                    customerPosition={testimonial.designation || testimonial.customerPosition || testimonial.company}
                                    customerImage={testimonial.customerImage}
                                />
                            ))}
                        </Slider>
                    ) : (
                        <div className="text-center py-5">
                            <p className="text-muted">No testimonials available at the moment.</p>
                        </div>
                    )}
                    
                    {/* View All Testimonials Button */}
                    {/* <div className="row mt-4">
                        <div className="col-12 text-center">
                            <Link to="/testimonials" className="px-btn px-btn-primary">
                                <span>View All Testimonials</span>
                                <i className="fas fa-arrow-right ms-2"></i>
                            </Link>
                        </div>
                    </div> */}
                </div>
            </section>
        </>
    )
}

export default TestimonialsSection