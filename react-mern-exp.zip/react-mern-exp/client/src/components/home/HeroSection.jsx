import React, { useEffect, useRef } from 'react'
import TypeIt from 'typeit-react';

const HeroSection = () => {

    return (
        <>
            <section id="home" data-scroll-index="0" className="home-section" style={{ backgroundImage: `url(/assets/img/bg.jpg)` }}>
                <div className="container">
                    <div className="home-intro-box">
                        <div className="user-text">
                            <h6><img src="assets/img/hend.png" title="Hands Image" alt="Hands Image" /> Hello, I am</h6>
                            <h1>Good</h1>
                            <h2>Nice <TypeIt id="type-it"
                            options={{
                                        strings: ["Thinking", "Good", "Going", "Working", "UI"],
                                        speed: 150,
                                        loop: true,
                                        breakLines: false,
                                        deleteSpeed: 100,
                                        nextStringDelay: 1000,
                                    }}
                            ></TypeIt></h2>
                        </div>
                        <div className="user-review">
                            <div className="d-flex star-box">
                                {['bi bi-lightbulb', 'bi bi-code-slash', 'bi bi-magic', 'bi bi-star'].map((_, i) => (
                                    <i key={`star-${i}`} className={_} style={{ color: '#f39c12' }}></i>
                                ))}
                            </div>
                            <p>Nice Thinking — and code into magic</p>
                            <h6>Thanks</h6>
                        </div>
                        <div className="user-img">
                            <div className="user-img-round"></div>
                            <img src="assets/img/image.png" title="hero Image" alt="Hero Image" />
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default HeroSection