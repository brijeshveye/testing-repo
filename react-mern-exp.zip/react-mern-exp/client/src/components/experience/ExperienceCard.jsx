import React from 'react';

const ExperienceCard = ({ experience, onEdit, onDelete, onToggleFeatured, onToggleActive, showActions = true }) => {
  const formatDate = (date) => {
    if (!date) return 'Present';
    return new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  const getDuration = (startDate, endDate, current) => {
    const start = formatDate(startDate);
    const end = current ? 'Present' : formatDate(endDate);
    return `${start} - ${end}`;
  };

  return (
    <div className="col-12 col-md-6 col-lg-4">
      <div 
        className="card border-0 shadow-sm h-100" 
        style={{ 
          borderRadius: '16px',
          transition: 'transform 0.2s ease, box-shadow 0.2s ease'
        }}
        onMouseEnter={(e) => {
          e.currentTarget.style.transform = 'translateY(-4px)';
          e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)';
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'translateY(0)';
          e.currentTarget.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
        }}
      >
        {/* Company Logo Section */}
        {experience.companyLogo && (
          <div 
            className="card-img-top d-flex justify-content-center align-items-center p-4" 
            style={{ 
              height: '120px',
              backgroundColor: '#f8f9fa',
              borderRadius: '16px 16px 0 0'
            }}
          >
            <img 
              src={experience.companyLogo} 
              alt={experience.company}
              className="img-fluid rounded"
              style={{ maxHeight: '80px', maxWidth: '100%', objectFit: 'contain' }}
            />
          </div>
        )}
        
        <div className="card-body d-flex flex-column p-4">
          {/* Header Section */}
          <div className="d-flex justify-content-between align-items-start mb-3">
            <div className="flex-grow-1">
              <h5 className="card-title mb-1 fw-bold" style={{ color: '#2c3e50', lineHeight: '1.3' }}>
                {experience.title}
              </h5>
              <h6 className="card-subtitle text-primary fw-medium mb-0">
                <i className="fas fa-building me-2"></i>
                {experience.company}
              </h6>
            </div>
            <div className="d-flex flex-column gap-1 align-items-end">
              {experience.featured && (
                <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: '#fff3e0', color: '#ffa000' }}>
                  <i className="fas fa-star me-1"></i>Featured
                </span>
              )}
              {experience.current && (
                <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: '#e8f5e8', color: '#2e7d32' }}>
                  <i className="fas fa-circle me-1" style={{ fontSize: '8px' }}></i>Current
                </span>
              )}
              {!experience.isActive && (
                <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: '#f5f5f5', color: '#6c757d' }}>
                  <i className="fas fa-eye-slash me-1"></i>Hidden
                </span>
              )}
            </div>
          </div>
          
          {/* Date and Location Info */}
          <div className="mb-3">
            <div className="d-flex align-items-center mb-1">
              <div 
                className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                style={{ width: '24px', height: '24px', backgroundColor: '#e3f2fd' }}
              >
                <i className="fas fa-calendar text-primary" style={{ fontSize: '10px' }}></i>
              </div>
              <small className="text-muted fw-medium">
                {getDuration(experience.startDate, experience.endDate, experience.current)}
              </small>
            </div>
            {experience.location && (
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                  style={{ width: '24px', height: '24px', backgroundColor: '#f3e5f5' }}
                >
                  <i className="fas fa-map-marker-alt text-secondary" style={{ fontSize: '10px' }}></i>
                </div>
                <small className="text-muted fw-medium">{experience.location}</small>
              </div>
            )}
          </div>

          {/* Employment Type and Industry Badges */}
          <div className="mb-3">
            <span 
              className="badge rounded-pill px-3 py-1 me-2 fw-medium"
              style={{ 
                backgroundColor: '#e1f5fe', 
                color: '#0277bd',
                fontSize: '0.75rem'
              }}
            >
              {experience.employmentType}
            </span>
            {experience.industry && (
              <span 
                className="badge rounded-pill px-3 py-1 fw-medium"
                style={{ 
                  backgroundColor: '#f3e5f5', 
                  color: '#7b1fa2',
                  fontSize: '0.75rem'
                }}
              >
                {experience.industry}
              </span>
            )}
          </div>
          
          {/* Description */}
          {experience.description && (
            <p className="card-text text-muted mb-3" style={{ fontSize: '0.9rem', lineHeight: '1.5' }}>
              {experience.description.length > 120 
                ? `${experience.description.substring(0, 120)}...` 
                : experience.description
              }
            </p>
          )}

          {/* Key Responsibilities */}
          {experience.responsibilities && experience.responsibilities.length > 0 && (
            <div className="mb-3">
              <h6 className="fw-bold mb-2" style={{ color: '#2c3e50', fontSize: '0.85rem' }}>
                <i className="fas fa-tasks me-2 text-primary"></i>Key Responsibilities
              </h6>
              <div className="ps-3">
                {experience.responsibilities.slice(0, 2).map((resp, index) => (
                  <div key={index} className="d-flex align-items-start mb-1">
                    <div 
                      className="rounded-circle me-2 mt-1 flex-shrink-0"
                      style={{ 
                        width: '6px', 
                        height: '6px', 
                        backgroundColor: '#2e7d32' 
                      }}
                    ></div>
                    <small className="text-muted" style={{ fontSize: '0.8rem' }}>
                      {resp.length > 70 ? `${resp.substring(0, 70)}...` : resp}
                    </small>
                  </div>
                ))}
                {experience.responsibilities.length > 2 && (
                  <small className="text-muted fst-italic" style={{ fontSize: '0.75rem' }}>
                    +{experience.responsibilities.length - 2} more responsibilities...
                  </small>
                )}
              </div>
            </div>
          )}

          {/* Skills */}
          {experience.skills && experience.skills.length > 0 && (
            <div className="mb-3">
              <h6 className="fw-bold mb-2" style={{ color: '#2c3e50', fontSize: '0.85rem' }}>
                <i className="fas fa-cogs me-2 text-success"></i>Skills Used
              </h6>
              <div className="d-flex flex-wrap gap-1">
                {experience.skills.slice(0, 5).map((skill, index) => (
                  <span 
                    key={index} 
                    className="badge rounded-pill px-2 py-1"
                    style={{ 
                      backgroundColor: '#e8f5e8', 
                      color: '#2e7d32',
                      fontSize: '0.7rem',
                      fontWeight: '500'
                    }}
                  >
                    {skill}
                  </span>
                ))}
                {experience.skills.length > 5 && (
                  <span 
                    className="badge rounded-pill px-2 py-1"
                    style={{ 
                      backgroundColor: '#f5f5f5', 
                      color: '#6c757d',
                      fontSize: '0.7rem'
                    }}
                  >
                    +{experience.skills.length - 5}
                  </span>
                )}
              </div>
            </div>
          )}
          
          {/* Action Buttons */}
          {showActions && (
            <div className="mt-auto pt-3">
              <div 
                className="p-3 rounded-3"
                style={{ backgroundColor: '#f8f9fa' }}
              >
                <div className="d-flex justify-content-between align-items-center">
                  <div className="btn-group" role="group">
                    <button
                      className="btn btn-outline-primary btn-sm rounded-pill px-3"
                      onClick={() => onEdit(experience)}
                      title="Edit Experience"
                      style={{ fontSize: '0.8rem' }}
                    >
                      <i className="fas fa-edit me-1"></i>Edit
                    </button>
                    <button
                      className={`btn btn-sm rounded-pill px-2 ms-1 ${
                        experience.featured 
                          ? 'btn-warning text-white' 
                          : 'btn-outline-warning'
                      }`}
                      onClick={() => onToggleFeatured(experience.slug)}
                      title="Toggle Featured"
                    >
                      <i className="fas fa-star"></i>
                    </button>
                    <button
                      className={`btn btn-sm rounded-pill px-2 ms-1 ${
                        experience.isActive 
                          ? 'btn-success text-white' 
                          : 'btn-outline-success'
                      }`}
                      onClick={() => onToggleActive(experience.slug)}
                      title="Toggle Visibility"
                    >
                      <i className={`fas ${experience.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                    </button>
                  </div>
                  <button
                    className="btn btn-outline-danger btn-sm rounded-pill px-2"
                    onClick={() => onDelete(experience)}
                    title="Delete Experience"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExperienceCard;
