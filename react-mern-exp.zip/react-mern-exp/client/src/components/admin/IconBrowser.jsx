import React, { useState } from 'react';

const IconBrowser = ({ onSelectIcon, currentIcon }) => {
  const [showBrowser, setShowBrowser] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Popular FontAwesome icons categorized
  const iconCategories = {
    'General': [
      'fas fa-star', 'fas fa-heart', 'fas fa-thumbs-up', 'fas fa-check',
      'fas fa-times', 'fas fa-plus', 'fas fa-minus', 'fas fa-info',
      'fas fa-exclamation', 'fas fa-question', 'fas fa-bell', 'fas fa-flag'
    ],
    'Technology': [
      'fas fa-code', 'fas fa-laptop', 'fas fa-mobile-alt', 'fas fa-desktop',
      'fas fa-server', 'fas fa-database', 'fas fa-wifi', 'fas fa-microchip',
      'fab fa-html5', 'fab fa-css3-alt', 'fab fa-js-square', 'fab fa-react',
      'fab fa-node-js', 'fab fa-python', 'fab fa-github', 'fab fa-docker'
    ],
    'Business': [
      'fas fa-briefcase', 'fas fa-chart-line', 'fas fa-chart-bar', 'fas fa-chart-pie',
      'fas fa-handshake', 'fas fa-building', 'fas fa-users', 'fas fa-user-tie',
      'fas fa-bullseye', 'fas fa-lightbulb', 'fas fa-rocket', 'fas fa-trophy'
    ],
    'Communication': [
      'fas fa-comments', 'fas fa-comment', 'fas fa-phone', 'fas fa-envelope',
      'fas fa-microphone', 'fas fa-bullhorn', 'fas fa-broadcast-tower', 'fas fa-satellite-dish',
      'fab fa-twitter', 'fab fa-facebook', 'fab fa-linkedin', 'fab fa-instagram'
    ],
    'Education': [
      'fas fa-graduation-cap', 'fas fa-book', 'fas fa-bookmark', 'fas fa-pencil-alt',
      'fas fa-chalkboard-teacher', 'fas fa-university', 'fas fa-award', 'fas fa-certificate'
    ],
    'Creative': [
      'fas fa-palette', 'fas fa-paint-brush', 'fas fa-camera', 'fas fa-video',
      'fas fa-music', 'fas fa-headphones', 'fas fa-film', 'fas fa-theater-masks',
      'fab fa-adobe', 'fab fa-figma', 'fab fa-sketch'
    ]
  };

  const allIcons = Object.values(iconCategories).flat();

  const filteredIcons = searchTerm 
    ? allIcons.filter(icon => 
        icon.toLowerCase().includes(searchTerm.toLowerCase()) ||
        icon.split(' ')[1]?.includes(searchTerm.toLowerCase())
      )
    : allIcons;

  const handleSelectIcon = (iconClass) => {
    onSelectIcon(iconClass);
    setShowBrowser(false);
  };

  return (
    <div className="position-relative">
      <div className="d-flex gap-2 align-items-center">
        <button
          type="button"
          className="btn btn-outline-secondary btn-sm"
          onClick={() => setShowBrowser(!showBrowser)}
        >
          <i className="fas fa-search me-1"></i>
          Browse Icons
        </button>
        {currentIcon && (
          <div className="d-flex align-items-center gap-2">
            <i className={currentIcon}></i>
            <small className="text-muted">{currentIcon}</small>
          </div>
        )}
      </div>

      {showBrowser && (
        <div className="icon-browser-modal">
          <div className="icon-browser-content">
            <div className="icon-browser-header">
              <h6 className="mb-0">Choose an Icon</h6>
              <button
                type="button"
                className="btn btn-sm btn-outline-secondary"
                onClick={() => setShowBrowser(false)}
              >
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="icon-browser-body">
              <div className="mb-3">
                <input
                  type="text"
                  className="form-control form-control-sm"
                  placeholder="Search icons..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              {!searchTerm ? (
                // Show categorized icons
                Object.entries(iconCategories).map(([category, icons]) => (
                  <div key={category} className="mb-3">
                    <h6 className="text-muted small mb-2">{category}</h6>
                    <div className="icon-grid">
                      {icons.map((iconClass) => (
                        <button
                          key={iconClass}
                          type="button"
                          className={`icon-option ${currentIcon === iconClass ? 'selected' : ''}`}
                          onClick={() => handleSelectIcon(iconClass)}
                          title={iconClass}
                        >
                          <i className={iconClass}></i>
                        </button>
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                // Show search results
                <div className="icon-grid">
                  {filteredIcons.length > 0 ? (
                    filteredIcons.map((iconClass) => (
                      <button
                        key={iconClass}
                        type="button"
                        className={`icon-option ${currentIcon === iconClass ? 'selected' : ''}`}
                        onClick={() => handleSelectIcon(iconClass)}
                        title={iconClass}
                      >
                        <i className={iconClass}></i>
                      </button>
                    ))
                  ) : (
                    <div className="text-center text-muted py-3">
                      <i className="fas fa-search fa-2x mb-2"></i>
                      <p>No icons found for "{searchTerm}"</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .icon-browser-modal {
          position: absolute;
          top: 100%;
          left: 0;
          right: 0;
          z-index: 1050;
          background: white;
          border: 1px solid #dee2e6;
          border-radius: 8px;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
          max-height: 400px;
          overflow: hidden;
        }

        .icon-browser-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 0.75rem;
          border-bottom: 1px solid #dee2e6;
          background: #f8f9fa;
        }

        .icon-browser-body {
          padding: 0.75rem;
          max-height: 320px;
          overflow-y: auto;
        }

        .icon-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(40px, 1fr));
          gap: 0.5rem;
        }

        .icon-option {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 40px;
          height: 40px;
          border: 1px solid #dee2e6;
          border-radius: 6px;
          background: white;
          color: #495057;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .icon-option:hover {
          background: #f8f9fa;
          border-color: #007bff;
          color: #007bff;
          transform: scale(1.1);
        }

        .icon-option.selected {
          background: #007bff;
          border-color: #007bff;
          color: white;
        }

        .icon-option i {
          font-size: 1.1rem;
        }

        @media (max-width: 768px) {
          .icon-browser-modal {
            position: fixed;
            top: 50%;
            left: 50%;
            right: auto;
            transform: translate(-50%, -50%);
            width: 90vw;
            max-width: 400px;
          }
        }
      `}</style>
    </div>
  );
};

export default IconBrowser;
