import React from 'react'

const ProjectInfoWidget = (props) => {
    return (
        <>
            <div className="prot__itembox">
                <div className="prot__left">
                    <div className="items mb__cus30">
                        <h5>
                            Clients
                        </h5>
                        <p>
                            {props.client}
                        </p>
                    </div>
                    <div className="items">
                        <h5>
                            Date
                        </h5>
                        <p>
                            {props.date}
                        </p>
                    </div>
                </div>
                <div className="prot__left">
                    <div className="items mb__cus30">
                        <h5>
                            Category
                        </h5>
                        <p>
                            {props.category}
                        </p>
                    </div>
                    <div className="items">
                        <h5>
                            Location
                        </h5>
                        <p>
                            {props.location}
                        </p>
                    </div>
                </div>
            </div>
            <ul className="social d-flex gap-3">
                <li>
                    <a href="javascript:void(0)">
                        <i className="bi bi-facebook"></i>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <i className="bi bi-twitter"></i>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <i className="bi bi-linkedin"></i>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)">
                        <i className="bi bi-youtube"></i>
                    </a>
                </li>
            </ul>
        </>
    )
}

ProjectInfoWidget.defaultProps = {
    client: 'Default Client',
    date: '2023-01-01',
    category: 'Default Category',
    location: 'Default Location'
}

export default ProjectInfoWidget