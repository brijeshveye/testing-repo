import React from 'react';

const ServiceCard = ({ service, onEdit, onDelete, onToggleFeatured, onToggleActive, showActions = true }) => {
  const formatPrice = (pricing) => {
    if (!pricing || !pricing.startingPrice) return 'Contact for pricing';
    
    const { startingPrice, currency, pricingModel } = pricing;
    const currencySymbol = currency === 'USD' ? '$' : currency;
    
    switch (pricingModel) {
      case 'hourly':
        return `${currencySymbol}${startingPrice}/hour`;
      case 'monthly':
        return `${currencySymbol}${startingPrice}/month`;
      case 'fixed':
        return `Starting at ${currencySymbol}${startingPrice}`;
      default:
        return 'Contact for pricing';
    }
  };

  return (
    <div className="col-lg-4 col-md-6 mb-4">
      <div className="card h-100 border-0 rounded-4 shadow-sm" 
           style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)', overflow: 'hidden' }}>
        {service.image && (
          <div className="position-relative" style={{ height: '200px', overflow: 'hidden' }}>
            <img 
              src={service.image} 
              alt={service.title}
              className="img-fluid w-100 h-100"
              style={{ objectFit: 'cover' }}
            />
            <div className="position-absolute top-0 end-0 m-3">
              <div className="d-flex flex-column gap-1">
                {service.featured && (
                  <span className="badge rounded-pill px-3 py-2" 
                        style={{ backgroundColor: '#f59e0b', color: 'white', fontSize: '0.75rem' }}>
                    <i className="fas fa-star me-1"></i>Featured
                  </span>
                )}
                {!service.isActive && (
                  <span className="badge rounded-pill px-3 py-2" 
                        style={{ backgroundColor: '#6b7280', color: 'white', fontSize: '0.75rem' }}>
                    <i className="fas fa-eye-slash me-1"></i>Hidden
                  </span>
                )}
              </div>
            </div>
          </div>
        )}
        
        <div className="card-body d-flex flex-column p-4">
          <div className="mb-3">
            <div className="d-flex justify-content-between align-items-start mb-2">
              <h5 className="card-title text-dark mb-0 fw-bold">{service.title}</h5>
              {!service.image && (
                <div className="d-flex gap-1">
                  {service.featured && (
                    <span className="badge rounded-pill px-2 py-1" 
                          style={{ backgroundColor: '#f59e0b', color: 'white', fontSize: '0.7rem' }}>
                      <i className="fas fa-star"></i>
                    </span>
                  )}
                  {!service.isActive && (
                    <span className="badge rounded-pill px-2 py-1" 
                          style={{ backgroundColor: '#6b7280', color: 'white', fontSize: '0.7rem' }}>
                      <i className="fas fa-eye-slash"></i>
                    </span>
                  )}
                </div>
              )}
            </div>

            {service.category && (
              <span className="badge rounded-pill px-3 py-1 mb-2" 
                    style={{ backgroundColor: '#e5e7eb', color: '#374151', fontSize: '0.75rem' }}>
                <i className="fas fa-tag me-1"></i>{service.category}
              </span>
            )}
          </div>

          {service.iconClass && (
            <div className="text-center mb-3">
              <div className="rounded-circle mx-auto d-flex align-items-center justify-content-center" 
                   style={{ width: '60px', height: '60px', backgroundColor: '#f3f4f6' }}>
                <i className={`${service.iconClass} fa-2x text-primary`}></i>
              </div>
            </div>
          )}
          
          <p className="card-text text-muted mb-3" style={{ fontSize: '0.95rem', lineHeight: '1.5' }}>
            {service.shortDescription || service.description}
          </p>

          {service.technologies && service.technologies.length > 0 && (
            <div className="mb-3">
              <div className="d-flex align-items-center mb-2">
                <i className="fas fa-code text-primary me-2" style={{ fontSize: '0.875rem' }}></i>
                <small className="text-dark fw-semibold">Technologies</small>
              </div>
              <div className="d-flex flex-wrap gap-1">
                {service.technologies.slice(0, 4).map((tech, index) => (
                  <span key={index} 
                        className="badge rounded-pill px-2 py-1" 
                        style={{ backgroundColor: '#3b82f6', color: 'white', fontSize: '0.7rem' }}>
                    {tech}
                  </span>
                ))}
                {service.technologies.length > 4 && (
                  <span className="badge rounded-pill px-2 py-1" 
                        style={{ backgroundColor: '#6b7280', color: 'white', fontSize: '0.7rem' }}>
                    +{service.technologies.length - 4}
                  </span>
                )}
              </div>
            </div>
          )}

          {service.features && service.features.length > 0 && (
            <div className="mb-3">
              <div className="d-flex align-items-center mb-2">
                <i className="fas fa-list-check text-success me-2" style={{ fontSize: '0.875rem' }}></i>
                <small className="text-dark fw-semibold">Key Features</small>
              </div>
              <ul className="list-unstyled mb-0">
                {service.features.slice(0, 3).map((feature, index) => (
                  <li key={index} className="small mb-1 d-flex align-items-start">
                    <i className="fas fa-check-circle text-success me-2 mt-1" style={{ fontSize: '0.75rem' }}></i>
                    <span className="text-muted">{feature}</span>
                  </li>
                ))}
                {service.features.length > 3 && (
                  <li className="small text-muted">
                    <i className="fas fa-ellipsis-h me-2"></i>
                    +{service.features.length - 3} more features
                  </li>
                )}
              </ul>
            </div>
          )}

          <div className="mt-auto">
            {service.pricing && (
              <div className="mb-3 p-3 rounded-3" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0' }}>
                <div className="d-flex align-items-center justify-content-between">
                  <div>
                    <div className="h6 text-success mb-1 fw-bold">{formatPrice(service.pricing)}</div>
                    {service.deliveryTime && (
                      <small className="text-muted d-flex align-items-center">
                        <i className="fas fa-clock me-1"></i>
                        {service.deliveryTime}
                      </small>
                    )}
                  </div>
                  <i className="fas fa-dollar-sign text-success opacity-50"></i>
                </div>
              </div>
            )}

            {showActions && (
              <div className="pt-3" style={{ borderTop: '1px solid #e5e7eb' }}>
                <div className="d-flex justify-content-between align-items-center gap-2">
                  <div className="d-flex gap-1">
                    <button
                      className="btn btn-outline-primary btn-sm rounded-3 px-3"
                      onClick={() => onEdit(service)}
                      title="Edit Service"
                      style={{ fontSize: '0.8rem' }}
                    >
                      <i className="fas fa-edit me-1"></i>Edit
                    </button>
                    <button
                      className={`btn btn-sm rounded-3 px-2 ${
                        service.featured 
                          ? 'btn-warning text-white' 
                          : 'btn-outline-warning'
                      }`}
                      onClick={() => onToggleFeatured(service.slug)}
                      title="Toggle Featured"
                      style={{ fontSize: '0.8rem' }}
                    >
                      <i className="fas fa-star"></i>
                    </button>
                    <button
                      className={`btn btn-sm rounded-3 px-2 ${
                        service.isActive 
                          ? 'btn-success' 
                          : 'btn-outline-success'
                      }`}
                      onClick={() => onToggleActive(service.slug)}
                      title="Toggle Visibility"
                      style={{ fontSize: '0.8rem' }}
                    >
                      <i className={`fas ${service.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                    </button>
                  </div>
                  <button
                    className="btn btn-outline-danger btn-sm rounded-3 px-2"
                    onClick={() => onDelete(service)}
                    title="Delete Service"
                    style={{ fontSize: '0.8rem' }}
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
