import React from 'react';

const BlogWidgets = {
  // Heading Widget
  heading: ({ data }) => (
    <div className="text__box mb-30" data-aos="fade-up" data-aos-duration="1400">
      <h3 className="white" style={{ fontSize: data.size || '24px', color: data.color || 'inherit' }}>
        {data.text}
      </h3>
    </div>
  ),

  // Paragraph Widget
  paragraph: ({ data }) => (
    <div className="text__box mb-30" data-aos="fade-up" data-aos-duration="1400">
      <p className="fz-16 pra ttext__one" style={{ color: data.color || 'inherit' }}>
        {data.text}
      </p>
    </div>
  ),

  // List Widget
  list: ({ data }) => (
    <div className="text__box mb-30" data-aos="fade-up" data-aos-duration="1600">
      {data.title && (
        <h3 className="white mb-30">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra ttext__one mb-30">
          {data.description}
        </p>
      )}
      <ul className={data.listType === 'ordered' ? 'challenge__list ordered-list' : 'challenge__list'}>
        {data.items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  ),

  // Quote Widget (specific to blogs)
  quote: ({ data }) => (
    <div className="quite__box mb-30">
      <img src="/assets/img/blog/straight-quotes.png" alt="img" />
      <p>
        {data.text}
      </p>
      {data.author && (
        <a href="#0">
          {data.author}
        </a>
      )}
    </div>
  ),

  // Spacer Widget
  spacer: ({ data }) => (
    <div style={{ height: data.height || '20px' }} data-aos="fade-up" data-aos-duration="1200">
      {/* Spacer for layout */}
    </div>
  ),

  // Image Widget
  image: ({ data }) => (
    <div className="text__box mb-30" data-aos="fade-up" data-aos-duration="1800">
      {data.title && (
        <h3 className="white mb-30">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra ttext__one mb-30">
          {data.description}
        </p>
      )}
      {data.layout === 'side-by-side' && data.images?.length >= 2 ? (
        <div className="details__small">
          <div className="thumb">
            <img 
              src={data.images[0]} 
              alt={data.alt || 'Blog image'} 
              style={{ borderRadius: data.borderRadius || '0px' }}
            />
          </div>
          <div className="thumb">
            <img 
              src={data.images[1]} 
              alt={data.alt || 'Blog image'} 
              style={{ borderRadius: data.borderRadius || '0px' }}
            />
          </div>
        </div>
      ) : (
        <div className="thumb mb-30">
          <img 
            src={data.src || data.images?.[0]} 
            alt={data.alt || 'Blog image'} 
            style={{ 
              width: data.width || '100%', 
              borderRadius: data.borderRadius || '0px'
            }} 
          />
        </div>
      )}
      {data.caption && (
        <div className="image-caption text-center mt-2" style={{ fontSize: '14px', color: '#6c757d', fontStyle: 'italic' }}>
          {data.caption}
        </div>
      )}
    </div>
  ),

  // Video Widget (specific to blogs)
  video: ({ data }) => (
    <div className="paythumb position-relative mb-30" data-aos="fade-up" data-aos-duration="2000">
      {data.title && (
        <h3 className="white mb-30">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra ttext__one mb-30">
          {data.description}
        </p>
      )}
      <img src={data.image || data.src} alt={data.alt || 'Blog video thumbnail'} />
      <a href={data.videoUrl} className="video__80 video-btn">
        <i className="bi bi-play-fill"></i>
      </a>
    </div>
  ),

  // YouTube Widget
  youtube: ({ data }) => (
    <div className="text__box mb-30" data-aos="fade-up" data-aos-duration="2000">
      {data.title && (
        <h3 className="white mb-30">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra ttext__one mb-30">
          {data.description}
        </p>
      )}
      <div className="video-container mb-30" style={{ position: 'relative', paddingBottom: '56.25%', height: 0, overflow: 'hidden' }}>
        <iframe
          src={`https://www.youtube.com/embed/${data.videoId}`}
          title={data.title || 'Blog video'}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            border: 'none'
          }}
          allowFullScreen
        />
      </div>
    </div>
  )
};

export default BlogWidgets;
