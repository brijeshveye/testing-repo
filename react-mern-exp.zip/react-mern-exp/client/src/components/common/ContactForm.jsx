import React, { useState } from 'react';
import { showSuccess, showError } from '../utils/toastUtils';

const ContactForm = ({ className = '', buttonText = 'Send Message', variant = 'default' }) => {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });
    const [submitting, setSubmitting] = useState(false);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        // Validate form
        if (!formData.name.trim() || !formData.email.trim() || !formData.subject.trim() || !formData.message.trim()) {
            showError('Please fill in all fields');
            return;
        }

        // Validate email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(formData.email)) {
            showError('Please enter a valid email address');
            return;
        }

        setSubmitting(true);

        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });

            const result = await response.json();

            if (result.success) {
                showSuccess(result.message);
                // Reset form
                setFormData({
                    name: '',
                    email: '',
                    subject: '',
                    message: ''
                });
            } else {
                showError(result.message || 'Failed to send message');
            }
        } catch (error) {
            console.error('Error sending message:', error);
            showError('Failed to send message. Please try again later.');
        } finally {
            setSubmitting(false);
        }
    };

    // Render different variants
    if (variant === 'floating') {
        return (
            <form onSubmit={handleSubmit} className={className}>
                <div className="row">
                    <div className="col-md-6">
                        <div className="form-floating">
                            <input 
                                type="text" 
                                className="form-control" 
                                id="contact_name"
                                name="name"
                                value={formData.name}
                                onChange={handleInputChange}
                                placeholder="Your Name"
                                required
                            />
                            <label htmlFor="contact_name">Your Name</label>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="form-floating">
                            <input 
                                type="email" 
                                className="form-control" 
                                id="contact_email"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                placeholder="name@example.com"
                                required
                            />
                            <label htmlFor="contact_email">Email Address</label>
                        </div>
                    </div>
                    <div className="col-12">
                        <div className="form-floating">
                            <input 
                                type="text" 
                                className="form-control" 
                                id="contact_subject"
                                name="subject"
                                value={formData.subject}
                                onChange={handleInputChange}
                                placeholder="Subject"
                                required
                            />
                            <label htmlFor="contact_subject">Subject</label>
                        </div>
                    </div>
                    <div className="col-12">
                        <div className="form-floating">
                            <textarea 
                                className="form-control" 
                                placeholder="Leave a comment here"
                                id="contact_message" 
                                name="message"
                                value={formData.message}
                                onChange={handleInputChange}
                                style={{ height: "150px" }}
                                required
                            ></textarea>
                            <label htmlFor="contact_message">Your Message here</label>
                        </div>
                    </div>
                    <div className="col-12 btn-bar text-center">
                        <button 
                            type="submit" 
                            className="px-btn px-btn-primary"
                            disabled={submitting}
                        >
                            {submitting ? 'SENDING...' : buttonText.toUpperCase()}
                        </button>
                    </div>
                </div>
            </form>
        );
    }

    // Default variant
    return (
        <form onSubmit={handleSubmit} className={className}>
            <div className="row">
                <div className="col-md-12">
                    <div className="form-group">
                        <input 
                            type="text" 
                            className="form-control" 
                            name="name" 
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="Name"
                            required
                        />
                    </div>
                </div>
                <div className="col-md-12">
                    <div className="form-group">
                        <input 
                            type="email" 
                            className="form-control" 
                            name="email" 
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="Email"
                            required
                        />
                    </div>
                </div>
                <div className="col-md-12">
                    <input 
                        type="text" 
                        className="form-control" 
                        name="subject" 
                        value={formData.subject}
                        onChange={handleInputChange}
                        placeholder="Subject"
                        required
                    />
                </div>
            </div>
            <div className="col-md-12">
                <div className="form-group">
                    <textarea 
                        name="message" 
                        className="form-control" 
                        cols="30"
                        rows="4" 
                        value={formData.message}
                        onChange={handleInputChange}
                        placeholder="Message"
                        required
                    ></textarea>
                </div>
            </div>
            <div className="col-md-12">
                <div className="form-group">
                    <input 
                        type="submit" 
                        value={submitting ? "Sending..." : buttonText} 
                        className="cmn--btn base"
                        disabled={submitting}
                    />
                </div>
            </div>
        </form>
    );
};

export default ContactForm;
