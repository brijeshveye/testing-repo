import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import CertificatesDataApi from '../../api/CertificatesDataApi';
import { ImageUploader } from './ImageUpload';
import { showSuccess, showError } from '../../utils/toastUtils';

const CertificateForm = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(slug);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    issuer: '',
    year: new Date().getFullYear().toString(),
    image: '',
    url: '',
    category: 'General',
    credentialId: '',
    expiryDate: '',
    skills: [],
    featured: false,
    isActive: true
  });
  
  const [skillInput, setSkillInput] = useState('');
  const [loading, setLoading] = useState(false);

  const categories = [
    'General',
    'Web Development',
    'Programming',
    'Frameworks',
    'Cloud Computing',
    'Data Science',
    'Mobile Development',
    'UI/UX Design',
    'DevOps',
    'Cybersecurity',
    'Database',
    'Project Management'
  ];

  useEffect(() => {
    if (isEdit) {
      fetchCertificate();
    }
  }, [slug, isEdit]);

  const fetchCertificate = async () => {
    try {
      setLoading(true);
      const certificate = await CertificatesDataApi.getCertificateDetails(slug);
      if (certificate) {
        setFormData({
          title: certificate.title || '',
          description: certificate.description || '',
          issuer: certificate.issuer || '',
          year: certificate.year || new Date().getFullYear().toString(),
          image: certificate.image || '',
          url: certificate.url || '',
          category: certificate.category || 'General',
          credentialId: certificate.credentialId || '',
          expiryDate: certificate.expiryDate ? new Date(certificate.expiryDate).toISOString().split('T')[0] : '',
          skills: certificate.skills || [],
          featured: certificate.featured || false,
          isActive: certificate.isActive !== false
        });
      } else {
        showError('Certificate not found');
      }
    } catch (err) {
      showError('Failed to load certificate');
      console.error('Error fetching certificate:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleImageUpload = (imageUrl) => {
    setFormData(prev => ({
      ...prev,
      image: imageUrl
    }));
  };

  const handleAddSkill = () => {
    if (skillInput.trim() && !formData.skills.includes(skillInput.trim())) {
      setFormData(prev => ({
        ...prev,
        skills: [...prev.skills, skillInput.trim()]
      }));
      setSkillInput('');
    }
  };

  const handleRemoveSkill = (skillToRemove) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter(skill => skill !== skillToRemove)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.title.trim()) {
      showError('Certificate title is required');
      return;
    }
    if (!formData.description.trim()) {
      showError('Certificate description is required');
      return;
    }
    if (!formData.issuer.trim()) {
      showError('Issuer is required');
      return;
    }
    if (!formData.year.trim()) {
      showError('Year is required');
      return;
    }

    try {
      setLoading(true);

      const submitData = {
        ...formData,
        expiryDate: formData.expiryDate ? new Date(formData.expiryDate) : null
      };

      if (isEdit) {
        await CertificatesDataApi.updateCertificate(slug, submitData);
        showSuccess('Certificate updated successfully!');
      } else {
        await CertificatesDataApi.createCertificate(submitData);
        showSuccess('Certificate created successfully!');
      }

      // Redirect after a short delay
      setTimeout(() => {
        navigate('/admin/certificates');
      }, 1500);

    } catch (err) {
      showError(err.response?.data?.message || `Failed to ${isEdit ? 'update' : 'create'} certificate`);
      console.error('Error saving certificate:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
        <div className="row justify-content-center">
          <div className="col-12 col-xl-10">
            <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
              <div className="card-body py-5 text-center">
                <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
                  <span className="visually-hidden">Loading...</span>
                </div>
                <div className="mt-3">
                  <h5 className="text-muted">Loading certificate data...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-10">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: isEdit ? '#f57c00' : '#2e7d32',
                        color: 'white'
                      }}
                    >
                      <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'} fs-3`}></i>
                    </div>
                  </div>
                  <div>
                    <h2 className="mb-1 text-dark fw-bold">{isEdit ? 'Edit Certificate' : 'Create New Certificate'}</h2>
                    <p className="text-muted mb-0">{isEdit ? 'Update your certificate information and settings' : 'Add a new professional certificate to your portfolio'}</p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => navigate('/admin/certificates')}
                  className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                >
                  <i className="fas fa-arrow-left me-2"></i>Back to Certificates
                </button>
              </div>
            </div>
          </div>

          <div className="row g-4">
            {/* Main Form Card */}
            <div className="col-12 col-lg-8">
              <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
                <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-clipboard-list text-primary fs-5"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold text-dark">Certificate Information</h5>
                      <small className="text-muted">Fill in the details for your certificate</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">

                  <form onSubmit={handleSubmit}>
                    {/* Basic Information Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-info-circle text-primary me-2"></i>
                        Basic Information
                      </h6>
                      <div className="row">
                        <div className="col-md-8 mb-3">
                          <label htmlFor="title" className="form-label text-dark fw-medium">
                            Certificate Title <span className="text-danger">*</span>
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-lg border-2"
                            id="title"
                            name="title"
                            value={formData.title}
                            onChange={handleChange}
                            style={{ borderRadius: '12px' }}
                            placeholder="Enter certificate title"
                            required
                          />
                        </div>
                        
                        <div className="col-md-4 mb-3">
                          <label htmlFor="year" className="form-label text-dark fw-medium">
                            Year <span className="text-danger">*</span>
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-lg border-2"
                            id="year"
                            name="year"
                            value={formData.year}
                            onChange={handleChange}
                            style={{ borderRadius: '12px' }}
                            placeholder="2024"
                            required
                          />
                        </div>
                      </div>

                      <div className="mb-3">
                        <label htmlFor="description" className="form-label text-dark fw-medium">
                          Description <span className="text-danger">*</span>
                        </label>
                        <textarea
                          className="form-control form-control-lg border-2"
                          id="description"
                          name="description"
                          rows="4"
                          value={formData.description}
                          onChange={handleChange}
                          style={{ borderRadius: '12px' }}
                          placeholder="Brief description of the certificate..."
                          required
                        ></textarea>
                      </div>

                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label htmlFor="issuer" className="form-label text-dark fw-medium">
                            Issuing Organization <span className="text-danger">*</span>
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-lg border-2"
                            id="issuer"
                            name="issuer"
                            value={formData.issuer}
                            onChange={handleChange}
                            style={{ borderRadius: '12px' }}
                            placeholder="e.g., Google, Microsoft, AWS"
                            required
                          />
                        </div>
                        
                        <div className="col-md-6 mb-3">
                          <label htmlFor="category" className="form-label text-dark fw-medium">
                            Category
                          </label>
                          <select
                            className="form-select form-select-lg border-2"
                            id="category"
                            name="category"
                            value={formData.category}
                            onChange={handleChange}
                            style={{ borderRadius: '12px' }}
                          >
                            {categories.map(category => (
                              <option key={category} value={category}>{category}</option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Additional Details Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-cogs text-primary me-2"></i>
                        Additional Details
                      </h6>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <label htmlFor="url" className="form-label text-dark fw-medium">
                            Certificate URL
                          </label>
                          <input
                            type="url"
                            className="form-control form-control-lg border-2"
                            id="url"
                            name="url"
                            value={formData.url}
                            onChange={handleChange}
                            style={{ borderRadius: '12px' }}
                            placeholder="https://example.com/certificate/123"
                          />
                        </div>
                        
                        <div className="col-md-6 mb-3">
                          <label htmlFor="credentialId" className="form-label text-dark fw-medium">
                            Credential ID
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-lg border-2"
                            id="credentialId"
                            name="credentialId"
                            value={formData.credentialId}
                            onChange={handleChange}
                            style={{ borderRadius: '12px' }}
                            placeholder="Certificate ID or verification code"
                          />
                        </div>
                      </div>

                      <div className="mb-3">
                        <label htmlFor="expiryDate" className="form-label text-dark fw-medium">
                          Expiry Date (Optional)
                        </label>
                        <input
                          type="date"
                          className="form-control form-control-lg border-2"
                          id="expiryDate"
                          name="expiryDate"
                          value={formData.expiryDate}
                          onChange={handleChange}
                          style={{ borderRadius: '12px' }}
                        />
                        <div className="form-text">Leave empty if the certificate doesn't expire</div>
                      </div>
                    </div>

                    {/* Skills Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-code text-primary me-2"></i>
                        Skills (Optional)
                      </h6>
                      <div className="input-group mb-3">
                        <input
                          type="text"
                          className="form-control form-control-lg border-2"
                          value={skillInput}
                          onChange={(e) => setSkillInput(e.target.value)}
                          placeholder="Add a skill..."
                          style={{ borderRadius: '12px 0 0 12px' }}
                          onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddSkill())}
                        />
                        <button
                          type="button"
                          className="btn btn-primary px-4"
                          onClick={handleAddSkill}
                          style={{ borderRadius: '0 12px 12px 0' }}
                        >
                          <i className="fas fa-plus me-1"></i>Add
                        </button>
                      </div>
                      
                      {formData.skills.length > 0 && (
                        <div className="d-flex flex-wrap gap-2">
                          {formData.skills.map((skill, index) => (
                            <span key={`skill-${index}-${skill}`} className="badge bg-light text-dark fs-6 px-3 py-2 rounded-pill">
                              {skill}
                              <button
                                type="button"
                                className="btn-close ms-2"
                                onClick={() => handleRemoveSkill(skill)}
                                style={{ fontSize: '0.7em' }}
                                aria-label={`Remove ${skill}`}
                              ></button>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Settings Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-cog text-primary me-2"></i>
                        Certificate Settings
                      </h6>
                      <div className="row">
                        <div className="col-md-6 mb-3">
                          <div className="form-check form-switch">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="featured"
                              name="featured"
                              checked={formData.featured}
                              onChange={handleChange}
                              style={{ transform: 'scale(1.3)' }}
                            />
                            <label className="form-check-label fw-medium text-dark ms-2" htmlFor="featured">
                              <i className="fas fa-star text-warning me-2"></i>
                              Featured Certificate
                            </label>
                            <div className="form-text ms-4">Display this certificate prominently</div>
                          </div>
                        </div>
                        
                        <div className="col-md-6 mb-3">
                          <div className="form-check form-switch">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="isActive"
                              name="isActive"
                              checked={formData.isActive}
                              onChange={handleChange}
                              style={{ transform: 'scale(1.3)' }}
                            />
                            <label className="form-check-label fw-medium text-dark ms-2" htmlFor="isActive">
                              <i className="fas fa-eye text-success me-2"></i>
                              Active/Published
                            </label>
                            <div className="form-text ms-4">Make this certificate visible to visitors</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Image Upload Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-image text-primary me-2"></i>
                        Certificate Image
                      </h6>
                      {formData.image && (
                        <div className="mb-3">
                          <div className="position-relative d-inline-block">
                            <img 
                              src={formData.image} 
                              alt="Certificate preview" 
                              className="img-thumbnail shadow-sm"
                              style={{ maxHeight: '200px', maxWidth: '100%', borderRadius: '12px' }}
                            />
                            <button
                              type="button"
                              className="btn btn-danger btn-sm position-absolute top-0 end-0 m-2 rounded-circle"
                              onClick={() => setFormData(prev => ({ ...prev, image: '' }))}
                              title="Remove image"
                              style={{ width: '32px', height: '32px' }}
                            >
                              <i className="fas fa-times"></i>
                            </button>
                          </div>
                          <div className="mt-2">
                            <small className="text-muted">Current certificate image</small>
                          </div>
                        </div>
                      )}
                      <ImageUploader 
                        onUpload={handleImageUpload}
                        category="certificates"
                      />
                      {!formData.image && (
                        <div className="form-text mt-2">
                          <i className="fas fa-info-circle me-1"></i>
                          Upload an image for the certificate. Recommended size: 400x300px or larger.
                        </div>
                      )}
                    </div>

                    {/* Action Buttons */}
                    <div className="d-flex gap-3 justify-content-end">
                      <button 
                        type="button" 
                        className="btn btn-outline-secondary btn-lg rounded-pill px-4"
                        onClick={() => navigate('/admin/certificates')}
                      >
                        <i className="fas fa-times me-2"></i>Cancel
                      </button>
                      
                      <button 
                        type="submit" 
                        className="btn btn-primary btn-lg rounded-pill px-4"
                        disabled={loading}
                      >
                        {loading ? (
                          <>
                            <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                            {isEdit ? 'Updating...' : 'Creating...'}
                          </>
                        ) : (
                          <>
                            <i className="fas fa-save me-2"></i>
                            {isEdit ? 'Update Certificate' : 'Create Certificate'}
                          </>
                        )}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            
            {/* Preview Card */}
            <div className="col-12 col-lg-4">
              <div className="card shadow-sm border-0 sticky-top" style={{ borderRadius: '16px', top: '2rem' }}>
                <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#fff3e0'
                      }}
                    >
                      <i className="fas fa-eye text-warning fs-5"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold text-dark">Live Preview</h5>
                      <small className="text-muted">See how your certificate will appear</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">
                  <div className="certificate-preview">
                    <div className="text-center mb-3">
                      {formData.image ? (
                        <img 
                          src={formData.image} 
                          alt="Certificate"
                          className="img-fluid rounded shadow-sm"
                          style={{ maxHeight: '140px', objectFit: 'contain' }}
                        />
                      ) : (
                        <div 
                          className="d-flex align-items-center justify-content-center rounded border-2 border-dashed"
                          style={{ height: '140px', backgroundColor: '#f8f9fa', borderColor: '#dee2e6' }}
                        >
                          <div className="text-center">
                            <i className="fas fa-certificate fa-3x text-muted mb-2"></i>
                            <p className="text-muted small mb-0">No image uploaded</p>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="mb-3">
                      <h6 className="mb-2 fw-bold text-dark">
                        {formData.title || 'Certificate Title'}
                      </h6>
                      <p className="text-muted small mb-0" style={{ lineHeight: '1.4' }}>
                        {formData.description || 'Certificate description will appear here...'}
                      </p>
                    </div>
                    
                    <div className="mb-2">
                      <div className="d-flex align-items-center mb-1">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '20px', height: '20px', backgroundColor: '#e3f2fd' }}
                        >
                          <i className="fas fa-building text-primary" style={{ fontSize: '8px' }}></i>
                        </div>
                        <small className="text-muted fw-medium">
                          {formData.issuer || 'Issuing Organization'}
                        </small>
                      </div>
                    </div>
                    
                    <div className="mb-3">
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '20px', height: '20px', backgroundColor: '#e3f2fd' }}
                        >
                          <i className="fas fa-calendar text-primary" style={{ fontSize: '8px' }}></i>
                        </div>
                        <small className="text-muted fw-medium">
                          {formData.year || 'YYYY'}
                        </small>
                      </div>
                    </div>

                    <div className="mb-3">
                      <span className={`badge rounded-pill px-3 py-2 ${
                        formData.category === 'Web Development' ? 'text-primary' :
                        formData.category === 'Programming' ? 'text-success' :
                        formData.category === 'Frameworks' ? 'text-info' :
                        formData.category === 'Cloud Computing' ? 'text-warning' :
                        'text-secondary'
                      }`} style={{
                        backgroundColor: formData.category === 'Web Development' ? '#e3f2fd' :
                        formData.category === 'Programming' ? '#e8f5e8' :
                        formData.category === 'Frameworks' ? '#e1f5fe' :
                        formData.category === 'Cloud Computing' ? '#fff3e0' :
                        '#f5f5f5'
                      }}>
                        <i className="fas fa-tag me-1"></i>{formData.category}
                      </span>
                    </div>

                    {formData.skills.length > 0 && (
                      <div className="mb-3">
                        <small className="text-muted d-block mb-2 fw-semibold">
                          <i className="fas fa-code me-1"></i>Skills:
                        </small>
                        <div className="d-flex flex-wrap gap-1">
                          {formData.skills.slice(0, 4).map((skill, index) => (
                            <span key={`preview-skill-${index}-${skill}`} className="badge bg-light text-muted rounded-pill" style={{ fontSize: '0.7rem' }}>
                              {skill}
                            </span>
                          ))}
                          {formData.skills.length > 4 && (
                            <span className="badge bg-light text-muted rounded-pill" style={{ fontSize: '0.7rem' }}>
                              +{formData.skills.length - 4} more
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    {(formData.featured || !formData.isActive) && (
                      <div className="d-flex gap-1 justify-content-center mt-3">
                        {formData.featured && (
                          <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: '#fff3e0', color: '#ffa000' }}>
                            <i className="fas fa-star me-1"></i>Featured
                          </span>
                        )}
                        {!formData.isActive && (
                          <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: '#f5f5f5', color: '#6c757d' }}>
                            <i className="fas fa-eye-slash me-1"></i>Hidden
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CertificateForm;
