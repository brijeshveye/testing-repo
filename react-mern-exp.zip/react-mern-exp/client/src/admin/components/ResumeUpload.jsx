import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ResumeUpload = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [currentResume, setCurrentResume] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState(''); // 'success' or 'error'
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    
    // Fetch current user data to show existing resume
    const fetchUserData = async () => {
      try {
        const response = await axios.get('/api/user');
        if (mountedRef.current) {
          setCurrentResume(response.data.aboutData?.resume || '');
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        if (mountedRef.current) {
          setMessage('Error loading current resume data');
          setMessageType('error');
        }
      }
    };
    
    fetchUserData();
    
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const clearMessage = () => {
    setMessage('');
    setMessageType('');
  };

  const showMessage = (msg, type = 'info') => {
    setMessage(msg);
    setMessageType(type);
  };

  const handleFileSelect = (event) => {
    clearMessage();
    const file = event.target.files?.[0];
    
    if (!file) {
      setSelectedFile(null);
      return;
    }

    // Validate file type (PDF only for resume)
    if (file.type !== 'application/pdf') {
      showMessage('Please select a PDF file for your resume.', 'error');
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      return;
    }
    
    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      showMessage('File size should be less than 10MB.', 'error');
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      return;
    }
    
    setSelectedFile(file);
    clearMessage();
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      showMessage('Please select a file first.', 'error');
      return;
    }

    if (!mountedRef.current) return;

    setUploading(true);
    setUploadProgress(0);
    clearMessage();

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('category', 'resume');

      // Upload the file
      const uploadResponse = await axios.post('/api/upload/resume', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          if (mountedRef.current && progressEvent.total) {
            const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setUploadProgress(progress);
          }
        },
      });

      if (!mountedRef.current) return;

      const resumeUrl = uploadResponse.data.url;

      // Update user's aboutData with the new resume URL
      const userResponse = await axios.get('/api/user');
      if (!mountedRef.current) return;
      
      const currentAboutData = userResponse.data.aboutData || {};
      
      const updatedAboutData = {
        ...currentAboutData,
        resume: resumeUrl
      };

      await axios.put('/api/user/aboutData', updatedAboutData);

      if (!mountedRef.current) return;

      showMessage('Resume uploaded successfully!', 'success');
      setCurrentResume(resumeUrl);
      setSelectedFile(null);
      
      // Reset file input safely
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      
      // Navigate back after a short delay
      setTimeout(() => {
        if (mountedRef.current) {
          navigate('/admin/user');
        }
      }, 2000);
      
    } catch (error) {
      console.error('Error uploading resume:', error);
      if (mountedRef.current) {
        showMessage('Error uploading resume. Please try again.', 'error');
      }
    } finally {
      if (mountedRef.current) {
        setUploading(false);
        setUploadProgress(0);
      }
    }
  };

  const handleRemoveResume = async () => {
    if (!window.confirm('Are you sure you want to remove your current resume?')) {
      return;
    }

    clearMessage();
    
    try {
      const userResponse = await axios.get('/api/user');
      if (!mountedRef.current) return;
      
      const currentAboutData = userResponse.data.aboutData || {};
      
      const updatedAboutData = {
        ...currentAboutData,
        resume: ''
      };

      await axios.put('/api/user/aboutData', updatedAboutData);
      
      if (!mountedRef.current) return;
      
      setCurrentResume('');
      showMessage('Resume removed successfully!', 'success');
    } catch (error) {
      console.error('Error removing resume:', error);
      if (mountedRef.current) {
        showMessage('Error removing resume. Please try again.', 'error');
      }
    }
  };

  const getMessageClass = () => {
    switch (messageType) {
      case 'success': return 'alert-success';
      case 'error': return 'alert-danger';
      default: return 'alert-info';
    }
  };

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-8">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center">
                <div className="me-3">
                  <div 
                    className="rounded-circle d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '60px', 
                      height: '60px', 
                      backgroundColor: '#2e7d32',
                      color: 'white'
                    }}
                  >
                    <i className="fas fa-file-pdf fs-3"></i>
                  </div>
                </div>
                <div>
                  <h2 className="mb-1 text-dark fw-bold">Resume Upload</h2>
                  <p className="text-muted mb-0">Upload or update your professional resume/CV document</p>
                </div>
              </div>
            </div>
          </div>

          {/* Message Display */}
          {message && (
            <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className={`alert ${getMessageClass()} border-0 mb-0`} role="alert" style={{ borderRadius: '12px' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: messageType === 'success' ? '#e8f5e8' : messageType === 'error' ? '#ffebee' : '#e3f2fd',
                        color: messageType === 'success' ? '#2e7d32' : messageType === 'error' ? '#d32f2f' : '#1976d2'
                      }}
                    >
                      <i className={`fas ${messageType === 'success' ? 'fa-check-circle' : messageType === 'error' ? 'fa-exclamation-triangle' : 'fa-info-circle'}`}></i>
                    </div>
                    <div className="flex-grow-1">
                      <div className="fw-medium">{message}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Current Resume Section */}
          {currentResume && (
            <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
              <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '48px', 
                      height: '48px', 
                      backgroundColor: '#e8f5e8'
                    }}
                  >
                    <i className="fas fa-file-check text-success fs-5"></i>
                  </div>
                  <div>
                    <h5 className="mb-0 fw-bold text-dark">Current Resume</h5>
                    <small className="text-muted">Your currently uploaded resume document</small>
                  </div>
                </div>
              </div>
              <div className="card-body px-4 pb-4">
                <div className="row g-3">
                  <div className="col-12 col-md-8">
                    <div className="p-3 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                      <div className="d-flex align-items-center">
                        <i className="fas fa-file-pdf text-success me-3 fs-4"></i>
                        <div className="flex-grow-1">
                          <div className="fw-medium text-success">Resume Available</div>
                          <small className="text-muted">PDF document ready for download</small>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-4">
                    <div className="d-grid gap-2">
                      <a 
                        href={currentResume} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="btn btn-outline-success rounded-pill"
                      >
                        <i className="fas fa-eye me-2"></i>View Resume
                      </a>
                      <button 
                        type="button" 
                        className="btn btn-outline-danger rounded-pill"
                        onClick={handleRemoveResume}
                        disabled={uploading}
                      >
                        <i className="fas fa-trash me-2"></i>Remove
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Upload New Resume Section */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#e3f2fd'
                  }}
                >
                  <i className="fas fa-upload text-primary fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">{currentResume ? 'Replace Resume' : 'Upload New Resume'}</h5>
                  <small className="text-muted">Select a PDF file to upload as your resume</small>
                </div>
              </div>
            </div>
            <div className="card-body px-4 pb-4">
              {/* File Upload Area */}
              <div className="mb-4">
                <div 
                  className="border-2 border-dashed rounded-3 p-4 text-center position-relative"
                  style={{ 
                    borderColor: selectedFile ? '#2e7d32' : '#e0e0e0',
                    backgroundColor: selectedFile ? '#f1f8e9' : '#fafafa',
                    minHeight: '200px',
                    cursor: 'pointer'
                  }}
                  onClick={() => !uploading && fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    id="resumeFile"
                    type="file"
                    className="d-none"
                    accept=".pdf"
                    onChange={handleFileSelect}
                    disabled={uploading}
                  />
                  
                  {!selectedFile ? (
                    <div className="d-flex flex-column align-items-center justify-content-center h-100">
                      <div 
                        className="rounded-circle mb-3 d-flex align-items-center justify-content-center"
                        style={{ 
                          width: '80px', 
                          height: '80px', 
                          backgroundColor: '#e3f2fd'
                        }}
                      >
                        <i className="fas fa-cloud-upload-alt text-primary fs-1"></i>
                      </div>
                      <h5 className="fw-bold text-dark mb-2">Drop your PDF here or click to browse</h5>
                      <p className="text-muted mb-0">Maximum file size: 10MB • PDF format only</p>
                    </div>
                  ) : (
                    <div className="d-flex flex-column align-items-center justify-content-center h-100">
                      <div 
                        className="rounded-circle mb-3 d-flex align-items-center justify-content-center"
                        style={{ 
                          width: '80px', 
                          height: '80px', 
                          backgroundColor: '#e8f5e8'
                        }}
                      >
                        <i className="fas fa-file-pdf text-success fs-1"></i>
                      </div>
                      <h5 className="fw-bold text-success mb-2">{selectedFile.name}</h5>
                      <p className="text-muted mb-0">
                        Size: {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                        <span className="mx-2">•</span>
                        <span className="text-success">Ready to upload</span>
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Upload Progress */}
              {uploading && (
                <div className="mb-4">
                  <div className="p-3 rounded-3" style={{ backgroundColor: '#e3f2fd' }}>
                    <div className="d-flex align-items-center mb-2">
                      <i className="fas fa-upload text-primary me-2"></i>
                      <span className="fw-medium text-primary">Uploading your resume...</span>
                    </div>
                    <div className="progress" style={{ height: '8px', borderRadius: '4px' }}>
                      <div 
                        className="progress-bar progress-bar-striped progress-bar-animated" 
                        role="progressbar" 
                        style={{width: `${uploadProgress}%`}}
                        aria-valuenow={uploadProgress} 
                        aria-valuemin="0" 
                        aria-valuemax="100"
                      >
                      </div>
                    </div>
                    <div className="d-flex justify-content-between mt-2">
                      <small className="text-muted">Progress</small>
                      <small className="text-primary fw-medium">{uploadProgress}%</small>
                    </div>
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="row">
                <div className="col-12">
                  <div className="p-4 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                    <div className="d-flex flex-column flex-md-row gap-3 justify-content-between align-items-center">
                      <div>
                        <h6 className="mb-1 fw-bold text-dark">Ready to upload?</h6>
                        <small className="text-muted">
                          {selectedFile ? 'Click upload to save your resume' : 'Select a PDF file first'}
                        </small>
                      </div>
                      <div className="d-flex gap-2">
                        <button
                          type="button"
                          className="btn btn-outline-secondary rounded-pill px-4"
                          onClick={() => navigate('/admin/user')}
                          disabled={uploading}
                          style={{ minWidth: '140px' }}
                        >
                          <i className="fas fa-arrow-left me-2"></i>Back to Profile
                        </button>
                        <button
                          type="button"
                          className="btn btn-success rounded-pill px-4"
                          onClick={handleUpload}
                          disabled={!selectedFile || uploading}
                          style={{ minWidth: '140px' }}
                        >
                          {uploading ? (
                            <>
                              <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                              Uploading...
                            </>
                          ) : (
                            <>
                              <i className="fas fa-upload me-2"></i>Upload Resume
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Guidelines Card */}
          <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
            <div className="card-body p-4">
              <div className="d-flex align-items-start">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center flex-shrink-0"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#fff3e0'
                  }}
                >
                  <i className="fas fa-info-circle text-warning fs-5"></i>
                </div>
                <div className="flex-grow-1">
                  <h6 className="mb-3 fw-bold text-dark">Upload Guidelines</h6>
                  <div className="row g-3">
                    <div className="col-12 col-md-6">
                      <div className="d-flex align-items-start">
                        <i className="fas fa-file-pdf text-danger me-2 mt-1"></i>
                        <div>
                          <div className="fw-medium text-dark">PDF Format Only</div>
                          <small className="text-muted">Only PDF files are accepted for resumes</small>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-6">
                      <div className="d-flex align-items-start">
                        <i className="fas fa-weight-hanging text-primary me-2 mt-1"></i>
                        <div>
                          <div className="fw-medium text-dark">10MB Maximum</div>
                          <small className="text-muted">Keep your file size under 10MB</small>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-6">
                      <div className="d-flex align-items-start">
                        <i className="fas fa-globe text-success me-2 mt-1"></i>
                        <div>
                          <div className="fw-medium text-dark">Public Access</div>
                          <small className="text-muted">Available for download on your portfolio</small>
                        </div>
                      </div>
                    </div>
                    <div className="col-12 col-md-6">
                      <div className="d-flex align-items-start">
                        <i className="fas fa-sync-alt text-info me-2 mt-1"></i>
                        <div>
                          <div className="fw-medium text-dark">Auto-Replace</div>
                          <small className="text-muted">New uploads replace existing resume</small>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResumeUpload;
