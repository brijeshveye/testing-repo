import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createCharacteristic, getCharacteristic, updateCharacteristic } from '../../api/CharacteristicsDataApi';
import IconBrowser from '../../components/admin/IconBrowser';

const CharacteristicForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDescription: '',
    icon: '',
    iconClass: '',
    image: '',
    category: 'personal',
    value: 85,
    unit: '%',
    color: '#007bff',
    link: '',
    backTitle: '',
    backDescription: '',
    tags: [],
    featured: false,
    isActive: true,
    seoTitle: '',
    seoDescription: '',
    seoKeywords: []
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [uploadingImage, setUploadingImage] = useState(false);
  const [imagePreview, setImagePreview] = useState('');
  const [iconType, setIconType] = useState('iconClass'); // 'iconClass' or 'image'
  const [imageLoadError, setImageLoadError] = useState(false);
  const [previewImageError, setPreviewImageError] = useState(false);
  const [fileInputKey, setFileInputKey] = useState(0); // Force file input re-render

  useEffect(() => {
    if (isEdit) {
      fetchCharacteristic();
    }
    
    // Cleanup function to handle component unmounting
    return () => {
      setImagePreview('');
      setImageLoadError(false);
      setPreviewImageError(false);
    };
  }, [slug, isEdit]);

  const fetchCharacteristic = async () => {
    try {
      setLoading(true);
      const response = await getCharacteristic(slug, true);
      if (response.success) {
        const characteristicData = response.data;
        setFormData({
          title: characteristicData.title || '',
          description: characteristicData.description || '',
          shortDescription: characteristicData.shortDescription || '',
          icon: characteristicData.icon || '',
          iconClass: characteristicData.iconClass || '',
          image: characteristicData.image || '',
          category: characteristicData.category || 'personal',
          value: characteristicData.value || 85,
          unit: characteristicData.unit || '%',
          color: characteristicData.color || '#007bff',
          link: characteristicData.link || '',
          backTitle: characteristicData.backTitle || '',
          backDescription: characteristicData.backDescription || '',
          tags: characteristicData.tags || [],
          featured: characteristicData.featured || false,
          isActive: characteristicData.isActive !== false,
          seoTitle: characteristicData.seoTitle || '',
          seoDescription: characteristicData.seoDescription || '',
          seoKeywords: characteristicData.seoKeywords || []
        });
        
        // Set icon type and preview based on existing data
        if (characteristicData.image) {
          setIconType('image');
          setImagePreview(characteristicData.image);
          setImageLoadError(false);
          setPreviewImageError(false);
        } else if (characteristicData.iconClass) {
          setIconType('iconClass');
        }
      } else {
        setErrors({ general: response.message || 'Failed to fetch characteristic details' });
      }
    } catch (error) {
      console.error('Error fetching characteristic:', error);
      setErrors({ general: 'Failed to fetch characteristic details' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) : value)
    }));
  };

  const handleTagsChange = (e) => {
    const tags = e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag);
    setFormData(prev => ({ ...prev, tags }));
  };

  const handleSeoKeywordsChange = (e) => {
    const seoKeywords = e.target.value.split(',').map(keyword => keyword.trim()).filter(keyword => keyword);
    setFormData(prev => ({ ...prev, seoKeywords }));
  };

  const handleIconTypeChange = (type) => {
    // Prevent unnecessary re-renders if type hasn't changed
    if (iconType === type) return;
    
    setIconType(type);
    setImageLoadError(false);
    setPreviewImageError(false);
    setFileInputKey(prev => prev + 1); // Force file input re-render
    
    // Clear errors
    setErrors(prev => ({ ...prev, image: '' }));
    
    if (type === 'iconClass') {
      setFormData(prev => ({ ...prev, image: '' }));
      setImagePreview('');
    } else {
      setFormData(prev => ({ ...prev, iconClass: '' }));
    }
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ['image/svg+xml', 'image/png', 'image/jpeg', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      setErrors(prev => ({ ...prev, image: 'Please select a valid image file (SVG, PNG, JPG, GIF, WebP)' }));
      return;
    }

    // Validate file size (5MB limit to match server)
    if (file.size > 5 * 1024 * 1024) {
      setErrors(prev => ({ ...prev, image: 'File size must be less than 5MB' }));
      return;
    }

    try {
      setUploadingImage(true);
      setErrors(prev => ({ ...prev, image: '' }));

      // First test if the upload API is working
      try {
        const testResponse = await fetch('/api/upload/test');
        const testResult = await testResponse.json();
        console.log('Upload API test:', testResult);
      } catch (testError) {
        console.warn('Upload API test failed:', testError);
      }

      // Create FormData for file upload (use 'image' field name as expected by server)
      const formDataUpload = new FormData();
      formDataUpload.append('image', file);
      formDataUpload.append('category', 'characteristics');

      console.log('Uploading file:', file.name, 'Type:', file.type, 'Size:', file.size);

      // Upload to the upload API endpoint
      const uploadResponse = await fetch('/api/upload/upload', {
        method: 'POST',
        body: formDataUpload
      });

      console.log('Upload response status:', uploadResponse.status);
      console.log('Upload response headers:', uploadResponse.headers);

      // Get response text first to check what we actually received
      const responseText = await uploadResponse.text();
      console.log('Raw response:', responseText);

      // Try to parse as JSON
      let uploadResult;
      try {
        uploadResult = JSON.parse(responseText);
      } catch (parseError) {
        console.error('Failed to parse response as JSON:', parseError);
        throw new Error(`Server returned invalid response: ${responseText.substring(0, 100)}...`);
      }

      console.log('Parsed upload result:', uploadResult);

      if (!uploadResponse.ok) {
        throw new Error(uploadResult.error || uploadResult.details || `Upload failed with status ${uploadResponse.status}`);
      }
      
      if (uploadResult.success && uploadResult.url) {
        setFormData(prev => ({ ...prev, image: uploadResult.url }));
        setImagePreview(uploadResult.url);
        setImageLoadError(false);
        setPreviewImageError(false);
        setFileInputKey(prev => prev + 1); // Clear the file input by forcing re-render
        console.log('Upload successful:', uploadResult.url);
      } else {
        throw new Error(uploadResult.message || 'Upload failed - no URL returned');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      setErrors(prev => ({ ...prev, image: error.message || 'Failed to upload image. Please try again.' }));
    } finally {
      setUploadingImage(false);
    }
  };

  const handleImageUrlChange = (e) => {
    const url = e.target.value;
    setFormData(prev => ({ ...prev, image: url }));
    setImagePreview(url);
    setImageLoadError(false);
    setPreviewImageError(false);
  };

  const removeImage = () => {
    setFormData(prev => ({ ...prev, image: '' }));
    setImagePreview('');
    setImageLoadError(false);
    setPreviewImageError(false);
    setFileInputKey(prev => prev + 1); // Force file input re-render
    setErrors(prev => ({ ...prev, image: '' }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (formData.value < 0 || formData.value > 100) {
      newErrors.value = 'Value must be between 0 and 100';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      
      // Prepare form data for submission
      const submitData = { ...formData };
      
      // Ensure we're using the correct image field based on icon type
      if (iconType === 'image') {
        // Keep the image URL
        submitData.iconClass = ''; // Clear icon class when using image
      } else {
        // Clear image when using icon class
        submitData.image = '';
      }
      
      console.log('Submitting form data:', submitData);
      
      let response;

      if (isEdit) {
        response = await updateCharacteristic(slug, submitData);
      } else {
        response = await createCharacteristic(submitData);
      }

      if (response.success) {
        navigate('/admin/characteristics');
      } else {
        setErrors({ general: response.message || 'Failed to save characteristic' });
      }
    } catch (error) {
      console.error('Error saving characteristic:', error);
      setErrors({ general: 'Failed to save characteristic. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading characteristic...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex align-items-center">
              <div 
                className="rounded-circle d-flex align-items-center justify-content-center me-3"
                style={{ 
                  width: '48px', 
                  height: '48px', 
                  backgroundColor: '#9c27b0',
                  color: 'white'
                }}
              >
                <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'}`} style={{ fontSize: '20px' }}></i>
              </div>
              <div>
                <h2 className="mb-1" style={{ color: '#2c3e50', fontWeight: '600' }}>
                  {isEdit ? 'Edit Characteristic' : 'Create New Characteristic'}
                </h2>
                <p className="text-muted mb-0">
                  {isEdit ? 'Update your characteristic details' : 'Add a new personal attribute or skill'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-lg-8">
            <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                {/* Error Message */}
                {errors.general && (
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '12px', borderLeft: '4px solid #dc3545' }}>
                    <div className="card-body p-3" style={{ backgroundColor: '#fff5f5' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#dc3545', color: 'white' }}
                        >
                          <i className="fas fa-exclamation-triangle"></i>
                        </div>
                        <div>
                          <h6 className="mb-0" style={{ color: '#dc3545', fontWeight: '600' }}>Error</h6>
                          <small className="text-muted">{errors.general}</small>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <form onSubmit={handleSubmit}>
                  {/* Basic Information Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #2e7d32' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#e8f5e8'
                          }}
                        >
                          <i className="fas fa-info-circle text-success"></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Basic Information</h5>
                          <small className="text-muted">Core details about your characteristic</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      <div className="row g-3">
                        <div className="col-12">
                          <label htmlFor="title" className="form-label fw-medium text-dark">
                            <i className="fas fa-heading me-2 text-muted"></i>Title *
                          </label>
                          <input
                            type="text"
                            className={`form-control rounded-pill py-2 ${errors.title ? 'is-invalid' : ''}`}
                            id="title"
                            name="title"
                            value={formData.title}
                            onChange={handleChange}
                            required
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="Enter characteristic title..."
                          />
                          {errors.title && <div className="invalid-feedback">{errors.title}</div>}
                        </div>

                        <div className="col-12">
                          <label htmlFor="description" className="form-label fw-medium text-dark">
                            <i className="fas fa-align-left me-2 text-muted"></i>Description *
                          </label>
                          <textarea
                            className={`form-control ${errors.description ? 'is-invalid' : ''}`}
                            id="description"
                            name="description"
                            rows="4"
                            value={formData.description}
                            onChange={handleChange}
                            required
                            style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                            placeholder="Describe this characteristic in detail..."
                          />
                          {errors.description && <div className="invalid-feedback">{errors.description}</div>}
                        </div>

                        <div className="col-12">
                          <label htmlFor="shortDescription" className="form-label fw-medium text-dark">
                            <i className="fas fa-quote-left me-2 text-muted"></i>Short Description
                          </label>
                          <textarea
                            className="form-control"
                            id="shortDescription"
                            name="shortDescription"
                            rows="2"
                            value={formData.shortDescription}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                            placeholder="Brief summary for cards..."
                          />
                        </div>

                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-icons me-2 text-muted"></i>Icon Type
                          </label>
                          <div className="btn-group w-100" role="group">
                            <input
                              type="radio"
                              className="btn-check"
                              name="iconType"
                              id="iconTypeClass"
                              checked={iconType === 'iconClass'}
                              onChange={() => handleIconTypeChange('iconClass')}
                            />
                            <label className="btn btn-outline-primary rounded-pill me-2" htmlFor="iconTypeClass">
                              <i className="fas fa-font me-1"></i>Icon Class
                            </label>

                            <input
                              type="radio"
                              className="btn-check"
                              name="iconType"
                              id="iconTypeImage"
                              checked={iconType === 'image'}
                              onChange={() => handleIconTypeChange('image')}
                            />
                            <label className="btn btn-outline-primary rounded-pill" htmlFor="iconTypeImage">
                              <i className="fas fa-image me-1"></i>Custom Image
                            </label>
                          </div>
                        </div>

                        <div className="col-md-6">
                          <label htmlFor="color" className="form-label fw-medium text-dark">
                            <i className="fas fa-palette me-2 text-muted"></i>Color
                          </label>
                          <input
                            type="color"
                            className="form-control form-control-color"
                            id="color"
                            name="color"
                            value={formData.color}
                            onChange={handleChange}
                            style={{ height: '42px', borderRadius: '12px' }}
                          />
                        </div>

                        <div className="col-md-6">
                          <label htmlFor="category" className="form-label fw-medium text-dark">
                            <i className="fas fa-layer-group me-2 text-muted"></i>Category
                          </label>
                          <select
                            className="form-select rounded-pill py-2"
                            id="category"
                            name="category"
                            value={formData.category}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            <option value="personal">Personal</option>
                            <option value="professional">Professional</option>
                            <option value="technical">Technical</option>
                            <option value="creative">Creative</option>
                            <option value="leadership">Leadership</option>
                            <option value="communication">Communication</option>
                          </select>
                        </div>

                        <div className="col-md-6">
                          <label htmlFor="tags" className="form-label fw-medium text-dark">
                            <i className="fas fa-tags me-2 text-muted"></i>Tags
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            id="tags"
                            value={(formData.tags || []).join(', ')}
                            onChange={handleTagsChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="leadership, communication, teamwork"
                          />
                        </div>

                        <div className="col-md-8">
                          <label htmlFor="value" className="form-label fw-medium text-dark">
                            <i className="fas fa-chart-line me-2 text-muted"></i>Value/Level
                          </label>
                          <input
                            type="number"
                            className={`form-control rounded-pill py-2 ${errors.value ? 'is-invalid' : ''}`}
                            id="value"
                            name="value"
                            value={formData.value}
                            onChange={handleChange}
                            min="0"
                            max="100"
                            style={{ border: '2px solid #e0e0e0' }}
                          />
                          {errors.value && <div className="invalid-feedback">{errors.value}</div>}
                        </div>

                        <div className="col-md-4">
                          <label htmlFor="unit" className="form-label fw-medium text-dark">
                            <i className="fas fa-ruler me-2 text-muted"></i>Unit
                          </label>
                          <select
                            className="form-select rounded-pill py-2"
                            id="unit"
                            name="unit"
                            value={formData.unit}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            <option value="%">%</option>
                            <option value="/10">/10</option>
                            <option value="/5">/5</option>
                            <option value="years">years</option>
                            <option value="level">level</option>
                          </select>
                        </div>

                        <div className="col-12">
                          <div className="d-flex gap-3">
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="featured"
                                name="featured"
                                checked={formData.featured}
                                onChange={handleChange}
                              />
                              <label className="form-check-label fw-medium text-dark" htmlFor="featured">
                                <i className="fas fa-star me-2 text-warning"></i>Featured Characteristic
                              </label>
                            </div>

                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="isActive"
                                name="isActive"
                                checked={formData.isActive}
                                onChange={handleChange}
                              />
                              <label className="form-check-label fw-medium text-dark" htmlFor="isActive">
                                <i className="fas fa-check-circle me-2 text-success"></i>Active
                              </label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Icon Configuration Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #ff9800' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#fff8e1'
                          }}
                        >
                          <i className="fas fa-image" style={{ color: '#ff9800' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Icon Configuration</h5>
                          <small className="text-muted">Choose icon type and customize appearance</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      {/* Render icon sections with unique keys to prevent DOM conflicts */}
                      <div key={`icon-section-${iconType}`}>
                        {iconType === 'iconClass' && (
                          <div>
                            <label htmlFor="iconClass" className="form-label fw-medium text-dark">
                              <i className="fas fa-font me-2 text-muted"></i>Icon Class
                            </label>
                            <input
                              type="text"
                              className="form-control rounded-pill py-2 mb-3"
                              id="iconClass"
                              name="iconClass"
                              value={formData.iconClass}
                              onChange={handleChange}
                              style={{ border: '2px solid #e0e0e0' }}
                              placeholder="e.g., fas fa-star, fab fa-react, bi bi-heart"
                            />
                            <div className="alert alert-info mb-3" style={{ borderRadius: '12px' }}>
                              <i className="fas fa-info-circle me-2"></i>
                              <strong>Icon Examples:</strong> fas fa-code, fab fa-js-square, bi bi-lightning
                              <br />
                              <small>Use FontAwesome (fas, fab, far), Bootstrap Icons (bi), or any icon font classes.</small>
                            </div>
                            
                            {/* Icon Browser */}
                            <div className="card border-0" style={{ backgroundColor: '#f8f9fa', borderRadius: '12px' }}>
                              <div className="card-body p-3">
                                <IconBrowser 
                                  onSelectIcon={(iconClass) => setFormData(prev => ({ ...prev, iconClass }))}
                                  currentIcon={formData.iconClass}
                                />
                              </div>
                            </div>
                          </div>
                        )}

                        {iconType === 'image' && (
                          <div>
                            <label className="form-label fw-medium text-dark">
                              <i className="fas fa-upload me-2 text-muted"></i>Custom Image/Icon
                            </label>
                            
                            {/* Image Preview */}
                            {imagePreview && (
                              <div className="card border-0 shadow-sm mb-3" style={{ borderRadius: '12px' }}>
                                <div className="card-body p-3">
                                  <div className="d-flex align-items-center gap-3">
                                    <div 
                                      className="d-flex align-items-center justify-content-center rounded"
                                      style={{ 
                                        width: '60px', 
                                        height: '60px', 
                                        backgroundColor: '#f8f9fa',
                                        border: '2px solid #e0e0e0',
                                        borderRadius: '12px'
                                      }}
                                    >
                                      {!imageLoadError ? (
                                        <img 
                                          src={imagePreview} 
                                          alt="Icon preview" 
                                          style={{ 
                                            maxWidth: '50px', 
                                            maxHeight: '50px', 
                                            objectFit: 'contain' 
                                          }}
                                          onError={() => setImageLoadError(true)}
                                          onLoad={() => setImageLoadError(false)}
                                        />
                                      ) : (
                                        <div 
                                          className="d-flex align-items-center justify-content-center text-muted"
                                          style={{ width: '50px', height: '50px' }}
                                        >
                                          <i className="fas fa-image"></i>
                                        </div>
                                      )}
                                    </div>
                                    <div className="flex-grow-1">
                                      <h6 className="mb-1 text-dark">Preview</h6>
                                      <small className="text-muted text-truncate d-block" style={{ maxWidth: '200px' }}>
                                        {imagePreview}
                                      </small>
                                    </div>
                                    <button
                                      type="button"
                                      className="btn btn-sm btn-outline-danger rounded-pill"
                                      onClick={removeImage}
                                      title="Remove image"
                                    >
                                      <i className="fas fa-trash"></i>
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}

                            {/* Upload Options */}
                            <div className="row g-3">
                              <div className="col-md-6">
                                <label className="form-label fw-medium text-dark">Upload Image</label>
                                <input
                                  key={fileInputKey}
                                  type="file"
                                  className={`form-control ${errors.image ? 'is-invalid' : ''}`}
                                  accept=".svg,.png,.jpg,.jpeg,.gif,.webp"
                                  onChange={handleImageUpload}
                                  disabled={uploadingImage}
                                  style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                                />
                                {uploadingImage && (
                                  <div className="mt-2">
                                    <small className="text-primary">
                                      <i className="fas fa-spinner fa-spin me-1"></i>
                                      Uploading...
                                    </small>
                                  </div>
                                )}
                                <div className="form-text">
                                  <i className="fas fa-info-circle me-1"></i>
                                  Supported: SVG, PNG, JPG, GIF, WebP (Max: 5MB)
                                </div>
                              </div>
                              <div className="col-md-6">
                                <label htmlFor="imageUrl" className="form-label fw-medium text-dark">Or Image URL</label>
                                <input
                                  type={formData.image && formData.image.startsWith('/uploads/') ? "text" : "url"}
                                  className="form-control rounded-pill py-2"
                                  id="imageUrl"
                                  value={formData.image}
                                  onChange={handleImageUrlChange}
                                  style={{ border: '2px solid #e0e0e0' }}
                                  placeholder="https://example.com/icon.svg"
                                />
                                <div className="form-text">
                                  {formData.image ? (
                                    <span className="text-success">
                                      <i className="fas fa-check me-1"></i>
                                      {formData.image.startsWith('/uploads/') ? 'Uploaded file' : 'Image URL set'}: {formData.image.length > 50 ? `${formData.image.substring(0, 50)}...` : formData.image}
                                    </span>
                                  ) : (
                                    'Direct URL to your image file'
                                  )}
                                </div>
                              </div>
                            </div>
                            {errors.image && (
                              <div className="alert alert-danger mt-3" style={{ borderRadius: '12px' }}>
                                <i className="fas fa-exclamation-triangle me-2"></i>
                                {errors.image}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Additional Details Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #673ab7' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#f3e5f5'
                          }}
                        >
                          <i className="fas fa-plus-circle" style={{ color: '#673ab7' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Additional Details</h5>
                          <small className="text-muted">Extra information and customization options</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      <div className="row g-3">
                        <div className="col-md-6">
                          <label htmlFor="backTitle" className="form-label fw-medium text-dark">
                            <i className="fas fa-heading me-2 text-muted"></i>Back Title
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            id="backTitle"
                            name="backTitle"
                            value={formData.backTitle}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="Title for card back/hover"
                          />
                        </div>

                        <div className="col-md-6">
                          <label htmlFor="link" className="form-label fw-medium text-dark">
                            <i className="fas fa-link me-2 text-muted"></i>Custom Link
                          </label>
                          <input
                            type="url"
                            className="form-control rounded-pill py-2"
                            id="link"
                            name="link"
                            value={formData.link}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="https://example.com"
                          />
                        </div>

                        <div className="col-12">
                          <label htmlFor="backDescription" className="form-label fw-medium text-dark">
                            <i className="fas fa-align-left me-2 text-muted"></i>Back Description
                          </label>
                          <textarea
                            className="form-control"
                            id="backDescription"
                            name="backDescription"
                            rows="3"
                            value={formData.backDescription}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                            placeholder="Description for card back/hover"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* SEO Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #00acc1' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#e0f7fa'
                          }}
                        >
                          <i className="fas fa-search" style={{ color: '#00acc1' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">SEO Settings</h5>
                          <small className="text-muted">Optional search engine optimization</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      <div className="row g-3">
                        <div className="col-12">
                          <label htmlFor="seoTitle" className="form-label fw-medium text-dark">
                            <i className="fas fa-heading me-2 text-muted"></i>SEO Title
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            id="seoTitle"
                            name="seoTitle"
                            value={formData.seoTitle}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="SEO optimized title"
                          />
                        </div>

                        <div className="col-12">
                          <label htmlFor="seoDescription" className="form-label fw-medium text-dark">
                            <i className="fas fa-align-left me-2 text-muted"></i>SEO Description
                          </label>
                          <textarea
                            className="form-control"
                            id="seoDescription"
                            name="seoDescription"
                            rows="2"
                            value={formData.seoDescription}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                            placeholder="Meta description for search engines"
                          />
                        </div>

                        <div className="col-12">
                          <label htmlFor="seoKeywords" className="form-label fw-medium text-dark">
                            <i className="fas fa-tags me-2 text-muted"></i>SEO Keywords
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            id="seoKeywords"
                            value={(formData.seoKeywords || []).join(', ')}
                            onChange={handleSeoKeywordsChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="leadership, skills, personality"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Form Actions */}
                  <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                    <div className="card-body p-4">
                      <div className="d-flex justify-content-between align-items-center">
                        <button
                          type="button"
                          className="btn btn-outline-secondary rounded-pill px-4 py-2"
                          onClick={() => navigate('/admin/characteristics')}
                          disabled={loading}
                        >
                          <i className="fas fa-arrow-left me-2"></i>Cancel
                        </button>
                        <button
                          type="submit"
                          className="btn btn-primary rounded-pill px-4 py-2"
                          disabled={loading}
                          style={{ minWidth: '150px' }}
                        >
                          {loading ? (
                            <>
                              <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                              {isEdit ? 'Updating...' : 'Creating...'}
                            </>
                          ) : (
                            <>
                              <i className={`fas ${isEdit ? 'fa-save' : 'fa-plus'} me-2`}></i>
                              {isEdit ? 'Update Characteristic' : 'Create Characteristic'}
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
          
          <div className="col-lg-4">
            <div className="position-sticky" style={{ top: '2rem' }}>
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-eye text-primary"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold text-dark">Live Preview</h5>
                      <small className="text-muted">See how it will look</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">
                  <div className="characteristic-preview">
                    <div className="text-center mb-4">
                      <div 
                        className="d-inline-flex align-items-center justify-content-center rounded-circle mx-auto"
                        style={{ 
                          width: '80px', 
                          height: '80px', 
                          backgroundColor: iconType === 'iconClass' ? (formData.color || '#007bff') : '#f8f9fa',
                          color: iconType === 'iconClass' ? 'white' : '#495057',
                          border: iconType === 'image' ? '3px solid #e0e0e0' : 'none',
                          overflow: 'hidden'
                        }}
                      >
                        <div key={`preview-container-${iconType}-${formData.iconClass}-${formData.image || imagePreview}`}>
                          {iconType === 'image' && (formData.image || imagePreview) ? (
                            !previewImageError ? (
                              <img 
                                src={formData.image || imagePreview} 
                                alt="Icon preview" 
                                style={{ 
                                  width: '60px', 
                                  height: '60px', 
                                  objectFit: 'contain'
                                }}
                                onError={() => setPreviewImageError(true)}
                                onLoad={() => setPreviewImageError(false)}
                              />
                            ) : (
                              <div 
                                className="d-flex align-items-center justify-content-center text-muted"
                                style={{ width: '60px', height: '60px' }}
                              >
                                <i className="fas fa-image fa-2x"></i>
                              </div>
                            )
                          ) : iconType === 'iconClass' && formData.iconClass ? (
                            <i className={`${formData.iconClass} fa-2x`}></i>
                          ) : (
                            <i className="fas fa-star fa-2x"></i>
                          )}
                        </div>
                      </div>
                    </div>

                    <h4 className="mb-2 text-center fw-bold text-dark">
                      {formData.title || 'Characteristic Title'}
                    </h4>
                    <p className="text-muted mb-4 text-center">
                      {formData.shortDescription || formData.description || 'Characteristic description will appear here...'}
                    </p>

                    {formData.value !== undefined && (
                      <div className="mb-4">
                        <div className="d-flex justify-content-between align-items-center mb-2">
                          <span className="fw-medium text-dark">Progress</span>
                          <span className="fw-bold" style={{ color: formData.color || '#007bff' }}>
                            {formData.value}{formData.unit}
                          </span>
                        </div>
                        <div className="progress" style={{ height: '12px', borderRadius: '6px' }}>
                          <div 
                            className="progress-bar" 
                            role="progressbar" 
                            style={{ 
                              width: `${formData.value}%`,
                              backgroundColor: formData.color || '#007bff',
                              borderRadius: '6px'
                            }}
                            aria-valuenow={formData.value} 
                            aria-valuemin="0" 
                            aria-valuemax="100"
                          ></div>
                        </div>
                      </div>
                    )}

                    {(formData.tags || []).length > 0 && (
                      <div className="mb-4">
                        <h6 className="fw-bold text-dark mb-2">Tags</h6>
                        <div className="d-flex flex-wrap gap-2">
                          {(formData.tags || []).slice(0, 3).map((tag, index) => (
                            <span key={index} className="badge bg-light text-dark px-3 py-2 rounded-pill">
                              {tag}
                            </span>
                          ))}
                          {(formData.tags || []).length > 3 && (
                            <span className="badge bg-light text-muted px-3 py-2 rounded-pill">
                              +{(formData.tags || []).length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="d-flex justify-content-center gap-2 flex-wrap mb-4">
                      {formData.featured && (
                        <span className="badge bg-warning text-dark px-3 py-2 rounded-pill">
                          <i className="fas fa-star me-1"></i>Featured
                        </span>
                      )}
                      <span className={`badge px-3 py-2 rounded-pill ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                        <i className={`fas ${formData.isActive ? 'fa-check-circle' : 'fa-times-circle'} me-1`}></i>
                        {formData.isActive ? 'Active' : 'Inactive'}
                      </span>
                      <span className="badge bg-info px-3 py-2 rounded-pill">
                        <i className="fas fa-layer-group me-1"></i>
                        {formData.category}
                      </span>
                    </div>

                    {/* Technical Info */}
                    <div className="card border-0" style={{ backgroundColor: '#f8f9fa', borderRadius: '12px' }}>
                      <div className="card-body p-3">
                        <h6 className="fw-bold text-dark mb-2">
                          <i className="fas fa-cog me-2"></i>Technical Details
                        </h6>
                        <div className="row g-2 text-sm">
                          <div className="col-6">
                            <small className="text-muted d-block">Icon Type:</small>
                            <small className="fw-medium">{iconType === 'image' ? 'Custom Image' : 'Icon Class'}</small>
                          </div>
                          <div className="col-6">
                            <small className="text-muted d-block">Color:</small>
                            <div className="d-flex align-items-center">
                              <div 
                                className="rounded me-2"
                                style={{ 
                                  width: '16px', 
                                  height: '16px', 
                                  backgroundColor: formData.color || '#007bff',
                                  border: '1px solid #dee2e6'
                                }}
                              ></div>
                              <small className="fw-medium">{formData.color || '#007bff'}</small>
                            </div>
                          </div>
                          {iconType === 'image' ? (
                            <div className="col-12">
                              <small className="text-muted d-block">Source:</small>
                              <small className="fw-medium text-truncate d-block">
                                {formData.image || imagePreview || 'No image selected'}
                              </small>
                            </div>
                          ) : (
                            <div className="col-12">
                              <small className="text-muted d-block">Class:</small>
                              <small className="fw-medium">
                                {formData.iconClass || 'No icon class specified'}
                              </small>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacteristicForm;
