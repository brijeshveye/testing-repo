import React, { useState, useEffect } from 'react';
import { showSuccess, showError } from '../../utils/toastUtils';

const ContactList = () => {
    const [contacts, setContacts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [pagination, setPagination] = useState({
        page: 1,
        limit: 10,
        total: 0,
        pages: 0
    });
    const [statusFilter, setStatusFilter] = useState('');
    const [updating, setUpdating] = useState({});

    useEffect(() => {
        fetchContacts();
    }, [pagination.page, statusFilter]);

    const fetchContacts = async () => {
        try {
            setLoading(true);
            const query = new URLSearchParams({
                page: pagination.page,
                limit: pagination.limit,
                ...(statusFilter && { status: statusFilter })
            });

            const response = await fetch(`/api/contact?${query}`);
            const result = await response.json();

            if (result.success) {
                setContacts(result.data);
                setPagination(result.pagination);
            } else {
                showError('Failed to fetch contacts');
            }
        } catch (error) {
            console.error('Error fetching contacts:', error);
            showError('Failed to fetch contacts');
        } finally {
            setLoading(false);
        }
    };

    const updateStatus = async (contactId, newStatus) => {
        setUpdating(prev => ({ ...prev, [contactId]: true }));

        try {
            const response = await fetch(`/api/contact/${contactId}/status`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ status: newStatus })
            });

            const result = await response.json();

            if (result.success) {
                showSuccess('Status updated successfully');
                fetchContacts();
            } else {
                showError(result.message || 'Failed to update status');
            }
        } catch (error) {
            console.error('Error updating status:', error);
            showError('Failed to update status');
        } finally {
            setUpdating(prev => ({ ...prev, [contactId]: false }));
        }
    };

    const deleteContact = async (contactId) => {
        if (!window.confirm('Are you sure you want to delete this contact?')) {
            return;
        }

        try {
            const response = await fetch(`/api/contact/${contactId}`, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                showSuccess('Contact deleted successfully');
                fetchContacts();
            } else {
                showError(result.message || 'Failed to delete contact');
            }
        } catch (error) {
            console.error('Error deleting contact:', error);
            showError('Failed to delete contact');
        }
    };

    const getStatusBadge = (status) => {
        const badges = {
            'new': 'badge bg-primary',
            'read': 'badge bg-info',
            'replied': 'badge bg-success',
            'archived': 'badge bg-secondary'
        };
        return badges[status] || 'badge bg-secondary';
    };

    if (loading) {
        return (
            <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
                <div className="row justify-content-center">
                    <div className="col-12">
                        <div className="d-flex justify-content-center align-items-center" style={{ height: '400px' }}>
                            <div className="text-center">
                                <div className="spinner-border text-primary" style={{ width: '3rem', height: '3rem' }} role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                                <p className="mt-3 text-muted">Loading contact messages...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
            <div className="row justify-content-center">
                <div className="col-12 col-xl-11">
                    {/* Header Card */}
                    <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
                        <div className="card-body py-4">
                            <div className="d-flex align-items-center justify-content-between">
                                <div className="d-flex align-items-center">
                                    <div className="me-3">
                                        <div 
                                            className="rounded-circle d-flex align-items-center justify-content-center"
                                            style={{ 
                                                width: '60px', 
                                                height: '60px', 
                                                backgroundColor: '#28a745',
                                                color: 'white'
                                            }}
                                        >
                                            <i className="fas fa-envelope fs-3"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <h2 className="mb-1 text-dark fw-bold">Contact Messages</h2>
                                        <p className="text-muted mb-0">Manage and respond to website inquiries</p>
                                    </div>
                                </div>
                                <div className="d-flex gap-2">
                                    <select 
                                        className="form-select"
                                        value={statusFilter}
                                        onChange={(e) => setStatusFilter(e.target.value)}
                                        style={{ minWidth: '150px' }}
                                    >
                                        <option value="">All Status</option>
                                        <option value="new">New</option>
                                        <option value="read">Read</option>
                                        <option value="replied">Replied</option>
                                        <option value="archived">Archived</option>
                                    </select>
                                    <button 
                                        className="btn btn-primary rounded-pill px-4"
                                        onClick={() => fetchContacts()}
                                        style={{ backgroundColor: '#28a745', border: 'none' }}
                                    >
                                        <i className="fas fa-sync-alt me-2"></i>Refresh
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Stats Cards */}
                    <div className="row mb-4">
                        <div className="col-md-3 mb-3">
                            <div className="card border-0 bg-primary bg-opacity-10 h-100">
                                <div className="card-body text-center py-4">
                                    <div
                                        className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                        style={{
                                            width: '50px',
                                            height: '50px',
                                            backgroundColor: '#0d6efd',
                                            color: 'white'
                                        }}
                                    >
                                        <i className="fas fa-inbox"></i>
                                    </div>
                                    <h4 className="fw-bold text-primary mb-1">{pagination.total || 0}</h4>
                                    <p className="text-muted mb-0 small">Total Messages</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-3 mb-3">
                            <div className="card border-0 bg-warning bg-opacity-10 h-100">
                                <div className="card-body text-center py-4">
                                    <div
                                        className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                        style={{
                                            width: '50px',
                                            height: '50px',
                                            backgroundColor: '#ffc107',
                                            color: 'white'
                                        }}
                                    >
                                        <i className="fas fa-star"></i>
                                    </div>
                                    <h4 className="fw-bold text-warning mb-1">{contacts.filter(c => c.status === 'new').length}</h4>
                                    <p className="text-muted mb-0 small">New Messages</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-3 mb-3">
                            <div className="card border-0 bg-success bg-opacity-10 h-100">
                                <div className="card-body text-center py-4">
                                    <div
                                        className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                        style={{
                                            width: '50px',
                                            height: '50px',
                                            backgroundColor: '#198754',
                                            color: 'white'
                                        }}
                                    >
                                        <i className="fas fa-check"></i>
                                    </div>
                                    <h4 className="fw-bold text-success mb-1">{contacts.filter(c => c.status === 'replied').length}</h4>
                                    <p className="text-muted mb-0 small">Replied</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-3 mb-3">
                            <div className="card border-0 bg-info bg-opacity-10 h-100">
                                <div className="card-body text-center py-4">
                                    <div
                                        className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                        style={{
                                            width: '50px',
                                            height: '50px',
                                            backgroundColor: '#0dcaf0',
                                            color: 'white'
                                        }}
                                    >
                                        <i className="fas fa-eye"></i>
                                    </div>
                                    <h4 className="fw-bold text-info mb-1">{contacts.filter(c => c.status === 'read').length}</h4>
                                    <p className="text-muted mb-0 small">Read</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Main Content Card */}
                    <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
                        <div className="card-body p-0">
                            {contacts.length === 0 ? (
                                <div className="text-center py-5">
                                    <div 
                                        className="rounded-circle mx-auto mb-4 d-flex align-items-center justify-content-center"
                                        style={{
                                            width: '100px',
                                            height: '100px',
                                            backgroundColor: '#f8f9fa',
                                            border: '3px solid #e9ecef'
                                        }}
                                    >
                                        <i className="fas fa-inbox text-muted" style={{ fontSize: '2.5rem' }}></i>
                                    </div>
                                    <h4 className="text-muted mb-2">No Contact Messages</h4>
                                    <p className="text-muted">No contact messages found. When visitors submit the contact form, they will appear here.</p>
                                </div>
                            ) : (
                                <>
                                    <div className="table-responsive">
                                        <table className="table table-hover mb-0">
                                            <thead style={{ backgroundColor: '#f8f9fa' }}>
                                                <tr>
                                                    <th className="border-0 fw-bold text-dark py-3 px-4" style={{ borderRadius: '16px 0 0 0' }}>
                                                        <i className="fas fa-user me-2 text-muted"></i>Name
                                                    </th>
                                                    <th className="border-0 fw-bold text-dark py-3">
                                                        <i className="fas fa-envelope me-2 text-muted"></i>Email
                                                    </th>
                                                    <th className="border-0 fw-bold text-dark py-3">
                                                        <i className="fas fa-tag me-2 text-muted"></i>Subject
                                                    </th>
                                                    <th className="border-0 fw-bold text-dark py-3">
                                                        <i className="fas fa-info-circle me-2 text-muted"></i>Status
                                                    </th>
                                                    <th className="border-0 fw-bold text-dark py-3">
                                                        <i className="fas fa-calendar me-2 text-muted"></i>Date
                                                    </th>
                                                    <th className="border-0 fw-bold text-dark py-3 px-4" style={{ borderRadius: '0 16px 0 0' }}>
                                                        <i className="fas fa-cogs me-2 text-muted"></i>Actions
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {contacts.map((contact, index) => (
                                                    <tr key={contact._id} style={{ borderLeft: `4px solid ${contact.status === 'new' ? '#ffc107' : contact.status === 'replied' ? '#198754' : contact.status === 'read' ? '#0dcaf0' : '#6c757d'}` }}>
                                                        <td className="py-3 px-4">
                                                            <div className="d-flex align-items-center">
                                                                <div 
                                                                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                                                                    style={{
                                                                        width: '40px',
                                                                        height: '40px',
                                                                        backgroundColor: '#e9ecef',
                                                                        color: '#6c757d'
                                                                    }}
                                                                >
                                                                    {contact.name.charAt(0).toUpperCase()}
                                                                </div>
                                                                <div>
                                                                    <div className="fw-medium text-dark">{contact.name}</div>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td className="py-3">
                                                            <a href={`mailto:${contact.email}`} className="text-decoration-none text-primary">
                                                                {contact.email}
                                                            </a>
                                                        </td>
                                                        <td className="py-3">
                                                            <div className="text-dark fw-medium" style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                                                {contact.subject}
                                                            </div>
                                                        </td>
                                                        <td className="py-3">
                                                            <span className={`badge rounded-pill ${getStatusBadge(contact.status).replace('badge', '').trim()}`}>
                                                                {contact.status.charAt(0).toUpperCase() + contact.status.slice(1)}
                                                            </span>
                                                        </td>
                                                        <td className="py-3">
                                                            <small className="text-muted">
                                                                {new Date(contact.createdAt).toLocaleDateString('en-US', {
                                                                    year: 'numeric',
                                                                    month: 'short',
                                                                    day: 'numeric'
                                                                })}
                                                            </small>
                                                        </td>
                                                        <td className="py-3 px-4">
                                                            <div className="btn-group">
                                                                <button
                                                                    className="btn btn-sm btn-outline-info rounded-pill me-1"
                                                                    onClick={() => updateStatus(contact._id, 'read')}
                                                                    disabled={updating[contact._id] || contact.status === 'read'}
                                                                    title="Mark as Read"
                                                                >
                                                                    <i className="fas fa-eye"></i>
                                                                </button>
                                                                <button
                                                                    className="btn btn-sm btn-outline-success rounded-pill me-1"
                                                                    onClick={() => updateStatus(contact._id, 'replied')}
                                                                    disabled={updating[contact._id] || contact.status === 'replied'}
                                                                    title="Mark as Replied"
                                                                >
                                                                    <i className="fas fa-reply"></i>
                                                                </button>
                                                                <button
                                                                    className="btn btn-sm btn-outline-danger rounded-pill"
                                                                    onClick={() => deleteContact(contact._id)}
                                                                    title="Delete Message"
                                                                >
                                                                    <i className="fas fa-trash"></i>
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>

                                    {/* Pagination */}
                                    {pagination.pages > 1 && (
                                        <div className="card-footer bg-white border-0 py-4">
                                            <nav className="d-flex justify-content-center">
                                                <ul className="pagination pagination-sm mb-0">
                                                    <li className={`page-item ${pagination.page === 1 ? 'disabled' : ''}`}>
                                                        <button 
                                                            className="page-link rounded-pill me-1"
                                                            onClick={() => setPagination(prev => ({ ...prev, page: prev.page - 1 }))}
                                                            disabled={pagination.page === 1}
                                                        >
                                                            <i className="fas fa-chevron-left"></i>
                                                        </button>
                                                    </li>
                                                    {[...Array(pagination.pages)].map((_, index) => (
                                                        <li key={index} className={`page-item ${pagination.page === index + 1 ? 'active' : ''}`}>
                                                            <button 
                                                                className="page-link rounded-pill mx-1"
                                                                onClick={() => setPagination(prev => ({ ...prev, page: index + 1 }))}
                                                                style={pagination.page === index + 1 ? { backgroundColor: '#28a745', borderColor: '#28a745' } : {}}
                                                            >
                                                                {index + 1}
                                                            </button>
                                                        </li>
                                                    ))}
                                                    <li className={`page-item ${pagination.page === pagination.pages ? 'disabled' : ''}`}>
                                                        <button 
                                                            className="page-link rounded-pill ms-1"
                                                            onClick={() => setPagination(prev => ({ ...prev, page: prev.page + 1 }))}
                                                            disabled={pagination.page === pagination.pages}
                                                        >
                                                            <i className="fas fa-chevron-right"></i>
                                                        </button>
                                                    </li>
                                                </ul>
                                            </nav>
                                        </div>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ContactList;
