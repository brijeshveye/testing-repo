import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import './BackupRestore.css';
import { showSuccess, showError, showWarning } from '../../utils/toastUtils';

const BackupRestoreSection = () => {
    const [loading, setLoading] = useState({});
    const [status, setStatus] = useState({});
    const downloadLinkRef = useRef(null);

    const dataModels = [
        {
            id: 'projects',
            name: 'Projects',
            description: 'Portfolio projects and their details',
            icon: 'fas fa-code',
            color: '#007bff',
            endpoint: '/api/projects'
        },
        {
            id: 'blogs',
            name: 'Blogs',
            description: 'Blog posts and articles',
            icon: 'fas fa-blog',
            color: '#28a745',
            endpoint: '/api/blogs'
        },
        {
            id: 'certificates',
            name: 'Certificates',
            description: 'Professional certifications',
            icon: 'fas fa-certificate',
            color: '#ffc107',
            endpoint: '/api/certificates'
        },
        {
            id: 'skills',
            name: 'Skills',
            description: 'Technical and professional skills',
            icon: 'fas fa-tools',
            color: '#17a2b8',
            endpoint: '/api/skills'
        },
        {
            id: 'experience',
            name: 'Experience',
            description: 'Work experience and employment history',
            icon: 'fas fa-briefcase',
            color: '#6f42c1',
            endpoint: '/api/experience'
        },
        {
            id: 'education',
            name: 'Education',
            description: 'Educational background and qualifications',
            icon: 'fas fa-graduation-cap',
            color: '#e83e8c',
            endpoint: '/api/education'
        },
        {
            id: 'services',
            name: 'Services',
            description: 'Services offered and their details',
            icon: 'fas fa-cogs',
            color: '#fd7e14',
            endpoint: '/api/services'
        },
        {
            id: 'testimonials',
            name: 'Testimonials',
            description: 'Client feedback and testimonials',
            icon: 'fas fa-comments',
            color: '#20c997',
            endpoint: '/api/testimonials'
        },
        {
            id: 'characteristics',
            name: 'Characteristics',
            description: 'Personal characteristics and traits',
            icon: 'fas fa-user-circle',
            color: '#6c757d',
            endpoint: '/api/characteristics'
        },
        {
            id: 'user',
            name: 'User Profile',
            description: 'Personal information and social links',
            icon: 'fas fa-user',
            color: '#dc3545',
            endpoint: '/api/user'
        }
    ];

    const handleBackup = async (model) => {
        setLoading(prev => ({ ...prev, [`backup_${model.id}`]: true }));

        try {
            const response = await axios.get(`${model.endpoint}/backup`, {
                responseType: 'blob'
            });

            // Check if we received a valid blob response
            if (!response.data) {
                throw new Error('No data received from server');
            }

            // Check if the response is actually an error (sometimes error responses come as blobs)
            if (response.data.type === 'application/json' && response.data.size < 100) {
                const text = await response.data.text();
                try {
                    const errorData = JSON.parse(text);
                    if (errorData.message) {
                        throw new Error(errorData.message);
                    }
                } catch (parseError) {
                    // If it's not JSON, continue with download
                }
            }

            // Create download link only if we have valid data
            const blob = new Blob([response.data], { type: 'application/json' });
            const url = window.URL.createObjectURL(blob);

            // Use the ref to safely trigger download
            const downloadFileName = `${model.id}_backup_${new Date().toISOString().split('T')[0]}.json`;

            if (downloadLinkRef.current) {
                downloadLinkRef.current.href = url;
                downloadLinkRef.current.download = downloadFileName;
                downloadLinkRef.current.click();
            }

            // Clean up the URL after download
            setTimeout(() => {
                window.URL.revokeObjectURL(url);
            }, 1000);

            showSuccess(`${model.name} data backed up successfully!`);
        } catch (err) {
            console.error('Backup error:', err);

            // Handle different types of errors
            let errorMessage = 'Unknown error occurred';

            if (err.response) {
                // Server responded with an error status
                if (err.response.data instanceof Blob) {
                    // Handle blob error responses
                    try {
                        const text = await err.response.data.text();
                        const errorData = JSON.parse(text);
                        errorMessage = errorData.message || `Server error: ${err.response.status}`;
                    } catch (parseError) {
                        errorMessage = `Server error: ${err.response.status}`;
                    }
                } else if (err.response.data && typeof err.response.data === 'string') {
                    errorMessage = err.response.data;
                } else if (err.response.data && err.response.data.message) {
                    errorMessage = err.response.data.message;
                } else {
                    errorMessage = `Server error: ${err.response.status}`;
                }
            } else if (err.message) {
                // Error thrown by our code or network error
                errorMessage = err.message;
            }

            showError(`Failed to backup ${model.name}: ${errorMessage}`);
        } finally {
            setLoading(prev => ({ ...prev, [`backup_${model.id}`]: false }));
        }
    };

    const handleRestore = async (model, file) => {
        setLoading(prev => ({ ...prev, [`restore_${model.id}`]: true }));

        try {
            const formData = new FormData();
            formData.append('file', file);

            const response = await axios.post(`${model.endpoint}/restore`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });

            showSuccess(`${model.name} data restored successfully! ${response.data.message}`);
        } catch (err) {
            showError(`Failed to restore ${model.name}: ${err.response?.data?.message || err.message}`);
        } finally {
            setLoading(prev => ({ ...prev, [`restore_${model.id}`]: false }));
        }
    };

    const handleReset = async (model) => {
        if (!window.confirm(`Are you sure you want to reset all ${model.name} data? This action cannot be undone.`)) {
            return;
        }

        setLoading(prev => ({ ...prev, [`reset_${model.id}`]: true }));

        try {
            const response = await axios.delete(`${model.endpoint}/reset`);
            showSuccess(`${model.name} data reset successfully! ${response.data.message}`);
        } catch (err) {
            showError(`Failed to reset ${model.name}: ${err.response?.data?.message || err.message}`);
        } finally {
            setLoading(prev => ({ ...prev, [`reset_${model.id}`]: false }));
        }
    };

    const handleFileSelect = (model, event) => {
        const file = event.target.files[0];
        if (file) {
            if (file.type !== 'application/json') {
                showError('Please select a valid JSON file');
                return;
            }
            handleRestore(model, file);
        }
    };

    const handleBulkBackup = async () => {
        setLoading(prev => ({ ...prev, bulk_backup: true }));

        try {
            const response = await axios.get('/api/backup/all', {
                responseType: 'blob'
            });

            // Check if we received a valid blob response
            if (!response.data) {
                throw new Error('No data received from server');
            }

            // Check if the response is actually an error (sometimes error responses come as blobs)
            if (response.data.type === 'application/json' && response.data.size < 100) {
                const text = await response.data.text();
                try {
                    const errorData = JSON.parse(text);
                    if (errorData.message) {
                        throw new Error(errorData.message);
                    }
                } catch (parseError) {
                    // If it's not JSON, continue with download
                }
            }

            const blob = new Blob([response.data], { type: 'application/zip' });
            const url = window.URL.createObjectURL(blob);

            // Use the ref to safely trigger download
            const downloadFileName = `portfolio_backup_${new Date().toISOString().split('T')[0]}.zip`;

            if (downloadLinkRef.current) {
                downloadLinkRef.current.href = url;
                downloadLinkRef.current.download = downloadFileName;
                downloadLinkRef.current.click();
            }

            // Clean up the URL after download
            setTimeout(() => {
                window.URL.revokeObjectURL(url);
            }, 1000);

            showSuccess('All data backed up successfully!');
        } catch (err) {
            console.error('Bulk backup error:', err);

            // Handle different types of errors
            let errorMessage = 'Unknown error occurred';

            if (err.response) {
                // Server responded with an error status
                if (err.response.data instanceof Blob) {
                    // Handle blob error responses
                    try {
                        const text = await err.response.data.text();
                        const errorData = JSON.parse(text);
                        errorMessage = errorData.message || `Server error: ${err.response.status}`;
                    } catch (parseError) {
                        errorMessage = `Server error: ${err.response.status}`;
                    }
                } else if (err.response.data && typeof err.response.data === 'string') {
                    errorMessage = err.response.data;
                } else if (err.response.data && err.response.data.message) {
                    errorMessage = err.response.data.message;
                } else {
                    errorMessage = `Server error: ${err.response.status}`;
                }
            } else if (err.message) {
                // Error thrown by our code or network error
                errorMessage = err.message;
            }

            showError(`Failed to create bulk backup: ${errorMessage}`);
        } finally {
            setLoading(prev => ({ ...prev, bulk_backup: false }));
        }
    };

    const handleMigrateSampleData = async () => {
        if (!window.confirm('Are you sure you want to migrate sample data? This will populate the database with example content. Existing data will be cleared and replaced.')) {
            return;
        }

        setLoading(prev => ({ ...prev, migrate_sample: true }));

        try {
            const response = await axios.post('/api/migration/sample-data');
            
            if (response.data.success) {
                showSuccess('Sample data migrated successfully! Database has been populated with example content.');
            } else {
                throw new Error(response.data.message || 'Migration failed');
            }
        } catch (err) {
            console.error('Migration error:', err);
            const errorMessage = err.response?.data?.message || err.message || 'Failed to migrate sample data';
            showError(`Migration failed: ${errorMessage}`);
        } finally {
            setLoading(prev => ({ ...prev, migrate_sample: false }));
        }
    };

    return (
        <div className="backup-restore-container">
            {/* Hidden download link */}
            <a
                ref={downloadLinkRef}
                style={{ display: 'none' }}
                download
                href="#"
            >
                Download
            </a>

            <div className="container-fluid">
                <div className="row">
                    <div className="col-12">
                        {/* Header Section - Material Card Design */}
                        <div className="card border-0 shadow-sm mb-5" style={{ borderRadius: '16px' }}>
                            <div className="card-body text-center py-5">
                                {/* Icon Container */}
                                <div
                                    className="d-inline-flex align-items-center justify-content-center mb-4 rounded-circle"
                                    style={{
                                        width: '100px',
                                        height: '100px',
                                        backgroundColor: '#f8f9fa',
                                        border: '3px solid #e9ecef'
                                    }}
                                >
                                    <i className="fas fa-database text-primary" style={{ fontSize: '2.5rem' }}></i>
                                </div>

                                {/* Title and Description */}
                                <div>
                                    <h1 className="display-6 fw-bold mb-3 text-dark">
                                        Backup & Restore Center
                                    </h1>
                                    <p className="lead text-muted mb-4" style={{ fontSize: '1.1rem', maxWidth: '600px', margin: '0 auto' }}>
                                        Securely manage your portfolio data with comprehensive backup, restore, reset, and sample data migration operations for individual sections
                                    </p>

                                    {/* Feature Highlights */}
                                    <div className="row justify-content-center mt-4">
                                        <div className="col-lg-10">
                                            <div className="row g-3">
                                                <div className="col-md-3">
                                                    <div className="p-3 bg-light rounded-3 h-100">
                                                        <i className="fas fa-shield-alt text-success mb-2" style={{ fontSize: '1.5rem' }}></i>
                                                        <h6 className="fw-bold text-dark mb-1">Secure Backup</h6>
                                                        <small className="text-muted">Protected data export</small>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="p-3 bg-light rounded-3 h-100">
                                                        <i className="fas fa-history text-info mb-2" style={{ fontSize: '1.5rem' }}></i>
                                                        <h6 className="fw-bold text-dark mb-1">One-Click Restore</h6>
                                                        <small className="text-muted">Easy data recovery</small>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="p-3 bg-light rounded-3 h-100">
                                                        <i className="fas fa-layer-group text-warning mb-2" style={{ fontSize: '1.5rem' }}></i>
                                                        <h6 className="fw-bold text-dark mb-1">Bulk Operations</h6>
                                                        <small className="text-muted">Multiple section support</small>
                                                    </div>
                                                </div>
                                                <div className="col-md-3">
                                                    <div className="p-3 bg-light rounded-3 h-100">
                                                        <i className="fas fa-database text-primary mb-2" style={{ fontSize: '1.5rem' }}></i>
                                                        <h6 className="fw-bold text-dark mb-1">Sample Migration</h6>
                                                        <small className="text-muted">Demo content setup</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Quick Stats Cards */}
                        <div className="row mb-4">
                            <div className="col-md-3 mb-3">
                                <div className="card border-0 bg-primary bg-opacity-10 h-100">
                                    <div className="card-body text-center py-4">
                                        <div
                                            className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                            style={{
                                                width: '60px',
                                                height: '60px',
                                                backgroundColor: '#0d6efd',
                                                color: 'white'
                                            }}
                                        >
                                            <i className="fas fa-download"></i>
                                        </div>
                                        <h5 className="fw-bold text-dark mb-1">Individual Backup</h5>
                                        <p className="text-muted mb-0 small">Export specific data sections as JSON files</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 mb-3">
                                <div className="card border-0 bg-success bg-opacity-10 h-100">
                                    <div className="card-body text-center py-4">
                                        <div
                                            className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                            style={{
                                                width: '60px',
                                                height: '60px',
                                                backgroundColor: '#198754',
                                                color: 'white'
                                            }}
                                        >
                                            <i className="fas fa-upload"></i>
                                        </div>
                                        <h5 className="fw-bold text-dark mb-1">Smart Restore</h5>
                                        <p className="text-muted mb-0 small">Import and validate JSON data safely</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 mb-3">
                                <div className="card border-0 bg-danger bg-opacity-10 h-100">
                                    <div className="card-body text-center py-4">
                                        <div
                                            className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                            style={{
                                                width: '60px',
                                                height: '60px',
                                                backgroundColor: '#dc3545',
                                                color: 'white'
                                            }}
                                        >
                                            <i className="fas fa-redo"></i>
                                        </div>
                                        <h5 className="fw-bold text-dark mb-1">Safe Reset</h5>
                                        <p className="text-muted mb-0 small">Clean slate with confirmation dialogs</p>
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-3 mb-3">
                                <div className="card border-0 bg-warning bg-opacity-10 h-100">
                                    <div className="card-body text-center py-4">
                                        <div
                                            className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                                            style={{
                                                width: '60px',
                                                height: '60px',
                                                backgroundColor: '#ffc107',
                                                color: 'white'
                                            }}
                                        >
                                            <i className="fas fa-database"></i>
                                        </div>
                                        <h5 className="fw-bold text-dark mb-1">Sample Migration</h5>
                                        <p className="text-muted mb-0 small">Populate database with example content</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Bulk Operations */}
                        <div className="card mb-4 bulk-operations-card">
                            <div className="card-body">
                                <h4 className="card-title">
                                    <i className="fas fa-layer-group me-2"></i>
                                    Bulk Operations
                                </h4>
                                <p className="card-text">Perform operations on all data sections at once, including backup and sample data migration</p>
                                <div className="d-flex gap-2 flex-wrap">
                                    <button
                                        className="btn btn-primary"
                                        onClick={handleBulkBackup}
                                        disabled={loading.bulk_backup}
                                    >
                                        <span className="me-1" style={{ display: loading.bulk_backup ? 'inline-block' : 'none' }}>
                                            <span className="spinner-border spinner-border-sm"></span>
                                        </span>
                                        <span className="me-1" style={{ display: !loading.bulk_backup ? 'inline-block' : 'none' }}>
                                            <i className="fas fa-download"></i>
                                        </span>
                                        {loading.bulk_backup ? 'Creating Backup...' : 'Backup All Data'}
                                    </button>
                                    
                                    <button
                                        className="btn btn-warning"
                                        onClick={handleMigrateSampleData}
                                        disabled={loading.migrate_sample}
                                    >
                                        <span className="me-1" style={{ display: loading.migrate_sample ? 'inline-block' : 'none' }}>
                                            <span className="spinner-border spinner-border-sm"></span>
                                        </span>
                                        <span className="me-1" style={{ display: !loading.migrate_sample ? 'inline-block' : 'none' }}>
                                            <i className="fas fa-database"></i>
                                        </span>
                                        {loading.migrate_sample ? 'Migrating...' : 'Migrate Sample Data'}
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* Individual Section Cards */}
                        <div className="row">
                            {dataModels.map((model) => (
                                <div key={model.id} className="col-xl-4 col-lg-6 col-md-6 mb-4">
                                    <div className="card data-section-card h-100">
                                        <div className="card-body">
                                            <div className="d-flex align-items-center mb-3">
                                                <div
                                                    className="icon-wrapper me-3"
                                                    style={{ backgroundColor: `${model.color}20`, color: model.color }}
                                                >
                                                    <i className={model.icon}></i>
                                                </div>
                                                <div>
                                                    <h5 className="card-title mb-0">{model.name}</h5>
                                                    <small className="text-muted">{model.description}</small>
                                                </div>
                                            </div>

                                            <div className="action-buttons">
                                                {/* Backup Button */}
                                                <button
                                                    className="btn btn-outline-success btn-sm mb-2"
                                                    onClick={() => handleBackup(model)}
                                                    disabled={loading[`backup_${model.id}`]}
                                                >
                                                    <span className="me-1" style={{ display: loading[`backup_${model.id}`] ? 'inline-block' : 'none' }}>
                                                        <span className="spinner-border spinner-border-sm"></span>
                                                    </span>
                                                    <span className="me-1" style={{ display: !loading[`backup_${model.id}`] ? 'inline-block' : 'none' }}>
                                                        <i className="fas fa-download"></i>
                                                    </span>
                                                    {loading[`backup_${model.id}`] ? 'Backing up...' : 'Backup'}
                                                </button>

                                                {/* Restore Button */}
                                                <div className="restore-section mb-2">
                                                    <label className="btn btn-outline-info btn-sm">
                                                        <span className="me-1" style={{ display: loading[`restore_${model.id}`] ? 'inline-block' : 'none' }}>
                                                            <span className="spinner-border spinner-border-sm"></span>
                                                        </span>
                                                        <span className="me-1" style={{ display: !loading[`restore_${model.id}`] ? 'inline-block' : 'none' }}>
                                                            <i className="fas fa-upload"></i>
                                                        </span>
                                                        {loading[`restore_${model.id}`] ? 'Restoring...' : 'Restore'}
                                                        <input
                                                            type="file"
                                                            accept=".json"
                                                            onChange={(e) => handleFileSelect(model, e)}
                                                            disabled={loading[`restore_${model.id}`]}
                                                            style={{ display: 'none' }}
                                                        />
                                                    </label>
                                                </div>

                                                {/* Reset Button */}
                                                <button
                                                    className="btn btn-outline-danger btn-sm"
                                                    onClick={() => handleReset(model)}
                                                    disabled={loading[`reset_${model.id}`]}
                                                >
                                                    <span className="me-1" style={{ display: loading[`reset_${model.id}`] ? 'inline-block' : 'none' }}>
                                                        <span className="spinner-border spinner-border-sm"></span>
                                                    </span>
                                                    <span className="me-1" style={{ display: !loading[`reset_${model.id}`] ? 'inline-block' : 'none' }}>
                                                        <i className="fas fa-trash"></i>
                                                    </span>
                                                    {loading[`reset_${model.id}`] ? 'Resetting...' : 'Reset'}
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BackupRestoreSection;
