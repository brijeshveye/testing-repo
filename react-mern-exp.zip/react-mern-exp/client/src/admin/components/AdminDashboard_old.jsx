import React from 'react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-11">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center">
                <div className="me-3">
                  <div 
                    className="rounded-circle d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '60px', 
                      height: '60px', 
                      backgroundColor: '#1976d2',
                      color: 'white'
                    }}
                  >
                    <i className="fas fa-tachometer-alt fs-3"></i>
                  </div>
                </div>
                <div>
                  <h2 className="mb-1 text-dark fw-bold">Admin Dashboard</h2>
                  <p className="text-muted mb-0">Welcome to your admin panel. Manage your portfolio content from here.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Management Cards */}
          <div className="row g-4 mb-5">
        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-user fa-3x text-primary"></i>
              </div>
              <h5 className="card-title">About</h5>
              <p className="card-text">Manage your personal information, education, skills, and experience.</p>
              <Link to="/admin/user" className="btn btn-primary">
                Manage Profile
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-code fa-3x text-info"></i>
              </div>
              <h5 className="card-title">Skills</h5>
              <p className="card-text">Manage your technical skills and expertise levels.</p>
              <Link to="/admin/skills" className="btn btn-info">
                Manage Skills
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-briefcase fa-3x text-secondary"></i>
              </div>
              <h5 className="card-title">Experience</h5>
              <p className="card-text">Manage your professional work experience and career history.</p>
              <Link to="/admin/experience" className="btn btn-secondary">
                Manage Experience
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-star fa-3x text-warning"></i>
              </div>
              <h5 className="card-title">Characteristics</h5>
              <p className="card-text">Manage your personal and professional characteristics.</p>
              <Link to="/admin/characteristics" className="btn btn-warning">
                Manage Characteristics
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-graduation-cap fa-3x text-primary"></i>
              </div>
              <h5 className="card-title">Education</h5>
              <p className="card-text">Manage your educational background and qualifications.</p>
              <Link to="/admin/education" className="btn btn-primary">
                Manage Education
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-cogs fa-3x text-dark"></i>
              </div>
              <h5 className="card-title">Services</h5>
              <p className="card-text">Manage your service offerings and pricing packages.</p>
              <Link to="/admin/services" className="btn btn-dark">
                Manage Services
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-certificate fa-3x text-success"></i>
              </div>
              <h5 className="card-title">Certificates</h5>
              <p className="card-text">Manage your professional certifications and achievements.</p>
              <Link to="/admin/certificates" className="btn btn-success">
                Manage Certificates
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-project-diagram fa-3x text-success"></i>
              </div>
              <h5 className="card-title">Projects</h5>
              <p className="card-text">Create, edit, and manage your portfolio projects and showcase your work.</p>
              <Link to="/admin/projects" className="btn btn-success">
                Manage Projects
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-quote-right fa-3x text-warning"></i>
              </div>
              <h5 className="card-title">Testimonials</h5>
              <p className="card-text">Manage client testimonials and feedback to showcase your work.</p>
              <Link to="/admin/testimonials" className="btn btn-warning">
                Manage Testimonials
              </Link>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card h-100 shadow-sm">
            <div className="card-body text-center">
              <div className="mb-3">
                <i className="fas fa-blog fa-3x text-info"></i>
              </div>
              <h5 className="card-title">Blog Posts</h5>
              <p className="card-text">Write and publish blog posts to share your thoughts and expertise.</p>
              <Link to="/admin/blogs" className="btn btn-info">
                Manage Blogs
              </Link>
            </div>
          </div>
        </div>

      </div>


      <div className="row mt-5">
        <div className="col-12">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">Quick Actions</h5>
            </div>
            <div className="card-body">
              <div className="row">
                <div className="col-md-3 mb-2">
                  <Link to="/admin/skills/create" className="btn btn-outline-info w-100">
                    <i className="fas fa-plus me-2"></i>New Skill
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/experience/create" className="btn btn-outline-secondary w-100">
                    <i className="fas fa-plus me-2"></i>New Experience
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/characteristics/create" className="btn btn-outline-warning w-100">
                    <i className="fas fa-plus me-2"></i>New Characteristic
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/education/create" className="btn btn-outline-primary w-100">
                    <i className="fas fa-plus me-2"></i>New Education
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/services/create" className="btn btn-outline-dark w-100">
                    <i className="fas fa-plus me-2"></i>New Service
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/certificates/create" className="btn btn-outline-success w-100">
                    <i className="fas fa-plus me-2"></i>New Certificate
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/projects/create" className="btn btn-outline-success w-100">
                    <i className="fas fa-plus me-2"></i>New Project
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/testimonials/create" className="btn btn-outline-warning w-100">
                    <i className="fas fa-plus me-2"></i>New Testimonial
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/blogs/create" className="btn btn-outline-info w-100">
                    <i className="fas fa-plus me-2"></i>New Blog Post
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <Link to="/admin/user/upload-resume" className="btn btn-outline-primary w-100">
                    <i className="fas fa-file-pdf me-2"></i>Upload Resume
                  </Link>
                </div>
                
                <div className="col-md-3 mb-2">
                  <Link to="/" className="btn btn-outline-primary w-100">
                    <i className="fas fa-eye me-2"></i>View Website
                  </Link>
                </div>
                <div className="col-md-3 mb-2">
                  <button
                    onClick={() => {
                      localStorage.removeItem('adminToken');
                      localStorage.removeItem('adminSession');
                      window.location.href = '/';
                    }}
                    className="btn btn-outline-danger w-100"
                  >
                    <i className="fas fa-sign-out-alt me-2"></i>Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
