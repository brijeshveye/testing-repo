import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const UserDashboard = () => {
  const [userData, setUserData] = useState(null);

  const fetchUserData = async () => {
    const res = await axios.get('/api/user');
    setUserData(res.data);
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  if (!userData) return <div className="container mt-5">Loading...</div>;

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-10">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center">
                <div className="me-3">
                  <div 
                    className="rounded-circle d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '60px', 
                      height: '60px', 
                      backgroundColor: '#1976d2',
                      color: 'white'
                    }}
                  >
                    <i className="fas fa-user-circle fs-3"></i>
                  </div>
                </div>
                <div>
                  <h2 className="mb-1 text-dark fw-bold">User Profile Dashboard</h2>
                  <p className="text-muted mb-0">Manage your personal and professional information</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content Grid */}
          <div className="row g-4">
            {/* Personal Information Card */}
            {userData.aboutData && (
              <div className="col-12 col-lg-8">
                <div className="card shadow-sm border-0 h-100" style={{ borderRadius: '16px' }}>
                  <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                    <div className="d-flex align-items-center justify-content-between">
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '48px', 
                            height: '48px', 
                            backgroundColor: '#e3f2fd'
                          }}
                        >
                          <i className="fas fa-id-card text-primary fs-5"></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Personal Information</h5>
                          <small className="text-muted">Your basic details and contact information</small>
                        </div>
                      </div>
                      <Link 
                        to="/admin/user/edit/aboutData" 
                        className="btn btn-outline-primary btn-sm rounded-pill px-3"
                        style={{ borderRadius: '20px' }}
                      >
                        <i className="fas fa-edit me-1"></i>
                        Edit
                      </Link>
                    </div>
                  </div>
                  <div className="card-body px-4 pb-4">
                    {/* Name Section */}
                    <div className="mb-4 p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                      <div className="d-flex align-items-center">
                        <i className="fas fa-user text-secondary me-3 fs-5"></i>
                        <div>
                          <small className="text-muted text-uppercase fw-medium">Full Name</small>
                          <h6 className="mb-0 fw-bold text-dark">{userData.aboutData.name}</h6>
                        </div>
                      </div>
                    </div>

                    {/* Contact Information Grid */}
                    <div className="row g-3">
                      {/* Primary Email */}
                      <div className="col-12 col-md-6">
                        <div className="p-3 rounded-3 h-100" style={{ backgroundColor: '#e3f2fd' }}>
                          <div className="d-flex align-items-start">
                            <i className="fas fa-envelope text-primary me-3 mt-1"></i>
                            <div className="flex-grow-1">
                              <small className="text-muted text-uppercase fw-medium">Primary Email</small>
                              <div className="mt-1">
                                <a 
                                  href={`mailto:${userData.aboutData.email}`} 
                                  className="text-decoration-none fw-medium"
                                  style={{ color: '#1976d2' }}
                                >
                                  {userData.aboutData.email}
                                </a>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Professional Email */}
                      {userData.aboutData.professionalEmail && (
                        <div className="col-12 col-md-6">
                          <div className="p-3 rounded-3 h-100" style={{ backgroundColor: '#e8f5e8' }}>
                            <div className="d-flex align-items-start">
                              <i className="fas fa-briefcase text-success me-3 mt-1"></i>
                              <div className="flex-grow-1">
                                <small className="text-muted text-uppercase fw-medium">Professional Email</small>
                                <div className="mt-1">
                                  <a 
                                    href={`mailto:${userData.aboutData.professionalEmail}`} 
                                    className="text-decoration-none fw-medium"
                                    style={{ color: '#2e7d32' }}
                                  >
                                    {userData.aboutData.professionalEmail}
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Secondary Email */}
                      {userData.aboutData.secondaryEmail && (
                        <div className="col-12 col-md-6">
                          <div className="p-3 rounded-3 h-100" style={{ backgroundColor: '#fff3e0' }}>
                            <div className="d-flex align-items-start">
                              <i className="fas fa-envelope text-warning me-3 mt-1"></i>
                              <div className="flex-grow-1">
                                <small className="text-muted text-uppercase fw-medium">Secondary Email</small>
                                <div className="mt-1">
                                  <a 
                                    href={`mailto:${userData.aboutData.secondaryEmail}`} 
                                    className="text-decoration-none fw-medium"
                                    style={{ color: '#f57c00' }}
                                  >
                                    {userData.aboutData.secondaryEmail}
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Phone */}
                      {userData.aboutData.phone && (
                        <div className="col-12 col-md-6">
                          <div className="p-3 rounded-3 h-100" style={{ backgroundColor: '#e8f5e8' }}>
                            <div className="d-flex align-items-start">
                              <i className="fas fa-phone text-success me-3 mt-1"></i>
                              <div className="flex-grow-1">
                                <small className="text-muted text-uppercase fw-medium">Phone Number</small>
                                <div className="mt-1">
                                  <a 
                                    href={`tel:${userData.aboutData.phone}`} 
                                    className="text-decoration-none fw-medium"
                                    style={{ color: '#2e7d32' }}
                                  >
                                    {userData.aboutData.phone}
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Secondary Phone */}
                      {userData.aboutData.secondaryPhone && (
                        <div className="col-12 col-md-6">
                          <div className="p-3 rounded-3 h-100" style={{ backgroundColor: '#fff3e0' }}>
                            <div className="d-flex align-items-start">
                              <i className="fas fa-mobile-alt text-warning me-3 mt-1"></i>
                              <div className="flex-grow-1">
                                <small className="text-muted text-uppercase fw-medium">Secondary Phone</small>
                                <div className="mt-1">
                                  <a 
                                    href={`tel:${userData.aboutData.secondaryPhone}`} 
                                    className="text-decoration-none fw-medium"
                                    style={{ color: '#f57c00' }}
                                  >
                                    {userData.aboutData.secondaryPhone}
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Skype */}
                      {userData.aboutData.skype && (
                        <div className="col-12 col-md-6">
                          <div className="p-3 rounded-3 h-100" style={{ backgroundColor: '#e1f5fe' }}>
                            <div className="d-flex align-items-start">
                              <i className="fab fa-skype text-info me-3 mt-1"></i>
                              <div className="flex-grow-1">
                                <small className="text-muted text-uppercase fw-medium">Skype ID</small>
                                <div className="mt-1">
                                  <a 
                                    href={`skype:${userData.aboutData.skype}?call`} 
                                    className="text-decoration-none fw-medium"
                                    style={{ color: '#0288d1' }}
                                  >
                                    {userData.aboutData.skype}
                                  </a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Address */}
                      {userData.aboutData.address && (
                        <div className="col-12">
                          <div className="p-3 rounded-3" style={{ backgroundColor: '#ffebee' }}>
                            <div className="d-flex align-items-start">
                              <i className="fas fa-map-marker-alt text-danger me-3 mt-1"></i>
                              <div className="flex-grow-1">
                                <small className="text-muted text-uppercase fw-medium">Address</small>
                                <div className="mt-1 fw-medium text-dark">{userData.aboutData.address}</div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Bio Sections */}
                    {(userData.aboutData.bio || userData.aboutData.tagline || userData.aboutData.afterBio) && (
                      <div className="mt-4">
                        <h6 className="fw-bold text-dark mb-3">About Me</h6>
                        {userData.aboutData.tagline && (
                          <div className="mb-3 p-3 rounded-3" style={{ backgroundColor: '#f3e5f5' }}>
                            <small className="text-muted text-uppercase fw-medium">Tagline</small>
                            <p className="mb-0 mt-1 fw-medium text-dark">{userData.aboutData.tagline}</p>
                          </div>
                        )}
                        {userData.aboutData.bio && (
                          <div className="mb-3 p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                            <small className="text-muted text-uppercase fw-medium">Biography</small>
                            <p className="mb-0 mt-1 text-dark">{userData.aboutData.bio}</p>
                          </div>
                        )}
                        {userData.aboutData.afterBio && (
                          <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                            <small className="text-muted text-uppercase fw-medium">Additional Info</small>
                            <p className="mb-0 mt-1 text-dark">{userData.aboutData.afterBio}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Sidebar Cards */}
            <div className="col-12 col-lg-4">
              <div className="row g-4">
                {/* Social Media Card */}
                {userData.socialLinks && (
                  <div className="col-12">
                    <div className="card shadow-sm border-0 h-100" style={{ borderRadius: '16px' }}>
                      <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                        <div className="d-flex align-items-center justify-content-between">
                          <div className="d-flex align-items-center">
                            <div 
                              className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                              style={{ 
                                width: '48px', 
                                height: '48px', 
                                backgroundColor: '#e3f2fd'
                              }}
                            >
                              <i className="fas fa-share-alt text-primary fs-5"></i>
                            </div>
                            <div>
                              <h6 className="mb-0 fw-bold text-dark">Social Media</h6>
                              <small className="text-muted">Your online presence</small>
                            </div>
                          </div>
                          <Link 
                            to="/admin/user/edit/socialLinks" 
                            className="btn btn-outline-primary btn-sm rounded-pill px-3"
                          >
                            <i className="fas fa-edit me-1"></i>
                            Edit
                          </Link>
                        </div>
                      </div>
                      <div className="card-body px-4 pb-4">
                        <div className="row g-2">
                          {userData.socialLinks.linkedin && (
                            <div className="col-12">
                              <div className="p-2 rounded-3 d-flex align-items-center" style={{ backgroundColor: '#e7f3ff' }}>
                                <i className="fab fa-linkedin text-primary me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">LinkedIn</small>
                                  <div>
                                    <a 
                                      href={userData.socialLinks.linkedin} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-decoration-none small fw-medium"
                                      style={{ color: '#0077b5' }}
                                    >
                                      View Profile
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          {userData.socialLinks.github && (
                            <div className="col-12">
                              <div className="p-2 rounded-3 d-flex align-items-center" style={{ backgroundColor: '#f6f8fa' }}>
                                <i className="fab fa-github text-dark me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">GitHub</small>
                                  <div>
                                    <a 
                                      href={userData.socialLinks.github} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-decoration-none small fw-medium text-dark"
                                    >
                                      View Repository
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          {userData.socialLinks.twitter && (
                            <div className="col-12">
                              <div className="p-2 rounded-3 d-flex align-items-center" style={{ backgroundColor: '#e7f3ff' }}>
                                <i className="fab fa-twitter text-info me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">Twitter</small>
                                  <div>
                                    <a 
                                      href={userData.socialLinks.twitter} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-decoration-none small fw-medium"
                                      style={{ color: '#1da1f2' }}
                                    >
                                      View Profile
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          {userData.socialLinks.instagram && (
                            <div className="col-12">
                              <div className="p-2 rounded-3 d-flex align-items-center" style={{ backgroundColor: '#fce4ec' }}>
                                <i className="fab fa-instagram text-danger me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">Instagram</small>
                                  <div>
                                    <a 
                                      href={userData.socialLinks.instagram} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-decoration-none small fw-medium"
                                      style={{ color: '#e4405f' }}
                                    >
                                      View Profile
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          {userData.socialLinks.facebook && (
                            <div className="col-12">
                              <div className="p-2 rounded-3 d-flex align-items-center" style={{ backgroundColor: '#e7f3ff' }}>
                                <i className="fab fa-facebook text-primary me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">Facebook</small>
                                  <div>
                                    <a 
                                      href={userData.socialLinks.facebook} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-decoration-none small fw-medium"
                                      style={{ color: '#1877f2' }}
                                    >
                                      View Profile
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                          {userData.socialLinks.website && (
                            <div className="col-12">
                              <div className="p-2 rounded-3 d-flex align-items-center" style={{ backgroundColor: '#f8f9fa' }}>
                                <i className="fas fa-globe text-secondary me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">Website</small>
                                  <div>
                                    <a 
                                      href={userData.socialLinks.website} 
                                      target="_blank" 
                                      rel="noopener noreferrer"
                                      className="text-decoration-none small fw-medium text-secondary"
                                    >
                                      Visit Website
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Resume Card */}
                {userData.aboutData && (
                  <div className="col-12">
                    <div className="card shadow-sm border-0 h-100" style={{ borderRadius: '16px' }}>
                      <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                        <div className="d-flex align-items-center">
                          <div 
                            className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                            style={{ 
                              width: '48px', 
                              height: '48px', 
                              backgroundColor: '#e8f5e8'
                            }}
                          >
                            <i className="fas fa-file-pdf text-success fs-5"></i>
                          </div>
                          <div>
                            <h6 className="mb-0 fw-bold text-dark">Resume/CV</h6>
                            <small className="text-muted">Your professional document</small>
                          </div>
                        </div>
                      </div>
                      <div className="card-body px-4 pb-4">
                        {userData.aboutData.resume ? (
                          <div>
                            <div className="p-3 rounded-3 mb-3" style={{ backgroundColor: '#e8f5e8' }}>
                              <div className="d-flex align-items-center">
                                <i className="fas fa-check-circle text-success me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">Status</small>
                                  <div className="fw-medium text-success">Resume Uploaded</div>
                                </div>
                              </div>
                            </div>
                            <div className="d-grid gap-2">
                              <a 
                                href={userData.aboutData.resume} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="btn btn-outline-success rounded-pill"
                              >
                                <i className="fas fa-eye me-2"></i>
                                View Resume
                              </a>
                              <Link 
                                to="/admin/user/upload-resume" 
                                className="btn btn-success rounded-pill"
                              >
                                <i className="fas fa-upload me-2"></i>
                                Update Resume
                              </Link>
                            </div>
                            <small className="text-muted mt-2 d-block">
                              Upload a new resume to replace the current one
                            </small>
                          </div>
                        ) : (
                          <div>
                            <div className="p-3 rounded-3 mb-3" style={{ backgroundColor: '#fff3e0' }}>
                              <div className="d-flex align-items-center">
                                <i className="fas fa-exclamation-circle text-warning me-3"></i>
                                <div className="flex-grow-1">
                                  <small className="text-muted">Status</small>
                                  <div className="fw-medium text-warning">No Resume Uploaded</div>
                                </div>
                              </div>
                            </div>
                            <div className="d-grid">
                              <Link 
                                to="/admin/user/upload-resume" 
                                className="btn btn-success rounded-pill"
                              >
                                <i className="fas fa-upload me-2"></i>
                                Upload Resume
                              </Link>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  );
};

export default UserDashboard;
