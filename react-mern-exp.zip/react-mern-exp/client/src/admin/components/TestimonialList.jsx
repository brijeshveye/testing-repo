import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import TestimonialsDataApi from '../../api/TestimonialsDataApi';

const TestimonialList = () => {
  const [testimonials, setTestimonials] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    fetchTestimonials();
  }, [filter]);

  const fetchTestimonials = async () => {
    try {
      setLoading(true);
      setError('');
      
      let data;
      if (filter === 'all') {
        // For 'all' filter, call the API without any parameters to get all testimonials
        data = await TestimonialsDataApi.getTestimonialsData();
      } else {
        // For specific filters, pass the appropriate parameters
        const params = {};
        if (filter === 'active') {
          params.isActive = true;
        } else if (filter === 'inactive') {
          params.isActive = false;
        } else if (filter === 'featured') {
          params.featured = true;
        }
        data = await TestimonialsDataApi.getTestimonialsData(params);
      }
      
      setTestimonials(data || []);
    } catch (error) {
      console.error('Error fetching testimonials:', error);
      setError('Failed to load testimonials. Please check the server connection.');
      setTestimonials([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (slug) => {
    if (window.confirm('Are you sure you want to delete this testimonial?')) {
      try {
        await TestimonialsDataApi.deleteTestimonial(slug);
        setSuccess('Testimonial deleted successfully');
        fetchTestimonials();
        // Clear success message after 3 seconds
        setTimeout(() => setSuccess(''), 3000);
      } catch (error) {
        console.error('Error deleting testimonial:', error);
        setError('Failed to delete testimonial');
      }
    }
  };

  const toggleFeatured = async (slug, currentFeatured) => {
    try {
      await TestimonialsDataApi.updateTestimonial(slug, { featured: !currentFeatured });
      setSuccess(`Testimonial ${!currentFeatured ? 'added to' : 'removed from'} featured`);
      fetchTestimonials();
      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(''), 3000);
    } catch (error) {
      console.error('Error updating testimonial:', error);
      setError('Failed to update testimonial');
    }
  };

  const renderStars = (rating) => {
    return '★'.repeat(rating) + '☆'.repeat(5 - rating);
  };

  if (loading) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
          <div className="text-center">
            <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="text-muted">Loading testimonials...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-start">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '56px', 
                    height: '56px', 
                    backgroundColor: '#2e7d32',
                    color: 'white'
                  }}
                >
                  <i className="fas fa-comments fs-3"></i>
                </div>
                <div>
                  <h2 className="mb-1 text-dark fw-bold">Testimonials Management</h2>
                  <p className="text-muted mb-0">Manage customer testimonials and reviews</p>
                </div>
              </div>
              <Link 
                to="/admin/testimonials/create" 
                className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                style={{ fontSize: '14px' }}
              >
                <i className="fas fa-plus me-2"></i>Add New Testimonial
              </Link>
            </div>
          </div>
        </div>

        {error && (
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body p-4">
              <div className="alert alert-danger border-0 mb-0" style={{ borderRadius: '12px' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '40px', 
                      height: '40px', 
                      backgroundColor: '#ffebee',
                      color: '#d32f2f'
                    }}
                  >
                    <i className="fas fa-exclamation-triangle"></i>
                  </div>
                  <div className="fw-medium text-danger">{error}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {success && (
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body p-4">
              <div className="alert alert-success border-0 mb-0" style={{ borderRadius: '12px' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '40px', 
                      height: '40px', 
                      backgroundColor: '#e8f5e8',
                      color: '#2e7d32'
                    }}
                  >
                    <i className="fas fa-check-circle"></i>
                  </div>
                  <div className="fw-medium text-success">{success}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters and Stats Row */}
        <div className="row g-4 mb-4">
          {/* Filter Card */}
          <div className="col-lg-8">
            <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className="d-flex align-items-center mb-3">
                  <div 
                    className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '32px', 
                      height: '32px', 
                      backgroundColor: '#e3f2fd',
                      color: '#1976d2'
                    }}
                  >
                    <i className="fas fa-filter fs-6"></i>
                  </div>
                  <h6 className="mb-0 fw-bold text-dark">Filter Testimonials</h6>
                </div>
                
                <div className="d-flex flex-wrap gap-2">
                  {[
                    { key: 'all', label: 'All Testimonials', icon: 'fas fa-list', color: '#6c757d' },
                    { key: 'active', label: 'Active', icon: 'fas fa-check-circle', color: '#2e7d32' },
                    { key: 'inactive', label: 'Inactive', icon: 'fas fa-times-circle', color: '#d32f2f' },
                    { key: 'featured', label: 'Featured', icon: 'fas fa-star', color: '#f57c00' }
                  ].map((filterOption) => (
                    <button
                      key={filterOption.key}
                      type="button"
                      className={`btn rounded-pill px-3 py-2 fw-medium ${
                        filter === filterOption.key 
                          ? 'btn-primary' 
                          : 'btn-outline-secondary'
                      }`}
                      style={{ fontSize: '13px' }}
                      onClick={() => setFilter(filterOption.key)}
                    >
                      <i className={`${filterOption.icon} me-1`}></i>
                      {filterOption.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Quick Stats Card */}
          <div className="col-lg-4">
            <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className="d-flex align-items-center mb-3">
                  <div 
                    className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '32px', 
                      height: '32px', 
                      backgroundColor: '#fff3e0',
                      color: '#f57c00'
                    }}
                  >
                    <i className="fas fa-chart-bar fs-6"></i>
                  </div>
                  <h6 className="mb-0 fw-bold text-dark">Quick Stats</h6>
                </div>
                
                <div className="row g-2 text-center">
                  <div className="col-6">
                    <div className="p-2 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                      <div className="fw-bold text-success">{testimonials.length}</div>
                      <div className="small text-muted">Total</div>
                    </div>
                  </div>
                  <div className="col-6">
                    <div className="p-2 rounded-3" style={{ backgroundColor: '#fff3e0' }}>
                      <div className="fw-bold text-warning">{testimonials.filter(t => t.featured).length}</div>
                      <div className="small text-muted">Featured</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
          <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '40px', 
                    height: '40px', 
                    backgroundColor: '#e8f5e8'
                  }}
                >
                  <i className="fas fa-quote-left text-success fs-6"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Customer Testimonials</h5>
                  <small className="text-muted">
                    {testimonials.length} testimonial{testimonials.length !== 1 ? 's' : ''} found
                  </small>
                </div>
              </div>
            </div>
          </div>
          <div className="card-body p-4">
            {testimonials.length === 0 ? (
              <div className="text-center py-5">
                <div 
                  className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '80px', 
                    height: '80px', 
                    backgroundColor: '#f8f9fa',
                    color: '#6c757d'
                  }}
                >
                  <i className="fas fa-comments fs-1"></i>
                </div>
                <h5 className="text-muted mb-2">No testimonials found</h5>
                <p className="text-muted mb-3">
                  {filter === 'all' 
                    ? "You haven't added any testimonials yet." 
                    : `No ${filter} testimonials found. Try adjusting your filter.`
                  }
                </p>
                <Link 
                  to="/admin/testimonials/create" 
                  className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                >
                  <i className="fas fa-plus me-2"></i>Add First Testimonial
                </Link>
              </div>
            ) : (
              <div className="row g-4">
                {testimonials.map((testimonial) => (
                  <div key={testimonial._id} className="col-md-6 col-xl-4">
                    <div 
                      className="card h-100 border-0 shadow-sm position-relative"
                      style={{ borderRadius: '12px' }}
                    >
                      {/* Status Badges */}
                      <div className="position-absolute top-0 end-0 p-2">
                        <div className="d-flex gap-1">
                          {testimonial.featured && (
                            <span 
                              className="badge rounded-pill px-2 py-1"
                              style={{ 
                                backgroundColor: '#fff3e0',
                                color: '#f57c00',
                                fontSize: '10px'
                              }}
                            >
                              <i className="fas fa-star me-1"></i>Featured
                            </span>
                          )}
                          <span 
                            className={`badge rounded-pill px-2 py-1`}
                            style={{ 
                              backgroundColor: testimonial.isActive ? '#e8f5e8' : '#ffebee',
                              color: testimonial.isActive ? '#2e7d32' : '#d32f2f',
                              fontSize: '10px'
                            }}
                          >
                            <i className={`fas ${testimonial.isActive ? 'fa-check-circle' : 'fa-times-circle'} me-1`}></i>
                            {testimonial.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>

                      <div className="card-body p-4">
                        {/* Customer Info */}
                        <div className="d-flex align-items-center mb-3">
                          {testimonial.customerImage ? (
                            <img
                              src={testimonial.customerImage}
                              alt={testimonial.customerName}
                              className="rounded-circle border border-3 border-light shadow-sm me-3"
                              style={{ width: '50px', height: '50px', objectFit: 'cover' }}
                            />
                          ) : (
                            <div 
                              className="rounded-circle bg-light border border-3 border-white shadow-sm text-muted d-flex align-items-center justify-content-center me-3"
                              style={{ width: '50px', height: '50px' }}
                            >
                              <i className="fas fa-user"></i>
                            </div>
                          )}
                          <div className="flex-grow-1">
                            <h6 className="mb-0 fw-bold text-dark">{testimonial.customerName}</h6>
                            <small className="text-muted">{testimonial.customerPosition || 'Customer'}</small>
                          </div>
                        </div>

                        {/* Rating */}
                        <div className="d-flex align-items-center mb-3">
                          <div className="d-flex me-2">
                            {[...Array(5)].map((_, index) => (
                              <i 
                                key={index} 
                                className={`${index < (testimonial.stars || testimonial.rating) ? 'fas fa-star text-warning' : 'far fa-star text-muted'} me-1`}
                                style={{ fontSize: '14px' }}
                              ></i>
                            ))}
                          </div>
                          <small className="text-muted">({testimonial.stars || testimonial.rating}/5)</small>
                        </div>

                        {/* Feedback Preview */}
                        <div 
                          className="p-3 rounded-3 mb-3"
                          style={{ backgroundColor: '#f8f9fa' }}
                        >
                          <p className="mb-0 text-dark" style={{ fontSize: '13px', lineHeight: '1.5' }}>
                            "{testimonial.customerFeedback.length > 120
                              ? `${testimonial.customerFeedback.substring(0, 120)}...`
                              : testimonial.customerFeedback}"
                          </p>
                        </div>

                        {/* Date */}
                        <div className="small text-muted mb-3">
                          <i className="fas fa-calendar-alt me-1"></i>
                          {new Date(testimonial.dateReceived || testimonial.createdAt).toLocaleDateString()}
                        </div>

                        {/* Action Buttons */}
                        <div className="d-flex gap-2">
                          <button
                            type="button"
                            className={`btn btn-sm rounded-pill px-3 ${testimonial.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                            onClick={() => toggleFeatured(testimonial.slug, testimonial.featured)}
                            title={testimonial.featured ? 'Remove from featured' : 'Mark as featured'}
                          >
                            <i className="fas fa-star me-1"></i>
                            {testimonial.featured ? 'Featured' : 'Feature'}
                          </button>
                          
                          <Link
                            to={`/admin/testimonials/edit/${testimonial.slug}`}
                            className="btn btn-sm btn-outline-primary rounded-pill px-3"
                            title="Edit testimonial"
                          >
                            <i className="fas fa-edit me-1"></i>Edit
                          </Link>
                          
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-danger rounded-pill px-3"
                            onClick={() => handleDelete(testimonial.slug)}
                            title="Delete testimonial"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Detailed Stats Card */}
        {testimonials.length > 0 && (
          <div className="card shadow-sm border-0 mt-4" style={{ borderRadius: '16px' }}>
            <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '40px', 
                    height: '40px', 
                    backgroundColor: '#e3f2fd'
                  }}
                >
                  <i className="fas fa-analytics text-primary fs-6"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Testimonial Analytics</h5>
                  <small className="text-muted">Overview of your testimonial performance</small>
                </div>
              </div>
            </div>
            <div className="card-body p-4">
              <div className="row g-4">
                <div className="col-md-3">
                  <div className="text-center p-4 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                    <div 
                      className="rounded-circle mx-auto mb-2 d-flex align-items-center justify-content-center"
                      style={{ width: '48px', height: '48px', backgroundColor: '#2e7d32', color: 'white' }}
                    >
                      <i className="fas fa-comments fs-5"></i>
                    </div>
                    <h4 className="fw-bold text-success mb-1">{testimonials.length}</h4>
                    <p className="small text-muted mb-0">Total Testimonials</p>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="text-center p-4 rounded-3" style={{ backgroundColor: '#e3f2fd' }}>
                    <div 
                      className="rounded-circle mx-auto mb-2 d-flex align-items-center justify-content-center"
                      style={{ width: '48px', height: '48px', backgroundColor: '#1976d2', color: 'white' }}
                    >
                      <i className="fas fa-check-circle fs-5"></i>
                    </div>
                    <h4 className="fw-bold text-primary mb-1">{testimonials.filter(t => t.isActive).length}</h4>
                    <p className="small text-muted mb-0">Active</p>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="text-center p-4 rounded-3" style={{ backgroundColor: '#fff3e0' }}>
                    <div 
                      className="rounded-circle mx-auto mb-2 d-flex align-items-center justify-content-center"
                      style={{ width: '48px', height: '48px', backgroundColor: '#f57c00', color: 'white' }}
                    >
                      <i className="fas fa-star fs-5"></i>
                    </div>
                    <h4 className="fw-bold text-warning mb-1">{testimonials.filter(t => t.featured).length}</h4>
                    <p className="small text-muted mb-0">Featured</p>
                  </div>
                </div>
                <div className="col-md-3">
                  <div className="text-center p-4 rounded-3" style={{ backgroundColor: '#fce4ec' }}>
                    <div 
                      className="rounded-circle mx-auto mb-2 d-flex align-items-center justify-content-center"
                      style={{ width: '48px', height: '48px', backgroundColor: '#e91e63', color: 'white' }}
                    >
                      <i className="fas fa-chart-line fs-5"></i>
                    </div>
                    <h4 className="fw-bold" style={{ color: '#e91e63' }}>
                      {testimonials.length > 0 
                        ? (testimonials.reduce((sum, t) => sum + (t.stars || t.rating), 0) / testimonials.length).toFixed(1)
                        : '0'
                      }
                    </h4>
                    <p className="small text-muted mb-0">Avg Rating</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TestimonialList;
