import React, { useState, useEffect } from 'react';
import AdminPinAuth from './AdminPinAuth';
import AdminNavBar from './AdminNavBar';

const AdminProtectedRoute = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [sessionToken, setSessionToken] = useState(null);
  const [deviceFingerprint, setDeviceFingerprint] = useState(null);

  useEffect(() => {
    checkAuthentication();
  }, []);

  const checkAuthentication = async () => {
    const savedSession = localStorage.getItem('adminSession');
    const savedDeviceFingerprint = localStorage.getItem('deviceFingerprint');
    
    if (savedSession && savedDeviceFingerprint) {
      const sessionData = JSON.parse(savedSession);
      
      try {
        const response = await fetch('/api/pin/verify-session', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            sessionToken: sessionData.sessionToken,
            deviceFingerprint: savedDeviceFingerprint
          }),
        });

        const data = await response.json();

        if (data.success) {
          setSessionToken(sessionData.sessionToken);
          setDeviceFingerprint(savedDeviceFingerprint);
          setIsAuthenticated(true);
        } else {
          // Session invalid, clear storage
          localStorage.removeItem('adminSession');
          localStorage.removeItem('deviceFingerprint');
          setIsAuthenticated(false);
        }
      } catch (error) {
        console.error('Session verification error:', error);
        localStorage.removeItem('adminSession');
        localStorage.removeItem('deviceFingerprint');
        setIsAuthenticated(false);
      }
    } else {
      setIsAuthenticated(false);
    }
    
    setIsLoading(false);
  };

  const handleAuthSuccess = (token, fingerprint) => {
    setSessionToken(token);
    setDeviceFingerprint(fingerprint);
    setIsAuthenticated(true);
  };

  if (isLoading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AdminPinAuth onSuccess={handleAuthSuccess} />;
  }

  return (
    <div className="admin-layout">
      <AdminNavBar 
        sessionToken={sessionToken} 
        deviceFingerprint={deviceFingerprint}
        onLogout={() => {
          setIsAuthenticated(false);
          setSessionToken(null);
          setDeviceFingerprint(null);
        }}
      />
      <div className="admin-content">
        {React.cloneElement(children, { 
          sessionToken, 
          deviceFingerprint 
        })}
      </div>
    </div>
  );
};

export default AdminProtectedRoute;
