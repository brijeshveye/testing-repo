import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createService, getService, updateService } from '../../api/ServiceDataApi';
import WidgetManager from './widgets/WidgetManager';
import { ImageUploader, uploadImage, IMAGE_CATEGORIES } from './ImageUpload';

const ServiceForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDescription: '',
    icon: '',
    iconClass: '',
    image: '',
    bannerImage: '',
    widgets: [], // Dynamic content widgets
    details: {
      section1: { para1: '', para2: '' },
      section2: { image1: '', image2: '', image3: '', image4: '' },
      section3: { title: '', para: '' },
      section4: { image1: '', video: '' }
    },
    faqs: [],
    category: 'general',
    tag: '',
    number: 1,
    bgText: '',
    technologies: [],
    features: [],
    pricing: {
      startingPrice: 0,
      currency: 'USD',
      pricingModel: 'custom'
    },
    deliveryTime: '',
    processSteps: [],
    featured: false,
    isActive: true,
    seoTitle: '',
    seoDescription: '',
    seoKeywords: []
  });

  const [activeTab, setActiveTab] = useState('basic');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEdit) {
      fetchService();
    }
  }, [slug, isEdit]);

  const fetchService = async () => {
    try {
      setLoading(true);
      const response = await getService(slug, true);
      if (response.success) {
        const serviceData = response.data;
        setFormData({
          title: serviceData.title || '',
          description: serviceData.description || '',
          shortDescription: serviceData.shortDescription || '',
          icon: serviceData.icon || '',
          iconClass: serviceData.iconClass || '',
          image: serviceData.image || '',
          bannerImage: serviceData.bannerImage || '',
          widgets: serviceData.widgets || [],
          details: {
            section1: serviceData.details?.section1 || { para1: '', para2: '' },
            section2: serviceData.details?.section2 || { image1: '', image2: '', image3: '', image4: '' },
            section3: serviceData.details?.section3 || { title: '', para: '' },
            section4: serviceData.details?.section4 || { image1: '', video: '' }
          },
          faqs: serviceData.faqs || [],
          category: serviceData.category || 'general',
          tag: serviceData.tag || '',
          number: serviceData.number || 1,
          bgText: serviceData.bgText || '',
          technologies: serviceData.technologies || [],
          features: serviceData.features || [],
          pricing: {
            startingPrice: serviceData.pricing?.startingPrice || 0,
            currency: serviceData.pricing?.currency || 'USD',
            pricingModel: serviceData.pricing?.pricingModel || 'custom'
          },
          deliveryTime: serviceData.deliveryTime || '',
          processSteps: serviceData.processSteps || [],
          featured: serviceData.featured || false,
          isActive: serviceData.isActive !== false,
          seoTitle: serviceData.seoTitle || '',
          seoDescription: serviceData.seoDescription || '',
          seoKeywords: serviceData.seoKeywords || []
        });
      } else {
        setErrors({ general: response.message || 'Failed to fetch service details' });
      }
    } catch (error) {
      console.error('Error fetching service:', error);
      setErrors({ general: 'Failed to fetch service details' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) : value)
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }
  };

  const handleWidgetsChange = (widgets) => {
    setFormData(prev => ({ ...prev, widgets }));
  };

  const handleImageUpload = async (file, category) => {
    try {
      return await uploadImage(file, category);
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (formData.pricing.startingPrice < 0) {
      newErrors['pricing.startingPrice'] = 'Price cannot be negative';
    }

    // Debug: Log validation results
    console.log('Form validation errors:', newErrors);
    console.log('Current form data structure:', {
      title: formData.title,
      description: formData.description,
      widgets: formData.widgets.length,
      faqs: formData.faqs.length,
      technologies: formData.technologies.length,
      features: formData.features.length,
      pricing: formData.pricing
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      
      // Debug: Log the form data being sent
      console.log('Submitting service data:', formData);
      
      let response;

      if (isEdit) {
        response = await updateService(slug, formData);
      } else {
        response = await createService(formData);
      }

      // Debug: Log the response
      console.log('Service save response:', response);

      if (response.success) {
        navigate('/admin/services');
      } else {
        setErrors({ general: response.message || 'Failed to save service' });
      }
    } catch (error) {
      console.error('Error saving service:', error);
      setErrors({ general: 'Failed to save service. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '60vh' }}>
          <div className="card border-0 rounded-4 shadow-lg" 
               style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)' }}>
            <div className="card-body text-center py-5 px-5">
              <div className="spinner-border text-primary mb-3" 
                   style={{ width: '3rem', height: '3rem' }} role="status">
                <span className="visually-hidden">Loading service data...</span>
              </div>
              <h5 className="text-dark mb-1">Loading Service</h5>
              <p className="text-muted mb-0">Please wait while we fetch the service details...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      {/* Header Card */}
      <div className="card shadow-lg border-0 rounded-4 mb-4" 
           style={{ 
             background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
             color: 'white' 
           }}>
        <div className="card-body p-4">
          <div className="d-flex align-items-center">
            <i className="fas fa-cogs fs-2 me-3" style={{ color: 'rgba(255, 255, 255, 0.9)' }}></i>
            <div>
              <h1 className="mb-1 fw-bold">
                {isEdit ? 'Edit Service' : 'Create New Service'}
              </h1>
              <p className="mb-0 opacity-75">
                {isEdit ? 'Update your service offering details' : 'Add a new service to your portfolio'}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="row g-4">
        <div className="col-lg-8">
          <div className="card border-0 rounded-4 shadow-sm" 
               style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)' }}>
            <div className="card-body p-4">
              {/* Error Alert */}
              {errors.general && (
                <div className="card border-0 rounded-4 shadow-sm mb-4" 
                     style={{ backgroundColor: '#fef2f2', borderLeft: '4px solid #ef4444' }}>
                  <div className="card-body p-4">
                    <div className="d-flex align-items-center">
                      <div className="flex-shrink-0 me-3">
                        <div className="rounded-circle p-2" style={{ backgroundColor: '#fee2e2' }}>
                          <i className="fas fa-exclamation-triangle text-danger"></i>
                        </div>
                      </div>
                      <div>
                        <h6 className="mb-1 text-danger fw-semibold">Error</h6>
                        <p className="mb-0 text-dark">{errors.general}</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab Navigation */}
              <div className="card border-0 rounded-4 shadow-sm mb-4" 
                   style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
                <div className="card-body p-3">
                  <div className="d-flex flex-wrap gap-1">
                    {[
                      { key: 'basic', label: 'Basic Info', icon: 'fas fa-info-circle', color: '#3b82f6' },
                      { key: 'content', label: 'Content', icon: 'fas fa-edit', color: '#10b981' },
                      { key: 'faqs', label: 'FAQs', icon: 'fas fa-question-circle', color: '#f59e0b' },
                      { key: 'advanced', label: 'Advanced', icon: 'fas fa-cog', color: '#8b5cf6' }
                    ].map((tab) => (
                      <button 
                        key={tab.key}
                        className={`btn btn-lg rounded-3 px-4 py-2 d-flex align-items-center ${
                          activeTab === tab.key 
                            ? 'text-white shadow-sm' 
                            : 'btn-light text-muted border-0'
                        }`}
                        style={{
                          backgroundColor: activeTab === tab.key ? tab.color : 'transparent',
                          borderColor: activeTab === tab.key ? tab.color : 'transparent',
                          transition: 'all 0.3s ease'
                        }}
                        onClick={() => setActiveTab(tab.key)}
                        type="button"
                      >
                        <i className={`${tab.icon} me-2`}></i>
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit}>
                {/* Basic Information Tab */}
                {activeTab === 'basic' && (
                  <div className="card border-0 rounded-4 shadow-sm" 
                       style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
                    <div className="card-body p-4">
                      <div className="d-flex align-items-center mb-4">
                        <div className="rounded-circle p-2 me-3" style={{ backgroundColor: '#dbeafe' }}>
                          <i className="fas fa-info-circle text-primary"></i>
                        </div>
                        <div>
                          <h5 className="mb-1 text-dark fw-bold">Basic Information</h5>
                          <p className="mb-0 text-muted">Essential details about your service</p>
                        </div>
                      </div>
                      
                      <div className="row g-4">
                        <div className="col-12">
                          <label htmlFor="title" className="form-label fw-semibold text-dark">
                            <i className="fas fa-heading me-2 text-primary"></i>Service Title *
                          </label>
                          <input
                            type="text"
                            className={`form-control form-control-lg rounded-3 border-2 ${errors.title ? 'is-invalid border-danger' : ''}`}
                            id="title"
                            name="title"
                            value={formData.title}
                            onChange={handleChange}
                            placeholder="Enter your service title..."
                            style={{ borderColor: errors.title ? '#ef4444' : '#e5e7eb', fontSize: '1rem' }}
                            required
                          />
                          {errors.title && <div className="invalid-feedback fw-semibold">{errors.title}</div>}
                        </div>

                        <div className="col-12">
                          <label htmlFor="description" className="form-label fw-semibold text-dark">
                            <i className="fas fa-align-left me-2 text-primary"></i>Full Description *
                          </label>
                          <textarea
                            className={`form-control form-control-lg rounded-3 border-2 ${errors.description ? 'is-invalid border-danger' : ''}`}
                            id="description"
                            name="description"
                            rows="4"
                            value={formData.description}
                            onChange={handleChange}
                            placeholder="Provide a detailed description of your service..."
                            style={{ borderColor: errors.description ? '#ef4444' : '#e5e7eb', fontSize: '0.95rem' }}
                            required
                          />
                          {errors.description && <div className="invalid-feedback fw-semibold">{errors.description}</div>}
                        </div>

                        <div className="col-12">
                          <label htmlFor="shortDescription" className="form-label fw-semibold text-dark">
                            <i className="fas fa-file-alt me-2 text-success"></i>Short Description
                          </label>
                          <textarea
                            className="form-control form-control-lg rounded-3 border-2"
                            id="shortDescription"
                            name="shortDescription"
                            rows="2"
                            value={formData.shortDescription}
                            onChange={handleChange}
                            placeholder="Brief summary for service cards and previews..."
                            style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                          />
                          <small className="text-muted">Used in service cards and quick previews</small>
                        </div>

                        <div className="col-lg-6">
                          <label className="form-label fw-semibold text-dark">
                            <i className="fas fa-image me-2 text-warning"></i>Service Image
                          </label>
                          <div className="border-2 border-dashed rounded-3 p-4 text-center" 
                               style={{ borderColor: '#e5e7eb', backgroundColor: '#f9fafb' }}>
                            <ImageUploader
                              onUpload={(imageUrl) => setFormData(prev => ({ ...prev, image: imageUrl }))}
                              category={IMAGE_CATEGORIES.GENERAL}
                            />
                            {formData.image && (
                              <div className="mt-3">
                                <img src={formData.image} alt="Current" 
                                     className="img-thumbnail rounded-3 shadow-sm" 
                                     style={{maxWidth: '150px'}} />
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="col-lg-6">
                          <label className="form-label fw-semibold text-dark">
                            <i className="fas fa-panorama me-2 text-warning"></i>Banner Image
                          </label>
                          <div className="border-2 border-dashed rounded-3 p-4 text-center" 
                               style={{ borderColor: '#e5e7eb', backgroundColor: '#f9fafb' }}>
                            <ImageUploader
                              onUpload={(imageUrl) => setFormData(prev => ({ ...prev, bannerImage: imageUrl }))}
                              category={IMAGE_CATEGORIES.GENERAL}
                            />
                            {formData.bannerImage && (
                              <div className="mt-3">
                                <img src={formData.bannerImage} alt="Current Banner" 
                                     className="img-thumbnail rounded-3 shadow-sm" 
                                     style={{maxWidth: '150px'}} />
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="col-lg-6">
                          <label htmlFor="category" className="form-label fw-semibold text-dark">
                            <i className="fas fa-tag me-2 text-purple"></i>Category
                          </label>
                          <select
                            className="form-select form-select-lg rounded-3 border-2"
                            id="category"
                            name="category"
                            value={formData.category}
                            onChange={handleChange}
                            style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                          >
                            <option value="general">General</option>
                            <option value="development">Development</option>
                            <option value="design">Design</option>
                            <option value="marketing">Marketing</option>
                            <option value="consultation">Consultation</option>
                          </select>
                        </div>

                        <div className="col-lg-6">
                          <label htmlFor="deliveryTime" className="form-label fw-semibold text-dark">
                            <i className="fas fa-clock me-2 text-info"></i>Delivery Time
                          </label>
                          <input
                            type="text"
                            className="form-control form-control-lg rounded-3 border-2"
                            id="deliveryTime"
                            name="deliveryTime"
                            value={formData.deliveryTime}
                            onChange={handleChange}
                            placeholder="e.g., 2-3 weeks, 1 month"
                            style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                          />
                        </div>

                        <div className="col-12">
                          <div className="card rounded-3" style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0' }}>
                            <div className="card-body p-3">
                              <h6 className="text-dark mb-3">
                                <i className="fas fa-toggle-on me-2 text-success"></i>Service Settings
                              </h6>
                              <div className="row">
                                <div className="col-md-6">
                                  <div className="form-check form-switch">
                                    <input
                                      className="form-check-input"
                                      type="checkbox"
                                      id="featured"
                                      name="featured"
                                      checked={formData.featured}
                                      onChange={handleChange}
                                      style={{ transform: 'scale(1.2)' }}
                                    />
                                    <label className="form-check-label fw-semibold text-dark" htmlFor="featured">
                                      <i className="fas fa-star me-2 text-warning"></i>Featured Service
                                      <br /><small className="text-muted">Highlight this service in listings</small>
                                    </label>
                                  </div>
                                </div>
                                <div className="col-md-6">
                                  <div className="form-check form-switch">
                                    <input
                                      className="form-check-input"
                                      type="checkbox"
                                      id="isActive"
                                      name="isActive"
                                      checked={formData.isActive}
                                      onChange={handleChange}
                                      style={{ transform: 'scale(1.2)' }}
                                    />
                                    <label className="form-check-label fw-semibold text-dark" htmlFor="isActive">
                                      <i className="fas fa-eye me-2 text-success"></i>Active & Visible
                                      <br /><small className="text-muted">Make this service publicly visible</small>
                                    </label>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Content Tab */}
                {activeTab === 'content' && (
                  <div className="card border-0 rounded-4 shadow-sm" 
                       style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
                    <div className="card-body p-4">
                      <div className="d-flex align-items-center mb-4">
                        <div className="rounded-circle p-2 me-3" style={{ backgroundColor: '#dcfce7' }}>
                          <i className="fas fa-edit text-success"></i>
                        </div>
                        <div>
                          <h5 className="mb-1 text-dark fw-bold">Dynamic Content Widgets</h5>
                          <p className="mb-0 text-muted">Create rich, interactive content using our widget system</p>
                        </div>
                      </div>
                      
                      <div className="alert alert-info border-0 rounded-3 mb-4" 
                           style={{ backgroundColor: '#e0f2fe', borderLeft: '4px solid #0ea5e9' }}>
                        <div className="d-flex align-items-center">
                          <i className="fas fa-info-circle text-info me-3"></i>
                          <div>
                            <h6 className="mb-1 text-info fw-semibold">Widget System</h6>
                            <p className="mb-0 text-dark">
                              Use widgets to create dynamic, reusable content blocks. This replaces the legacy content sections 
                              with a more flexible and maintainable approach.
                            </p>
                          </div>
                        </div>
                      </div>

                      <WidgetManager
                        widgets={formData.widgets}
                        onChange={handleWidgetsChange}
                        onImageUpload={handleImageUpload}
                      />
                    </div>
                  </div>
                )}

                {/* FAQs Tab */}
                {activeTab === 'faqs' && (
                  <div className="card border-0 rounded-4 shadow-sm" 
                       style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
                    <div className="card-body p-4">
                      <div className="d-flex align-items-center mb-4">
                        <div className="rounded-circle p-2 me-3" style={{ backgroundColor: '#fef3c7' }}>
                          <i className="fas fa-question-circle text-warning"></i>
                        </div>
                        <div>
                          <h5 className="mb-1 text-dark fw-bold">Frequently Asked Questions</h5>
                          <p className="mb-0 text-muted">Help customers understand your service better</p>
                        </div>
                      </div>
                      
                      {formData.faqs.length === 0 ? (
                        <div className="text-center py-5">
                          <div className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" 
                               style={{ width: '60px', height: '60px', backgroundColor: '#f3f4f6' }}>
                            <i className="fas fa-question-circle fa-2x text-muted"></i>
                          </div>
                          <h6 className="text-dark mb-2">No FAQs Added Yet</h6>
                          <p className="text-muted mb-4">Start by adding common questions about your service</p>
                        </div>
                      ) : (
                        <div className="mb-4">
                          {formData.faqs.map((faq, index) => (
                            <div key={index} 
                                 className="card border-0 rounded-3 shadow-sm mb-3" 
                                 style={{ backgroundColor: '#f8fafc', border: '1px solid #e2e8f0' }}>
                              <div className="card-body p-4">
                                <div className="d-flex align-items-start justify-content-between mb-3">
                                  <div className="d-flex align-items-center">
                                    <span className="badge rounded-pill px-3 py-2 me-3" 
                                          style={{ backgroundColor: '#f59e0b', color: 'white' }}>
                                      Q{index + 1}
                                    </span>
                                    <h6 className="mb-0 text-dark">FAQ #{index + 1}</h6>
                                  </div>
                                  <button
                                    type="button"
                                    className="btn btn-outline-danger btn-sm rounded-3"
                                    onClick={() => {
                                      const newFaqs = formData.faqs.filter((_, i) => i !== index);
                                      setFormData(prev => ({ ...prev, faqs: newFaqs }));
                                    }}
                                    title="Remove this FAQ"
                                  >
                                    <i className="fas fa-trash"></i>
                                  </button>
                                </div>
                                
                                <div className="mb-3">
                                  <label className="form-label fw-semibold text-dark">
                                    <i className="fas fa-question me-2 text-warning"></i>Question
                                  </label>
                                  <input
                                    type="text"
                                    className="form-control form-control-lg rounded-3 border-2"
                                    value={faq.title}
                                    onChange={(e) => {
                                      const newFaqs = [...formData.faqs];
                                      newFaqs[index].title = e.target.value;
                                      setFormData(prev => ({ ...prev, faqs: newFaqs }));
                                    }}
                                    placeholder="Enter the question..."
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                </div>
                                
                                <div>
                                  <label className="form-label fw-semibold text-dark">
                                    <i className="fas fa-comment me-2 text-success"></i>Answer
                                  </label>
                                  <textarea
                                    className="form-control form-control-lg rounded-3 border-2"
                                    rows="3"
                                    value={faq.description}
                                    onChange={(e) => {
                                      const newFaqs = [...formData.faqs];
                                      newFaqs[index].description = e.target.value;
                                      setFormData(prev => ({ ...prev, faqs: newFaqs }));
                                    }}
                                    placeholder="Provide a helpful answer..."
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                      
                      <div className="text-center">
                        <button
                          type="button"
                          className="btn btn-primary btn-lg rounded-3 px-4"
                          onClick={() => {
                            setFormData(prev => ({
                              ...prev,
                              faqs: [...prev.faqs, { title: '', description: '' }]
                            }));
                          }}
                        >
                          <i className="fas fa-plus me-2"></i>Add New FAQ
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Advanced Tab */}
                {activeTab === 'advanced' && (
                  <div className="card border-0 rounded-4 shadow-sm" 
                       style={{ backgroundColor: 'rgba(255, 255, 255, 0.8)' }}>
                    <div className="card-body p-4">
                      <div className="d-flex align-items-center mb-4">
                        <div className="rounded-circle p-2 me-3" style={{ backgroundColor: '#ede9fe' }}>
                          <i className="fas fa-cog" style={{ color: '#8b5cf6' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-1 text-dark fw-bold">Advanced Settings</h5>
                          <p className="mb-0 text-muted">Configure pricing, SEO, and technical details</p>
                        </div>
                      </div>

                      <div className="row g-4">
                        {/* Technologies & Features Section */}
                        <div className="col-12">
                          <div className="card rounded-3" style={{ backgroundColor: '#f0f9ff', border: '1px solid #bae6fd' }}>
                            <div className="card-body p-4">
                              <h6 className="text-dark mb-3">
                                <i className="fas fa-code me-2 text-primary"></i>Technologies & Features
                              </h6>
                              <div className="row g-3">
                                <div className="col-lg-6">
                                  <label htmlFor="technologies" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-laptop-code me-2 text-primary"></i>Technologies
                                  </label>
                                  <input
                                    type="text"
                                    className="form-control form-control-lg rounded-3 border-2"
                                    id="technologies"
                                    value={(formData.technologies || []).join(', ')}
                                    onChange={(e) => {
                                      const technologies = e.target.value.split(',').map(tech => tech.trim()).filter(tech => tech);
                                      setFormData(prev => ({ ...prev, technologies }));
                                    }}
                                    placeholder="React, Node.js, MongoDB, AWS..."
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                  <small className="text-muted">Separate multiple technologies with commas</small>
                                </div>
                                <div className="col-lg-6">
                                  <label htmlFor="features" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-list-check me-2 text-success"></i>Key Features
                                  </label>
                                  <input
                                    type="text"
                                    className="form-control form-control-lg rounded-3 border-2"
                                    id="features"
                                    value={(formData.features || []).join(', ')}
                                    onChange={(e) => {
                                      const features = e.target.value.split(',').map(feature => feature.trim()).filter(feature => feature);
                                      setFormData(prev => ({ ...prev, features }));
                                    }}
                                    placeholder="Custom Design, Responsive Layout, SEO Optimized..."
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                  <small className="text-muted">Separate multiple features with commas</small>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Pricing Section */}
                        <div className="col-12">
                          <div className="card rounded-3" style={{ backgroundColor: '#f0fdf4', border: '1px solid #bbf7d0' }}>
                            <div className="card-body p-4">
                              <h6 className="text-dark mb-3">
                                <i className="fas fa-dollar-sign me-2 text-success"></i>Pricing Configuration
                              </h6>
                              <div className="row g-3">
                                <div className="col-lg-4">
                                  <label htmlFor="pricing.startingPrice" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-tag me-2 text-success"></i>Starting Price
                                  </label>
                                  <input
                                    type="number"
                                    className="form-control form-control-lg rounded-3 border-2"
                                    id="pricing.startingPrice"
                                    name="pricing.startingPrice"
                                    value={formData.pricing.startingPrice}
                                    onChange={handleChange}
                                    min="0"
                                    step="0.01"
                                    placeholder="0.00"
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                </div>
                                <div className="col-lg-4">
                                  <label htmlFor="pricing.currency" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-coins me-2 text-warning"></i>Currency
                                  </label>
                                  <select
                                    className="form-select form-select-lg rounded-3 border-2"
                                    id="pricing.currency"
                                    name="pricing.currency"
                                    value={formData.pricing.currency}
                                    onChange={handleChange}
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  >
                                    <option value="USD">USD ($)</option>
                                    <option value="EUR">EUR (€)</option>
                                    <option value="GBP">GBP (£)</option>
                                  </select>
                                </div>
                                <div className="col-lg-4">
                                  <label htmlFor="pricing.pricingModel" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-calculator me-2 text-info"></i>Pricing Model
                                  </label>
                                  <select
                                    className="form-select form-select-lg rounded-3 border-2"
                                    id="pricing.pricingModel"
                                    name="pricing.pricingModel"
                                    value={formData.pricing.pricingModel}
                                    onChange={handleChange}
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  >
                                    <option value="hourly">Hourly Rate</option>
                                    <option value="fixed">Fixed Price</option>
                                    <option value="monthly">Monthly Subscription</option>
                                    <option value="custom">Custom Quote</option>
                                  </select>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* SEO Section */}
                        <div className="col-12">
                          <div className="card rounded-3" style={{ backgroundColor: '#fefce8', border: '1px solid #fde047' }}>
                            <div className="card-body p-4">
                              <h6 className="text-dark mb-3">
                                <i className="fas fa-search me-2 text-warning"></i>SEO Settings
                              </h6>
                              <div className="row g-3">
                                <div className="col-lg-6">
                                  <label htmlFor="seoTitle" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-heading me-2 text-warning"></i>SEO Title
                                  </label>
                                  <input
                                    type="text"
                                    className="form-control form-control-lg rounded-3 border-2"
                                    id="seoTitle"
                                    name="seoTitle"
                                    value={formData.seoTitle}
                                    onChange={handleChange}
                                    placeholder="Custom SEO title for search engines..."
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                  <small className="text-muted">Leave empty to use service title</small>
                                </div>
                                <div className="col-lg-6">
                                  <label htmlFor="seoDescription" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-file-text me-2 text-warning"></i>SEO Description
                                  </label>
                                  <textarea
                                    className="form-control form-control-lg rounded-3 border-2"
                                    id="seoDescription"
                                    name="seoDescription"
                                    rows="2"
                                    value={formData.seoDescription}
                                    onChange={handleChange}
                                    placeholder="Meta description for search engines..."
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                  <small className="text-muted">Recommended: 150-160 characters</small>
                                </div>
                                <div className="col-12">
                                  <label htmlFor="seoKeywords" className="form-label fw-semibold text-dark">
                                    <i className="fas fa-tags me-2 text-warning"></i>SEO Keywords
                                  </label>
                                  <input
                                    type="text"
                                    className="form-control form-control-lg rounded-3 border-2"
                                    id="seoKeywords"
                                    value={(formData.seoKeywords || []).join(', ')}
                                    onChange={(e) => {
                                      const keywords = e.target.value.split(',').map(keyword => keyword.trim()).filter(keyword => keyword);
                                      setFormData(prev => ({ ...prev, seoKeywords: keywords }));
                                    }}
                                    placeholder="web development, react, nodejs, custom software..."
                                    style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
                                  />
                                  <small className="text-muted">Separate keywords with commas. Focus on relevant terms.</small>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                <div className="d-flex gap-3 mt-4 pt-4" style={{ borderTop: '2px solid #e5e7eb' }}>
                  <button 
                    type="submit" 
                    className="btn btn-primary btn-lg rounded-3 px-4 d-flex align-items-center"
                    disabled={loading}
                    style={{ minWidth: '160px' }}
                  >
                    {loading ? (
                      <>
                        <div className="spinner-border spinner-border-sm me-2" role="status">
                          <span className="visually-hidden">Saving...</span>
                        </div>
                        Saving...
                      </>
                    ) : (
                      <>
                        <i className={`fas ${isEdit ? 'fa-save' : 'fa-plus'} me-2`}></i>
                        {isEdit ? 'Update Service' : 'Create Service'}
                      </>
                    )}
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-outline-secondary btn-lg rounded-3 px-4"
                    onClick={() => navigate('/admin/services')}
                    disabled={loading}
                  >
                    <i className="fas fa-times me-2"></i>Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        {/* Preview Panel */}
        <div className="col-lg-4">
          <div className="sticky-top" style={{ top: '2rem' }}>
            <div className="card border-0 rounded-4 shadow-sm" 
                 style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)' }}>
              <div className="card-header border-0 bg-transparent p-4 pb-0">
                <div className="d-flex align-items-center">
                  <div className="rounded-circle p-2 me-3" style={{ backgroundColor: '#e0f2fe' }}>
                    <i className="fas fa-eye text-info"></i>
                  </div>
                  <div>
                    <h5 className="mb-1 text-dark fw-bold">Live Preview</h5>
                    <p className="mb-0 text-muted">See how your service will appear</p>
                  </div>
                </div>
              </div>
              
              <div className="card-body p-4">
                <div className="card border-0 rounded-3 shadow-sm" 
                     style={{ backgroundColor: '#f8fafc' }}>
                  {formData.image && (
                    <div className="position-relative" style={{ height: '160px', overflow: 'hidden' }}>
                      <img src={formData.image} alt="Service Preview" 
                           className="card-img-top rounded-top-3" 
                           style={{ height: '100%', objectFit: 'cover' }} />
                      <div className="position-absolute top-0 end-0 m-2">
                        <div className="d-flex flex-column gap-1">
                          {formData.featured && (
                            <span className="badge rounded-pill px-2 py-1" 
                                  style={{ backgroundColor: '#f59e0b', color: 'white', fontSize: '0.7rem' }}>
                              <i className="fas fa-star me-1"></i>Featured
                            </span>
                          )}
                          <span className={`badge rounded-pill px-2 py-1 ${
                            formData.isActive 
                              ? 'bg-success' 
                              : 'bg-secondary'
                          }`} style={{ fontSize: '0.7rem' }}>
                            {formData.isActive ? 'Active' : 'Hidden'}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div className="card-body p-3">
                    <div className="mb-2">
                      <h6 className="mb-1 text-dark fw-bold">
                        {formData.title || 'Service Title'}
                      </h6>
                      {formData.category && (
                        <span className="badge rounded-pill px-2 py-1 mb-2" 
                              style={{ backgroundColor: '#e5e7eb', color: '#374151', fontSize: '0.7rem' }}>
                          <i className="fas fa-tag me-1"></i>{formData.category}
                        </span>
                      )}
                    </div>
                    
                    <p className="text-muted small mb-3" style={{ fontSize: '0.85rem' }}>
                      {formData.shortDescription || formData.description || 'No description provided'}
                    </p>
                    
                    {(formData.technologies?.length > 0 || formData.features?.length > 0) && (
                      <div className="mb-3">
                        {formData.technologies?.length > 0 && (
                          <div className="mb-2">
                            <small className="text-muted d-block mb-1">
                              <i className="fas fa-code me-1"></i>Technologies:
                            </small>
                            <div className="d-flex flex-wrap gap-1">
                              {formData.technologies.slice(0, 3).map((tech, index) => (
                                <span key={index} 
                                      className="badge rounded-pill" 
                                      style={{ backgroundColor: '#3b82f6', color: 'white', fontSize: '0.65rem' }}>
                                  {tech}
                                </span>
                              ))}
                              {formData.technologies.length > 3 && (
                                <span className="badge rounded-pill" 
                                      style={{ backgroundColor: '#6b7280', color: 'white', fontSize: '0.65rem' }}>
                                  +{formData.technologies.length - 3}
                                </span>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {formData.features?.length > 0 && (
                          <div>
                            <small className="text-muted d-block mb-1">
                              <i className="fas fa-check me-1"></i>Features:
                            </small>
                            <ul className="list-unstyled mb-0">
                              {formData.features.slice(0, 3).map((feature, index) => (
                                <li key={index} className="small text-muted mb-1">
                                  <i className="fas fa-check-circle text-success me-1" style={{ fontSize: '0.7rem' }}></i>
                                  {feature}
                                </li>
                              ))}
                              {formData.features.length > 3 && (
                                <li className="small text-muted">
                                  <i className="fas fa-ellipsis-h me-1"></i>
                                  +{formData.features.length - 3} more
                                </li>
                              )}
                            </ul>
                          </div>
                        )}
                      </div>
                    )}
                    
                    {formData.pricing?.startingPrice > 0 && (
                      <div className="d-flex align-items-center justify-content-between p-2 rounded-2" 
                           style={{ backgroundColor: '#f0fdf4', border: '1px solid #bbf7d0' }}>
                        <div>
                          <small className="text-success fw-semibold">
                            {formData.pricing.currency === 'USD' ? '$' : formData.pricing.currency}
                            {formData.pricing.startingPrice}
                            {formData.pricing.pricingModel === 'hourly' ? '/hr' : 
                             formData.pricing.pricingModel === 'monthly' ? '/mo' : ''}
                          </small>
                          {formData.deliveryTime && (
                            <div className="small text-muted">
                              <i className="fas fa-clock me-1"></i>{formData.deliveryTime}
                            </div>
                          )}
                        </div>
                        <i className="fas fa-dollar-sign text-success"></i>
                      </div>
                    )}
                    
                    {!formData.image && !formData.featured && formData.isActive && (
                      <div className="text-center py-3">
                        <div className="d-flex gap-1 justify-content-center">
                          <span className="badge bg-success" style={{ fontSize: '0.7rem' }}>
                            Active
                          </span>
                          <span className="badge bg-info" style={{ fontSize: '0.7rem' }}>
                            {formData.category}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="mt-3 p-3 rounded-3" style={{ backgroundColor: '#fef9e7', border: '1px solid #fde047' }}>
                  <div className="d-flex align-items-center">
                    <i className="fas fa-lightbulb text-warning me-2"></i>
                    <small className="text-dark fw-semibold">Preview Tips</small>
                  </div>
                  <small className="text-muted d-block mt-1">
                    This preview shows how your service will appear in the service grid. 
                    Add an image and description to see the full preview.
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceForm;
