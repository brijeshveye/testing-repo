import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createService, getService, updateService } from '../../api/ServiceDataApi';

const ServiceForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDescription: '',
    icon: '',
    iconClass: '',
    image: '',
    category: 'general',
    technologies: [],
    features: [],
    pricing: {
      startingPrice: 0,
      currency: 'USD',
      pricingModel: 'custom'
    },
    deliveryTime: '',
    processSteps: [],
    featured: false,
    isActive: true,
    seoTitle: '',
    seoDescription: '',
    seoKeywords: []
  });

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEdit) {
      fetchService();
    }
  }, [slug, isEdit]);

  const fetchService = async () => {
    try {
      setLoading(true);
      const response = await getService(slug, true); // Include inactive for admin edit
      if (response.success) {
        const serviceData = response.data;
        setFormData({
          title: serviceData.title || '',
          description: serviceData.description || '',
          shortDescription: serviceData.shortDescription || '',
          icon: serviceData.icon || '',
          iconClass: serviceData.iconClass || '',
          image: serviceData.image || '',
          category: serviceData.category || 'general',
          technologies: serviceData.technologies || [],
          features: serviceData.features || [],
          pricing: {
            startingPrice: serviceData.pricing?.startingPrice || 0,
            currency: serviceData.pricing?.currency || 'USD',
            pricingModel: serviceData.pricing?.pricingModel || 'custom'
          },
          deliveryTime: serviceData.deliveryTime || '',
          processSteps: serviceData.processSteps || [],
          featured: serviceData.featured || false,
          isActive: serviceData.isActive !== false,
          seoTitle: serviceData.seoTitle || '',
          seoDescription: serviceData.seoDescription || '',
          seoKeywords: serviceData.seoKeywords || []
        });
      } else {
        setErrors({ general: response.message || 'Failed to fetch service details' });
      }
    } catch (error) {
      console.error('Error fetching service:', error);
      setErrors({ general: 'Failed to fetch service details' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: type === 'checkbox' ? checked : value
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }
  };

  const handleArrayChange = (field, index, value) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: prev[parent][child].map((item, i) => i === index ? value : item)
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: prev[field].map((item, i) => i === index ? value : item)
      }));
    }
  };

  const addArrayItem = (field) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: [...prev[parent][child], '']
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: [...prev[field], '']
      }));
    }
  };

  const removeArrayItem = (field, index) => {
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: prev[parent][child].filter((_, i) => i !== index)
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [field]: prev[field].filter((_, i) => i !== index)
      }));
    }
  };

  const handleTagsChange = (e) => {
    const tags = e.target.value.split(',').map(tag => tag.trim()).filter(tag => tag);
    setFormData(prev => ({ ...prev, tags }));
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (!formData.icon.trim()) {
      newErrors.icon = 'Icon is required';
    }

    if ((formData.pricing?.amount || 0) < 0) {
      newErrors['pricing.amount'] = 'Price cannot be negative';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      let response;

      if (isEdit) {
        response = await updateService(slug, formData);
      } else {
        response = await createService(formData);
      }

      if (response.success) {
        navigate('/admin/services');
      } else {
        setErrors({ general: response.message || 'Failed to save service' });
      }
    } catch (error) {
      console.error('Error saving service:', error);
      setErrors({ general: 'Failed to save service. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">
                {isEdit ? 'Edit Service' : 'Create New Service'}
              </h5>
            </div>
            <div className="card-body">
              {errors.general && (
                <div className="alert alert-danger" role="alert">
                  {errors.general}
                </div>
              )}

              <form onSubmit={handleSubmit}>
                {/* Basic Information */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Basic Information</h6>
                  
                  <div className="mb-3">
                    <label htmlFor="title" className="form-label">Title *</label>
                    <input
                      type="text"
                      className={`form-control ${errors.title ? 'is-invalid' : ''}`}
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      required
                    />
                    {errors.title && <div className="invalid-feedback">{errors.title}</div>}
                  </div>

                  <div className="mb-3">
                    <label htmlFor="description" className="form-label">Description *</label>
                    <textarea
                      className={`form-control ${errors.description ? 'is-invalid' : ''}`}
                      id="description"
                      name="description"
                      rows="3"
                      value={formData.description}
                      onChange={handleChange}
                      required
                    />
                    {errors.description && <div className="invalid-feedback">{errors.description}</div>}
                  </div>

                  <div className="mb-3">
                    <label htmlFor="shortDescription" className="form-label">Short Description</label>
                    <textarea
                      className="form-control"
                      id="shortDescription"
                      name="shortDescription"
                      rows="2"
                      value={formData.shortDescription}
                      onChange={handleChange}
                      placeholder="Brief summary of the service..."
                    />
                  </div>

                  <div className="row">
                    <div className="col-md-6">
                      <label htmlFor="icon" className="form-label">Icon</label>
                      <input
                        type="text"
                        className="form-control"
                        id="icon"
                        name="icon"
                        value={formData.icon}
                        onChange={handleChange}
                        placeholder="Icon URL or path"
                      />
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="iconClass" className="form-label">Icon Class</label>
                      <input
                        type="text"
                        className="form-control"
                        id="iconClass"
                        name="iconClass"
                        value={formData.iconClass}
                        onChange={handleChange}
                        placeholder="e.g., fas fa-code"
                      />
                    </div>
                  </div>

                  <div className="mb-3">
                    <label htmlFor="image" className="form-label">Service Image</label>
                    <input
                      type="text"
                      className="form-control"
                      id="image"
                      name="image"
                      value={formData.image}
                      onChange={handleChange}
                      placeholder="Image URL or path"
                    />
                  </div>

                  <div className="row">
                    <div className="col-md-6">
                      <label htmlFor="category" className="form-label">Category</label>
                      <select
                        className="form-select"
                        id="category"
                        name="category"
                        value={formData.category}
                        onChange={handleChange}
                      >
                        <option value="general">General</option>
                        <option value="development">Development</option>
                        <option value="design">Design</option>
                        <option value="consulting">Consulting</option>
                        <option value="marketing">Marketing</option>
                      </select>
                    </div>
                    <div className="col-md-6">
                      <label htmlFor="deliveryTime" className="form-label">Delivery Time</label>
                      <input
                        type="text"
                        className="form-control"
                        id="deliveryTime"
                        name="deliveryTime"
                        value={formData.deliveryTime}
                        onChange={handleChange}
                        placeholder="e.g., 2-3 weeks"
                      />
                    </div>
                  </div>

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="featured"
                      name="featured"
                      checked={formData.featured}
                      onChange={handleChange}
                    />
                    <label className="form-check-label" htmlFor="featured">
                      Featured Service
                    </label>
                  </div>

                  <div className="form-check mb-3">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="isActive"
                      name="isActive"
                      checked={formData.isActive}
                      onChange={handleChange}
                    />
                    <label className="form-check-label" htmlFor="isActive">
                      Active
                    </label>
                  </div>
                </div>

                {/* Details Section */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Service Details</h6>
                  
                  <div className="mb-3">
                    <label htmlFor="details.overview" className="form-label">Overview</label>
                    <textarea
                      className="form-control"
                      id="details.overview"
                      name="details.overview"
                      rows="4"
                      value={formData.details.overview}
                      onChange={handleChange}
                      placeholder="Detailed overview of the service..."
                    />
                  </div>

                  {/* Features */}
                  <div className="mb-3">
                    <label className="form-label">Features</label>
                    {(formData.details?.features || []).map((feature, index) => (
                      <div key={index} className="input-group mb-2">
                        <input
                          type="text"
                          className="form-control"
                          value={feature}
                          onChange={(e) => handleArrayChange('details.features', index, e.target.value)}
                          placeholder="Service feature..."
                        />
                        <button
                          type="button"
                          className="btn btn-outline-danger"
                          onClick={() => removeArrayItem('details.features', index)}
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm"
                      onClick={() => addArrayItem('details.features')}
                    >
                      Add Feature
                    </button>
                  </div>

                  {/* Benefits */}
                  <div className="mb-3">
                    <label className="form-label">Benefits</label>
                    {(formData.details?.benefits || []).map((benefit, index) => (
                      <div key={index} className="input-group mb-2">
                        <input
                          type="text"
                          className="form-control"
                          value={benefit}
                          onChange={(e) => handleArrayChange('details.benefits', index, e.target.value)}
                          placeholder="Service benefit..."
                        />
                        <button
                          type="button"
                          className="btn btn-outline-danger"
                          onClick={() => removeArrayItem('details.benefits', index)}
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm"
                      onClick={() => addArrayItem('details.benefits')}
                    >
                      Add Benefit
                    </button>
                  </div>

                  {/* Process */}
                  <div className="mb-3">
                    <label className="form-label">Process Steps</label>
                    {(formData.details?.process || []).map((step, index) => (
                      <div key={index} className="input-group mb-2">
                        <input
                          type="text"
                          className="form-control"
                          value={step}
                          onChange={(e) => handleArrayChange('details.process', index, e.target.value)}
                          placeholder="Process step..."
                        />
                        <button
                          type="button"
                          className="btn btn-outline-danger"
                          onClick={() => removeArrayItem('details.process', index)}
                        >
                          Remove
                        </button>
                      </div>
                    ))}
                    <button
                      type="button"
                      className="btn btn-outline-primary btn-sm"
                      onClick={() => addArrayItem('details.process')}
                    >
                      Add Process Step
                    </button>
                  </div>
                </div>

                {/* Pricing Section */}
                <div className="mb-4">
                  <h6 className="border-bottom pb-2">Pricing</h6>
                  
                  <div className="row">
                    <div className="col-md-4">
                      <label htmlFor="pricing.type" className="form-label">Pricing Type</label>
                      <select
                        className="form-select"
                        id="pricing.type"
                        name="pricing.type"
                        value={formData.pricing.type}
                        onChange={handleChange}
                      >
                        <option value="fixed">Fixed Price</option>
                        <option value="hourly">Hourly Rate</option>
                        <option value="project">Project Based</option>
                      </select>
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="pricing.amount" className="form-label">Amount</label>
                      <input
                        type="number"
                        className={`form-control ${errors['pricing.amount'] ? 'is-invalid' : ''}`}
                        id="pricing.amount"
                        name="pricing.amount"
                        value={formData.pricing.amount}
                        onChange={handleChange}
                        min="0"
                        step="0.01"
                      />
                      {errors['pricing.amount'] && <div className="invalid-feedback">{errors['pricing.amount']}</div>}
                    </div>
                    <div className="col-md-4">
                      <label htmlFor="pricing.currency" className="form-label">Currency</label>
                      <select
                        className="form-select"
                        id="pricing.currency"
                        name="pricing.currency"
                        value={formData.pricing.currency}
                        onChange={handleChange}
                      >
                        <option value="USD">USD</option>
                        <option value="EUR">EUR</option>
                        <option value="GBP">GBP</option>
                        <option value="CAD">CAD</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Form Actions */}
                <div className="d-flex justify-content-between">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/services')}
                    disabled={loading}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        {isEdit ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      isEdit ? 'Update Service' : 'Create Service'
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">Preview</h5>
            </div>
            <div className="card-body">
              <div className="service-preview">
                <div className="text-center mb-3">
                  <div 
                    className="d-inline-flex align-items-center justify-content-center rounded-circle"
                    style={{ 
                      width: '80px', 
                      height: '80px', 
                      backgroundColor: formData.color || '#007bff',
                      color: 'white'
                    }}
                  >
                    {formData.icon ? (
                      <i className={`${formData.icon} fa-2x`}></i>
                    ) : (
                      <i className="fas fa-cogs fa-2x"></i>
                    )}
                  </div>
                </div>

                <h6 className="mb-2 text-center">{formData.title || 'Service Title'}</h6>
                <p className="text-muted small mb-3 text-center">
                  {formData.description || 'Service description will appear here...'}
                </p>

                {(formData.pricing?.amount || 0) > 0 && (
                  <div className="text-center mb-3">
                    <span className="h5 text-primary">
                      {formData.pricing?.currency || 'USD'} {formData.pricing?.amount || 0}
                      {formData.pricing?.type === 'hourly' && '/hr'}
                      {formData.pricing?.type === 'project' && '/project'}
                    </span>
                  </div>
                )}

                {(formData.tags || []).length > 0 && (
                  <div className="mb-3">
                    <small className="text-muted d-block mb-1">
                      <strong>Tags:</strong>
                    </small>
                    <div className="d-flex flex-wrap gap-1">
                      {(formData.tags || []).slice(0, 3).map((tag, index) => (
                        <span key={index} className="badge bg-light text-dark">
                          {tag}
                        </span>
                      ))}
                      {(formData.tags || []).length > 3 && (
                        <span className="badge bg-light text-muted">
                          +{(formData.tags || []).length - 3} more
                        </span>
                      )}
                    </div>
                  </div>
                )}

                {(formData.details?.features || []).length > 0 && (
                  <div className="mb-3">
                    <small className="text-muted d-block mb-1">
                      <strong>Features:</strong>
                    </small>
                    <ul className="list-unstyled small">
                      {(formData.details?.features || []).slice(0, 3).map((feature, index) => (
                        <li key={index} className="mb-1">
                          <i className="fas fa-check text-success me-2"></i>
                          {feature || 'Feature description'}
                        </li>
                      ))}
                      {(formData.details?.features || []).length > 3 && (
                        <li className="text-muted">
                          +{(formData.details?.features || []).length - 3} more features
                        </li>
                      )}
                    </ul>
                  </div>
                )}

                <div className="d-flex justify-content-center gap-2">
                  {formData.featured && (
                    <span className="badge bg-warning text-dark">
                      <i className="fas fa-star me-1"></i>Featured
                    </span>
                  )}
                  <span className={`badge ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                    {formData.isActive ? 'Active' : 'Inactive'}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceForm;
