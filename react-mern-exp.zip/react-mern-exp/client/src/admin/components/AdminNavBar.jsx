import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const AdminNavBar = ({ sessionToken, deviceFingerprint, onLogout }) => {
    const location = useLocation();
    const navigate = useNavigate();

    const handleLogout = async () => {
        try {
            if (sessionToken) {
                await fetch('/api/pin/logout', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        sessionToken,
                        deviceFingerprint
                    }),
                });
            }
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            // Clear local storage
            localStorage.removeItem('adminSession');
            localStorage.removeItem('deviceFingerprint');
            
            // Call parent logout handler
            if (onLogout) {
                onLogout();
            }
            
            toast.success('Logged out successfully');
            navigate('/');
        }
    };

    return (
        <div className="mb-4 pt-5">
            <nav className="navbar navbar-expand-lg shadow-sm mt-5" style={{ backgroundColor: 'white', borderBottom: '1px solid #e0e0e0' }}>
                <div className="container-fluid px-4">
                    {/* Brand */}
                    <Link className="navbar-brand d-flex align-items-center" to="/admin" style={{ textDecoration: 'none' }}>
                        <div 
                            className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                            style={{ 
                                width: '40px', 
                                height: '40px', 
                                backgroundColor: '#1976d2',
                                color: 'white'
                            }}
                        >
                            <i className="fas fa-user-shield"></i>
                        </div>
                        <div>
                            <div className="fw-bold text-dark" style={{ fontSize: '1.1rem' }}>Admin Panel</div>
                            <small className="text-muted">BR Portfolio Management</small>
                        </div>
                    </Link>

                    {/* Mobile Toggle */}
                    <button
                        className="navbar-toggler border-0 p-2"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#adminNavbar"
                        style={{ backgroundColor: '#f8f9fa', borderRadius: '8px' }}
                    >
                        <i className="fas fa-bars text-dark"></i>
                    </button>

                    {/* Navigation Menu */}
                    <div className="collapse navbar-collapse" id="adminNavbar">
                        <ul className="navbar-nav me-auto ms-lg-4">
                            <li className="nav-item mx-1">
                                <Link 
                                    className={`nav-link px-3 py-2 rounded-pill fw-medium ${location.pathname.includes('/admin/user') ? 'text-white' : 'text-dark'}`}
                                    to="/admin/user"
                                    style={{
                                        backgroundColor: location.pathname.includes('/admin/user') ? '#1976d2' : 'transparent',
                                        transition: 'all 0.2s ease-in-out'
                                    }}
                                >
                                    <i className="fas fa-user me-2"></i>
                                    Profile
                                </Link>
                            </li>
                            <li className="nav-item mx-1">
                                <Link 
                                    className={`nav-link px-3 py-2 rounded-pill fw-medium ${location.pathname.includes('/admin/skills') ? 'text-white' : 'text-dark'}`}
                                    to="/admin/skills"
                                    style={{
                                        backgroundColor: location.pathname.includes('/admin/skills') ? '#0288d1' : 'transparent',
                                        transition: 'all 0.2s ease-in-out'
                                    }}
                                >
                                    <i className="fas fa-code me-2"></i>
                                    Skills
                                </Link>
                            </li>
                            <li className="nav-item mx-1">
                                <Link 
                                    className={`nav-link px-3 py-2 rounded-pill fw-medium ${location.pathname.includes('/admin/experience') ? 'text-white' : 'text-dark'}`}
                                    to="/admin/experience"
                                    style={{
                                        backgroundColor: location.pathname.includes('/admin/experience') ? '#6c757d' : 'transparent',
                                        transition: 'all 0.2s ease-in-out'
                                    }}
                                >
                                    <i className="fas fa-briefcase me-2"></i>
                                    Experience
                                </Link>
                            </li>
                            <li className="nav-item mx-1">
                                <Link 
                                    className={`nav-link px-3 py-2 rounded-pill fw-medium ${location.pathname.includes('/admin/projects') ? 'text-white' : 'text-dark'}`}
                                    to="/admin/projects"
                                    style={{
                                        backgroundColor: location.pathname.includes('/admin/projects') ? '#43a047' : 'transparent',
                                        transition: 'all 0.2s ease-in-out'
                                    }}
                                >
                                    <i className="fas fa-project-diagram me-2"></i>
                                    Projects
                                </Link>
                            </li>
                            <li className="nav-item mx-1">
                                <Link 
                                    className={`nav-link px-3 py-2 rounded-pill fw-medium ${location.pathname.includes('/admin/blogs') ? 'text-white' : 'text-dark'}`}
                                    to="/admin/blogs"
                                    style={{
                                        backgroundColor: location.pathname.includes('/admin/blogs') ? '#00acc1' : 'transparent',
                                        transition: 'all 0.2s ease-in-out'
                                    }}
                                >
                                    <i className="fas fa-blog me-2"></i>
                                    Blogs
                                </Link>
                            </li>
                        </ul>

                        {/* User Menu */}
                        <ul className="navbar-nav">
                            <li className="nav-item dropdown">
                                <a
                                    className="nav-link dropdown-toggle d-flex align-items-center px-3 py-2 rounded-pill"
                                    href="#"
                                    id="adminDropdown"
                                    role="button"
                                    data-bs-toggle="dropdown"
                                    style={{ 
                                        backgroundColor: '#f8f9fa',
                                        color: '#495057',
                                        textDecoration: 'none',
                                        transition: 'all 0.2s ease-in-out'
                                    }}
                                >
                                    <div 
                                        className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                                        style={{ 
                                            width: '32px', 
                                            height: '32px', 
                                            backgroundColor: '#1976d2',
                                            color: 'white'
                                        }}
                                    >
                                        <i className="fas fa-user" style={{ fontSize: '0.8rem' }}></i>
                                    </div>
                                    <span className="fw-medium">Admin</span>
                                </a>
                                <ul className="dropdown-menu dropdown-menu-end shadow-sm border-0 mt-2" style={{ borderRadius: '12px', minWidth: '200px' }}>
                                    <li>
                                        <div className="px-3 py-2 border-bottom">
                                            <small className="text-muted text-uppercase fw-medium">Account</small>
                                        </div>
                                    </li>
                                    <li>
                                        <Link 
                                            className="dropdown-item d-flex align-items-center px-3 py-2" 
                                            to="/"
                                            style={{ transition: 'background-color 0.2s ease-in-out' }}
                                        >
                                            <div 
                                                className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                                                style={{ 
                                                    width: '32px', 
                                                    height: '32px', 
                                                    backgroundColor: '#e8f5e8'
                                                }}
                                            >
                                                <i className="fas fa-home text-success" style={{ fontSize: '0.8rem' }}></i>
                                            </div>
                                            <div>
                                                <div className="fw-medium text-dark">View Website</div>
                                                <small className="text-muted">Go to public site</small>
                                            </div>
                                        </Link>
                                    </li>
                                    <li><hr className="dropdown-divider my-1" /></li>
                                    <li>
                                        <button 
                                            className="dropdown-item d-flex align-items-center px-3 py-2 w-100 border-0 bg-transparent" 
                                            onClick={handleLogout}
                                            style={{ transition: 'background-color 0.2s ease-in-out' }}
                                        >
                                            <div 
                                                className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                                                style={{ 
                                                    width: '32px', 
                                                    height: '32px', 
                                                    backgroundColor: '#ffebee'
                                                }}
                                            >
                                                <i className="fas fa-sign-out-alt text-danger" style={{ fontSize: '0.8rem' }}></i>
                                            </div>
                                            <div>
                                                <div className="fw-medium text-dark">Logout</div>
                                                <small className="text-muted">Sign out of admin</small>
                                            </div>
                                        </button>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

    );
};

export default AdminNavBar;
