import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ExperienceDataApi from '../../api/ExperienceDataApi';
import ExperienceCard from '../../components/experience/ExperienceCard';
import { showSuccess, showError } from '../../utils/toastUtils';

const ExperienceList = () => {
  const [experience, setExperience] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    company: '',
    employmentType: 'all',
    featured: 'all',
    status: 'all',
    current: 'all',
    search: ''
  });

  useEffect(() => {
    fetchExperience();
    fetchStats();
  }, [filters]);

  const fetchExperience = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.company) params.company = filters.company;
      if (filters.employmentType !== 'all') params.employmentType = filters.employmentType;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.current !== 'all') params.current = filters.current;
      if (filters.search) params.search = filters.search;

      const data = await ExperienceDataApi.getExperienceData(params);
      setExperience(data);
    } catch (err) {
      setError('Failed to fetch experience records');
      console.error('Error fetching experience:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await ExperienceDataApi.getExperienceStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleEdit = (experienceItem) => {
    window.location.href = `/admin/experience/edit/${experienceItem.slug}`;
  };

  const handleDelete = async (experienceItem) => {
    if (window.confirm(`Are you sure you want to delete "${experienceItem.title}" at ${experienceItem.company}?`)) {
      try {
        await ExperienceDataApi.deleteExperience(experienceItem.slug);
        showSuccess('Experience record deleted successfully!');
        fetchExperience();
        fetchStats();
      } catch (err) {
        showError('Failed to delete experience record');
        console.error('Error deleting experience:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await ExperienceDataApi.toggleFeatured(slug);
      showSuccess('Featured status updated successfully!');
      fetchExperience();
      fetchStats();
    } catch (err) {
      showError('Failed to toggle featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await ExperienceDataApi.toggleActive(slug);
      showSuccess('Active status updated successfully!');
      fetchExperience();
      fetchStats();
    } catch (err) {
      showError('Failed to toggle active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  if (loading && experience.length === 0) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading experience data...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-center">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-3"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#1976d2',
                    color: 'white'
                  }}
                >
                  <i className="fas fa-briefcase" style={{ fontSize: '20px' }}></i>
                </div>
                <div>
                  <h2 className="mb-1" style={{ color: '#2c3e50', fontWeight: '600' }}>
                    Experience Management
                  </h2>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb mb-0" style={{ fontSize: '0.9rem' }}>
                      <li className="breadcrumb-item">
                        <Link to="/admin" className="text-decoration-none">Admin</Link>
                      </li>
                      <li className="breadcrumb-item active text-muted">Experience</li>
                    </ol>
                  </nav>
                </div>
              </div>
              <Link 
                to="/admin/experience/create" 
                className="btn btn-primary d-flex align-items-center"
                style={{ borderRadius: '12px', padding: '0.6rem 1.2rem' }}
              >
                <i className="fas fa-plus me-2"></i>
                Add Experience
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="row g-4 mb-4">
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #1976d2' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#e3f2fd' }}
                        >
                          <i className="fas fa-briefcase text-primary"></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Total Experience</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#1976d2' }}>{stats.totalExperience}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #2e7d32' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#e8f5e8' }}
                        >
                          <i className="fas fa-eye text-success"></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Active</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#2e7d32' }}>{stats.activeExperience}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #ffa000' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#fff8e1' }}
                        >
                          <i className="fas fa-star" style={{ color: '#ffa000' }}></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Featured</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#ffa000' }}>{stats.featuredExperience}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #0288d1' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#e1f5fe' }}
                        >
                          <i className="fas fa-play text-info"></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Current</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#0288d1' }}>{stats.currentExperience}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
            <div className="d-flex align-items-center">
              <div 
                className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                style={{ 
                  width: '48px', 
                  height: '48px', 
                  backgroundColor: '#f3e5f5'
                }}
              >
                <i className="fas fa-filter text-secondary fs-5"></i>
              </div>
              <div>
                <h5 className="mb-0 fw-bold text-dark">Filters & Search</h5>
                <small className="text-muted">Filter experience records by various criteria</small>
              </div>
            </div>
          </div>
          <div className="card-body p-4">
            <div className="row g-3">
              <div className="col-md-4">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-search me-2 text-muted"></i>Search
                </label>
                <input
                  type="text"
                  className="form-control rounded-pill py-2"
                  placeholder="Search experience..."
                  value={filters.search}
                  onChange={(e) => handleFilterChange('search', e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                />
              </div>
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-building me-2 text-muted"></i>Company
                </label>
                <input
                  type="text"
                  className="form-control rounded-pill py-2"
                  placeholder="Company name..."
                  value={filters.company}
                  onChange={(e) => handleFilterChange('company', e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                />
              </div>
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-user-tie me-2 text-muted"></i>Employment
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={filters.employmentType}
                  onChange={(e) => handleFilterChange('employmentType', e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All Types</option>
                  <option value="Full-time">Full-time</option>
                  <option value="Part-time">Part-time</option>
                  <option value="Contract">Contract</option>
                  <option value="Internship">Internship</option>
                  <option value="Freelance">Freelance</option>
                  <option value="Volunteer">Volunteer</option>
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-star me-2 text-muted"></i>Featured
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={filters.featured}
                  onChange={(e) => handleFilterChange('featured', e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Featured</option>
                  <option value="false">Not Featured</option>
                </select>
              </div>
              <div className="col-md-1">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-eye me-2 text-muted"></i>Status
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={filters.status}
                  onChange={(e) => handleFilterChange('status', e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Active</option>
                  <option value="false">Hidden</option>
                </select>
              </div>
              <div className="col-md-1">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-clock me-2 text-muted"></i>Current
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={filters.current}
                  onChange={(e) => handleFilterChange('current', e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Current</option>
                  <option value="false">Past</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #dc3545' }}>
            <div className="card-body p-4" style={{ backgroundColor: '#fff5f5' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ width: '40px', height: '40px', backgroundColor: '#dc3545', color: 'white' }}
                >
                  <i className="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                  <h6 className="mb-1" style={{ color: '#dc3545', fontWeight: '600' }}>Error</h6>
                  <p className="mb-0 text-muted">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Experience Grid */}
        {experience.length === 0 ? (
          <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
            <div className="card-body py-5 text-center">
              <div 
                className="rounded-circle mx-auto mb-4 d-flex align-items-center justify-content-center"
                style={{ 
                  width: '80px', 
                  height: '80px', 
                  backgroundColor: '#f8f9fa'
                }}
              >
                <i className="fas fa-briefcase fa-2x text-muted"></i>
              </div>
              <h3 className="text-dark mb-3">No Experience Records Found</h3>
              <p className="text-muted mb-4">Start by adding your first work experience to showcase your professional journey.</p>
              <Link 
                to="/admin/experience/create" 
                className="btn btn-primary rounded-pill px-4 py-2"
              >
                <i className="fas fa-plus me-2"></i>Add Your First Experience
              </Link>
            </div>
          </div>
        ) : (
          <div className="row g-4">
            {experience.map((exp) => (
              <ExperienceCard
                key={exp._id}
                experience={exp}
                onEdit={handleEdit}
                onDelete={handleDelete}
                onToggleFeatured={handleToggleFeatured}
                onToggleActive={handleToggleActive}
              />
            ))}
          </div>
        )}

        {/* Loading Overlay */}
        {loading && experience.length > 0 && (
          <div className="card border-0 shadow-sm mt-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4 text-center">
              <div className="spinner-border text-primary mb-2" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
              <p className="text-muted mb-0">Updating experience data...</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExperienceList;
