import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  getAllCharacteristics, 
  deleteCharacteristic, 
  toggleCharacteristicFeatured, 
  toggleCharacteristicActive,
  getCharacteristicStats
} from '../../api/CharacteristicsDataApi';
import { showSuccess, showError } from '../../utils/toastUtils';

const CharacteristicList = () => {
  const [characteristics, setCharacteristics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [sortBy, setSortBy] = useState('order');
  const [sortOrder, setSortOrder] = useState('asc');
  const [stats, setStats] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [pagination, setPagination] = useState(null);
  const [imageErrors, setImageErrors] = useState({}); // Track image load errors

  useEffect(() => {
    fetchCharacteristics();
    fetchStats();
  }, [searchTerm, filterCategory, filterStatus, sortBy, sortOrder, currentPage]);

  const fetchCharacteristics = async () => {
    try {
      setLoading(true);
      const params = {
        page: currentPage,
        limit: 10,
        sortBy,
        sortOrder
      };

      if (searchTerm) params.search = searchTerm;
      if (filterCategory) params.category = filterCategory;
      if (filterStatus) {
        if (filterStatus === 'active') params.isActive = 'true';
        if (filterStatus === 'inactive') params.isActive = 'false';
        if (filterStatus === 'featured') params.featured = 'true';
      }

      const response = await getAllCharacteristics(params);
      setCharacteristics(response.characteristics || response);
      setPagination(response.pagination);
      setImageErrors({}); // Reset image errors when loading new data
    } catch (error) {
      console.error('Error fetching characteristics:', error);
      setError('Failed to load characteristics');
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await getCharacteristicStats();
      setStats(statsData);
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await deleteCharacteristic(slug);
        showSuccess('Characteristic deleted successfully!');
        fetchCharacteristics();
        fetchStats();
      } catch (error) {
        console.error('Error deleting characteristic:', error);
        showError('Failed to delete characteristic');
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await toggleCharacteristicFeatured(slug);
      showSuccess('Featured status updated successfully!');
      fetchCharacteristics();
      fetchStats();
    } catch (error) {
      console.error('Error toggling featured:', error);
      showError('Failed to update featured status');
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await toggleCharacteristicActive(slug);
      showSuccess('Active status updated successfully!');
      fetchCharacteristics();
      fetchStats();
    } catch (error) {
      console.error('Error toggling active:', error);
      showError('Failed to update active status');
    }
  };

  const getUniqueCategories = () => {
    const categories = characteristics.map(char => char.category).filter(Boolean);
    return [...new Set(categories)];
  };

  if (loading) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading characteristics...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-center">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-3"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#9c27b0',
                    color: 'white'
                  }}
                >
                  <i className="fas fa-star" style={{ fontSize: '20px' }}></i>
                </div>
                <div>
                  <h2 className="mb-1" style={{ color: '#2c3e50', fontWeight: '600' }}>
                    Manage Characteristics
                  </h2>
                  <p className="text-muted mb-0">
                    Showcase your key attributes and achievements
                  </p>
                </div>
              </div>
              <Link 
                to="/admin/characteristics/create" 
                className="btn btn-primary d-flex align-items-center"
                style={{ borderRadius: '12px', padding: '0.6rem 1.2rem' }}
              >
                <i className="fas fa-plus me-2"></i>
                Add Characteristic
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        {stats && (
          <div className="row g-4 mb-4">
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #9c27b0' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#f3e5f5' }}
                        >
                          <i className="fas fa-star" style={{ color: '#9c27b0' }}></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Total</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#9c27b0' }}>{stats.total}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #2e7d32' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#e8f5e8' }}
                        >
                          <i className="fas fa-check-circle text-success"></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Active</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#2e7d32' }}>{stats.active}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #ffa000' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#fff8e1' }}
                        >
                          <i className="fas fa-star" style={{ color: '#ffa000' }}></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Featured</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#ffa000' }}>{stats.featured}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #6c757d' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#f8f9fa' }}
                        >
                          <i className="fas fa-times-circle text-secondary"></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Inactive</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#6c757d' }}>{stats.inactive}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
            <div className="d-flex align-items-center">
              <div 
                className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                style={{ 
                  width: '48px', 
                  height: '48px', 
                  backgroundColor: '#f3e5f5'
                }}
              >
                <i className="fas fa-filter text-secondary fs-5"></i>
              </div>
              <div>
                <h5 className="mb-0 fw-bold text-dark">Filters & Search</h5>
                <small className="text-muted">Filter and sort your characteristics</small>
              </div>
            </div>
          </div>
          <div className="card-body p-4">
            <div className="row g-3">
              <div className="col-md-3">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-search me-2 text-muted"></i>Search
                </label>
                <input
                  type="text"
                  className="form-control rounded-pill py-2"
                  placeholder="Search characteristics..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                />
              </div>
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-layer-group me-2 text-muted"></i>Category
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={filterCategory}
                  onChange={(e) => setFilterCategory(e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="">All Categories</option>
                  {getUniqueCategories().map(category => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-toggle-on me-2 text-muted"></i>Status
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="">All Status</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                  <option value="featured">Featured</option>
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-sort me-2 text-muted"></i>Sort By
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="order">Order</option>
                  <option value="title">Title</option>
                  <option value="category">Category</option>
                  <option value="createdAt">Created Date</option>
                </select>
              </div>
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-sort-amount-up me-2 text-muted"></i>Order
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value)}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="asc">Ascending</option>
                  <option value="desc">Descending</option>
                </select>
              </div>
              <div className="col-md-1">
                <label className="form-label fw-medium text-dark">&nbsp;</label>
                <button
                  className="btn btn-outline-secondary rounded-pill w-100 py-2"
                  onClick={() => {
                    setSearchTerm('');
                    setFilterCategory('');
                    setFilterStatus('');
                    setSortBy('order');
                    setSortOrder('asc');
                  }}
                  title="Clear all filters"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #dc3545' }}>
            <div className="card-body p-4" style={{ backgroundColor: '#fff5f5' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ width: '40px', height: '40px', backgroundColor: '#dc3545', color: 'white' }}
                >
                  <i className="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                  <h6 className="mb-1" style={{ color: '#dc3545', fontWeight: '600' }}>Error</h6>
                  <p className="mb-0 text-muted">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Characteristics Table Card */}
        <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
          <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#e3f2fd'
                  }}
                >
                  <i className="fas fa-list text-primary fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Characteristics List</h5>
                  <small className="text-muted">Manage your personal characteristics and attributes</small>
                </div>
              </div>
              {characteristics.length > 0 && (
                <span className="badge bg-light text-dark px-3 py-2 rounded-pill">
                  {characteristics.length} item{characteristics.length !== 1 ? 's' : ''}
                </span>
              )}
            </div>
          </div>
          <div className="card-body p-4">
            {characteristics.length === 0 ? (
              <div className="text-center py-5">
                <div 
                  className="rounded-circle mx-auto mb-4 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '80px', 
                    height: '80px', 
                    backgroundColor: '#f8f9fa'
                  }}
                >
                  <i className="fas fa-star fa-2x text-muted"></i>
                </div>
                <h3 className="text-dark mb-3">No Characteristics Found</h3>
                <p className="text-muted mb-4">Start building your profile by adding your first characteristic.</p>
                <Link 
                  to="/admin/characteristics/create" 
                  className="btn btn-primary rounded-pill px-4 py-2"
                >
                  <i className="fas fa-plus me-2"></i>Create First Characteristic
                </Link>
              </div>
            ) : (
              <>
                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead style={{ backgroundColor: '#f8f9fa' }}>
                      <tr>
                        <th className="border-0 py-3 fw-bold text-dark">Characteristic</th>
                        <th className="border-0 py-3 fw-bold text-dark">Category</th>
                        <th className="border-0 py-3 fw-bold text-dark">Value</th>
                        <th className="border-0 py-3 fw-bold text-dark">Status</th>
                        <th className="border-0 py-3 fw-bold text-dark">Featured</th>
                        <th className="border-0 py-3 fw-bold text-dark">Order</th>
                        <th className="border-0 py-3 fw-bold text-dark">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {characteristics.map((characteristic) => (
                        <tr key={characteristic._id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                          <td className="py-3">
                            <div className="d-flex align-items-center">
                              {/* Icon/Image Display */}
                              <div 
                                className="me-3 rounded-circle d-flex align-items-center justify-content-center"
                                style={{ 
                                  width: '48px', 
                                  height: '48px', 
                                  backgroundColor: '#f8f9fa',
                                  border: '2px solid #e0e0e0'
                                }}
                              >
                                {characteristic.image && !imageErrors[characteristic._id] ? (
                                  <img 
                                    src={characteristic.image} 
                                    alt="Icon" 
                                    style={{ 
                                      maxWidth: '32px', 
                                      maxHeight: '32px', 
                                      objectFit: 'contain',
                                      borderRadius: '50%'
                                    }}
                                    onError={() => {
                                      console.warn('Image failed to load for characteristic:', characteristic.title);
                                      setImageErrors(prev => ({ ...prev, [characteristic._id]: true }));
                                    }}
                                    onLoad={() => {
                                      setImageErrors(prev => ({ ...prev, [characteristic._id]: false }));
                                    }}
                                  />
                                ) : characteristic.image && imageErrors[characteristic._id] ? (
                                  <i 
                                    className="fas fa-image text-muted"
                                    title="Image failed to load"
                                  ></i>
                                ) : characteristic.iconClass ? (
                                  <i 
                                    className={characteristic.iconClass} 
                                    style={{ 
                                      color: characteristic.color || '#007bff',
                                      fontSize: '18px'
                                    }}
                                  ></i>
                                ) : (
                                  <i className="fas fa-star text-muted"></i>
                                )}
                              </div>
                              <div>
                                <h6 className="mb-1 fw-bold text-dark">{characteristic.title}</h6>
                                <small className="text-muted">
                                  {characteristic.description?.substring(0, 80)}
                                  {characteristic.description?.length > 80 ? '...' : ''}
                                </small>
                              </div>
                            </div>
                          </td>
                          <td className="py-3">
                            <span 
                              className="badge rounded-pill px-3 py-2 fw-medium"
                              style={{ 
                                backgroundColor: '#f3e5f5', 
                                color: '#7b1fa2'
                              }}
                            >
                              {characteristic.category || 'Uncategorized'}
                            </span>
                          </td>
                          <td className="py-3">
                            {characteristic.value !== undefined ? (
                              <span className="fw-medium text-dark">
                                {characteristic.value}{characteristic.unit}
                              </span>
                            ) : (
                              <span className="text-muted">-</span>
                            )}
                          </td>
                          <td className="py-3">
                            <button
                              className={`btn btn-sm rounded-pill px-3 fw-medium ${
                                characteristic.isActive 
                                  ? 'btn-success text-white' 
                                  : 'btn-outline-secondary'
                              }`}
                              onClick={() => handleToggleActive(characteristic.slug)}
                            >
                              <i className={`fas ${characteristic.isActive ? 'fa-check' : 'fa-times'} me-1`}></i>
                              {characteristic.isActive ? 'Active' : 'Inactive'}
                            </button>
                          </td>
                          <td className="py-3">
                            <button
                              className={`btn btn-sm rounded-circle ${
                                characteristic.featured 
                                  ? 'btn-warning text-white' 
                                  : 'btn-outline-warning'
                              }`}
                              onClick={() => handleToggleFeatured(characteristic.slug)}
                              style={{ width: '36px', height: '36px' }}
                              title={characteristic.featured ? 'Remove from featured' : 'Add to featured'}
                            >
                              <i className="fas fa-star"></i>
                            </button>
                          </td>
                          <td className="py-3">
                            <span 
                              className="badge bg-light text-dark px-3 py-2 rounded-pill fw-medium"
                            >
                              {characteristic.order}
                            </span>
                          </td>
                          <td className="py-3">
                            <div className="btn-group" role="group">
                              <Link
                                to={`/admin/characteristics/edit/${characteristic.slug}`}
                                className="btn btn-sm btn-outline-primary rounded-pill px-3"
                                title="Edit characteristic"
                              >
                                <i className="fas fa-edit me-1"></i>Edit
                              </Link>
                              <button
                                className="btn btn-sm btn-outline-danger rounded-pill px-2 ms-1"
                                onClick={() => handleDelete(characteristic.slug, characteristic.title)}
                                title="Delete characteristic"
                              >
                                <i className="fas fa-trash"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                {pagination && pagination.totalPages > 1 && (
                  <div className="d-flex justify-content-center mt-4">
                    <nav aria-label="Characteristics pagination">
                      <ul className="pagination mb-0">
                        <li className={`page-item ${!pagination.hasPrev ? 'disabled' : ''}`}>
                          <button
                            className="page-link rounded-pill me-1"
                            onClick={() => setCurrentPage(currentPage - 1)}
                            disabled={!pagination.hasPrev}
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            <i className="fas fa-chevron-left"></i>
                          </button>
                        </li>
                        {[...Array(pagination.totalPages)].map((_, index) => (
                          <li
                            key={index + 1}
                            className={`page-item ${currentPage === index + 1 ? 'active' : ''}`}
                          >
                            <button
                              className={`page-link rounded-pill mx-1 ${
                                currentPage === index + 1 
                                  ? 'bg-primary text-white border-primary' 
                                  : ''
                              }`}
                              onClick={() => setCurrentPage(index + 1)}
                              style={{ 
                                border: '2px solid #e0e0e0',
                                minWidth: '40px'
                              }}
                            >
                              {index + 1}
                            </button>
                          </li>
                        ))}
                        <li className={`page-item ${!pagination.hasNext ? 'disabled' : ''}`}>
                          <button
                            className="page-link rounded-pill ms-1"
                            onClick={() => setCurrentPage(currentPage + 1)}
                            disabled={!pagination.hasNext}
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            <i className="fas fa-chevron-right"></i>
                          </button>
                        </li>
                      </ul>
                    </nav>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CharacteristicList;
