import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import ExperienceDataApi from '../../api/ExperienceDataApi';

const ExperienceForm = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    company: '',
    location: '',
    startDate: '',
    endDate: '',
    current: false,
    employmentType: 'Full-time',
    description: '',
    responsibilities: [''],
    achievements: [''],
    skills: [''],
    technologies: [''],
    companyLogo: '',
    companyWebsite: '',
    industry: '',
    featured: false,
    isActive: true
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isEdit) {
      fetchExperience();
    }
  }, [slug, isEdit]);

  const fetchExperience = async () => {
    try {
      setLoading(true);
      const data = await ExperienceDataApi.getExperienceDetails(slug);
      if (data) {
        setFormData({
          ...data,
          startDate: data.startDate ? new Date(data.startDate).toISOString().split('T')[0] : '',
          endDate: data.endDate ? new Date(data.endDate).toISOString().split('T')[0] : '',
          responsibilities: data.responsibilities?.length ? data.responsibilities : [''],
          achievements: data.achievements?.length ? data.achievements : [''],
          skills: data.skills?.length ? data.skills : [''],
          technologies: data.technologies?.length ? data.technologies : ['']
        });
      }
    } catch (err) {
      setError('Failed to fetch experience details');
      console.error('Error fetching experience:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleArrayChange = (field, index, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => i === index ? value : item)
    }));
  };

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], '']
    }));
  };

  const removeArrayItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title || !formData.company || !formData.startDate) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      setError('');

      // Clean up array fields (remove empty strings)
      const cleanedData = {
        ...formData,
        responsibilities: formData.responsibilities.filter(item => item.trim() !== ''),
        achievements: formData.achievements.filter(item => item.trim() !== ''),
        skills: formData.skills.filter(item => item.trim() !== ''),
        technologies: formData.technologies.filter(item => item.trim() !== '')
      };

      if (isEdit) {
        await ExperienceDataApi.updateExperience(slug, cleanedData);
      } else {
        await ExperienceDataApi.createExperience(cleanedData);
      }

      navigate('/admin/experience');
    } catch (err) {
      setError(`Failed to ${isEdit ? 'update' : 'create'} experience record`);
      console.error(`Error ${isEdit ? 'updating' : 'creating'} experience:`, err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading experience data...</h5>
                </div>
              </div>
            </div>          {/* Preview Sidebar */}
          <div className="col-12 col-lg-4">
            <div className="card border-0 shadow-sm sticky-top" style={{ borderRadius: '16px', top: '20px' }}>
              <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '48px', 
                      height: '48px', 
                      backgroundColor: '#f3e5f5'
                    }}
                  >
                    <i className="fas fa-eye text-secondary fs-5"></i>
                  </div>
                  <div>
                    <h5 className="mb-0 fw-bold text-dark">Live Preview</h5>
                    <small className="text-muted">See how your experience will appear</small>
                  </div>
                </div>
              </div>
              <div className="card-body p-4">
                {/* Company Logo Preview */}
                {formData.companyLogo && (
                  <div 
                    className="d-flex justify-content-center align-items-center mb-3 p-3 rounded-3" 
                    style={{ backgroundColor: '#f8f9fa', height: '100px' }}
                  >
                    <img 
                      src={formData.companyLogo} 
                      alt="Company logo preview" 
                      className="img-fluid rounded"
                      style={{ maxHeight: '70px', maxWidth: '100%', objectFit: 'contain' }}
                      onError={(e) => { e.target.style.display = 'none'; }}
                    />
                  </div>
                )}
                
                <div className="text-center">
                  <h5 className="fw-bold text-dark mb-1">{formData.title || 'Job Title'}</h5>
                  <h6 className="text-primary fw-medium mb-3">
                    <i className="fas fa-building me-2"></i>
                    {formData.company || 'Company Name'}
                  </h6>
                  
                  {/* Status Badges */}
                  <div className="mb-3">
                    {formData.current && (
                      <span className="badge rounded-pill px-3 py-1 me-2" style={{ backgroundColor: '#e8f5e8', color: '#2e7d32' }}>
                        <i className="fas fa-circle me-1" style={{ fontSize: '8px' }}></i>Current
                      </span>
                    )}
                    {formData.featured && (
                      <span className="badge rounded-pill px-3 py-1 me-2" style={{ backgroundColor: '#fff3e0', color: '#ffa000' }}>
                        <i className="fas fa-star me-1"></i>Featured
                      </span>
                    )}
                    <span className={`badge rounded-pill px-3 py-1 ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                      <i className={`fas ${formData.isActive ? 'fa-check' : 'fa-times'} me-1`}></i>
                      {formData.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>

                  {/* Employment Type and Dates */}
                  <div className="mb-3">
                    <span 
                      className="badge rounded-pill px-3 py-1 fw-medium"
                      style={{ backgroundColor: '#e1f5fe', color: '#0277bd' }}
                    >
                      {formData.employmentType}
                    </span>
                  </div>

                  {/* Date Range */}
                  {formData.startDate && (
                    <div className="mb-3">
                      <div className="d-flex align-items-center justify-content-center">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '24px', height: '24px', backgroundColor: '#e3f2fd' }}
                        >
                          <i className="fas fa-calendar text-primary" style={{ fontSize: '10px' }}></i>
                        </div>
                        <small className="text-muted fw-medium">
                          {new Date(formData.startDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })} - {
                            formData.current 
                              ? 'Present' 
                              : formData.endDate 
                                ? new Date(formData.endDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })
                                : 'Present'
                          }
                        </small>
                      </div>
                    </div>
                  )}

                  {/* Location */}
                  {formData.location && (
                    <div className="mb-3">
                      <div className="d-flex align-items-center justify-content-center">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '24px', height: '24px', backgroundColor: '#f3e5f5' }}
                        >
                          <i className="fas fa-map-marker-alt text-secondary" style={{ fontSize: '10px' }}></i>
                        </div>
                        <small className="text-muted fw-medium">{formData.location}</small>
                      </div>
                    </div>
                  )}

                  {/* Industry */}
                  {formData.industry && (
                    <div className="mb-3">
                      <span 
                        className="badge rounded-pill px-3 py-1 fw-medium"
                        style={{ backgroundColor: '#f3e5f5', color: '#7b1fa2' }}
                      >
                        {formData.industry}
                      </span>
                    </div>
                  )}

                  {/* Description Preview */}
                  {formData.description && (
                    <div className="mb-3">
                      <p className="text-muted small" style={{ fontSize: '0.85rem' }}>
                        {formData.description.length > 100 
                          ? `${formData.description.substring(0, 100)}...` 
                          : formData.description
                        }
                      </p>
                    </div>
                  )}

                  {/* Skills Preview */}
                  {formData.skills.filter(s => s.trim()).length > 0 && (
                    <div className="mb-3">
                      <h6 className="fw-bold mb-2" style={{ color: '#2c3e50', fontSize: '0.85rem' }}>
                        Skills
                      </h6>
                      <div className="d-flex flex-wrap gap-1 justify-content-center">
                        {formData.skills.filter(s => s.trim()).slice(0, 4).map((skill, index) => (
                          <span 
                            key={index} 
                            className="badge rounded-pill px-2 py-1"
                            style={{ 
                              backgroundColor: '#e8f5e8', 
                              color: '#2e7d32',
                              fontSize: '0.7rem'
                            }}
                          >
                            {skill}
                          </span>
                        ))}
                        {formData.skills.filter(s => s.trim()).length > 4 && (
                          <span 
                            className="badge rounded-pill px-2 py-1"
                            style={{ 
                              backgroundColor: '#f5f5f5', 
                              color: '#6c757d',
                              fontSize: '0.7rem'
                            }}
                          >
                            +{formData.skills.filter(s => s.trim()).length - 4}
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Company Website Link */}
                  {formData.companyWebsite && (
                    <div className="mt-3">
                      <a 
                        href={formData.companyWebsite} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="btn btn-outline-primary btn-sm rounded-pill px-3"
                      >
                        <i className="fas fa-external-link-alt me-2"></i>
                        Visit Company
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
  }

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-center">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-3"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: isEdit ? '#f57c00' : '#2e7d32',
                    color: 'white'
                  }}
                >
                  <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'}`} style={{ fontSize: '20px' }}></i>
                </div>
                <div>
                  <h2 className="mb-1" style={{ color: '#2c3e50', fontWeight: '600' }}>
                    {isEdit ? 'Edit Experience' : 'Add New Experience'}
                  </h2>
                  <nav aria-label="breadcrumb">
                    <ol className="breadcrumb mb-0" style={{ fontSize: '0.9rem' }}>
                      <li className="breadcrumb-item">
                        <Link to="/admin" className="text-decoration-none">Admin</Link>
                      </li>
                      <li className="breadcrumb-item">
                        <Link to="/admin/experience" className="text-decoration-none">Experience</Link>
                      </li>
                      <li className="breadcrumb-item active text-muted">{isEdit ? 'Edit' : 'Add New'}</li>
                    </ol>
                  </nav>
                </div>
              </div>
              <Link 
                to="/admin/experience" 
                className="btn btn-light border d-flex align-items-center"
                style={{ borderRadius: '12px', padding: '0.6rem 1.2rem' }}
              >
                <i className="fas fa-arrow-left me-2"></i>
                Back to List
              </Link>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #dc3545' }}>
            <div className="card-body p-4" style={{ backgroundColor: '#fff5f5' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ width: '40px', height: '40px', backgroundColor: '#dc3545', color: 'white' }}
                >
                  <i className="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                  <h6 className="mb-1" style={{ color: '#dc3545', fontWeight: '600' }}>Error</h6>
                  <p className="mb-0 text-muted">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="row g-4">
          {/* Main Form Card */}
          <div className="col-12 col-lg-8">
            <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
              <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '48px', 
                      height: '48px', 
                      backgroundColor: '#e3f2fd'
                    }}
                  >
                    <i className="fas fa-briefcase text-primary fs-5"></i>
                  </div>
                  <div>
                    <h5 className="mb-0 fw-bold text-dark">Experience Information</h5>
                    <small className="text-muted">Fill in the details for your work experience</small>
                  </div>
                </div>
              </div>
              <div className="card-body p-4">
                <form onSubmit={handleSubmit}>
                  {/* Basic Information Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-info-circle text-primary me-2"></i>
                      Basic Information
                    </h6>
                    <div className="row g-3">
                      <div className="col-md-6">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-briefcase me-2 text-muted"></i>Job Title *
                        </label>
                        <input
                          type="text"
                          className="form-control rounded-pill py-2"
                          name="title"
                          value={formData.title}
                          onChange={handleInputChange}
                          required
                          style={{ border: '2px solid #e0e0e0' }}
                          placeholder="e.g., Software Engineer, Project Manager"
                        />
                      </div>

                      <div className="col-md-6">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-building me-2 text-muted"></i>Company *
                        </label>
                        <input
                          type="text"
                          className="form-control rounded-pill py-2"
                          name="company"
                          value={formData.company}
                          onChange={handleInputChange}
                          required
                          style={{ border: '2px solid #e0e0e0' }}
                          placeholder="e.g., Google, Microsoft, Startup Inc."
                        />
                      </div>

                      <div className="col-md-6">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-map-marker-alt me-2 text-muted"></i>Location
                        </label>
                        <input
                          type="text"
                          className="form-control rounded-pill py-2"
                          name="location"
                          value={formData.location}
                          onChange={handleInputChange}
                          placeholder="City, State/Country"
                          style={{ border: '2px solid #e0e0e0' }}
                        />
                      </div>

                      <div className="col-md-6">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-user-tie me-2 text-muted"></i>Employment Type
                        </label>
                        <select
                          className="form-select rounded-pill py-2"
                          name="employmentType"
                          value={formData.employmentType}
                          onChange={handleInputChange}
                          style={{ border: '2px solid #e0e0e0' }}
                        >
                          <option value="Full-time">Full-time</option>
                          <option value="Part-time">Part-time</option>
                          <option value="Contract">Contract</option>
                          <option value="Internship">Internship</option>
                          <option value="Freelance">Freelance</option>
                          <option value="Volunteer">Volunteer</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Dates Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-calendar text-success me-2"></i>
                      Employment Period
                    </h6>
                    <div className="row g-3">
                      <div className="col-md-4">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-play me-2 text-muted"></i>Start Date *
                        </label>
                        <input
                          type="date"
                          className="form-control rounded-pill py-2"
                          name="startDate"
                          value={formData.startDate}
                          onChange={handleInputChange}
                          required
                          style={{ border: '2px solid #e0e0e0' }}
                        />
                      </div>

                      <div className="col-md-4">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-stop me-2 text-muted"></i>End Date
                        </label>
                        <input
                          type="date"
                          className="form-control rounded-pill py-2"
                          name="endDate"
                          value={formData.endDate}
                          onChange={handleInputChange}
                          disabled={formData.current}
                          style={{ border: '2px solid #e0e0e0' }}
                        />
                      </div>

                      <div className="col-md-4">
                        <label className="form-label fw-medium text-dark">&nbsp;</label>
                        <div className="p-3 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                          <div className="form-check">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              name="current"
                              checked={formData.current}
                              onChange={handleInputChange}
                              style={{ fontSize: '1.1rem' }}
                            />
                            <label className="form-check-label fw-medium text-dark">
                              <i className="fas fa-circle text-success me-2" style={{ fontSize: '8px' }}></i>
                              I currently work here
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Description Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-align-left text-info me-2"></i>
                      Job Description
                    </h6>
                    <div className="mb-3">
                      <label className="form-label fw-medium text-dark">
                        <i className="fas fa-file-alt me-2 text-muted"></i>Role Description
                      </label>
                      <textarea
                        className="form-control"
                        name="description"
                        value={formData.description}
                        onChange={handleInputChange}
                        rows="4"
                        placeholder="Brief description of your role and what the company does..."
                        style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                      />
                    </div>
                  </div>

                  {/* Company Information Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-building text-secondary me-2"></i>
                      Company Details
                    </h6>
                    <div className="row g-3">
                      <div className="col-md-6">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-globe me-2 text-muted"></i>Company Website
                        </label>
                        <input
                          type="url"
                          className="form-control rounded-pill py-2"
                          name="companyWebsite"
                          value={formData.companyWebsite}
                          onChange={handleInputChange}
                          placeholder="https://company.com"
                          style={{ border: '2px solid #e0e0e0' }}
                        />
                      </div>

                      <div className="col-md-6">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-industry me-2 text-muted"></i>Industry
                        </label>
                        <input
                          type="text"
                          className="form-control rounded-pill py-2"
                          name="industry"
                          value={formData.industry}
                          onChange={handleInputChange}
                          placeholder="e.g., Technology, Healthcare, Finance"
                          style={{ border: '2px solid #e0e0e0' }}
                        />
                      </div>

                      <div className="col-12">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-image me-2 text-muted"></i>Company Logo URL
                        </label>
                        <input
                          type="url"
                          className="form-control rounded-pill py-2"
                          name="companyLogo"
                          value={formData.companyLogo}
                          onChange={handleInputChange}
                          placeholder="https://example.com/logo.png"
                          style={{ border: '2px solid #e0e0e0' }}
                        />
                        {formData.companyLogo && (
                          <div className="mt-2">
                            <small className="text-muted">Preview:</small>
                            <div className="p-2 bg-light rounded mt-1" style={{ maxWidth: '200px' }}>
                              <img 
                                src={formData.companyLogo} 
                                alt="Company logo preview" 
                                className="img-fluid rounded"
                                style={{ maxHeight: '60px' }}
                                onError={(e) => { e.target.style.display = 'none'; }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Responsibilities Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-tasks text-warning me-2"></i>
                      Key Responsibilities
                    </h6>
                    <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                      {formData.responsibilities.map((responsibility, index) => (
                        <div key={index} className="mb-3">
                          <div className="input-group">
                            <textarea
                              className="form-control"
                              value={responsibility}
                              onChange={(e) => handleArrayChange('responsibilities', index, e.target.value)}
                              placeholder="Describe a key responsibility..."
                              rows="2"
                              style={{ border: '2px solid #e0e0e0', borderRadius: '12px 0 0 12px' }}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-danger rounded-end"
                              onClick={() => removeArrayItem('responsibilities', index)}
                              disabled={formData.responsibilities.length === 1}
                              style={{ borderColor: '#e0e0e0' }}
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="btn btn-outline-primary btn-sm rounded-pill px-3"
                        onClick={() => addArrayItem('responsibilities')}
                      >
                        <i className="fas fa-plus me-2"></i>Add Responsibility
                      </button>
                    </div>
                  </div>

                  {/* Achievements Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-trophy text-success me-2"></i>
                      Key Achievements
                    </h6>
                    <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                      {formData.achievements.map((achievement, index) => (
                        <div key={index} className="mb-3">
                          <div className="input-group">
                            <textarea
                              className="form-control"
                              value={achievement}
                              onChange={(e) => handleArrayChange('achievements', index, e.target.value)}
                              placeholder="Describe a key achievement or accomplishment..."
                              rows="2"
                              style={{ border: '2px solid #e0e0e0', borderRadius: '12px 0 0 12px' }}
                            />
                            <button
                              type="button"
                              className="btn btn-outline-danger rounded-end"
                              onClick={() => removeArrayItem('achievements', index)}
                              disabled={formData.achievements.length === 1}
                              style={{ borderColor: '#e0e0e0' }}
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="btn btn-outline-primary btn-sm rounded-pill px-3"
                        onClick={() => addArrayItem('achievements')}
                      >
                        <i className="fas fa-plus me-2"></i>Add Achievement
                      </button>
                    </div>
                  </div>

                  {/* Skills & Technologies Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-cogs text-primary me-2"></i>
                      Skills & Technologies
                    </h6>
                    
                    {/* Skills */}
                    <div className="mb-4">
                      <label className="form-label fw-medium text-dark">
                        <i className="fas fa-brain me-2 text-muted"></i>Skills Used
                      </label>
                      <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                        {formData.skills.map((skill, index) => (
                          <div key={index} className="mb-2">
                            <div className="input-group">
                              <input
                                type="text"
                                className="form-control rounded-start-pill py-2"
                                value={skill}
                                onChange={(e) => handleArrayChange('skills', index, e.target.value)}
                                placeholder="Skill name..."
                                style={{ border: '2px solid #e0e0e0' }}
                              />
                              <button
                                type="button"
                                className="btn btn-outline-danger rounded-end-pill"
                                onClick={() => removeArrayItem('skills', index)}
                                disabled={formData.skills.length === 1}
                                style={{ borderColor: '#e0e0e0' }}
                              >
                                <i className="fas fa-trash"></i>
                              </button>
                            </div>
                          </div>
                        ))}
                        <button
                          type="button"
                          className="btn btn-outline-success btn-sm rounded-pill px-3"
                          onClick={() => addArrayItem('skills')}
                        >
                          <i className="fas fa-plus me-2"></i>Add Skill
                        </button>
                      </div>
                    </div>

                    {/* Technologies */}
                    <div className="mb-4">
                      <label className="form-label fw-medium text-dark">
                        <i className="fas fa-laptop-code me-2 text-muted"></i>Technologies Used
                      </label>
                      <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                        {formData.technologies.map((tech, index) => (
                          <div key={index} className="mb-2">
                            <div className="input-group">
                              <input
                                type="text"
                                className="form-control rounded-start-pill py-2"
                                value={tech}
                                onChange={(e) => handleArrayChange('technologies', index, e.target.value)}
                                placeholder="Technology/tool name..."
                                style={{ border: '2px solid #e0e0e0' }}
                              />
                              <button
                                type="button"
                                className="btn btn-outline-danger rounded-end-pill"
                                onClick={() => removeArrayItem('technologies', index)}
                                disabled={formData.technologies.length === 1}
                                style={{ borderColor: '#e0e0e0' }}
                              >
                                <i className="fas fa-trash"></i>
                              </button>
                            </div>
                          </div>
                        ))}
                        <button
                          type="button"
                          className="btn btn-outline-info btn-sm rounded-pill px-3"
                          onClick={() => addArrayItem('technologies')}
                        >
                          <i className="fas fa-plus me-2"></i>Add Technology
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Settings Section */}
                  <div className="mb-4">
                    <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                      <i className="fas fa-toggle-on text-secondary me-2"></i>
                      Settings & Visibility
                    </h6>
                    <div className="row g-3">
                      <div className="col-md-6">
                        <div className="p-3 rounded-3" style={{ backgroundColor: '#fff3e0' }}>
                          <div className="form-check form-switch">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              name="featured"
                              checked={formData.featured}
                              onChange={handleInputChange}
                              style={{ fontSize: '1.2rem' }}
                            />
                            <label className="form-check-label fw-medium text-dark">
                              <i className="fas fa-star text-warning me-2"></i>
                              Featured Experience
                            </label>
                            <div className="small text-muted mt-1">
                              Show this experience prominently in your portfolio
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="p-3 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                          <div className="form-check form-switch">
                            <input
                              type="checkbox"
                              className="form-check-input"
                              name="isActive"
                              checked={formData.isActive}
                              onChange={handleInputChange}
                              style={{ fontSize: '1.2rem' }}
                            />
                            <label className="form-check-label fw-medium text-dark">
                              <i className="fas fa-eye text-success me-2"></i>
                              Active (Visible on website)
                            </label>
                            <div className="small text-muted mt-1">
                              Make this experience visible to visitors
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Form Actions */}
                  <div className="d-flex justify-content-between pt-3">
                    <Link 
                      to="/admin/experience" 
                      className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                    >
                      Cancel
                    </Link>
                    <button 
                      type="submit" 
                      className="btn btn-primary rounded-pill px-4 py-2 fw-medium" 
                      disabled={loading}
                      style={{ backgroundColor: isEdit ? '#f57c00' : '#2e7d32', border: 'none' }}
                    >
                      {loading && <span className="spinner-border spinner-border-sm me-2"></span>}
                      <i className={`fas ${isEdit ? 'fa-save' : 'fa-plus'} me-2`}></i>
                      {isEdit ? 'Update Experience' : 'Create Experience'}
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>

          {/* Preview Sidebar */}
          <div className="col-12 col-lg-4">
            <div className="card border-0 shadow-sm sticky-top" style={{ borderRadius: '16px', top: '20px' }}>
              <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '48px', 
                      height: '48px', 
                      backgroundColor: '#f3e5f5'
                    }}
                  >
                    <i className="fas fa-eye text-secondary fs-5"></i>
                  </div>
                  <div>
                    <h5 className="mb-0 fw-bold text-dark">Live Preview</h5>
                    <small className="text-muted">See how your experience will appear</small>
                  </div>
                </div>
              </div>
              <div className="card-body p-4">
                {/* Company Logo Preview */}
                {formData.companyLogo && (
                  <div 
                    className="d-flex justify-content-center align-items-center mb-3 p-3 rounded-3" 
                    style={{ backgroundColor: '#f8f9fa', height: '100px' }}
                  >
                    <img 
                      src={formData.companyLogo} 
                      alt="Company logo preview" 
                      className="img-fluid rounded"
                      style={{ maxHeight: '70px', maxWidth: '100%', objectFit: 'contain' }}
                      onError={(e) => { e.target.style.display = 'none'; }}
                    />
                  </div>
                )}
                
                <div className="text-center">
                  <h5 className="fw-bold text-dark mb-1">{formData.title || 'Job Title'}</h5>
                  <h6 className="text-primary fw-medium mb-3">
                    <i className="fas fa-building me-2"></i>
                    {formData.company || 'Company Name'}
                  </h6>
                  
                  {/* Status Badges */}
                  <div className="mb-3">
                    {formData.current && (
                      <span className="badge rounded-pill px-3 py-1 me-2" style={{ backgroundColor: '#e8f5e8', color: '#2e7d32' }}>
                        <i className="fas fa-circle me-1" style={{ fontSize: '8px' }}></i>Current
                      </span>
                    )}
                    {formData.featured && (
                      <span className="badge rounded-pill px-3 py-1 me-2" style={{ backgroundColor: '#fff3e0', color: '#ffa000' }}>
                        <i className="fas fa-star me-1"></i>Featured
                      </span>
                    )}
                    <span className={`badge rounded-pill px-3 py-1 ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                      <i className={`fas ${formData.isActive ? 'fa-check' : 'fa-times'} me-1`}></i>
                      {formData.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>

                  {/* Employment Type and Dates */}
                  <div className="mb-3">
                    <span 
                      className="badge rounded-pill px-3 py-1 fw-medium"
                      style={{ backgroundColor: '#e1f5fe', color: '#0277bd' }}
                    >
                      {formData.employmentType}
                    </span>
                  </div>

                  {/* Date Range */}
                  {formData.startDate && (
                    <div className="mb-3">
                      <div className="d-flex align-items-center justify-content-center">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '24px', height: '24px', backgroundColor: '#e3f2fd' }}
                        >
                          <i className="fas fa-calendar text-primary" style={{ fontSize: '10px' }}></i>
                        </div>
                        <small className="text-muted fw-medium">
                          {new Date(formData.startDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })} - {
                            formData.current 
                              ? 'Present' 
                              : formData.endDate 
                                ? new Date(formData.endDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })
                                : 'Present'
                          }
                        </small>
                      </div>
                    </div>
                  )}

                  {/* Location */}
                  {formData.location && (
                    <div className="mb-3">
                      <div className="d-flex align-items-center justify-content-center">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '24px', height: '24px', backgroundColor: '#f3e5f5' }}
                        >
                          <i className="fas fa-map-marker-alt text-secondary" style={{ fontSize: '10px' }}></i>
                        </div>
                        <small className="text-muted fw-medium">{formData.location}</small>
                      </div>
                    </div>
                  )}

                  {/* Industry */}
                  {formData.industry && (
                    <div className="mb-3">
                      <span 
                        className="badge rounded-pill px-3 py-1 fw-medium"
                        style={{ backgroundColor: '#f3e5f5', color: '#7b1fa2' }}
                      >
                        {formData.industry}
                      </span>
                    </div>
                  )}

                  {/* Description Preview */}
                  {formData.description && (
                    <div className="mb-3">
                      <p className="text-muted small" style={{ fontSize: '0.85rem' }}>
                        {formData.description.length > 100 
                          ? `${formData.description.substring(0, 100)}...` 
                          : formData.description
                        }
                      </p>
                    </div>
                  )}

                  {/* Skills Preview */}
                  {formData.skills.filter(s => s.trim()).length > 0 && (
                    <div className="mb-3">
                      <h6 className="fw-bold mb-2" style={{ color: '#2c3e50', fontSize: '0.85rem' }}>
                        Skills
                      </h6>
                      <div className="d-flex flex-wrap gap-1 justify-content-center">
                        {formData.skills.filter(s => s.trim()).slice(0, 4).map((skill, index) => (
                          <span 
                            key={index} 
                            className="badge rounded-pill px-2 py-1"
                            style={{ 
                              backgroundColor: '#e8f5e8', 
                              color: '#2e7d32',
                              fontSize: '0.7rem'
                            }}
                          >
                            {skill}
                          </span>
                        ))}
                        {formData.skills.filter(s => s.trim()).length > 4 && (
                          <span 
                            className="badge rounded-pill px-2 py-1"
                            style={{ 
                              backgroundColor: '#f5f5f5', 
                              color: '#6c757d',
                              fontSize: '0.7rem'
                            }}
                          >
                            +{formData.skills.filter(s => s.trim()).length - 4}
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Company Website Link */}
                  {formData.companyWebsite && (
                    <div className="mt-3">
                      <a 
                        href={formData.companyWebsite} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="btn btn-outline-primary btn-sm rounded-pill px-3"
                      >
                        <i className="fas fa-external-link-alt me-2"></i>
                        Visit Company
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExperienceForm;
