import React, { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const PinSettingsPage = ({ sessionToken, deviceFingerprint }) => {
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPins, setShowPins] = useState(false);
  const [sessionInfo, setSessionInfo] = useState(null);
  const [lockStatus, setLockStatus] = useState(null);
  const [activeSessions, setActiveSessions] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchSessionInfo();
    fetchLockStatus();
  }, []);

  const fetchSessionInfo = async () => {
    try {
      const response = await fetch('/api/pin/verify-session', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          sessionToken,
          deviceFingerprint
        }),
      });

      const data = await response.json();
      if (data.success) {
        setSessionInfo(data);
      }
    } catch (error) {
      console.error('Session info fetch error:', error);
    }
  };

  const fetchLockStatus = async () => {
    try {
      const response = await fetch(`/api/pin/lock-status?deviceFingerprint=${deviceFingerprint}`);
      const data = await response.json();
      if (data.success) {
        setLockStatus(data);
      }
    } catch (error) {
      console.error('Lock status fetch error:', error);
    }
  };

  const handlePinChange = async (e) => {
    e.preventDefault();
    
    if (!currentPin || !newPin || !confirmPin) {
      toast.error('All fields are required');
      return;
    }

    if (newPin !== confirmPin) {
      toast.error('New PIN and confirmation do not match');
      return;
    }

    if (newPin.length < 4 || newPin.length > 6) {
      toast.error('PIN must be between 4 and 6 digits');
      return;
    }

    if (!/^\d+$/.test(newPin)) {
      toast.error('PIN must contain only numbers');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/pin/change', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          currentPin,
          newPin,
          sessionToken,
          deviceFingerprint
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('PIN changed successfully');
        setCurrentPin('');
        setNewPin('');
        setConfirmPin('');
        setShowPins(false);
      } else {
        toast.error(data.message || 'Failed to change PIN');
      }
    } catch (error) {
      console.error('Change PIN error:', error);
      toast.error('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      if (sessionToken) {
        await fetch('/api/pin/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            sessionToken,
            deviceFingerprint
          }),
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('adminSession');
      localStorage.removeItem('deviceFingerprint');
      toast.success('Logged out successfully');
      navigate('/');
    }
  };

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleString();
  };

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-lg-10 col-xl-8">
          {/* Header */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '20px' }}>
            <div className="card-body p-4">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '60px', 
                      height: '60px', 
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      color: 'white'
                    }}
                  >
                    <i className="fas fa-shield-alt fs-3"></i>
                  </div>
                  <div>
                    <h2 className="mb-1 fw-bold text-dark">Security Settings</h2>
                    <p className="text-muted mb-0">Manage your admin panel security and authentication</p>
                  </div>
                </div>
                <button
                  onClick={() => navigate('/admin')}
                  className="btn btn-outline-secondary rounded-pill px-4"
                >
                  <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
                </button>
              </div>
            </div>
          </div>

          {/* Current Session Info */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '20px' }}>
            <div className="card-header bg-white border-0 p-4" style={{ borderRadius: '20px 20px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '50px', 
                    height: '50px', 
                    background: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
                    color: 'white'
                  }}
                >
                  <i className="fas fa-clock"></i>
                </div>
                <div>
                  <h5 className="mb-1 fw-bold text-dark">Current Session</h5>
                  <p className="text-muted mb-0 small">Your active authentication session</p>
                </div>
              </div>
            </div>
            <div className="card-body p-4">
              <div className="row g-4">
                <div className="col-12 col-md-6">
                  <div className="p-3 rounded-3" style={{ backgroundColor: '#e3f2fd' }}>
                    <div className="d-flex align-items-center">
                      <i className="fas fa-hourglass-half text-primary me-3 fs-4"></i>
                      <div>
                        <h6 className="mb-1 fw-bold text-dark">Session Time</h6>
                        <p className="mb-0 text-muted">
                          {sessionInfo ? formatTime(sessionInfo.timeLeft) : 'Loading...'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6">
                  <div className="p-3 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                    <div className="d-flex align-items-center">
                      <i className="fas fa-calendar-alt text-success me-3 fs-4"></i>
                      <div>
                        <h6 className="mb-1 fw-bold text-dark">Expires At</h6>
                        <p className="mb-0 text-muted">
                          {sessionInfo ? formatDate(sessionInfo.expiresAt) : 'Loading...'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="mt-4">
                <button
                  onClick={handleLogout}
                  className="btn btn-danger rounded-pill px-4"
                  style={{ background: 'linear-gradient(135deg, #ff758c 0%, #ff7eb3 100%)', border: 'none' }}
                >
                  <i className="fas fa-sign-out-alt me-2"></i>End Session
                </button>
              </div>
            </div>
          </div>

          {/* Security Status */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '20px' }}>
            <div className="card-header bg-white border-0 p-4" style={{ borderRadius: '20px 20px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '50px', 
                    height: '50px', 
                    background: lockStatus?.isLocked ? 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)' : 'linear-gradient(135deg, #00b894 0%, #00cec9 100%)',
                    color: 'white'
                  }}
                >
                  <i className={`fas ${lockStatus?.isLocked ? 'fa-lock' : 'fa-shield-check'}`}></i>
                </div>
                <div>
                  <h5 className="mb-1 fw-bold text-dark">Security Status</h5>
                  <p className="text-muted mb-0 small">Current security and lockout status</p>
                </div>
              </div>
            </div>
            <div className="card-body p-4">
              <div className="row g-4">
                <div className="col-12 col-md-4">
                  <div className="p-3 rounded-3 text-center" style={{ backgroundColor: lockStatus?.isLocked ? '#ffebee' : '#e8f5e8' }}>
                    <i className={`fas ${lockStatus?.isLocked ? 'fa-exclamation-triangle text-danger' : 'fa-check-circle text-success'} mb-2 fs-3`}></i>
                    <h6 className="mb-1 fw-bold">{lockStatus?.isLocked ? 'Device Locked' : 'Device Secure'}</h6>
                    <p className="mb-0 text-muted small">
                      {lockStatus?.isLocked ? 'Temporarily locked' : 'No security issues'}
                    </p>
                  </div>
                </div>
                <div className="col-12 col-md-4">
                  <div className="p-3 rounded-3 text-center" style={{ backgroundColor: '#fff3e0' }}>
                    <i className="fas fa-attempt text-warning mb-2 fs-3"></i>
                    <h6 className="mb-1 fw-bold">Failed Attempts</h6>
                    <p className="mb-0 text-muted small">
                      {lockStatus?.attempts || 0} of {lockStatus?.maxAttempts || 3}
                    </p>
                  </div>
                </div>
                <div className="col-12 col-md-4">
                  <div className="p-3 rounded-3 text-center" style={{ backgroundColor: '#e3f2fd' }}>
                    <i className="fas fa-fingerprint text-primary mb-2 fs-3"></i>
                    <h6 className="mb-1 fw-bold">Device ID</h6>
                    <p className="mb-0 text-muted small" style={{ fontSize: '0.8rem' }}>
                      {deviceFingerprint?.slice(0, 8)}...
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* PIN Management */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '20px' }}>
            <div className="card-header bg-white border-0 p-4" style={{ borderRadius: '20px 20px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '50px', 
                    height: '50px', 
                    background: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
                    color: '#333'
                  }}
                >
                  <i className="fas fa-key"></i>
                </div>
                <div>
                  <h5 className="mb-1 fw-bold text-dark">PIN Management</h5>
                  <p className="text-muted mb-0 small">Change your admin access PIN</p>
                </div>
              </div>
            </div>
            <div className="card-body p-4">
              <form onSubmit={handlePinChange}>
                <div className="row g-4">
                  <div className="col-12 col-md-4">
                    <div className="form-floating">
                      <input
                        type={showPins ? 'text' : 'password'}
                        className="form-control"
                        id="currentPin"
                        value={currentPin}
                        onChange={(e) => setCurrentPin(e.target.value)}
                        placeholder="Current PIN"
                        maxLength="6"
                        style={{ borderRadius: '12px', fontSize: '1.1rem', letterSpacing: '0.2em' }}
                      />
                      <label htmlFor="currentPin" className="fw-medium text-muted">
                        <i className="fas fa-lock me-2"></i>Current PIN
                      </label>
                    </div>
                  </div>
                  
                  <div className="col-12 col-md-4">
                    <div className="form-floating">
                      <input
                        type={showPins ? 'text' : 'password'}
                        className="form-control"
                        id="newPin"
                        value={newPin}
                        onChange={(e) => setNewPin(e.target.value)}
                        placeholder="New PIN"
                        maxLength="6"
                        style={{ borderRadius: '12px', fontSize: '1.1rem', letterSpacing: '0.2em' }}
                      />
                      <label htmlFor="newPin" className="fw-medium text-muted">
                        <i className="fas fa-key me-2"></i>New PIN
                      </label>
                    </div>
                  </div>
                  
                  <div className="col-12 col-md-4">
                    <div className="form-floating">
                      <input
                        type={showPins ? 'text' : 'password'}
                        className="form-control"
                        id="confirmPin"
                        value={confirmPin}
                        onChange={(e) => setConfirmPin(e.target.value)}
                        placeholder="Confirm New PIN"
                        maxLength="6"
                        style={{ borderRadius: '12px', fontSize: '1.1rem', letterSpacing: '0.2em' }}
                      />
                      <label htmlFor="confirmPin" className="fw-medium text-muted">
                        <i className="fas fa-check me-2"></i>Confirm New PIN
                      </label>
                    </div>
                  </div>
                </div>
                
                <div className="d-flex align-items-center justify-content-between mt-4">
                  <div className="form-check form-switch">
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id="showPins"
                      checked={showPins}
                      onChange={(e) => setShowPins(e.target.checked)}
                      style={{ transform: 'scale(1.2)' }}
                    />
                    <label className="form-check-label fw-medium text-muted" htmlFor="showPins">
                      <i className="fas fa-eye me-2"></i>Show PINs
                    </label>
                  </div>
                  
                  <button
                    type="submit"
                    className="btn btn-primary rounded-pill px-4 py-2"
                    disabled={loading}
                    style={{ 
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
                      border: 'none',
                      minWidth: '150px'
                    }}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                        Changing...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-save me-2"></i>
                        Change PIN
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Security Information */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '20px' }}>
            <div className="card-header bg-white border-0 p-4" style={{ borderRadius: '20px 20px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '50px', 
                    height: '50px', 
                    background: 'linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%)',
                    color: '#333'
                  }}
                >
                  <i className="fas fa-info-circle"></i>
                </div>
                <div>
                  <h5 className="mb-1 fw-bold text-dark">Security Information</h5>
                  <p className="text-muted mb-0 small">Important security notes and features</p>
                </div>
              </div>
            </div>
            <div className="card-body p-4">
              <div className="row g-4">
                <div className="col-12 col-md-6">
                  <div className="p-4 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                    <div className="d-flex align-items-start">
                      <div 
                        className="rounded-circle me-3 d-flex align-items-center justify-content-center flex-shrink-0"
                        style={{ 
                          width: '40px', 
                          height: '40px', 
                          backgroundColor: '#28a745',
                          color: 'white'
                        }}
                      >
                        <i className="fas fa-crown"></i>
                      </div>
                      <div>
                        <h6 className="mb-2 fw-bold text-dark">Master PIN</h6>
                        <p className="mb-0 text-muted small">
                          The master PIN (xxxx) always works and provides emergency access. 
                          It cannot be changed or disabled.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6">
                  <div className="p-4 rounded-3" style={{ backgroundColor: '#fff3e0' }}>
                    <div className="d-flex align-items-start">
                      <div 
                        className="rounded-circle me-3 d-flex align-items-center justify-content-center flex-shrink-0"
                        style={{ 
                          width: '40px', 
                          height: '40px', 
                          backgroundColor: '#ff9800',
                          color: 'white'
                        }}
                      >
                        <i className="fas fa-shield-alt"></i>
                      </div>
                      <div>
                        <h6 className="mb-2 fw-bold text-dark">Auto-Lock</h6>
                        <p className="mb-0 text-muted small">
                          After 3 failed attempts, your device will be locked for 2 hours 
                          as a security measure.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6">
                  <div className="p-4 rounded-3" style={{ backgroundColor: '#e3f2fd' }}>
                    <div className="d-flex align-items-start">
                      <div 
                        className="rounded-circle me-3 d-flex align-items-center justify-content-center flex-shrink-0"
                        style={{ 
                          width: '40px', 
                          height: '40px', 
                          backgroundColor: '#2196f3',
                          color: 'white'
                        }}
                      >
                        <i className="fas fa-clock"></i>
                      </div>
                      <div>
                        <h6 className="mb-2 fw-bold text-dark">Session Duration</h6>
                        <p className="mb-0 text-muted small">
                          Each session lasts for 2 hours. Sessions are automatically 
                          extended if you're actively using the panel.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6">
                  <div className="p-4 rounded-3" style={{ backgroundColor: '#fce4ec' }}>
                    <div className="d-flex align-items-start">
                      <div 
                        className="rounded-circle me-3 d-flex align-items-center justify-content-center flex-shrink-0"
                        style={{ 
                          width: '40px', 
                          height: '40px', 
                          backgroundColor: '#e91e63',
                          color: 'white'
                        }}
                      >
                        <i className="fas fa-fingerprint"></i>
                      </div>
                      <div>
                        <h6 className="mb-2 fw-bold text-dark">Device Tracking</h6>
                        <p className="mb-0 text-muted small">
                          Each device is uniquely identified. Sessions and lockouts 
                          are device-specific for enhanced security.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PinSettingsPage;
