import React, { useState } from 'react';
import { toast } from 'react-toastify';

const PanelSettings = ({ sessionToken, deviceFingerprint }) => {
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPins, setShowPins] = useState(false);

  const handlePinChange = async (e) => {
    e.preventDefault();
    
    if (!currentPin || !newPin || !confirmPin) {
      toast.error('All fields are required');
      return;
    }

    if (newPin !== confirmPin) {
      toast.error('New PIN and confirmation do not match');
      return;
    }

    if (newPin.length < 4 || newPin.length > 6) {
      toast.error('PIN must be between 4 and 6 digits');
      return;
    }

    if (!/^\d+$/.test(newPin)) {
      toast.error('PIN must contain only numbers');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/pin/change', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          currentPin,
          newPin,
          sessionToken,
          deviceFingerprint
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast.success('PIN changed successfully');
        setCurrentPin('');
        setNewPin('');
        setConfirmPin('');
        setShowPins(false);
      } else {
        toast.error(data.message || 'Failed to change PIN');
      }
    } catch (error) {
      console.error('Change PIN error:', error);
      toast.error('Network error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const togglePinVisibility = () => {
    setShowPins(!showPins);
  };

  return (
    <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
      <div className="card-header bg-transparent border-0 pb-0">
        <div className="d-flex align-items-center">
          <div className="me-3">
            <div 
              className="rounded-circle d-flex align-items-center justify-content-center"
              style={{ 
                width: '50px', 
                height: '50px', 
                backgroundColor: '#f3e5f5',
                color: '#7b1fa2'
              }}
            >
              <i className="fas fa-cog"></i>
            </div>
          </div>
          <div>
            <h5 className="mb-1 fw-bold">Panel Settings</h5>
            <p className="text-muted mb-0 small">Configure your admin panel settings</p>
          </div>
        </div>
      </div>
      
      <div className="card-body pt-3">
        <div className="row">
          <div className="col-12 col-lg-8">
            <h6 className="fw-bold mb-3">
              <i className="fas fa-key me-2 text-primary"></i>
              Change Admin PIN
            </h6>
            
            <form onSubmit={handlePinChange}>
              <div className="row g-3">
                <div className="col-12 col-md-4">
                  <label className="form-label fw-medium">Current PIN</label>
                  <div className="input-group">
                    <input
                      type={showPins ? 'text' : 'password'}
                      className="form-control"
                      value={currentPin}
                      onChange={(e) => setCurrentPin(e.target.value)}
                      placeholder="Enter current PIN"
                      maxLength="6"
                      style={{ borderRadius: '8px' }}
                    />
                  </div>
                </div>
                
                <div className="col-12 col-md-4">
                  <label className="form-label fw-medium">New PIN</label>
                  <div className="input-group">
                    <input
                      type={showPins ? 'text' : 'password'}
                      className="form-control"
                      value={newPin}
                      onChange={(e) => setNewPin(e.target.value)}
                      placeholder="Enter new PIN"
                      maxLength="6"
                      style={{ borderRadius: '8px' }}
                    />
                  </div>
                </div>
                
                <div className="col-12 col-md-4">
                  <label className="form-label fw-medium">Confirm New PIN</label>
                  <div className="input-group">
                    <input
                      type={showPins ? 'text' : 'password'}
                      className="form-control"
                      value={confirmPin}
                      onChange={(e) => setConfirmPin(e.target.value)}
                      placeholder="Confirm new PIN"
                      maxLength="6"
                      style={{ borderRadius: '8px' }}
                    />
                  </div>
                </div>
              </div>
              
              <div className="d-flex align-items-center justify-content-between mt-3">
                <div className="form-check">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id="showPins"
                    checked={showPins}
                    onChange={togglePinVisibility}
                  />
                  <label className="form-check-label" htmlFor="showPins">
                    Show PINs
                  </label>
                </div>
                
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={loading}
                  style={{ borderRadius: '8px' }}
                >
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Changing...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save me-2"></i>
                      Change PIN
                    </>
                  )}
                </button>
              </div>
            </form>
            
            <div className="alert alert-info mt-3" role="alert">
              <i className="fas fa-info-circle me-2"></i>
              <strong>Note:</strong> The master PIN (2701) will always work and cannot be changed.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PanelSettings;
