// Image upload component
import React, { useState } from 'react';

export const uploadImage = async (file, category = 'general') => {
  try {
    // Create FormData for file upload
    const formData = new FormData();
    formData.append('image', file);
    formData.append('category', category);

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      throw new Error('Invalid file type. Please upload JPEG, PNG, GIF, or WebP images.');
    }

    // Validate file size (max 5MB)
    const maxSize = 5 * 1024 * 1024; // 5MB
    if (file.size > maxSize) {
      throw new Error('File size too large. Please upload images smaller than 5MB.');
    }

    // Upload to server
    const response = await fetch('/api/upload/upload', {
      method: 'POST',
      body: formData
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Upload failed');
    }

    const result = await response.json();
    return result.url;
  } catch (error) {
    console.error('Image upload failed:', error);
    throw error;
  }
};

// Image categories
export const IMAGE_CATEGORIES = {
  GENERAL: 'general',
  PROFILE: 'profile',
  PROJECT: 'project',
  BLOG: 'blog',
  CONTENT: 'content',
  BANNER: 'banner',
  THUMBNAIL: 'thumbnail'
};

export const ImageUploader = ({ onUpload, category = 'general', accept = 'image/*', multiple = false }) => {
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setUploading(true);
    setError('');

    try {
      if (multiple) {
        const uploadPromises = files.map(file => uploadImage(file, category));
        const urls = await Promise.all(uploadPromises);
        onUpload(urls);
      } else {
        const url = await uploadImage(files[0], category);
        onUpload(url);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="image-uploader">
      <input
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={handleFileSelect}
        disabled={uploading}
        className="form-control"
      />
      {uploading && (
        <div className="mt-2">
          <div className="d-flex align-items-center">
            <div className="spinner-border spinner-border-sm me-2" role="status">
              <span className="visually-hidden">Uploading...</span>
            </div>
            <small className="text-muted">Uploading image...</small>
          </div>
        </div>
      )}
      {error && (
        <div className="alert alert-danger mt-2 py-1">
          <small>{error}</small>
        </div>
      )}
    </div>
  );
};

// Drag and drop image uploader
export const DragDropImageUploader = ({ onUpload, category = 'general' }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length === 0) {
      setError('Please drop image files only.');
      return;
    }

    setUploading(true);
    setError('');

    try {
      const uploadPromises = imageFiles.map(file => uploadImage(file, category));
      const urls = await Promise.all(uploadPromises);
      onUpload(urls);
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div
      className={`drag-drop-uploader border-2 border-dashed rounded p-4 text-center ${
        isDragging ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {uploading ? (
        <div>
          <div className="spinner-border text-primary mb-2" role="status">
            <span className="visually-hidden">Uploading...</span>
          </div>
          <p className="mb-0">Uploading images...</p>
        </div>
      ) : (
        <div>
          <i className="fas fa-cloud-upload-alt fa-3x text-muted mb-3"></i>
          <p className="mb-0">
            Drag and drop images here or{' '}
            <label className="text-primary" style={{ cursor: 'pointer' }}>
              browse files
              <input
                type="file"
                multiple
                accept="image/*"
                className="d-none"
                onChange={(e) => {
                  const files = Array.from(e.target.files);
                  if (files.length > 0) {
                    handleDrop({ preventDefault: () => {}, dataTransfer: { files } });
                  }
                }}
              />
            </label>
          </p>
          <small className="text-muted">
            Supports: JPEG, PNG, GIF, WebP (Max 5MB each)
          </small>
        </div>
      )}
      {error && (
        <div className="alert alert-danger mt-3 py-2">
          <small>{error}</small>
        </div>
      )}
    </div>
  );
};
