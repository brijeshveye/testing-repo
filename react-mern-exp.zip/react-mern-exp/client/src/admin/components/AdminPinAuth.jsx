import React, { useState, useEffect } from 'react';
import './AdminPinAuth.css';
import { toast } from 'react-toastify';

const AdminPinAuth = ({ onSuccess }) => {
  const [pin, setPin] = useState(['', '', '', '']);
  const [timeLeft, setTimeLeft] = useState(0);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLocked, setIsLocked] = useState(false);
  const [lockTimeLeft, setLockTimeLeft] = useState(0);
  const [attemptsLeft, setAttemptsLeft] = useState(3);
  const [loading, setLoading] = useState(false);
  const [sessionToken, setSessionToken] = useState(null);
  const [deviceFingerprint, setDeviceFingerprint] = useState(null);

  useEffect(() => {
    generateDeviceFingerprint();
    checkExistingSession();
    checkLockStatus();
  }, []);

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && isAuthenticated) {
      handleSessionExpiry();
    }
  }, [timeLeft, isAuthenticated]);

  useEffect(() => {
    if (lockTimeLeft > 0) {
      const timer = setTimeout(() => setLockTimeLeft(lockTimeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (lockTimeLeft === 0 && isLocked) {
      setIsLocked(false);
      setAttemptsLeft(3);
      toast.info('Device unlocked. You can try again.');
    }
  }, [lockTimeLeft, isLocked]);

  const generateDeviceFingerprint = () => {
    // Create a unique device fingerprint
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('Device fingerprint', 2, 2);
    
    const fingerprint = canvas.toDataURL() + 
                       navigator.userAgent + 
                       navigator.language + 
                       window.screen.width + 'x' + window.screen.height;
    
    const deviceId = btoa(fingerprint).slice(0, 32);
    setDeviceFingerprint(deviceId);
    return deviceId;
  };

  const checkExistingSession = async () => {
    const savedSession = localStorage.getItem('adminSession');
    const savedDeviceFingerprint = localStorage.getItem('deviceFingerprint');
    
    if (savedSession && savedDeviceFingerprint) {
      const sessionData = JSON.parse(savedSession);
      
      try {
        const response = await fetch('/api/pin/verify-session', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            sessionToken: sessionData.sessionToken,
            deviceFingerprint: savedDeviceFingerprint
          }),
        });

        const data = await response.json();

        if (data.success) {
          setSessionToken(sessionData.sessionToken);
          setDeviceFingerprint(savedDeviceFingerprint);
          setIsAuthenticated(true);
          setTimeLeft(data.timeLeft);
          onSuccess(sessionData.sessionToken, savedDeviceFingerprint);
        } else {
          // Session invalid, clear storage
          localStorage.removeItem('adminSession');
          localStorage.removeItem('deviceFingerprint');
        }
      } catch (error) {
        console.error('Session verification error:', error);
        localStorage.removeItem('adminSession');
        localStorage.removeItem('deviceFingerprint');
      }
    }
  };

  const checkLockStatus = async () => {
    const deviceId = deviceFingerprint || generateDeviceFingerprint();
    
    try {
      const response = await fetch(`/api/pin/lock-status?deviceFingerprint=${deviceId}`);
      const data = await response.json();

      if (data.success) {
        setIsLocked(data.isLocked);
        setAttemptsLeft(data.maxAttempts - data.attempts);
        
        if (data.isLocked) {
          setLockTimeLeft(data.remainingTime);
        }
      }
    } catch (error) {
      console.error('Lock status check error:', error);
    }
  };

  const handleSessionExpiry = async () => {
    toast.info('Session expired. Please authenticate again.');
    await logout();
  };

  const handlePinChange = (index, value) => {
    if (value.length > 1) return;
    if (!/^\d*$/.test(value)) return;

    const newPin = [...pin];
    newPin[index] = value;
    setPin(newPin);

    // Auto focus next input
    if (value && index < 3) {
      const nextInput = document.querySelector(`input[data-index="${index + 1}"]`);
      if (nextInput) nextInput.focus();
    }

    // Check if PIN is complete
    if (newPin.every(digit => digit !== '') && newPin.join('').length === 4) {
      validatePin(newPin.join(''));
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !pin[index] && index > 0) {
      const prevInput = document.querySelector(`input[data-index="${index - 1}"]`);
      if (prevInput) prevInput.focus();
    }
  };

  const validatePin = async (enteredPin) => {
    if (isLocked) {
      toast.error('Device is locked. Please wait.');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('/api/pin/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          pin: enteredPin,
          deviceFingerprint: deviceFingerprint
        }),
      });

      const data = await response.json();

      if (data.success) {
        // Authentication successful
        setSessionToken(data.sessionToken);
        setIsAuthenticated(true);
        setTimeLeft(Math.floor((new Date(data.expiresAt) - new Date()) / 1000));
        
        // Store session data
        localStorage.setItem('adminSession', JSON.stringify({
          sessionToken: data.sessionToken,
          expiresAt: data.expiresAt
        }));
        localStorage.setItem('deviceFingerprint', data.deviceFingerprint);
        
        toast.success('Authentication successful!');
        onSuccess(data.sessionToken, data.deviceFingerprint);
      } else {
        // Authentication failed
        toast.error(data.message || 'Invalid PIN');
        setPin(['', '', '', '']);
        setAttemptsLeft(data.attemptsLeft || 0);
        
        // Focus first input
        const firstInput = document.querySelector(`input[data-index="0"]`);
        if (firstInput) firstInput.focus();
        
        // Check if device is now locked
        if (data.attemptsLeft === 0 || response.status === 423) {
          setIsLocked(true);
          setLockTimeLeft(data.remainingTime || 7200); // 2 hours default
          toast.error('Device locked due to multiple failed attempts!');
        }
      }
    } catch (error) {
      console.error('PIN validation error:', error);
      toast.error('Network error. Please try again.');
      setPin(['', '', '', '']);
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      if (sessionToken) {
        await fetch('/api/pin/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            sessionToken: sessionToken,
            deviceFingerprint: deviceFingerprint
          }),
        });
      }
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Clear local storage
      localStorage.removeItem('adminSession');
      localStorage.removeItem('deviceFingerprint');
      
      // Reset state
      setIsAuthenticated(false);
      setSessionToken(null);
      setTimeLeft(0);
      setPin(['', '', '', '']);
    }
  };
  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const formatLockTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${minutes}m`;
    }
  };

  // Device is locked
  if (isLocked && lockTimeLeft > 0) {
    return (
      <div className="admin-pin-auth">
        <div className="pin-container">
          <div className="pin-header d-flex flex-column align-items-center">
            <i className="fas fa-lock pin-icon text-danger" style={{ fontSize: '3rem' }}></i>
            <h2 className="text-danger">Device Locked</h2>
            <p className="text-center">
              Too many failed attempts. Your device is temporarily locked.
            </p>
          </div>
          
          <div className="lock-timer text-center">
            <div className="alert alert-danger">
              <h4>Time remaining: {formatLockTime(lockTimeLeft)}</h4>
              <p className="mb-0">Please wait before trying again.</p>
            </div>
          </div>
          
          <div className="pin-info text-center">
            <p>
              <i className="fas fa-info-circle"></i> 
              This lockout is device-specific and will expire automatically.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Session is active
  if (isAuthenticated && timeLeft > 0) {
    return (
      <div className="admin-pin-success">
        <div className="pin-container">
          <div className="success-icon">
            <i className="fas fa-check-circle"></i>
          </div>
          <h3>Access Granted</h3>
          <p>Session expires in: <strong>{formatTime(timeLeft)}</strong></p>
          <button 
            onClick={logout} 
            className="btn btn-outline-danger btn-sm"
            disabled={loading}
          >
            {loading ? 'Logging out...' : 'End Session'}
          </button>
        </div>
      </div>
    );
  }

  // Login form
  return (
    <div className="admin-pin-auth">
      <div className="pin-container">
        <div className="pin-header d-flex flex-column align-items-center">
          <i className="fas fa-shield-alt pin-icon"></i>
          <h2>Admin Access</h2>
          <p>Enter your 4-digit PIN to continue</p>
        </div>
        
        <div className="pin-inputs">
          {pin.map((digit, index) => (
            <input
              key={index}
              type="text"
              value={digit}
              onChange={(e) => handlePinChange(index, e.target.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              data-index={index}
              className="pin-input"
              maxLength="1"
              autoComplete="off"
              disabled={loading || isLocked}
            />
          ))}
        </div>
        
        {loading && (
          <div className="text-center my-3">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="mt-2">Verifying PIN...</p>
          </div>
        )}
        
        <div className="pin-info">
          <p>
            <i className="fas fa-info-circle"></i> 
            This session will be valid for 2 hours on this device
          </p>
          {attemptsLeft < 3 && !isLocked && (
            <div className="alert alert-warning">
              <i className="fas fa-exclamation-triangle"></i> 
              {attemptsLeft} attempt{attemptsLeft !== 1 ? 's' : ''} remaining before device lock
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPinAuth;
