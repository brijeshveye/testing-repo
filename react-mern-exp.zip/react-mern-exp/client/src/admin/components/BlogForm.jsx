import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import WidgetManager from './widgets/WidgetManager';
import { ImageUploader, uploadImage, IMAGE_CATEGORIES } from './ImageUpload';
import { showSuccess, showError } from '../../utils/toastUtils';

const BlogForm = () => {
  const [form, setForm] = useState({
    title: '',
    description: '',
    slug: '',
    bannerImage: '',
    image: '',
    date: '',
    author: '',
    category: '',
    tags: [],
    widgets: [], // Dynamic content widgets
    details: {
      section1: { para1: '', para2: '' },
      section2: { quote: '', author: '' },
      section3: { para: '' },
      section4: { title: '', image1: '', para1: '', para2: '', list: [] }
    }
  });
  const [activeTab, setActiveTab] = useState('basic');
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = !!slug;

  useEffect(() => {
    if (isEdit) {
      fetchBlog();
    }
  }, [slug, isEdit]);

  const fetchBlog = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`/api/blogs/${slug}`);
      setForm(response.data);
    } catch (err) {
      showError('Failed to load blog post');
      console.error('Error fetching blog:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleWidgetsChange = (widgets) => {
    setForm(prev => ({ ...prev, widgets }));
  };

  const handleImageUpload = async (file, category) => {
    try {
      return await uploadImage(file, category);
    } catch (error) {
      showError('Image upload failed: ' + error.message);
      throw error;
    }
  };

  const handleBannerImageUpload = (url) => {
    setForm(prev => ({ ...prev, bannerImage: url }));
  };

  const handleMainImageUpload = (url) => {
    setForm(prev => ({ ...prev, image: url }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!form.title.trim()) {
      showError('Blog title is required');
      return;
    }
    if (!form.slug.trim() && !isEdit) {
      showError('Blog slug is required');
      return;
    }

    try {
      setLoading(true);

      if (isEdit) {
        await axios.put(`/api/blogs/${slug}`, form);
        showSuccess('Blog post updated successfully!');
      } else {
        await axios.post('/api/blogs', form);
        showSuccess('Blog post created successfully!');
      }

      // Redirect after a short delay
      setTimeout(() => {
        navigate('/admin/blogs');
      }, 1500);

    } catch (err) {
      showError(err.response?.data?.message || `Failed to ${isEdit ? 'update' : 'create'} blog post`);
      console.error('Error saving blog:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
          <div className="text-center">
            <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="text-muted">Loading blog post...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-start">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '56px', 
                    height: '56px', 
                    backgroundColor: isEdit ? '#f57c00' : '#2e7d32',
                    color: 'white'
                  }}
                >
                  <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'} fs-3`}></i>
                </div>
                <div>
                  <h2 className="mb-1 text-dark fw-bold">{isEdit ? 'Edit Blog Post' : 'Create New Blog Post'}</h2>
                  <p className="text-muted mb-0">{isEdit ? 'Update blog post content and settings' : 'Add a new blog post to your portfolio'}</p>
                </div>
              </div>
              <button 
                type="button"
                onClick={() => navigate('/admin/blogs')}
                className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
              >
                <i className="fas fa-arrow-left me-2"></i>Back to Blogs
              </button>
            </div>
          </div>
        </div>

        <div className="row g-4">
          {/* Main Form Card */}
          <div className="col-12 col-lg-8">
            <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
              <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '48px', 
                      height: '48px', 
                      backgroundColor: '#e3f2fd'
                    }}
                  >
                    <i className="fas fa-blog text-primary fs-5"></i>
                  </div>
                  <div>
                    <h5 className="mb-0 fw-bold text-dark">Blog Content</h5>
                    <small className="text-muted">Fill in the blog post details and content</small>
                  </div>
                </div>
              </div>
              
              {/* Tab Navigation */}
              <div className="card-body p-0">
                <div className="card shadow-sm border-0 mx-4 mt-4" style={{ borderRadius: '12px' }}>
                  <div className="card-body p-3">
                    <div className="d-flex align-items-center mb-2">
                      <div 
                        className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                        style={{ 
                          width: '24px', 
                          height: '24px', 
                          backgroundColor: '#e3f2fd',
                          color: '#1976d2'
                        }}
                      >
                        <i className="fas fa-layer-group" style={{ fontSize: '10px' }}></i>
                      </div>
                      <h6 className="mb-0 fw-bold text-dark" style={{ fontSize: '14px' }}>Content Sections</h6>
                    </div>
                    
                    <div className="d-flex flex-wrap gap-2">
                      {[
                        { key: 'basic', label: 'Basic Info', icon: 'fas fa-info-circle', color: '#2e7d32' },
                        { key: 'images', label: 'Images', icon: 'fas fa-images', color: '#1976d2' },
                        { key: 'content', label: 'Dynamic Content', icon: 'fas fa-puzzle-piece', color: '#f57c00' }
                      ].map((tab) => (
                        <button
                          key={tab.key}
                          type="button"
                          className={`btn rounded-pill px-3 py-2 fw-medium ${
                            activeTab === tab.key 
                              ? 'btn-primary' 
                              : 'btn-outline-secondary'
                          }`}
                          style={{ fontSize: '12px' }}
                          onClick={() => setActiveTab(tab.key)}
                        >
                          <i className={`${tab.icon} me-1`}></i>
                          {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="card-body p-4">
                <form onSubmit={handleSubmit}>
                  {/* Basic Info Tab */}
                  {activeTab === 'basic' && (
                    <div>
                      {/* Basic Information Section */}
                      <div className="mb-5">
                        <div className="d-flex align-items-center mb-3">
                          <div 
                            className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                            style={{ 
                              width: '32px', 
                              height: '32px', 
                              backgroundColor: '#e8f5e8',
                              color: '#2e7d32'
                            }}
                          >
                            <i className="fas fa-info-circle fs-6"></i>
                          </div>
                          <h6 className="mb-0 fw-bold text-dark">Basic Information</h6>
                        </div>
                        
                        <div className="row g-3">
                          <div className="col-md-6">
                            <label className="form-label fw-medium text-dark mb-2">
                              Title <span className="text-danger">*</span>
                            </label>
                            <input 
                              className="form-control border-2 py-2"
                              style={{ borderRadius: '8px', fontSize: '14px' }}
                              name="title" 
                              value={form.title} 
                              onChange={handleChange} 
                              placeholder="Enter blog post title"
                              required 
                            />
                          </div>
                          <div className="col-md-6">
                            <label className="form-label fw-medium text-dark mb-2">
                              Slug <span className="text-danger">*</span>
                            </label>
                            <input 
                              className="form-control border-2 py-2"
                              style={{ borderRadius: '8px', fontSize: '14px' }}
                              name="slug" 
                              value={form.slug} 
                              onChange={handleChange} 
                              required={!isEdit} 
                              disabled={isEdit} 
                              placeholder="url-friendly-name"
                            />
                            <div className="form-text">
                              {isEdit ? 'URL slug cannot be changed after creation' : 'Used in the blog post URL'}
                            </div>
                          </div>
                        </div>
                        
                        <div className="mt-3">
                          <label className="form-label fw-medium text-dark mb-2">Description</label>
                          <textarea 
                            className="form-control border-2"
                            style={{ borderRadius: '8px', fontSize: '14px', minHeight: '100px' }}
                            name="description" 
                            value={form.description} 
                            onChange={handleChange}
                            rows="4"
                            placeholder="Brief description of the blog post..."
                          />
                        </div>
                      </div>

                      {/* Metadata Section */}
                      <div className="mb-5">
                        <div className="d-flex align-items-center mb-3">
                          <div 
                            className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                            style={{ 
                              width: '32px', 
                              height: '32px', 
                              backgroundColor: '#fff3e0',
                              color: '#f57c00'
                            }}
                          >
                            <i className="fas fa-tags fs-6"></i>
                          </div>
                          <h6 className="mb-0 fw-bold text-dark">Metadata</h6>
                        </div>
                        
                        <div className="row g-3">
                          <div className="col-md-4">
                            <label className="form-label fw-medium text-dark mb-2">Author</label>
                            <input 
                              className="form-control border-2 py-2"
                              style={{ borderRadius: '8px', fontSize: '14px' }}
                              name="author" 
                              value={form.author} 
                              onChange={handleChange} 
                              placeholder="Author name"
                            />
                          </div>
                          <div className="col-md-4">
                            <label className="form-label fw-medium text-dark mb-2">Publication Date</label>
                            <input 
                              type="date" 
                              className="form-control border-2 py-2"
                              style={{ borderRadius: '8px', fontSize: '14px' }}
                              name="date" 
                              value={form.date} 
                              onChange={handleChange} 
                            />
                          </div>
                          <div className="col-md-4">
                            <label className="form-label fw-medium text-dark mb-2">Category</label>
                            <input 
                              className="form-control border-2 py-2"
                              style={{ borderRadius: '8px', fontSize: '14px' }}
                              name="category" 
                              value={form.category} 
                              onChange={handleChange} 
                              placeholder="e.g., Technology, Tutorial"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Images Tab */}
                  {activeTab === 'images' && (
                    <div>
                      <div className="d-flex align-items-center mb-3">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '32px', 
                            height: '32px', 
                            backgroundColor: '#e3f2fd',
                            color: '#1976d2'
                          }}
                        >
                          <i className="fas fa-images fs-6"></i>
                        </div>
                        <h6 className="mb-0 fw-bold text-dark">Blog Images</h6>
                      </div>
                      
                      <div className="row g-4">
                        <div className="col-md-6">
                          <div 
                            className="p-4 rounded-3 border-2 border-dashed"
                            style={{ backgroundColor: '#fafafa' }}
                          >
                            <label className="form-label fw-medium text-dark mb-3">Banner Image</label>
                            {form.bannerImage && (
                              <div className="mb-3">
                                <img 
                                  src={form.bannerImage} 
                                  alt="Banner preview" 
                                  className="img-thumbnail rounded-3"
                                  style={{ maxHeight: '150px', width: '100%', objectFit: 'cover' }}
                                />
                              </div>
                            )}
                            <ImageUploader
                              onUpload={handleBannerImageUpload}
                              category={IMAGE_CATEGORIES.BANNER}
                              currentImage={form.bannerImage}
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div 
                            className="p-4 rounded-3 border-2 border-dashed"
                            style={{ backgroundColor: '#fafafa' }}
                          >
                            <label className="form-label fw-medium text-dark mb-3">Featured Image</label>
                            {form.image && (
                              <div className="mb-3">
                                <img 
                                  src={form.image} 
                                  alt="Featured image preview" 
                                  className="img-thumbnail rounded-3"
                                  style={{ maxHeight: '150px', width: '100%', objectFit: 'cover' }}
                                />
                              </div>
                            )}
                            <ImageUploader
                              onUpload={handleMainImageUpload}
                              category={IMAGE_CATEGORIES.BLOG}
                              currentImage={form.image}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Dynamic Content Tab */}
                  {activeTab === 'content' && (
                    <div>
                      <div className="d-flex align-items-center mb-3">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '32px', 
                            height: '32px', 
                            backgroundColor: '#fce4ec',
                            color: '#e91e63'
                          }}
                        >
                          <i className="fas fa-puzzle-piece fs-6"></i>
                        </div>
                        <h6 className="mb-0 fw-bold text-dark">Dynamic Content Widgets</h6>
                      </div>
                      
                      <div 
                        className="p-4 rounded-3 border"
                        style={{ backgroundColor: '#fafafa' }}
                      >
                        <WidgetManager
                          widgets={form.widgets}
                          onChange={handleWidgetsChange}
                          onImageUpload={handleImageUpload}
                        />
                      </div>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="d-flex gap-3 pt-3 border-top mt-4">
                    <button 
                      type="submit" 
                      className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                      style={{ fontSize: '14px' }}
                      disabled={loading}
                    >
                      {loading ? (
                        <>
                          <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                          {isEdit ? 'Updating...' : 'Creating...'}
                        </>
                      ) : (
                        <>
                          <i className="fas fa-save me-2"></i>
                          {isEdit ? 'Update Blog Post' : 'Create Blog Post'}
                        </>
                      )}
                    </button>
                    
                    <button 
                      type="button" 
                      className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                      style={{ fontSize: '14px' }}
                      onClick={() => navigate('/admin/blogs')}
                    >
                      <i className="fas fa-times me-2"></i>Cancel
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>

          {/* Preview/Info Sidebar */}
          <div className="col-12 col-lg-4">
            <div className="card shadow-sm border-0 sticky-top" style={{ borderRadius: '16px', top: '2rem' }}>
              <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '40px', 
                      height: '40px', 
                      backgroundColor: '#e8f5e8'
                    }}
                  >
                    <i className="fas fa-eye text-success fs-6"></i>
                  </div>
                  <div>
                    <h6 className="mb-0 fw-bold text-dark">Blog Preview</h6>
                    <small className="text-muted">Live preview</small>
                  </div>
                </div>
              </div>
              <div className="card-body p-4">
                {/* Blog Preview */}
                <div className="mb-4">
                  {form.bannerImage || form.image ? (
                    <img 
                      src={form.bannerImage || form.image} 
                      alt="Blog preview" 
                      className="img-fluid rounded-3 mb-3"
                      style={{ width: '100%', height: '120px', objectFit: 'cover' }}
                    />
                  ) : (
                    <div 
                      className="bg-light rounded-3 d-flex align-items-center justify-content-center mb-3"
                      style={{ height: '120px' }}
                    >
                      <i className="fas fa-image text-muted fs-1"></i>
                    </div>
                  )}
                  
                  <h6 className="fw-bold text-dark mb-2">
                    {form.title || 'Blog Title'}
                  </h6>
                  <p className="text-muted small mb-3" style={{ fontSize: '13px' }}>
                    {form.description || 'Blog description will appear here...'}
                  </p>
                </div>

                {/* Blog Stats */}
                <div className="border-top pt-3">
                  <div className="row g-2 text-center">
                    <div className="col-6">
                      <div className="p-2 rounded-3" style={{ backgroundColor: '#e3f2fd' }}>
                        <div className="small text-primary fw-bold">{form.author || 'N/A'}</div>
                        <div className="text-muted" style={{ fontSize: '11px' }}>Author</div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="p-2 rounded-3" style={{ backgroundColor: '#fff3e0' }}>
                        <div className="small text-warning fw-bold">{form.category || 'N/A'}</div>
                        <div className="text-muted" style={{ fontSize: '11px' }}>Category</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="row g-2 text-center mt-2">
                    <div className="col-6">
                      <div className="p-2 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                        <div className="small text-success fw-bold">{form.widgets?.length || 0}</div>
                        <div className="text-muted" style={{ fontSize: '11px' }}>Widgets</div>
                      </div>
                    </div>
                    <div className="col-6">
                      <div className="p-2 rounded-3" style={{ backgroundColor: '#fce4ec' }}>
                        <div className="small fw-bold" style={{ color: '#e91e63' }}>
                          {form.date ? new Date(form.date).toLocaleDateString() : 'Not set'}
                        </div>
                        <div className="text-muted" style={{ fontSize: '11px' }}>Publish Date</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Slug Preview */}
                {form.slug && (
                  <div className="mt-3 p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                    <small className="text-muted d-block mb-1">URL Preview:</small>
                    <div className="small text-primary fw-medium">/blog/{form.slug}</div>
                  </div>
                )}

                {/* Active Tab Indicator */}
                <div className="mt-3 p-2 rounded-3" style={{ backgroundColor: '#e3f2fd' }}>
                  <small className="text-primary fw-medium">
                    <i className="fas fa-layer-group me-1"></i>
                    Current: {activeTab === 'basic' ? 'Basic Info' : activeTab === 'images' ? 'Images' : 'Dynamic Content'}
                  </small>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogForm;
