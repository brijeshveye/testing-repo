import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';

const EditSectionForm = () => {
  const { section } = useParams(); // e.g. "aboutData"
  const [data, setData] = useState(null);
  const navigate = useNavigate();

  // Helper function to get appropriate icon for each field
  const getFieldIcon = (fieldName) => {
    const fieldKey = fieldName.toLowerCase();
    if (fieldKey.includes('email')) return 'fas fa-envelope';
    if (fieldKey.includes('phone')) return 'fas fa-phone';
    if (fieldKey.includes('name')) return 'fas fa-user';
    if (fieldKey.includes('address')) return 'fas fa-map-marker-alt';
    if (fieldKey.includes('bio') || fieldKey.includes('tagline')) return 'fas fa-quote-left';
    if (fieldKey.includes('skype')) return 'fab fa-skype';
    if (fieldKey.includes('linkedin')) return 'fab fa-linkedin';
    if (fieldKey.includes('github')) return 'fab fa-github';
    if (fieldKey.includes('twitter')) return 'fab fa-twitter';
    if (fieldKey.includes('instagram')) return 'fab fa-instagram';
    if (fieldKey.includes('facebook')) return 'fab fa-facebook';
    if (fieldKey.includes('website')) return 'fas fa-globe';
    if (fieldKey.includes('location')) return 'fas fa-location-dot';
    if (fieldKey.includes('age') || fieldKey.includes('birthday')) return 'fas fa-calendar';
    if (fieldKey.includes('resume')) return 'fas fa-file-pdf';
    return 'fas fa-edit';
  };

  useEffect(() => {
    axios.get('/api/user').then(res => {
      setData(res.data[section]);
    });
  }, [section]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Check if we're dealing with a nested object (like socialLinks)
    if (typeof data === 'object' && data !== null && !Array.isArray(data)) {
      // If all values in data are strings (flat object like socialLinks)
      const isFlat = Object.values(data).every(val => typeof val === 'string' || val === null || val === undefined);
      
      if (isFlat) {
        setData(prev => ({ ...prev, [name]: value }));
      } else {
        // Handle other nested structures if needed
        setData(prev => ({ ...prev, [name]: value }));
      }
    } else {
      setData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`/api/user/${section}`, data);
    navigate('/admin/user'); // Redirect to user dashboard after update
  };

  if (!data) return <div className="container mt-4">Loading...</div>;

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-8">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center">
                <div className="me-3">
                  <div 
                    className="rounded-circle d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '60px', 
                      height: '60px', 
                      backgroundColor: '#1976d2',
                      color: 'white'
                    }}
                  >
                    <i className="fas fa-edit fs-3"></i>
                  </div>
                </div>
                <div>
                  <h2 className="mb-1 text-dark fw-bold">Edit {section}</h2>
                  <p className="text-muted mb-0">Update your {section.replace(/([A-Z])/g, ' $1').toLowerCase()} information</p>
                </div>
              </div>
            </div>
          </div>

          {/* Edit Form Card */}
          <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
            <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#e3f2fd'
                  }}
                >
                  <i className="fas fa-form text-primary fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Update Information</h5>
                  <small className="text-muted">Fill in the details below to update your {section}</small>
                </div>
              </div>
            </div>
            <div className="card-body px-4 pb-4">
              <form onSubmit={handleSubmit}>
                <div className="row g-4">
                  {Object.keys(data).map((key, i) => (
                    <div className="col-12 col-md-6" key={i}>
                      <div className="form-floating">
                        <input
                          id={key}
                          className="form-control border-2"
                          name={key}
                          value={data[key] || ''}
                          onChange={handleChange}
                          type={key.includes('email') ? 'email' : key.includes('phone') ? 'tel' : 'text'}
                          placeholder={`Enter ${key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}`}
                          style={{ 
                            borderRadius: '12px',
                            borderColor: '#e0e0e0',
                            fontSize: '16px',
                            height: '60px'
                          }}
                        />
                        <label htmlFor={key} className="fw-medium text-muted">
                          <i className={getFieldIcon(key)} style={{ marginRight: '8px' }}></i>
                          {key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1')}
                        </label>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Action Buttons */}
                <div className="row mt-5">
                  <div className="col-12">
                    <div className="p-4 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                      <div className="d-flex flex-column flex-md-row gap-3 justify-content-between align-items-center">
                        <div>
                          <h6 className="mb-1 fw-bold text-dark">Ready to save changes?</h6>
                          <small className="text-muted">Make sure all information is correct before updating</small>
                        </div>
                        <div className="d-flex gap-2">
                          <button 
                            type="button" 
                            className="btn btn-outline-secondary rounded-pill px-4"
                            onClick={() => navigate('/admin/user')}
                            style={{ minWidth: '120px' }}
                          >
                            <i className="fas fa-times me-2"></i>
                            Cancel
                          </button>
                          <button 
                            type="submit" 
                            className="btn btn-primary rounded-pill px-4"
                            style={{ minWidth: '120px' }}
                          >
                            <i className="fas fa-save me-2"></i>
                            Update
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>

          {/* Quick Tips Card */}
          <div className="card shadow-sm border-0 mt-4" style={{ borderRadius: '16px' }}>
            <div className="card-body p-4">
              <div className="d-flex align-items-start">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center flex-shrink-0"
                  style={{ 
                    width: '40px', 
                    height: '40px', 
                    backgroundColor: '#fff3e0'
                  }}
                >
                  <i className="fas fa-lightbulb text-warning"></i>
                </div>
                <div>
                  <h6 className="mb-2 fw-bold text-dark">Quick Tips</h6>
                  <ul className="text-muted mb-0 small">
                    <li>Use professional email addresses for business contacts</li>
                    <li>Keep your contact information up to date</li>
                    <li>Add all relevant social media profiles</li>
                    <li>Double-check phone numbers and email addresses</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditSectionForm;
