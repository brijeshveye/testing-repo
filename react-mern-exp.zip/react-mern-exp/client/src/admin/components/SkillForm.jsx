import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import SkillsDataApi from '../../api/SkillsDataApi';

const SkillForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Language',
    level: 'Intermediate',
    percentage: 50,
    icon: 'fas fa-code',
    color: '#007bff',
    yearsExperience: 1,
    certifications: [],
    projects: [],
    featured: false,
    isActive: true,
    order: 0,
    customIcon: false
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Predefined options
  const categories = [
    'Language', 'Frontend', 'Backend', 'Database', 'Cloud', 
    'DevOps', 'Design', 'Mobile', 'Testing', 'Other'
  ];

  const levels = [
    'Beginner', 'Intermediate', 'Advanced', 'Expert'
  ];

  const commonIcons = [
    'fas fa-code', 'fab fa-js-square', 'fab fa-react', 'fab fa-node-js',
    'fab fa-python', 'fab fa-java', 'fab fa-php', 'fab fa-html5',
    'fab fa-css3-alt', 'fab fa-sass', 'fab fa-angular', 'fab fa-vue',
    'fab fa-bootstrap', 'fab fa-git-alt', 'fab fa-github', 'fab fa-docker',
    'fab fa-aws', 'fab fa-google', 'fas fa-database', 'fas fa-server',
    'fas fa-mobile-alt', 'fas fa-palette', 'fas fa-cogs', 'fas fa-chart-bar',
    'fab fa-laravel', 'fab fa-symfony', 'fab fa-wordpress', 'fab fa-drupal',
    'fab fa-figma', 'fab fa-sketch', 'fab fa-adobe', 'fab fa-microsoft',
    'fas fa-cloud', 'fas fa-lock', 'fas fa-shield-alt', 'fas fa-tools',
    'fas fa-laptop-code', 'fas fa-terminal', 'fas fa-bug', 'fas fa-rocket',
    'fab fa-android', 'fab fa-apple', 'fab fa-linux', 'fab fa-windows',
    'fab fa-unity', 'fab fa-unity', 'fas fa-gamepad', 'fas fa-video'
  ];

  const commonColors = [
    '#007bff', '#28a745', '#ffc107', '#dc3545', '#6f42c1', '#fd7e14',
    '#20c997', '#6c757d', '#e83e8c', '#17a2b8', '#343a40', '#f8f9fa'
  ];

  useEffect(() => {
    if (isEdit) {
      fetchSkillData();
    }
  }, [isEdit, slug]);

  const fetchSkillData = async () => {
    try {
      setLoading(true);
      const data = await SkillsDataApi.getSkillDetails(slug);
      if (data) {
        const isCustomIcon = !commonIcons.includes(data.icon || 'fas fa-code');
        setFormData({
          title: data.title || '',
          description: data.description || '',
          category: data.category || 'Language',
          level: data.level || 'Intermediate',
          percentage: data.percentage || 50,
          icon: data.icon || 'fas fa-code',
          color: data.color || '#007bff',
          yearsExperience: data.yearsExperience || 1,
          certifications: data.certifications || [],
          projects: data.projects || [],
          featured: data.featured || false,
          isActive: data.isActive !== undefined ? data.isActive : true,
          order: data.order || 0,
          customIcon: isCustomIcon
        });
      }
    } catch (err) {
      setError('Failed to fetch skill data');
      console.error('Error fetching skill:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleArrayChange = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => 
        i === index ? value : item
      )
    }));
  };

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], '']
    }));
  };

  const removeArrayItem = (index, field) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Clean up empty array items and remove UI-only fields
      const cleanedData = {
        ...formData,
        certifications: formData.certifications.filter(cert => cert.trim()),
        projects: formData.projects.filter(project => project.trim()),
        percentage: parseInt(formData.percentage),
        yearsExperience: parseInt(formData.yearsExperience),
        order: parseInt(formData.order)
      };
      
      // Remove UI-only fields
      delete cleanedData.customIcon;

      if (isEdit) {
        await SkillsDataApi.updateSkill(slug, cleanedData);
        setSuccess('Skill updated successfully!');
      } else {
        await SkillsDataApi.createSkill(cleanedData);
        setSuccess('Skill created successfully!');
      }

      setTimeout(() => {
        navigate('/admin/skills');
      }, 1500);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save skill');
      console.error('Error saving skill:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
        <div className="row justify-content-center">
          <div className="col-12 col-xl-10">
            <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
              <div className="card-body py-5 text-center">
                <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
                  <span className="visually-hidden">Loading...</span>
                </div>
                <div className="mt-3">
                  <h5 className="text-muted">Loading skill data...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-10">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: isEdit ? '#f57c00' : '#2e7d32',
                        color: 'white'
                      }}
                    >
                      <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'} fs-3`}></i>
                    </div>
                  </div>
                  <div>
                    <h2 className="mb-1 text-dark fw-bold">{isEdit ? 'Edit Skill' : 'Create New Skill'}</h2>
                    <p className="text-muted mb-0">{isEdit ? 'Update your skill information and settings' : 'Add a new skill to your portfolio'}</p>
                  </div>
                </div>
                <Link 
                  to="/admin/skills" 
                  className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                >
                  <i className="fas fa-arrow-left me-2"></i>Back to Skills
                </Link>
              </div>
            </div>
          </div>

          {error && (
            <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className="alert alert-danger border-0 mb-0" style={{ borderRadius: '12px' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#ffebee',
                        color: '#d32f2f'
                      }}
                    >
                      <i className="fas fa-exclamation-triangle"></i>
                    </div>
                    <div className="fw-medium text-danger">{error}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {success && (
            <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className="alert alert-success border-0 mb-0" style={{ borderRadius: '12px' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#e8f5e8',
                        color: '#2e7d32'
                      }}
                    >
                      <i className="fas fa-check-circle"></i>
                    </div>
                    <div className="fw-medium text-success">{success}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="row g-4">
            {/* Main Form Card */}
            <div className="col-12 col-lg-8">
              <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
                <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-clipboard-list text-primary fs-5"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold text-dark">Skill Information</h5>
                      <small className="text-muted">Fill in the details for your skill</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">
                  <form onSubmit={handleSubmit}>
                    {/* Basic Information Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-info-circle text-primary me-2"></i>
                        Basic Information
                      </h6>
                      <div className="row g-3">
                        <div className="col-12 col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-tag me-2 text-muted"></i>Skill Title *
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            name="title"
                            value={formData.title}
                            onChange={handleChange}
                            required
                            placeholder="e.g., JavaScript, React, Node.js"
                            style={{ border: '2px solid #e0e0e0' }}
                          />
                        </div>
                        <div className="col-6 col-md-3">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-layer-group me-2 text-muted"></i>Category *
                          </label>
                          <select
                            className="form-select rounded-pill py-2"
                            name="category"
                            value={formData.category}
                            onChange={handleChange}
                            required
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            {categories.map(category => (
                              <option key={category} value={category}>
                                {category}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="col-6 col-md-3">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-chart-line me-2 text-muted"></i>Level *
                          </label>
                          <select
                            className="form-select rounded-pill py-2"
                            name="level"
                            value={formData.level}
                            onChange={handleChange}
                            required
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            {levels.map(level => (
                              <option key={level} value={level}>
                                {level}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="col-12">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-align-left me-2 text-muted"></i>Description
                          </label>
                          <textarea
                            className="form-control"
                            name="description"
                            rows="3"
                            value={formData.description}
                            onChange={handleChange}
                            placeholder="Brief description of your skill and experience..."
                            style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Proficiency and Experience Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-chart-bar text-success me-2"></i>
                        Proficiency & Experience
                      </h6>
                      <div className="row g-3">
                        <div className="col-12 col-md-4">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-percentage me-2 text-muted"></i>Proficiency Level
                          </label>
                          <div className="input-group">
                            <input
                              type="number"
                              className="form-control rounded-start-pill py-2"
                              name="percentage"
                              value={formData.percentage}
                              onChange={handleChange}
                              min="0"
                              max="100"
                              style={{ border: '2px solid #e0e0e0' }}
                            />
                            <span className="input-group-text" style={{ borderColor: '#e0e0e0' }}>%</span>
                          </div>
                          <div className="progress mt-2" style={{ height: '8px', borderRadius: '4px' }}>
                            <div
                              className="progress-bar"
                              role="progressbar"
                              style={{ 
                                width: `${formData.percentage}%`,
                                backgroundColor: formData.percentage >= 80 ? '#2e7d32' : formData.percentage >= 60 ? '#0288d1' : formData.percentage >= 40 ? '#ffa000' : '#6c757d'
                              }}
                            ></div>
                          </div>
                        </div>
                        <div className="col-6 col-md-4">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-clock me-2 text-muted"></i>Years of Experience
                          </label>
                          <input
                            type="number"
                            className="form-control rounded-pill py-2"
                            name="yearsExperience"
                            value={formData.yearsExperience}
                            onChange={handleChange}
                            min="0"
                            step="0.5"
                            style={{ border: '2px solid #e0e0e0' }}
                          />
                        </div>
                        <div className="col-6 col-md-4">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-sort-numeric-up me-2 text-muted"></i>Display Order
                          </label>
                          <input
                            type="number"
                            className="form-control rounded-pill py-2"
                            name="order"
                            value={formData.order}
                            onChange={handleChange}
                            min="0"
                            style={{ border: '2px solid #e0e0e0' }}
                          />
                        </div>
                      </div>
                    </div>

                    {/* Visual Customization Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-palette text-warning me-2"></i>
                        Visual Customization
                      </h6>
                      <div className="row g-3">
                        <div className="col-12 col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-icons me-2 text-muted"></i>Icon
                          </label>
                          <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                            <div className="btn-group w-100 mb-3" role="group">
                              <input 
                                type="radio" 
                                className="btn-check" 
                                name="iconInputType" 
                                id="iconSelect" 
                                checked={!formData.customIcon} 
                                onChange={() => setFormData(prev => ({ ...prev, customIcon: false }))} 
                              />
                              <label className="btn btn-outline-primary rounded-start-pill" htmlFor="iconSelect">
                                <i className="fas fa-list me-2"></i>Select from List
                              </label>
                              
                              <input 
                                type="radio" 
                                className="btn-check" 
                                name="iconInputType" 
                                id="iconCustom" 
                                checked={formData.customIcon} 
                                onChange={() => setFormData(prev => ({ ...prev, customIcon: true }))} 
                              />
                              <label className="btn btn-outline-primary rounded-end-pill" htmlFor="iconCustom">
                                <i className="fas fa-edit me-2"></i>Custom Icon
                              </label>
                            </div>
                            
                            {!formData.customIcon ? (
                              <select
                                className="form-select rounded-pill py-2"
                                name="icon"
                                value={formData.icon}
                                onChange={handleChange}
                                style={{ border: '2px solid #e0e0e0' }}
                              >
                                {commonIcons.map(icon => (
                                  <option key={icon} value={icon}>
                                    {icon}
                                  </option>
                                ))}
                              </select>
                            ) : (
                              <div>
                                <input
                                  type="text"
                                  className="form-control rounded-pill py-2"
                                  name="icon"
                                  value={formData.icon}
                                  onChange={handleChange}
                                  placeholder="e.g., fas fa-code, fab fa-react, etc."
                                  style={{ border: '2px solid #e0e0e0' }}
                                />
                                <small className="form-text text-muted mt-2 d-block">
                                  Enter FontAwesome class names. Visit <a href="https://fontawesome.com/icons" target="_blank" rel="noopener noreferrer" className="text-primary">FontAwesome</a> for icon classes.
                                </small>
                              </div>
                            )}
                            
                            <div className="mt-3 p-3 rounded-3" style={{ backgroundColor: 'white', border: '2px solid #e0e0e0' }}>
                              <div className="d-flex align-items-center">
                                <span className="me-3 fw-medium text-dark">Preview:</span>
                                <div 
                                  className="icon-preview d-inline-flex align-items-center justify-content-center rounded-3"
                                  style={{ 
                                    width: '48px', 
                                    height: '48px', 
                                    backgroundColor: formData.color,
                                    color: 'white'
                                  }}
                                >
                                  <i className={formData.icon} style={{ fontSize: '20px' }}></i>
                                </div>
                                <span className="ms-3 text-muted small">
                                  <code>{formData.icon}</code>
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-paint-brush me-2 text-muted"></i>Color
                          </label>
                          <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                            <div className="row g-2 mb-3">
                              <div className="col-8">
                                <input
                                  type="color"
                                  className="form-control form-control-color"
                                  name="color"
                                  value={formData.color}
                                  onChange={handleChange}
                                  style={{ height: '48px', borderRadius: '12px' }}
                                />
                              </div>
                              <div className="col-4">
                                <input
                                  type="text"
                                  className="form-control rounded-pill py-2"
                                  name="color"
                                  value={formData.color}
                                  onChange={handleChange}
                                  placeholder="#007bff"
                                  style={{ border: '2px solid #e0e0e0', height: '48px' }}
                                />
                              </div>
                            </div>
                            <div className="d-flex flex-wrap gap-2">
                              {commonColors.map(color => (
                                <button
                                  key={color}
                                  type="button"
                                  className="btn p-0"
                                  style={{ 
                                    backgroundColor: color, 
                                    width: '32px', 
                                    height: '32px',
                                    borderRadius: '8px',
                                    border: formData.color === color ? '3px solid #333' : '2px solid #e0e0e0'
                                  }}
                                  onClick={() => setFormData(prev => ({ ...prev, color }))}
                                  title={color}
                                ></button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Additional Information Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-plus-circle text-info me-2"></i>
                        Additional Information
                      </h6>
                      
                      {/* Certifications */}
                      <div className="mb-3">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-certificate me-2 text-muted"></i>Certifications
                        </label>
                        <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                          {formData.certifications.map((cert, index) => (
                            <div key={index} className="input-group mb-2">
                              <input
                                type="text"
                                className="form-control rounded-start-pill py-2"
                                placeholder="Certificate name or link"
                                value={cert}
                                onChange={(e) => handleArrayChange(index, 'certifications', e.target.value)}
                                style={{ border: '2px solid #e0e0e0' }}
                              />
                              <button
                                type="button"
                                className="btn btn-outline-danger rounded-end-pill"
                                onClick={() => removeArrayItem(index, 'certifications')}
                                style={{ borderColor: '#e0e0e0' }}
                              >
                                <i className="fas fa-times"></i>
                              </button>
                            </div>
                          ))}
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm rounded-pill px-3"
                            onClick={() => addArrayItem('certifications')}
                          >
                            <i className="fas fa-plus me-2"></i>Add Certification
                          </button>
                        </div>
                      </div>

                      {/* Related Projects */}
                      <div className="mb-3">
                        <label className="form-label fw-medium text-dark">
                          <i className="fas fa-project-diagram me-2 text-muted"></i>Related Projects
                        </label>
                        <div className="p-3 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                          {formData.projects.map((project, index) => (
                            <div key={index} className="input-group mb-2">
                              <input
                                type="text"
                                className="form-control rounded-start-pill py-2"
                                placeholder="Project name or description"
                                value={project}
                                onChange={(e) => handleArrayChange(index, 'projects', e.target.value)}
                                style={{ border: '2px solid #e0e0e0' }}
                              />
                              <button
                                type="button"
                                className="btn btn-outline-danger rounded-end-pill"
                                onClick={() => removeArrayItem(index, 'projects')}
                                style={{ borderColor: '#e0e0e0' }}
                              >
                                <i className="fas fa-times"></i>
                              </button>
                            </div>
                          ))}
                          <button
                            type="button"
                            className="btn btn-outline-secondary btn-sm rounded-pill px-3"
                            onClick={() => addArrayItem('projects')}
                          >
                            <i className="fas fa-plus me-2"></i>Add Project
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Status Options Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-toggle-on text-secondary me-2"></i>
                        Status & Visibility
                      </h6>
                      <div className="row g-3">
                        <div className="col-12 col-md-6">
                          <div className="p-3 rounded-3" style={{ backgroundColor: '#fff3e0' }}>
                            <div className="form-check form-switch">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                name="featured"
                                id="featured"
                                checked={formData.featured}
                                onChange={handleChange}
                                style={{ fontSize: '1.2rem' }}
                              />
                              <label className="form-check-label fw-medium text-dark" htmlFor="featured">
                                <i className="fas fa-star text-warning me-2"></i>
                                Featured Skill
                              </label>
                              <div className="small text-muted mt-1">
                                Show this skill prominently in your portfolio
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-12 col-md-6">
                          <div className="p-3 rounded-3" style={{ backgroundColor: '#e8f5e8' }}>
                            <div className="form-check form-switch">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                name="isActive"
                                id="isActive"
                                checked={formData.isActive}
                                onChange={handleChange}
                                style={{ fontSize: '1.2rem' }}
                              />
                              <label className="form-check-label fw-medium text-dark" htmlFor="isActive">
                                <i className="fas fa-eye text-success me-2"></i>
                                Active/Visible
                              </label>
                              <div className="small text-muted mt-1">
                                Make this skill visible to visitors
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Submit Buttons */}
                    <div className="d-flex gap-3 pt-3">
                      <button
                        type="submit"
                        className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                        disabled={loading}
                        style={{ backgroundColor: isEdit ? '#f57c00' : '#2e7d32', border: 'none' }}
                      >
                        {loading ? (
                          <>
                            <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                            {isEdit ? 'Updating...' : 'Creating...'}
                          </>
                        ) : (
                          <>
                            <i className={`fas ${isEdit ? 'fa-save' : 'fa-plus'} me-2`}></i>
                            {isEdit ? 'Update Skill' : 'Create Skill'}
                          </>
                        )}
                      </button>
                      <Link 
                        to="/admin/skills" 
                        className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                      >
                        Cancel
                      </Link>
                    </div>
                  </form>
                </div>
              </div>
            </div>

            {/* Preview Card */}
            <div className="col-12 col-lg-4">
              <div className="card shadow-sm border-0 sticky-top" style={{ borderRadius: '16px', top: '20px' }}>
                <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#f3e5f5'
                      }}
                    >
                      <i className="fas fa-eye text-secondary fs-5"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold text-dark">Live Preview</h5>
                      <small className="text-muted">See how your skill will appear</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">
                  <div className="text-center">
                    <div
                      className="skill-icon d-inline-flex align-items-center justify-content-center rounded-3 mb-3"
                      style={{
                        width: '80px',
                        height: '80px',
                        backgroundColor: formData.color,
                        color: '#fff'
                      }}
                    >
                      <i className={formData.icon} style={{ fontSize: '2rem' }}></i>
                    </div>
                    <h5 className="fw-bold text-dark mb-2">{formData.title || 'Skill Title'}</h5>
                    <p className="text-muted small mb-3">
                      {formData.description || 'Skill description will appear here...'}
                    </p>
                    
                    <div className="mb-3">
                      <span className={`badge rounded-pill px-3 py-2 me-2 fw-medium`}
                        style={{
                          backgroundColor: 
                            formData.category === 'Language' ? '#1976d2' :
                            formData.category === 'Frontend' ? '#2e7d32' :
                            formData.category === 'Backend' ? '#0288d1' :
                            formData.category === 'Database' ? '#ffa000' :
                            '#6c757d',
                          color: formData.category === 'Database' ? '#000' : '#fff'
                        }}>
                        {formData.category}
                      </span>
                      <span className={`badge rounded-pill px-3 py-2 fw-medium`}
                        style={{
                          backgroundColor:
                            formData.level === 'Expert' ? '#2e7d32' :
                            formData.level === 'Advanced' ? '#0288d1' :
                            formData.level === 'Intermediate' ? '#ffa000' :
                            '#6c757d',
                          color: formData.level === 'Intermediate' ? '#000' : '#fff'
                        }}>
                        {formData.level}
                      </span>
                    </div>

                    <div className="mb-3">
                      <div className="progress mb-2" style={{ height: '12px', borderRadius: '6px' }}>
                        <div
                          className="progress-bar"
                          role="progressbar"
                          style={{ 
                            width: `${formData.percentage}%`,
                            backgroundColor: formData.percentage >= 80 ? '#2e7d32' : formData.percentage >= 60 ? '#0288d1' : formData.percentage >= 40 ? '#ffa000' : '#6c757d'
                          }}
                        ></div>
                      </div>
                      <small className="text-muted fw-medium">{formData.percentage}% Proficiency</small>
                    </div>

                    <div className="d-flex justify-content-center gap-2">
                      {formData.featured && (
                        <span className="badge bg-warning rounded-pill px-3 py-1">
                          <i className="fas fa-star me-1"></i>Featured
                        </span>
                      )}
                      <span className={`badge rounded-pill px-3 py-1 ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                        <i className={`fas ${formData.isActive ? 'fa-check' : 'fa-times'} me-1`}></i>
                        {formData.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>

                    {formData.yearsExperience > 0 && (
                      <div className="mt-3 p-2 rounded-3" style={{ backgroundColor: '#f8f9fa' }}>
                        <small className="text-muted">
                          <i className="fas fa-clock me-1"></i>
                          {formData.yearsExperience} {formData.yearsExperience === 1 ? 'year' : 'years'} experience
                        </small>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SkillForm;
