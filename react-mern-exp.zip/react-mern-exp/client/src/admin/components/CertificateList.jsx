import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import CertificatesDataApi from '../../api/CertificatesDataApi';

const CertificateList = () => {
  const [certificates, setCertificates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [filters, setFilters] = useState({
    category: 'all',
    featured: 'all',
    status: 'all',
    search: ''
  });

  useEffect(() => {
    fetchCertificates();
  }, [filters]);

  const fetchCertificates = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.category !== 'all') params.category = filters.category;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.search) params.search = filters.search;

      const data = await CertificatesDataApi.getCertificatesData(params);
      setCertificates(data);
    } catch (err) {
      setError('Failed to fetch certificates');
      console.error('Error fetching certificates:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await CertificatesDataApi.deleteCertificate(slug);
        fetchCertificates(); // Refresh the list
      } catch (err) {
        setError('Failed to delete certificate');
        console.error('Error deleting certificate:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await CertificatesDataApi.toggleFeatured(slug);
      fetchCertificates(); // Refresh the list
    } catch (err) {
      setError('Failed to update featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await CertificatesDataApi.toggleActive(slug);
      fetchCertificates(); // Refresh the list
    } catch (err) {
      setError('Failed to update active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (loading) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading certificates...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', color: 'white' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-center">
              <div>
                <div className="d-flex align-items-center mb-2">
                  <i className="fas fa-certificate fs-1 me-3 opacity-75"></i>
                  <div>
                    <h1 className="mb-1 fw-bold">Certificate Management</h1>
                    <p className="mb-0 opacity-75">Manage your professional certifications and achievements</p>
                  </div>
                </div>
                <nav aria-label="breadcrumb">
                  <ol className="breadcrumb mb-0" style={{ backgroundColor: 'transparent' }}>
                    <li className="breadcrumb-item">
                      <Link to="/admin" className="text-white text-decoration-none opacity-75">
                        <i className="fas fa-home me-1"></i>Admin
                      </Link>
                    </li>
                    <li className="breadcrumb-item active text-white" aria-current="page">Certificates</li>
                  </ol>
                </nav>
              </div>
              <Link to="/admin/certificates/create" className="btn btn-light btn-lg" style={{ borderRadius: '12px' }}>
                <i className="fas fa-plus me-2"></i>Add Certificate
              </Link>
            </div>
          </div>
        </div>

        {/* Error Alert */}
        {error && (
          <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', backgroundColor: '#fff5f5', borderLeft: '4px solid #ef4444' }}>
            <div className="card-body p-4">
              <div className="d-flex align-items-center">
                <div className="flex-shrink-0 me-3">
                  <div className="rounded-circle bg-red-100 p-2">
                    <i className="fas fa-exclamation-triangle text-danger"></i>
                  </div>
                </div>
                <div>
                  <h6 className="mb-1 text-danger fw-semibold">Error</h6>
                  <p className="mb-0 text-gray-700">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex align-items-center mb-3">
              <i className="fas fa-filter text-primary me-2 fs-5"></i>
              <h5 className="card-title mb-0">Filter & Search</h5>
            </div>
            <div className="row g-3">
              <div className="col-lg-3 col-md-6">
                <label className="form-label fw-semibold">
                  <i className="fas fa-search me-1 text-muted"></i>Search
                </label>
                <input
                  type="text"
                  className="form-control form-control-lg"
                  name="search"
                  placeholder="Search certificates..."
                  value={filters.search}
                  onChange={handleFilterChange}
                  style={{ borderRadius: '12px', border: '2px solid #e2e8f0' }}
                />
              </div>
              
              <div className="col-lg-3 col-md-6">
                <label className="form-label fw-semibold">
                  <i className="fas fa-tag me-1 text-muted"></i>Category
                </label>
                <select
                  className="form-select form-select-lg"
                  name="category"
                  value={filters.category}
                  onChange={handleFilterChange}
                  style={{ borderRadius: '12px', border: '2px solid #e2e8f0' }}
                >
                  <option value="all">All Categories</option>
                  <option value="Web Development">Web Development</option>
                  <option value="Programming">Programming</option>
                  <option value="Frameworks">Frameworks</option>
                  <option value="Cloud Computing">Cloud Computing</option>
                  <option value="General">General</option>
                </select>
              </div>
              
              <div className="col-lg-3 col-md-6">
                <label className="form-label fw-semibold">
                  <i className="fas fa-star me-1 text-warning"></i>Featured
                </label>
                <select
                  className="form-select form-select-lg"
                  name="featured"
                  value={filters.featured}
                  onChange={handleFilterChange}
                  style={{ borderRadius: '12px', border: '2px solid #e2e8f0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Featured</option>
                  <option value="false">Not Featured</option>
                </select>
              </div>
              
              <div className="col-lg-3 col-md-6">
                <label className="form-label fw-semibold">
                  <i className="fas fa-toggle-on me-1 text-success"></i>Status
                </label>
                <select
                  className="form-select form-select-lg"
                  name="status"
                  value={filters.status}
                  onChange={handleFilterChange}
                  style={{ borderRadius: '12px', border: '2px solid #e2e8f0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </div>
            </div>
          </div>
        </div>

        {/* Certificates Grid */}
        {certificates.length === 0 ? (
          <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
            <div className="card-body text-center py-5">
              <div 
                className="rounded-circle mx-auto mb-4 d-flex align-items-center justify-content-center"
                style={{ width: '80px', height: '80px', backgroundColor: '#f8f9fa', border: '3px dashed #dee2e6' }}
              >
                <i className="fas fa-certificate fa-2x text-muted"></i>
              </div>
              <h5 className="mb-3 text-dark">No certificates found</h5>
              <p className="text-muted mb-4">
                {filters.search || filters.category !== 'all' || filters.featured !== 'all' || filters.status !== 'all'
                  ? 'Try adjusting your filters or search terms to find certificates.'
                  : 'Start by creating your first certificate to showcase your achievements.'}
              </p>
              <Link to="/admin/certificates/create" className="btn btn-primary btn-lg" style={{ borderRadius: '12px' }}>
                <i className="fas fa-plus me-2"></i>Create Your First Certificate
              </Link>
            </div>
          </div>
        ) : (
          <div className="row g-4">
            {certificates.map((certificate) => (
              <div key={certificate._id} className="col-12 col-md-6 col-lg-4">
                <div 
                  className="card border-0 shadow-sm h-100" 
                  style={{ 
                    borderRadius: '16px',
                    transition: 'transform 0.2s ease, box-shadow 0.2s ease'
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.transform = 'translateY(-4px)';
                    e.currentTarget.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
                  }}
                >
                  {/* Certificate Image */}
                  {certificate.image && (
                    <div 
                      className="card-img-top d-flex justify-content-center align-items-center p-4" 
                      style={{ 
                        height: '200px',
                        backgroundColor: '#f8f9fa',
                        borderRadius: '16px 16px 0 0'
                      }}
                    >
                      <img 
                        src={certificate.image} 
                        alt={certificate.title}
                        className="img-fluid rounded shadow-sm"
                        style={{ maxHeight: '160px', maxWidth: '100%', objectFit: 'contain' }}
                      />
                    </div>
                  )}
                  
                  <div className="card-body d-flex flex-column p-4">
                    {/* Header Section */}
                    <div className="d-flex justify-content-between align-items-start mb-3">
                      <div className="flex-grow-1">
                        <h5 className="card-title mb-1 fw-bold" style={{ color: '#2c3e50', lineHeight: '1.3' }}>
                          {certificate.title}
                        </h5>
                        <h6 className="card-subtitle text-primary fw-medium mb-0">
                          <i className="fas fa-award me-2"></i>
                          {certificate.issuer}
                        </h6>
                      </div>
                      <div className="d-flex flex-column gap-1 align-items-end">
                        {certificate.featured && (
                          <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: '#fff3e0', color: '#ffa000' }}>
                            <i className="fas fa-star me-1"></i>Featured
                          </span>
                        )}
                        {!certificate.isActive && (
                          <span className="badge rounded-pill px-2 py-1" style={{ backgroundColor: '#f5f5f5', color: '#6c757d' }}>
                            <i className="fas fa-eye-slash me-1"></i>Hidden
                          </span>
                        )}
                      </div>
                    </div>
                    
                    {/* Certificate Info */}
                    <div className="mb-3">
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '24px', height: '24px', backgroundColor: '#e3f2fd' }}
                        >
                          <i className="fas fa-calendar text-primary" style={{ fontSize: '10px' }}></i>
                        </div>
                        <small className="text-muted fw-medium">
                          {certificate.year}
                        </small>
                      </div>
                      
                      {/* Category Badge */}
                      <div className="mb-3">
                        <span className={`badge rounded-pill px-3 py-2 ${
                          certificate.category === 'Web Development' ? 'text-primary' :
                          certificate.category === 'Programming' ? 'text-success' :
                          certificate.category === 'Frameworks' ? 'text-info' :
                          certificate.category === 'Cloud Computing' ? 'text-warning' :
                          'text-secondary'
                        }`} style={{
                          backgroundColor: certificate.category === 'Web Development' ? '#e3f2fd' :
                          certificate.category === 'Programming' ? '#e8f5e8' :
                          certificate.category === 'Frameworks' ? '#e1f5fe' :
                          certificate.category === 'Cloud Computing' ? '#fff3e0' :
                          '#f5f5f5'
                        }}>
                          <i className="fas fa-tag me-1"></i>{certificate.category}
                        </span>
                      </div>
                    </div>
                    
                    {/* Description */}
                    {certificate.description && (
                      <div className="mb-3 flex-grow-1">
                        <p className="text-muted small mb-0" style={{ lineHeight: '1.4' }}>
                          {certificate.description.length > 100 
                            ? `${certificate.description.substring(0, 100)}...`
                            : certificate.description
                          }
                        </p>
                      </div>
                    )}
                    
                    {/* Actions */}
                    <div className="d-flex gap-2 mt-auto">
                      <Link 
                        to={`/admin/certificates/edit/${certificate.slug}`}
                        className="btn btn-outline-primary btn-sm flex-fill"
                        style={{ borderRadius: '8px' }}
                        title="Edit certificate"
                      >
                        <i className="fas fa-edit me-1"></i>Edit
                      </Link>
                      
                      <button
                        onClick={() => handleToggleFeatured(certificate.slug)}
                        className={`btn btn-sm ${certificate.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                        style={{ borderRadius: '8px', width: '40px' }}
                        title={certificate.featured ? 'Remove from featured' : 'Add to featured'}
                      >
                        <i className="fas fa-star"></i>
                      </button>
                      
                      <button
                        onClick={() => handleToggleActive(certificate.slug)}
                        className={`btn btn-sm ${certificate.isActive ? 'btn-success' : 'btn-outline-success'}`}
                        style={{ borderRadius: '8px', width: '40px' }}
                        title={certificate.isActive ? 'Hide certificate' : 'Show certificate'}
                      >
                        <i className={`fas ${certificate.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                      </button>
                      
                      <button
                        onClick={() => handleDelete(certificate.slug, certificate.title)}
                        className="btn btn-outline-danger btn-sm"
                        style={{ borderRadius: '8px', width: '40px' }}
                        title="Delete certificate"
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Back to Dashboard */}
        <div className="mt-4">
          <Link to="/admin" className="btn btn-secondary btn-lg" style={{ borderRadius: '12px' }}>
            <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CertificateList;
