import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import TestimonialsDataApi from '../../api/TestimonialsDataApi';
import { ImageUploader } from './ImageUpload';
import { showSuccess, showError } from '../../utils/toastUtils';

const TestimonialForm = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(slug);
  
  const [formData, setFormData] = useState({
    customerName: '',
    customerFeedback: '',
    customerPosition: '',
    customerImage: '',
    stars: 5,
    featured: false,
    isActive: true
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (isEdit) {
      fetchTestimonial();
    }
  }, [slug, isEdit]);

  const fetchTestimonial = async () => {
    try {
      setLoading(true);
      const testimonial = await TestimonialsDataApi.getTestimonialDetails(slug);
      if (testimonial) {
        setFormData({
          customerName: testimonial.customerName || '',
          customerFeedback: testimonial.customerFeedback || '',
          customerPosition: testimonial.customerPosition || '',
          customerImage: testimonial.customerImage || '',
          stars: testimonial.stars || 5,
          featured: testimonial.featured || false,
          isActive: testimonial.isActive !== false
        });
      } else {
        setError('Testimonial not found');
      }
    } catch (err) {
      setError('Failed to load testimonial');
      console.error('Error fetching testimonial:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear messages when user starts typing
    if (error) setError('');
    if (success) setSuccess('');
  };

  const handleImageUpload = (imageUrl) => {
    setFormData(prev => ({
      ...prev,
      customerImage: imageUrl
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!formData.customerName.trim()) {
      setError('Customer name is required');
      return;
    }
    if (!formData.customerFeedback.trim()) {
      setError('Customer feedback is required');
      return;
    }
    if (!formData.customerPosition.trim()) {
      setError('Customer position is required');
      return;
    }

    try {
      setLoading(true);
      setError('');

      if (isEdit) {
        await TestimonialsDataApi.updateTestimonial(slug, formData);
        setSuccess('Testimonial updated successfully!');
      } else {
        await TestimonialsDataApi.createTestimonial(formData);
        setSuccess('Testimonial created successfully!');
      }

      // Redirect after a short delay
      setTimeout(() => {
        navigate('/admin/testimonials');
      }, 1500);

    } catch (err) {
      setError(err.response?.data?.message || `Failed to ${isEdit ? 'update' : 'create'} testimonial`);
      console.error('Error saving testimonial:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
        <div className="row justify-content-center">
          <div className="col-12 col-xl-10">
            <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
              <div className="card-body py-5 text-center">
                <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
                  <span className="visually-hidden">Loading...</span>
                </div>
                <div className="mt-3">
                  <h5 className="text-muted">Loading testimonial data...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-10">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: isEdit ? '#f57c00' : '#2e7d32',
                        color: 'white'
                      }}
                    >
                      <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'} fs-3`}></i>
                    </div>
                  </div>
                  <div>
                    <h2 className="mb-1 text-dark fw-bold">{isEdit ? 'Edit Testimonial' : 'Create New Testimonial'}</h2>
                    <p className="text-muted mb-0">{isEdit ? 'Update testimonial information and settings' : 'Add a new customer testimonial to your portfolio'}</p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => navigate('/admin/testimonials')}
                  className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                >
                  <i className="fas fa-arrow-left me-2"></i>Back to Testimonials
                </button>
              </div>
            </div>
          </div>

          {error && (
            <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className="alert alert-danger border-0 mb-0" style={{ borderRadius: '12px' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#ffebee',
                        color: '#d32f2f'
                      }}
                    >
                      <i className="fas fa-exclamation-triangle"></i>
                    </div>
                    <div className="fw-medium text-danger">{error}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {success && (
            <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className="alert alert-success border-0 mb-0" style={{ borderRadius: '12px' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#e8f5e8',
                        color: '#2e7d32'
                      }}
                    >
                      <i className="fas fa-check-circle"></i>
                    </div>
                    <div className="fw-medium text-success">{success}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="row g-4">
            {/* Main Form Card */}
            <div className="col-12 col-lg-8">
              <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
                <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-clipboard-list text-primary fs-5"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold text-dark">Testimonial Information</h5>
                      <small className="text-muted">Fill in the customer testimonial details</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">
                  <form onSubmit={handleSubmit}>
                    {/* Customer Information Section */}
                    <div className="mb-5">
                      <div className="d-flex align-items-center mb-3">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '32px', 
                            height: '32px', 
                            backgroundColor: '#e8f5e8',
                            color: '#2e7d32'
                          }}
                        >
                          <i className="fas fa-user fs-6"></i>
                        </div>
                        <h6 className="mb-0 fw-bold text-dark">Customer Information</h6>
                      </div>
                      
                      <div className="row g-3">
                        <div className="col-md-6">
                          <label htmlFor="customerName" className="form-label fw-medium text-dark mb-2">
                            Customer Name <span className="text-danger">*</span>
                          </label>
                          <input
                            type="text"
                            className="form-control border-2 py-2"
                            style={{ borderRadius: '8px', fontSize: '14px' }}
                            id="customerName"
                            name="customerName"
                            value={formData.customerName}
                            onChange={handleChange}
                            placeholder="Enter customer's full name"
                            required
                          />
                        </div>
                        
                        <div className="col-md-6">
                          <label htmlFor="customerPosition" className="form-label fw-medium text-dark mb-2">
                            Position/Title <span className="text-danger">*</span>
                          </label>
                          <input
                            type="text"
                            className="form-control border-2 py-2"
                            style={{ borderRadius: '8px', fontSize: '14px' }}
                            id="customerPosition"
                            name="customerPosition"
                            value={formData.customerPosition}
                            onChange={handleChange}
                            placeholder="e.g., CEO, Company Name"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    {/* Testimonial Content Section */}
                    <div className="mb-5">
                      <div className="d-flex align-items-center mb-3">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '32px', 
                            height: '32px', 
                            backgroundColor: '#fff3e0',
                            color: '#f57c00'
                          }}
                        >
                          <i className="fas fa-quote-left fs-6"></i>
                        </div>
                        <h6 className="mb-0 fw-bold text-dark">Testimonial Content</h6>
                      </div>
                      
                      <div className="mb-3">
                        <label htmlFor="customerFeedback" className="form-label fw-medium text-dark mb-2">
                          Testimonial Feedback <span className="text-danger">*</span>
                        </label>
                        <textarea
                          className="form-control border-2"
                          style={{ borderRadius: '8px', fontSize: '14px', minHeight: '120px' }}
                          id="customerFeedback"
                          name="customerFeedback"
                          rows="5"
                          value={formData.customerFeedback}
                          onChange={handleChange}
                          placeholder="Enter the customer's testimonial feedback..."
                          required
                        ></textarea>
                        <div className="form-text d-flex justify-content-between align-items-center mt-2">
                          <small className="text-muted">Provide authentic customer feedback</small>
                          <small className={`fw-medium ${formData.customerFeedback.length > 450 ? 'text-warning' : 'text-muted'}`}>
                            {formData.customerFeedback.length}/500 characters
                          </small>
                        </div>
                      </div>
                    </div>

                    {/* Rating & Settings Section */}
                    <div className="mb-5">
                      <div className="d-flex align-items-center mb-3">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '32px', 
                            height: '32px', 
                            backgroundColor: '#fce4ec',
                            color: '#e91e63'
                          }}
                        >
                          <i className="fas fa-star fs-6"></i>
                        </div>
                        <h6 className="mb-0 fw-bold text-dark">Rating & Settings</h6>
                      </div>
                      
                      <div className="row g-3">
                        <div className="col-md-4">
                          <label htmlFor="stars" className="form-label fw-medium text-dark mb-2">Rating</label>
                          <select
                            className="form-select border-2 py-2"
                            style={{ borderRadius: '8px', fontSize: '14px' }}
                            id="stars"
                            name="stars"
                            value={formData.stars}
                            onChange={handleChange}
                          >
                            <option value={1}>⭐ 1 Star</option>
                            <option value={2}>⭐⭐ 2 Stars</option>
                            <option value={3}>⭐⭐⭐ 3 Stars</option>
                            <option value={4}>⭐⭐⭐⭐ 4 Stars</option>
                            <option value={5}>⭐⭐⭐⭐⭐ 5 Stars</option>
                          </select>
                        </div>
                        
                        <div className="col-md-4">
                          <label className="form-label fw-medium text-dark mb-2">Display Options</label>
                          <div className="d-flex flex-column gap-2">
                            <div 
                              className="form-check p-3 rounded-3 border"
                              style={{ backgroundColor: formData.featured ? '#fff8e1' : '#f8f9fa' }}
                            >
                              <input
                                className="form-check-input"
                                type="checkbox"
                                id="featured"
                                name="featured"
                                checked={formData.featured}
                                onChange={handleChange}
                              />
                              <label className="form-check-label fw-medium ms-1" htmlFor="featured">
                                <i className="fas fa-star text-warning me-2"></i>Featured Testimonial
                              </label>
                            </div>
                          </div>
                        </div>
                        
                        <div className="col-md-4">
                          <label className="form-label fw-medium text-dark mb-2">Status</label>
                          <div 
                            className="form-check p-3 rounded-3 border"
                            style={{ backgroundColor: formData.isActive ? '#e8f5e8' : '#ffebee' }}
                          >
                            <input
                              className="form-check-input"
                              type="checkbox"
                              id="isActive"
                              name="isActive"
                              checked={formData.isActive}
                              onChange={handleChange}
                            />
                            <label className="form-check-label fw-medium ms-1" htmlFor="isActive">
                              <i className={`fas ${formData.isActive ? 'fa-check-circle text-success' : 'fa-times-circle text-danger'} me-2`}></i>
                              {formData.isActive ? 'Published' : 'Draft'}
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Image Upload Section */}
                    <div className="mb-5">
                      <div className="d-flex align-items-center mb-3">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '32px', 
                            height: '32px', 
                            backgroundColor: '#e3f2fd',
                            color: '#1976d2'
                          }}
                        >
                          <i className="fas fa-image fs-6"></i>
                        </div>
                        <h6 className="mb-0 fw-bold text-dark">Customer Image</h6>
                      </div>
                      
                      <div 
                        className="p-4 rounded-3 border-2 border-dashed"
                        style={{ backgroundColor: '#fafafa' }}
                      >
                        <ImageUploader 
                          onUpload={handleImageUpload}
                          currentImage={formData.customerImage}
                          category="testimonials"
                        />
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="d-flex gap-3 pt-3 border-top">
                      <button 
                        type="submit" 
                        className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                        style={{ fontSize: '14px' }}
                        disabled={loading}
                      >
                        {loading ? (
                          <>
                            <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                            {isEdit ? 'Updating...' : 'Creating...'}
                          </>
                        ) : (
                          <>
                            <i className="fas fa-save me-2"></i>
                            {isEdit ? 'Update Testimonial' : 'Create Testimonial'}
                          </>
                        )}
                      </button>
                      
                      <button 
                        type="button" 
                        className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                        style={{ fontSize: '14px' }}
                        onClick={() => navigate('/admin/testimonials')}
                      >
                        <i className="fas fa-times me-2"></i>Cancel
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            
            {/* Preview Card */}
            <div className="col-12 col-lg-4">
              <div className="card shadow-sm border-0 sticky-top" style={{ borderRadius: '16px', top: '2rem' }}>
                <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#e8f5e8'
                      }}
                    >
                      <i className="fas fa-eye text-success fs-6"></i>
                    </div>
                    <div>
                      <h6 className="mb-0 fw-bold text-dark">Live Preview</h6>
                      <small className="text-muted">See how it will look</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">
                  <div className="testimonial-preview">
                    {/* Customer Image and Rating */}
                    <div className="text-center mb-4">
                      {formData.customerImage ? (
                        <div className="position-relative d-inline-block">
                          <img 
                            src={formData.customerImage} 
                            alt="Customer"
                            className="rounded-circle border border-3 border-light shadow-sm"
                            style={{ width: '80px', height: '80px', objectFit: 'cover' }}
                          />
                          {formData.featured && (
                            <div 
                              className="position-absolute top-0 end-0 rounded-circle bg-warning text-white d-flex align-items-center justify-content-center"
                              style={{ width: '24px', height: '24px', fontSize: '10px' }}
                            >
                              <i className="fas fa-star"></i>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="position-relative d-inline-block">
                          <div 
                            className="rounded-circle bg-light border border-3 border-white shadow-sm text-muted d-flex align-items-center justify-content-center mx-auto"
                            style={{ width: '80px', height: '80px' }}
                          >
                            <i className="fas fa-user fs-4"></i>
                          </div>
                          {formData.featured && (
                            <div 
                              className="position-absolute top-0 end-0 rounded-circle bg-warning text-white d-flex align-items-center justify-content-center"
                              style={{ width: '24px', height: '24px', fontSize: '10px' }}
                            >
                              <i className="fas fa-star"></i>
                            </div>
                          )}
                        </div>
                      )}
                      
                      {/* Star Rating */}
                      <div className="d-flex justify-content-center mt-3 mb-2">
                        {[...Array(5)].map((_, index) => (
                          <i 
                            key={index} 
                            className={`${index < formData.stars ? 'fas fa-star text-warning' : 'far fa-star text-muted'} me-1`}
                            style={{ fontSize: '16px' }}
                          ></i>
                        ))}
                      </div>
                      
                      <div className="small text-muted">
                        {formData.stars} out of 5 stars
                      </div>
                    </div>

                    {/* Testimonial Content */}
                    <div 
                      className="p-4 rounded-3 position-relative"
                      style={{ backgroundColor: '#f8f9fa' }}
                    >
                      <div 
                        className="position-absolute top-0 start-50 translate-middle rounded-circle bg-primary text-white d-flex align-items-center justify-content-center"
                        style={{ width: '24px', height: '24px', fontSize: '12px' }}
                      >
                        <i className="fas fa-quote-left"></i>
                      </div>
                      
                      <blockquote className="text-center mt-3 mb-0">
                        <p className="text-dark fst-italic mb-3" style={{ fontSize: '14px', lineHeight: '1.6' }}>
                          {formData.customerFeedback || 'Customer feedback will appear here...'}
                        </p>
                        <footer className="blockquote-footer border-0">
                          <div className="fw-bold text-dark" style={{ fontSize: '15px' }}>
                            {formData.customerName || 'Customer Name'}
                          </div>
                          <div className="text-muted mt-1" style={{ fontSize: '13px' }}>
                            {formData.customerPosition || 'Position, Company'}
                          </div>
                        </footer>
                      </blockquote>
                    </div>

                    {/* Status Badges */}
                    <div className="d-flex justify-content-center gap-2 mt-3">
                      {formData.featured && (
                        <span 
                          className="badge rounded-pill px-3 py-2 text-warning border border-warning"
                          style={{ backgroundColor: '#fff8e1', fontSize: '11px' }}
                        >
                          <i className="fas fa-star me-1"></i>Featured
                        </span>
                      )}
                      <span 
                        className={`badge rounded-pill px-3 py-2 ${formData.isActive ? 'text-success border-success' : 'text-danger border-danger'}`}
                        style={{ 
                          backgroundColor: formData.isActive ? '#e8f5e8' : '#ffebee',
                          fontSize: '11px'
                        }}
                      >
                        <i className={`fas ${formData.isActive ? 'fa-check-circle' : 'fa-times-circle'} me-1`}></i>
                        {formData.isActive ? 'Published' : 'Draft'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestimonialForm;
