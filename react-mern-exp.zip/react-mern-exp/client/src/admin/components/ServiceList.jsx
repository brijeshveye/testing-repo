import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import ServiceDataApi from '../../api/ServiceDataApi';
import ServiceCard from '../../components/service/ServiceCard';
import { showSuccess, showError } from '../../utils/toastUtils';

const ServiceList = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    category: '',
    featured: 'all',
    status: 'all',
    search: ''
  });

  useEffect(() => {
    fetchServices();
    fetchStats();
  }, [filters]);

  const fetchServices = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.category) params.category = filters.category;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.search) params.search = filters.search;

      const data = await ServiceDataApi.getServiceData(params);
      setServices(data);
    } catch (err) {
      setError('Failed to fetch services');
      console.error('Error fetching services:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await ServiceDataApi.getServiceStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleEdit = (service) => {
    window.location.href = `/admin/services/edit/${service.slug}`;
  };

  const handleDelete = async (service) => {
    if (window.confirm(`Are you sure you want to delete "${service.title}"?`)) {
      try {
        await ServiceDataApi.deleteService(service.slug);
        showSuccess('Service deleted successfully!');
        fetchServices();
        fetchStats();
      } catch (err) {
        showError('Failed to delete service');
        console.error('Error deleting service:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await ServiceDataApi.toggleFeatured(slug);
      showSuccess('Featured status updated successfully!');
      fetchServices();
      fetchStats();
    } catch (err) {
      showError('Failed to toggle featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await ServiceDataApi.toggleActive(slug);
      showSuccess('Active status updated successfully!');
      fetchServices();
      fetchStats();
    } catch (err) {
      showError('Failed to toggle active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  if (loading && services.length === 0) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading services...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh' }}>
      {/* Header Card */}
      <div className="card shadow-lg border-0 rounded-4 mb-4" 
           style={{ 
             background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)', 
             color: 'white' 
           }}>
        <div className="card-body p-4">
          <div className="d-flex justify-content-between align-items-center">
            <div>
              <div className="d-flex align-items-center mb-2">
                <i className="fas fa-cogs fs-2 me-3" style={{ color: 'rgba(255, 255, 255, 0.9)' }}></i>
                <div>
                  <h1 className="mb-1 fw-bold">Service Management</h1>
                  <p className="mb-0 opacity-75">Manage your service offerings and portfolio</p>
                </div>
              </div>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb mb-0" style={{ backgroundColor: 'transparent' }}>
                  <li className="breadcrumb-item">
                    <Link to="/admin" className="text-white text-decoration-none opacity-75">
                      <i className="fas fa-home me-1"></i>Admin
                    </Link>
                  </li>
                  <li className="breadcrumb-item active text-white" aria-current="page">Services</li>
                </ol>
              </nav>
            </div>
            <Link to="/admin/services/create" 
                  className="btn btn-light btn-lg rounded-3 shadow-sm px-4">
              <i className="fas fa-plus me-2"></i>Add New Service
            </Link>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      {stats && (
        <div className="row g-4 mb-4">
          <div className="col-lg-4 col-md-6">
            <div className="card border-0 rounded-4 shadow-sm h-100" 
                 style={{ background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)', color: 'white' }}>
              <div className="card-body p-4">
                <div className="d-flex align-items-center justify-content-between">
                  <div>
                    <div className="d-flex align-items-center mb-2">
                      <i className="fas fa-cogs me-2 opacity-75"></i>
                      <h6 className="card-title mb-0 opacity-90">Total Services</h6>
                    </div>
                    <h2 className="mb-0 fw-bold">{stats.totalServices || 0}</h2>
                    <small className="opacity-75">All service offerings</small>
                  </div>
                  <div className="text-end">
                    <i className="fas fa-chart-bar fa-2x opacity-25"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className="card border-0 rounded-4 shadow-sm h-100" 
                 style={{ background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)', color: 'white' }}>
              <div className="card-body p-4">
                <div className="d-flex align-items-center justify-content-between">
                  <div>
                    <div className="d-flex align-items-center mb-2">
                      <i className="fas fa-eye me-2 opacity-75"></i>
                      <h6 className="card-title mb-0 opacity-90">Active Services</h6>
                    </div>
                    <h2 className="mb-0 fw-bold">{stats.activeServices || 0}</h2>
                    <small className="opacity-75">Publicly visible</small>
                  </div>
                  <div className="text-end">
                    <i className="fas fa-check-circle fa-2x opacity-25"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-4 col-md-6">
            <div className="card border-0 rounded-4 shadow-sm h-100" 
                 style={{ background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)', color: 'white' }}>
              <div className="card-body p-4">
                <div className="d-flex align-items-center justify-content-between">
                  <div>
                    <div className="d-flex align-items-center mb-2">
                      <i className="fas fa-star me-2 opacity-75"></i>
                      <h6 className="card-title mb-0 opacity-90">Featured</h6>
                    </div>
                    <h2 className="mb-0 fw-bold">{stats.featuredServices || 0}</h2>
                    <small className="opacity-75">Highlighted services</small>
                  </div>
                  <div className="text-end">
                    <i className="fas fa-crown fa-2x opacity-25"></i>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Filters Card */}
      <div className="card border-0 rounded-4 shadow-sm mb-4" 
           style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)' }}>
        <div className="card-body p-4">
          <div className="d-flex align-items-center mb-3">
            <i className="fas fa-filter text-primary me-2" style={{ fontSize: '1.25rem' }}></i>
            <h5 className="card-title mb-0 text-dark">Filter & Search</h5>
          </div>
          <div className="row g-3">
            <div className="col-lg-4 col-md-6">
              <label className="form-label fw-semibold text-dark">
                <i className="fas fa-search me-1 text-muted"></i>Search Services
              </label>
              <input
                type="text"
                className="form-control form-control-lg rounded-3 border-2"
                placeholder="Search by title, description..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
              />
            </div>
            <div className="col-lg-3 col-md-6">
              <label className="form-label fw-semibold text-dark">
                <i className="fas fa-tag me-1 text-muted"></i>Category
              </label>
              <input
                type="text"
                className="form-control form-control-lg rounded-3 border-2"
                placeholder="Enter category..."
                value={filters.category}
                onChange={(e) => handleFilterChange('category', e.target.value)}
                style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
              />
            </div>
            <div className="col-lg-2 col-md-6">
              <label className="form-label fw-semibold text-dark">
                <i className="fas fa-star me-1 text-warning"></i>Featured
              </label>
              <select
                className="form-select form-select-lg rounded-3 border-2"
                value={filters.featured}
                onChange={(e) => handleFilterChange('featured', e.target.value)}
                style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
              >
                <option value="all">All Services</option>
                <option value="true">Featured Only</option>
                <option value="false">Not Featured</option>
              </select>
            </div>
            <div className="col-lg-3 col-md-6">
              <label className="form-label fw-semibold text-dark">
                <i className="fas fa-toggle-on me-1 text-success"></i>Status
              </label>
              <select
                className="form-select form-select-lg rounded-3 border-2"
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                style={{ borderColor: '#e5e7eb', fontSize: '0.95rem' }}
              >
                <option value="all">All Status</option>
                <option value="true">Active</option>
                <option value="false">Hidden</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {error && (
        <div className="card border-0 rounded-4 shadow-sm mb-4" 
             style={{ backgroundColor: '#fef2f2', borderLeft: '4px solid #ef4444' }}>
          <div className="card-body p-4">
            <div className="d-flex align-items-center">
              <div className="flex-shrink-0 me-3">
                <div className="rounded-circle p-2" style={{ backgroundColor: '#fee2e2' }}>
                  <i className="fas fa-exclamation-triangle text-danger"></i>
                </div>
              </div>
              <div>
                <h6 className="mb-1 text-danger fw-semibold">Error Loading Services</h6>
                <p className="mb-0 text-dark">{error}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Services Grid */}
      {services.length === 0 ? (
        <div className="card border-0 rounded-4 shadow-sm" 
             style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)', backdropFilter: 'blur(10px)' }}>
          <div className="card-body text-center py-5">
            <div className="mb-4">
              <div className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" 
                   style={{ width: '80px', height: '80px', backgroundColor: '#f3f4f6' }}>
                <i className="fas fa-cogs fa-2x text-muted"></i>
              </div>
            </div>
            <h3 className="text-dark mb-2">No Services Found</h3>
            <p className="text-muted mb-4">
              {filters.search || filters.category || filters.featured !== 'all' || filters.status !== 'all'
                ? 'No services match your current filters. Try adjusting your search criteria.'
                : 'Start building your service portfolio by adding your first service offering.'
              }
            </p>
            <div className="d-flex justify-content-center gap-2">
              <Link to="/admin/services/create" 
                    className="btn btn-primary btn-lg rounded-3 px-4">
                <i className="fas fa-plus me-2"></i>Add Your First Service
              </Link>
              {(filters.search || filters.category || filters.featured !== 'all' || filters.status !== 'all') && (
                <button 
                  className="btn btn-outline-secondary btn-lg rounded-3 px-4"
                  onClick={() => setFilters({ category: '', featured: 'all', status: 'all', search: '' })}
                >
                  <i className="fas fa-times me-2"></i>Clear Filters
                </button>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="row g-4">
          {services.map((service) => (
            <ServiceCard
              key={service._id}
              service={service}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onToggleFeatured={handleToggleFeatured}
              onToggleActive={handleToggleActive}
            />
          ))}
        </div>
      )}

      {/* Loading Overlay */}
      {loading && services.length > 0 && (
        <div className="position-fixed top-0 start-0 w-100 h-100 d-flex align-items-center justify-content-center" 
             style={{ backgroundColor: 'rgba(0, 0, 0, 0.3)', zIndex: 1050, backdropFilter: 'blur(4px)' }}>
          <div className="card border-0 rounded-4 shadow-lg" 
               style={{ backgroundColor: 'rgba(255, 255, 255, 0.95)' }}>
            <div className="card-body text-center py-4 px-5">
              <div className="spinner-border text-primary mb-3" 
                   style={{ width: '3rem', height: '3rem' }} role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
              <h6 className="text-dark mb-0">Updating Services...</h6>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ServiceList;
