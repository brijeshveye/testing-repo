import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import WidgetManager from './widgets/WidgetManager';
import { ImageUploader, uploadImage, IMAGE_CATEGORIES } from './ImageUpload';
import { showSuccess, showError } from '../../utils/toastUtils';

const ProjectForm = () => {
  const [form, setForm] = useState({
    title: '',
    description: '',
    slug: '',
    date: '',
    location: '',
    client: '',
    type: '',
    category: '',
    bannerImage: '',
    image: '',
    techStack: [],
    domains: [],
    widgets: [], // Dynamic content widgets
    details: {
      section1: { para1: '', para2: '' },
      section2: { title: '', para: '', list: [] },
      section3: { title: '', para: '' },
      section4: { image1: '', image2: '' }
    }
  });
  const [activeTab, setActiveTab] = useState('basic');

  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = !!slug;

  useEffect(() => {
    if (isEdit) {
      axios.get(`/api/projects/${slug}`).then(res => setForm(res.data));
    }
  }, [slug]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  const handleWidgetsChange = (widgets) => {
    setForm(prev => ({ ...prev, widgets }));
  };

  const handleImageUpload = async (file, category) => {
    try {
      return await uploadImage(file, category);
    } catch (error) {
      showError('Image upload failed: ' + error.message);
      throw error;
    }
  };

  const handleBannerImageUpload = (url) => {
    setForm(prev => ({ ...prev, bannerImage: url }));
  };

  const handleMainImageUpload = (url) => {
    setForm(prev => ({ ...prev, image: url }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isEdit) {
      await axios.put(`/api/projects/${slug}`, form);
    } else {
      await axios.post('/api/projects', form);
    }
    navigate('/admin/projects');
  };

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-10">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: isEdit ? '#f57c00' : '#2e7d32',
                        color: 'white'
                      }}
                    >
                      <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'} fs-3`}></i>
                    </div>
                  </div>
                  <div>
                    <h2 className="mb-1 text-dark fw-bold">{isEdit ? 'Edit Project' : 'Create New Project'}</h2>
                    <p className="text-muted mb-0">{isEdit ? 'Update your project information and content' : 'Add a new project to your portfolio'}</p>
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => navigate('/admin/projects')}
                  className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
                >
                  <i className="fas fa-arrow-left me-2"></i>Back to Projects
                </button>
              </div>
            </div>
          </div>

          {/* Tab Navigation Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body p-4">
              <div className="d-flex align-items-center mb-3">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#e3f2fd'
                  }}
                >
                  <i className="fas fa-tabs text-primary fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Project Configuration</h5>
                  <small className="text-muted">Navigate through different sections</small>
                </div>
              </div>
              
              <ul className="nav nav-pills nav-fill" style={{ backgroundColor: '#f8f9fa', borderRadius: '12px', padding: '0.5rem' }}>
                <li className="nav-item">
                  <button 
                    type="button"
                    className={`nav-link fw-medium ${activeTab === 'basic' ? 'active' : ''}`}
                    onClick={() => setActiveTab('basic')}
                    style={{ 
                      borderRadius: '8px',
                      border: 'none',
                      backgroundColor: activeTab === 'basic' ? '#007bff' : 'transparent',
                      color: activeTab === 'basic' ? 'white' : '#6c757d'
                    }}
                  >
                    <i className="fas fa-info-circle me-2"></i>Basic Info
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    type="button"
                    className={`nav-link fw-medium ${activeTab === 'images' ? 'active' : ''}`}
                    onClick={() => setActiveTab('images')}
                    style={{ 
                      borderRadius: '8px',
                      border: 'none',
                      backgroundColor: activeTab === 'images' ? '#007bff' : 'transparent',
                      color: activeTab === 'images' ? 'white' : '#6c757d'
                    }}
                  >
                    <i className="fas fa-images me-2"></i>Images
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    type="button"
                    className={`nav-link fw-medium ${activeTab === 'content' ? 'active' : ''}`}
                    onClick={() => setActiveTab('content')}
                    style={{ 
                      borderRadius: '8px',
                      border: 'none',
                      backgroundColor: activeTab === 'content' ? '#007bff' : 'transparent',
                      color: activeTab === 'content' ? 'white' : '#6c757d'
                    }}
                  >
                    <i className="fas fa-puzzle-piece me-2"></i>Dynamic Content
                  </button>
                </li>
              </ul>
            </div>
          </div>

          {/* Main Content Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#e3f2fd'
                  }}
                >
                  <i className="fas fa-clipboard-list text-primary fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">
                    {activeTab === 'basic' ? 'Basic Information' : 
                     activeTab === 'images' ? 'Project Images' : 
                     'Dynamic Content Management'}
                  </h5>
                  <small className="text-muted">
                    {activeTab === 'basic' ? 'Fill in the basic details for your project' : 
                     activeTab === 'images' ? 'Upload and manage project images' : 
                     'Add dynamic content widgets to your project'}
                  </small>
                </div>
              </div>
            </div>
            <div className="card-body p-4">
              <form onSubmit={handleSubmit}>
                {/* Basic Info Tab */}
                {activeTab === 'basic' && (
                  <div>
                    {/* Project Identity Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-id-card text-primary me-2"></i>
                        Project Identity
                      </h6>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label className="form-label text-dark fw-medium">Title <span className="text-danger">*</span></label>
                            <input 
                              className="form-control form-control-lg border-2" 
                              name="title" 
                              value={form.title} 
                              onChange={handleChange} 
                              style={{ borderRadius: '12px' }}
                              placeholder="Enter project title"
                              required 
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label className="form-label text-dark fw-medium">Slug <span className="text-danger">*</span></label>
                            <input 
                              className="form-control form-control-lg border-2" 
                              name="slug" 
                              value={form.slug} 
                              onChange={handleChange} 
                              style={{ borderRadius: '12px' }}
                              placeholder="url-friendly-name"
                              required={!isEdit} 
                              disabled={isEdit}
                            />
                            {isEdit && <div className="form-text">Slug cannot be changed for existing projects</div>}
                          </div>
                        </div>
                      </div>
                      
                      <div className="mb-3">
                        <label className="form-label text-dark fw-medium">Description</label>
                        <textarea 
                          className="form-control form-control-lg border-2" 
                          name="description" 
                          value={form.description} 
                          onChange={handleChange}
                          style={{ borderRadius: '12px' }}
                          rows="4"
                          placeholder="Describe your project..."
                        />
                      </div>
                    </div>

                    {/* Project Details Section */}
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-cogs text-primary me-2"></i>
                        Project Details
                      </h6>
                      <div className="row">
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label className="form-label text-dark fw-medium">Date</label>
                            <input 
                              type="date" 
                              className="form-control form-control-lg border-2" 
                              name="date" 
                              value={form.date} 
                              onChange={handleChange}
                              style={{ borderRadius: '12px' }}
                            />
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label className="form-label text-dark fw-medium">Client</label>
                            <input 
                              className="form-control form-control-lg border-2" 
                              name="client" 
                              value={form.client} 
                              onChange={handleChange}
                              style={{ borderRadius: '12px' }}
                              placeholder="Client name"
                            />
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label className="form-label text-dark fw-medium">Location</label>
                            <input 
                              className="form-control form-control-lg border-2" 
                              name="location" 
                              value={form.location} 
                              onChange={handleChange}
                              style={{ borderRadius: '12px' }}
                              placeholder="Project location"
                            />
                          </div>
                        </div>
                      </div>
                      
                      <div className="row">
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label className="form-label text-dark fw-medium">Category</label>
                            <input 
                              className="form-control form-control-lg border-2" 
                              name="category" 
                              value={form.category} 
                              onChange={handleChange}
                              style={{ borderRadius: '12px' }}
                              placeholder="e.g., Web Development, Mobile App"
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label className="form-label text-dark fw-medium">Type</label>
                            <input 
                              className="form-control form-control-lg border-2" 
                              name="type" 
                              value={form.type} 
                              onChange={handleChange}
                              style={{ borderRadius: '12px' }}
                              placeholder="e.g., Commercial, Personal, Open Source"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Images Tab */}
                {activeTab === 'images' && (
                  <div>
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-image text-primary me-2"></i>
                        Project Images
                      </h6>
                      <div className="row">
                        <div className="col-md-6">
                          <div className="card mb-4" style={{ backgroundColor: '#f8f9fa', border: 'none', borderRadius: '12px' }}>
                            <div className="card-body p-4">
                              <h6 className="mb-3 fw-semibold">
                                <i className="fas fa-panorama me-2 text-info"></i>
                                Banner Image
                              </h6>
                              {form.bannerImage && (
                                <div className="mb-3">
                                  <div className="position-relative d-inline-block">
                                    <img 
                                      src={form.bannerImage} 
                                      alt="Banner preview" 
                                      className="img-thumbnail shadow-sm"
                                      style={{ maxHeight: '200px', maxWidth: '100%', borderRadius: '12px' }}
                                    />
                                    <button
                                      type="button"
                                      className="btn btn-danger btn-sm position-absolute top-0 end-0 m-2 rounded-circle"
                                      onClick={() => setForm(prev => ({ ...prev, bannerImage: '' }))}
                                      title="Remove banner image"
                                      style={{ width: '32px', height: '32px' }}
                                    >
                                      <i className="fas fa-times"></i>
                                    </button>
                                  </div>
                                  <div className="mt-2">
                                    <small className="text-muted">Current banner image</small>
                                  </div>
                                </div>
                              )}
                              <ImageUploader
                                onUpload={handleBannerImageUpload}
                                category={IMAGE_CATEGORIES.BANNER}
                              />
                              {!form.bannerImage && (
                                <div className="form-text mt-2">
                                  <i className="fas fa-info-circle me-1"></i>
                                  Upload a banner image for your project. Recommended size: 1200x600px.
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="card mb-4" style={{ backgroundColor: '#f8f9fa', border: 'none', borderRadius: '12px' }}>
                            <div className="card-body p-4">
                              <h6 className="mb-3 fw-semibold">
                                <i className="fas fa-image me-2 text-success"></i>
                                Main Project Image
                              </h6>
                              {form.image && (
                                <div className="mb-3">
                                  <div className="position-relative d-inline-block">
                                    <img 
                                      src={form.image} 
                                      alt="Main image preview" 
                                      className="img-thumbnail shadow-sm"
                                      style={{ maxHeight: '200px', maxWidth: '100%', borderRadius: '12px' }}
                                    />
                                    <button
                                      type="button"
                                      className="btn btn-danger btn-sm position-absolute top-0 end-0 m-2 rounded-circle"
                                      onClick={() => setForm(prev => ({ ...prev, image: '' }))}
                                      title="Remove main image"
                                      style={{ width: '32px', height: '32px' }}
                                    >
                                      <i className="fas fa-times"></i>
                                    </button>
                                  </div>
                                  <div className="mt-2">
                                    <small className="text-muted">Current main image</small>
                                  </div>
                                </div>
                              )}
                              <ImageUploader
                                onUpload={handleMainImageUpload}
                                category={IMAGE_CATEGORIES.PROJECT}
                              />
                              {!form.image && (
                                <div className="form-text mt-2">
                                  <i className="fas fa-info-circle me-1"></i>
                                  Upload the main project image. Recommended size: 800x600px.
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Dynamic Content Tab */}
                {activeTab === 'content' && (
                  <div>
                    <div className="mb-4">
                      <h6 className="fw-bold text-dark mb-3 d-flex align-items-center">
                        <i className="fas fa-puzzle-piece text-primary me-2"></i>
                        Dynamic Content Widgets
                      </h6>
                      <div className="card" style={{ backgroundColor: '#f8f9fa', border: 'none', borderRadius: '12px' }}>
                        <div className="card-body p-4">
                          <WidgetManager
                            widgets={form.widgets}
                            onChange={handleWidgetsChange}
                            onImageUpload={handleImageUpload}
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="d-flex gap-3 justify-content-end mt-4">
                  <button 
                    type="button" 
                    className="btn btn-outline-secondary btn-lg rounded-pill px-4"
                    onClick={() => navigate('/admin/projects')}
                  >
                    <i className="fas fa-times me-2"></i>Cancel
                  </button>
                  <button 
                    type="submit" 
                    className="btn btn-primary btn-lg rounded-pill px-4"
                  >
                    <i className="fas fa-save me-2"></i>
                    {isEdit ? 'Update Project' : 'Create Project'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectForm;
