import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import EducationDataApi from '../../api/EducationDataApi';

const EducationForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    institution: '',
    degree: '',
    fieldOfStudy: '',
    startDate: '',
    endDate: '',
    current: false,
    grade: '',
    description: '',
    activities: [],
    achievements: [],
    skills: [],
    location: '',
    image: '',
    certificateUrl: '',
    transcriptUrl: '',
    featured: false,
    isActive: true,
    order: 0
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Predefined options
  const degreeTypes = [
    'Bachelor of Science', 'Bachelor of Arts', 'Bachelor of Engineering', 'Bachelor of Technology',
    'Master of Science', 'Master of Arts', 'Master of Engineering', 'Master of Technology', 'MBA',
    'PhD', 'Doctorate', 'Diploma', 'Certificate', 'Associate Degree', 'Other'
  ];

  const fieldOptions = [
    'Computer Science', 'Information Technology', 'Software Engineering', 'Computer Engineering',
    'Data Science', 'Artificial Intelligence', 'Cybersecurity', 'Web Development',
    'Mobile Development', 'UI/UX Design', 'Digital Marketing', 'Business Administration',
    'Project Management', 'Other'
  ];

  useEffect(() => {
    if (isEdit) {
      fetchEducationData();
    }
  }, [isEdit, slug]);

  const fetchEducationData = async () => {
    try {
      setLoading(true);
      const data = await EducationDataApi.getEducationDetails(slug);
      if (data) {
        setFormData({
          title: data.title || '',
          institution: data.institution || '',
          degree: data.degree || '',
          fieldOfStudy: data.fieldOfStudy || '',
          startDate: data.startDate ? new Date(data.startDate).toISOString().split('T')[0] : '',
          endDate: data.endDate ? new Date(data.endDate).toISOString().split('T')[0] : '',
          current: data.current || false,
          grade: data.grade || '',
          description: data.description || '',
          activities: data.activities || [],
          achievements: data.achievements || [],
          skills: data.skills || [],
          location: data.location || '',
          image: data.image || '',
          certificateUrl: data.certificateUrl || '',
          transcriptUrl: data.transcriptUrl || '',
          featured: data.featured || false,
          isActive: data.isActive !== undefined ? data.isActive : true,
          order: data.order || 0
        });
      }
    } catch (err) {
      setError('Failed to fetch education data');
      console.error('Error fetching education:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleArrayChange = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => 
        i === index ? value : item
      )
    }));
  };

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], '']
    }));
  };

  const removeArrayItem = (index, field) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Clean up empty array items
      const cleanedData = {
        ...formData,
        activities: formData.activities.filter(activity => activity.trim()),
        achievements: formData.achievements.filter(achievement => achievement.trim()),
        skills: formData.skills.filter(skill => skill.trim()),
        order: parseInt(formData.order)
      };

      // Validate dates
      if (cleanedData.startDate && cleanedData.endDate && !cleanedData.current) {
        const start = new Date(cleanedData.startDate);
        const end = new Date(cleanedData.endDate);
        if (start > end) {
          setError('End date cannot be before start date');
          setLoading(false);
          return;
        }
      }

      if (isEdit) {
        await EducationDataApi.updateEducation(slug, cleanedData);
        setSuccess('Education record updated successfully!');
      } else {
        await EducationDataApi.createEducation(cleanedData);
        setSuccess('Education record created successfully!');
      }

      setTimeout(() => {
        navigate('/admin/education');
      }, 1500);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save education record');
      console.error('Error saving education:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading education record...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-center">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-3"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#1976d2',
                    color: 'white'
                  }}
                >
                  <i className={`fas ${isEdit ? 'fa-edit' : 'fa-plus'}`} style={{ fontSize: '20px' }}></i>
                </div>
                <div>
                  <h2 className="mb-1" style={{ color: '#2c3e50', fontWeight: '600' }}>
                    {isEdit ? 'Edit Education Record' : 'Create New Education Record'}
                  </h2>
                  <p className="text-muted mb-0">
                    {isEdit ? 'Update your education details' : 'Add a new academic achievement'}
                  </p>
                </div>
              </div>
              <Link 
                to="/admin/education" 
                className="btn btn-outline-secondary d-flex align-items-center"
                style={{ borderRadius: '12px', padding: '0.6rem 1.2rem' }}
              >
                <i className="fas fa-arrow-left me-2"></i>
                Back to List
              </Link>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #dc3545' }}>
            <div className="card-body p-4" style={{ backgroundColor: '#fff5f5' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ width: '40px', height: '40px', backgroundColor: '#dc3545', color: 'white' }}
                >
                  <i className="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                  <h6 className="mb-1" style={{ color: '#dc3545', fontWeight: '600' }}>Error</h6>
                  <p className="mb-0 text-muted">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Success Message */}
        {success && (
          <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #2e7d32' }}>
            <div className="card-body p-4" style={{ backgroundColor: '#f3f8f3' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ width: '40px', height: '40px', backgroundColor: '#2e7d32', color: 'white' }}
                >
                  <i className="fas fa-check-circle"></i>
                </div>
                <div>
                  <h6 className="mb-1" style={{ color: '#2e7d32', fontWeight: '600' }}>Success</h6>
                  <p className="mb-0 text-muted">{success}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="row">
          <div className="col-lg-8">
            <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <form onSubmit={handleSubmit}>
                  {/* Basic Information Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #1976d2' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#e3f2fd'
                          }}
                        >
                          <i className="fas fa-info-circle" style={{ color: '#1976d2' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Basic Information</h5>
                          <small className="text-muted">Core details about your education</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      <div className="row g-3">
                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-heading me-2 text-muted"></i>Title/Program Name *
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            name="title"
                            value={formData.title}
                            onChange={handleChange}
                            required
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="e.g., Computer Science, Web Development"
                          />
                        </div>
                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-university me-2 text-muted"></i>Institution *
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            name="institution"
                            value={formData.institution}
                            onChange={handleChange}
                            required
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="e.g., University of Technology"
                          />
                        </div>

                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-graduation-cap me-2 text-muted"></i>Degree Type
                          </label>
                          <select
                            className="form-select rounded-pill py-2"
                            name="degree"
                            value={formData.degree}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            <option value="">Select Degree Type</option>
                            {degreeTypes.map(degree => (
                              <option key={degree} value={degree}>
                                {degree}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-book me-2 text-muted"></i>Field of Study
                          </label>
                          <select
                            className="form-select rounded-pill py-2"
                            name="fieldOfStudy"
                            value={formData.fieldOfStudy}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                          >
                            <option value="">Select Field of Study</option>
                            {fieldOptions.map(field => (
                              <option key={field} value={field}>
                                {field}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="col-md-4">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-calendar-plus me-2 text-muted"></i>Start Date *
                          </label>
                          <input
                            type="date"
                            className="form-control rounded-pill py-2"
                            name="startDate"
                            value={formData.startDate}
                            onChange={handleChange}
                            required
                            style={{ border: '2px solid #e0e0e0' }}
                          />
                        </div>
                        <div className="col-md-4">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-calendar-check me-2 text-muted"></i>End Date
                          </label>
                          <input
                            type="date"
                            className="form-control rounded-pill py-2"
                            name="endDate"
                            value={formData.endDate}
                            onChange={handleChange}
                            disabled={formData.current}
                            style={{ border: '2px solid #e0e0e0' }}
                          />
                        </div>
                        <div className="col-md-4">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-map-marker-alt me-2 text-muted"></i>Location
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            name="location"
                            value={formData.location}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="City, Country"
                          />
                        </div>

                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-medal me-2 text-muted"></i>Grade/GPA
                          </label>
                          <input
                            type="text"
                            className="form-control rounded-pill py-2"
                            name="grade"
                            value={formData.grade}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="e.g., 3.8/4.0, First Class, A+"
                          />
                        </div>
                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-sort-numeric-up me-2 text-muted"></i>Display Order
                          </label>
                          <input
                            type="number"
                            className="form-control rounded-pill py-2"
                            name="order"
                            value={formData.order}
                            onChange={handleChange}
                            min="0"
                            style={{ border: '2px solid #e0e0e0' }}
                          />
                        </div>

                        <div className="col-12">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-align-left me-2 text-muted"></i>Description
                          </label>
                          <textarea
                            className="form-control"
                            name="description"
                            rows="4"
                            value={formData.description}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0', borderRadius: '12px' }}
                            placeholder="Brief description of the program, coursework, or achievements..."
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Activities Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #2e7d32' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#e8f5e8'
                          }}
                        >
                          <i className="fas fa-users text-success"></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Activities & Societies</h5>
                          <small className="text-muted">Extracurricular activities and organizations</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      {formData.activities.map((activity, index) => (
                        <div key={index} className="input-group mb-3">
                          <span className="input-group-text" style={{ borderRadius: '12px 0 0 12px', border: '2px solid #e0e0e0', borderRight: 'none' }}>
                            <i className="fas fa-user-friends text-muted"></i>
                          </span>
                          <input
                            type="text"
                            className="form-control py-2"
                            placeholder="Activity or society"
                            value={activity}
                            onChange={(e) => handleArrayChange(index, 'activities', e.target.value)}
                            style={{ border: '2px solid #e0e0e0', borderLeft: 'none', borderRight: 'none' }}
                          />
                          <button
                            type="button"
                            className="btn btn-outline-danger"
                            onClick={() => removeArrayItem(index, 'activities')}
                            style={{ borderRadius: '0 12px 12px 0', border: '2px solid #e0e0e0', borderLeft: 'none' }}
                          >
                            <i className="fas fa-times"></i>
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="btn btn-outline-success rounded-pill px-3"
                        onClick={() => addArrayItem('activities')}
                      >
                        <i className="fas fa-plus me-2"></i>Add Activity
                      </button>
                    </div>
                  </div>

                  {/* Achievements Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #ffa000' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#fff8e1'
                          }}
                        >
                          <i className="fas fa-trophy" style={{ color: '#ffa000' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Achievements & Awards</h5>
                          <small className="text-muted">Academic achievements and recognitions</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      {formData.achievements.map((achievement, index) => (
                        <div key={index} className="input-group mb-3">
                          <span className="input-group-text" style={{ borderRadius: '12px 0 0 12px', border: '2px solid #e0e0e0', borderRight: 'none' }}>
                            <i className="fas fa-medal text-muted"></i>
                          </span>
                          <input
                            type="text"
                            className="form-control py-2"
                            placeholder="Achievement or award"
                            value={achievement}
                            onChange={(e) => handleArrayChange(index, 'achievements', e.target.value)}
                            style={{ border: '2px solid #e0e0e0', borderLeft: 'none', borderRight: 'none' }}
                          />
                          <button
                            type="button"
                            className="btn btn-outline-danger"
                            onClick={() => removeArrayItem(index, 'achievements')}
                            style={{ borderRadius: '0 12px 12px 0', border: '2px solid #e0e0e0', borderLeft: 'none' }}
                          >
                            <i className="fas fa-times"></i>
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="btn btn-outline-warning rounded-pill px-3"
                        onClick={() => addArrayItem('achievements')}
                      >
                        <i className="fas fa-plus me-2"></i>Add Achievement
                      </button>
                    </div>
                  </div>

                  {/* Skills Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #673ab7' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#f3e5f5'
                          }}
                        >
                          <i className="fas fa-cogs" style={{ color: '#673ab7' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Skills Gained</h5>
                          <small className="text-muted">Technical and soft skills acquired</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      {formData.skills.map((skill, index) => (
                        <div key={index} className="input-group mb-3">
                          <span className="input-group-text" style={{ borderRadius: '12px 0 0 12px', border: '2px solid #e0e0e0', borderRight: 'none' }}>
                            <i className="fas fa-brain text-muted"></i>
                          </span>
                          <input
                            type="text"
                            className="form-control py-2"
                            placeholder="Skill gained during education"
                            value={skill}
                            onChange={(e) => handleArrayChange(index, 'skills', e.target.value)}
                            style={{ border: '2px solid #e0e0e0', borderLeft: 'none', borderRight: 'none' }}
                          />
                          <button
                            type="button"
                            className="btn btn-outline-danger"
                            onClick={() => removeArrayItem(index, 'skills')}
                            style={{ borderRadius: '0 12px 12px 0', border: '2px solid #e0e0e0', borderLeft: 'none' }}
                          >
                            <i className="fas fa-times"></i>
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="btn btn-outline-primary rounded-pill px-3"
                        onClick={() => addArrayItem('skills')}
                      >
                        <i className="fas fa-plus me-2"></i>Add Skill
                      </button>
                    </div>
                  </div>

                  {/* Links & Media Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #00acc1' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#e0f7fa'
                          }}
                        >
                          <i className="fas fa-link" style={{ color: '#00acc1' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Links & Media</h5>
                          <small className="text-muted">Institution logos and document links</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      <div className="row g-3">
                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-image me-2 text-muted"></i>Institution Logo/Image URL
                          </label>
                          <input
                            type="url"
                            className="form-control rounded-pill py-2"
                            name="image"
                            value={formData.image}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="https://example.com/logo.png"
                          />
                        </div>
                        <div className="col-md-6">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-certificate me-2 text-muted"></i>Certificate URL
                          </label>
                          <input
                            type="url"
                            className="form-control rounded-pill py-2"
                            name="certificateUrl"
                            value={formData.certificateUrl}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="https://example.com/certificate.pdf"
                          />
                        </div>
                        <div className="col-12">
                          <label className="form-label fw-medium text-dark">
                            <i className="fas fa-file-alt me-2 text-muted"></i>Transcript URL
                          </label>
                          <input
                            type="url"
                            className="form-control rounded-pill py-2"
                            name="transcriptUrl"
                            value={formData.transcriptUrl}
                            onChange={handleChange}
                            style={{ border: '2px solid #e0e0e0' }}
                            placeholder="https://example.com/transcript.pdf"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Status Options Section */}
                  <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #9c27b0' }}>
                    <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                      <div className="d-flex align-items-center">
                        <div 
                          className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                          style={{ 
                            width: '40px', 
                            height: '40px', 
                            backgroundColor: '#f3e5f5'
                          }}
                        >
                          <i className="fas fa-toggle-on" style={{ color: '#9c27b0' }}></i>
                        </div>
                        <div>
                          <h5 className="mb-0 fw-bold text-dark">Status Options</h5>
                          <small className="text-muted">Visibility and display settings</small>
                        </div>
                      </div>
                    </div>
                    <div className="card-body p-4">
                      <div className="row g-4">
                        <div className="col-md-4">
                          <div className="form-check form-switch">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              name="current"
                              id="current"
                              checked={formData.current}
                              onChange={handleChange}
                            />
                            <label className="form-check-label fw-medium text-dark" htmlFor="current">
                              <i className="fas fa-clock text-info me-2"></i>
                              Currently Studying
                            </label>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="form-check form-switch">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              name="featured"
                              id="featured"
                              checked={formData.featured}
                              onChange={handleChange}
                            />
                            <label className="form-check-label fw-medium text-dark" htmlFor="featured">
                              <i className="fas fa-star text-warning me-2"></i>
                              Featured Education
                            </label>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="form-check form-switch">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              name="isActive"
                              id="isActive"
                              checked={formData.isActive}
                              onChange={handleChange}
                            />
                            <label className="form-check-label fw-medium text-dark" htmlFor="isActive">
                              <i className="fas fa-eye text-success me-2"></i>
                              Active/Visible
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Form Actions */}
                  <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                    <div className="card-body p-4">
                      <div className="d-flex justify-content-between align-items-center">
                        <Link 
                          to="/admin/education" 
                          className="btn btn-outline-secondary rounded-pill px-4 py-2"
                        >
                          <i className="fas fa-arrow-left me-2"></i>Cancel
                        </Link>
                        <button
                          type="submit"
                          className="btn btn-primary rounded-pill px-4 py-2"
                          disabled={loading}
                          style={{ minWidth: '180px' }}
                        >
                          {loading ? (
                            <>
                              <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                              {isEdit ? 'Updating...' : 'Creating...'}
                            </>
                          ) : (
                            <>
                              <i className={`fas ${isEdit ? 'fa-save' : 'fa-plus'} me-2`}></i>
                              {isEdit ? 'Update Education' : 'Create Education'}
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>

          {/* Preview Card */}
          <div className="col-lg-4">
            <div className="position-sticky" style={{ top: '2rem' }}>
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-header bg-white border-0 py-3" style={{ borderRadius: '16px 16px 0 0' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-eye text-primary"></i>
                    </div>
                    <div>
                      <h5 className="mb-0 fw-bold text-dark">Live Preview</h5>
                      <small className="text-muted">See how it will look</small>
                    </div>
                  </div>
                </div>
                <div className="card-body p-4">
                  <div className="d-flex align-items-start mb-3">
                    <div 
                      className="me-3 d-flex align-items-center justify-content-center rounded"
                      style={{ 
                        width: '50px', 
                        height: '50px', 
                        backgroundColor: '#1976d2',
                        color: '#fff',
                        borderRadius: '12px'
                      }}
                    >
                      <i className="fas fa-graduation-cap"></i>
                    </div>
                    
                    <div className="flex-grow-1">
                      <h6 className="mb-1 fw-bold text-dark">{formData.title || 'Program Title'}</h6>
                      <div className="text-primary mb-1 fw-medium">{formData.institution || 'Institution Name'}</div>
                      {formData.location && (
                        <small className="text-muted">
                          <i className="fas fa-map-marker-alt me-1"></i>
                          {formData.location}
                        </small>
                      )}
                    </div>
                    
                    {formData.current && (
                      <span className="badge bg-info px-3 py-2 rounded-pill">
                        <i className="fas fa-clock me-1"></i>Current
                      </span>
                    )}
                  </div>

                  {(formData.degree || formData.fieldOfStudy) && (
                    <div className="mb-3">
                      {formData.degree && (
                        <span className="badge bg-primary me-2 px-3 py-2 rounded-pill">{formData.degree}</span>
                      )}
                      {formData.fieldOfStudy && (
                        <span className="badge bg-secondary px-3 py-2 rounded-pill">{formData.fieldOfStudy}</span>
                      )}
                    </div>
                  )}

                  {formData.startDate && (
                    <div className="mb-3">
                      <div className="d-flex align-items-center text-muted">
                        <i className="fas fa-calendar-alt me-2"></i>
                        <small>
                          {new Date(formData.startDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })} - 
                          {formData.current ? ' Present' : 
                           formData.endDate ? ` ${new Date(formData.endDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })}` : ' Present'}
                        </small>
                      </div>
                    </div>
                  )}

                  {formData.grade && (
                    <div className="mb-3">
                      <span className="badge bg-success px-3 py-2 rounded-pill">
                        <i className="fas fa-medal me-1"></i>Grade: {formData.grade}
                      </span>
                    </div>
                  )}

                  {formData.description && (
                    <p className="text-muted mb-3" style={{ fontSize: '0.9rem' }}>
                      {formData.description.substring(0, 120)}
                      {formData.description.length > 120 && '...'}
                    </p>
                  )}

                  <div className="d-flex justify-content-center gap-2 flex-wrap mb-3">
                    {formData.featured && (
                      <span className="badge bg-warning text-dark px-3 py-2 rounded-pill">
                        <i className="fas fa-star me-1"></i>Featured
                      </span>
                    )}
                    <span className={`badge px-3 py-2 rounded-pill ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                      <i className={`fas ${formData.isActive ? 'fa-check-circle' : 'fa-times-circle'} me-1`}></i>
                      {formData.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>

                  {/* Additional Info */}
                  <div className="card border-0" style={{ backgroundColor: '#f8f9fa', borderRadius: '12px' }}>
                    <div className="card-body p-3">
                      <h6 className="fw-bold text-dark mb-2">
                        <i className="fas fa-info-circle me-2"></i>Additional Details
                      </h6>
                      <div className="row g-2 text-sm">
                        <div className="col-6">
                          <small className="text-muted d-block">Activities:</small>
                          <small className="fw-medium">{formData.activities.filter(a => a.trim()).length}</small>
                        </div>
                        <div className="col-6">
                          <small className="text-muted d-block">Achievements:</small>
                          <small className="fw-medium">{formData.achievements.filter(a => a.trim()).length}</small>
                        </div>
                        <div className="col-6">
                          <small className="text-muted d-block">Skills:</small>
                          <small className="fw-medium">{formData.skills.filter(s => s.trim()).length}</small>
                        </div>
                        <div className="col-6">
                          <small className="text-muted d-block">Order:</small>
                          <small className="fw-medium">{formData.order}</small>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EducationForm;
