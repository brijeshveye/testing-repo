import React from 'react';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-11">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center">
                <div className="me-3">
                  <div 
                    className="rounded-circle d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '60px', 
                      height: '60px', 
                      backgroundColor: '#1976d2',
                      color: 'white'
                    }}
                  >
                    <i className="fas fa-tachometer-alt fs-3"></i>
                  </div>
                </div>
                <div>
                  <h2 className="mb-1 text-dark fw-bold">Admin Dashboard</h2>
                  <p className="text-muted mb-0">Welcome to your admin panel. Manage your portfolio content from here.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Management Cards */}
          <div className="row g-4 mb-5">
            {/* Profile Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-user text-primary" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Profile Management</h5>
                  <p className="card-text text-muted mb-4">Manage your personal information, contact details, and professional bio.</p>
                  <Link 
                    to="/admin/user" 
                    className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#1976d2', border: 'none' }}
                  >
                    <i className="fas fa-edit me-2"></i>
                    Manage Profile
                  </Link>
                </div>
              </div>
            </div>

            {/* Skills Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#e1f5fe'
                      }}
                    >
                      <i className="fas fa-code text-info" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Technical Skills</h5>
                  <p className="card-text text-muted mb-4">Manage your technical skills, programming languages, and expertise levels.</p>
                  <Link 
                    to="/admin/skills" 
                    className="btn btn-info rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#0288d1', border: 'none' }}
                  >
                    <i className="fas fa-cog me-2"></i>
                    Manage Skills
                  </Link>
                </div>
              </div>
            </div>

            {/* Experience Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#f3e5f5'
                      }}
                    >
                      <i className="fas fa-briefcase text-secondary" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Work Experience</h5>
                  <p className="card-text text-muted mb-4">Manage your professional work experience and career history.</p>
                  <Link 
                    to="/admin/experience" 
                    className="btn btn-secondary rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#6c757d', border: 'none' }}
                  >
                    <i className="fas fa-building me-2"></i>
                    Manage Experience
                  </Link>
                </div>
              </div>
            </div>

            {/* Characteristics Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#fff3e0'
                      }}
                    >
                      <i className="fas fa-star text-warning" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Personal Traits</h5>
                  <p className="card-text text-muted mb-4">Manage your personal and professional characteristics with icons.</p>
                  <Link 
                    to="/admin/characteristics" 
                    className="btn btn-warning rounded-pill px-4 py-2 fw-medium text-white"
                    style={{ backgroundColor: '#f57c00', border: 'none' }}
                  >
                    <i className="fas fa-palette me-2"></i>
                    Manage Traits
                  </Link>
                </div>
              </div>
            </div>

            {/* Education Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#e8f5e8'
                      }}
                    >
                      <i className="fas fa-graduation-cap text-success" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Education</h5>
                  <p className="card-text text-muted mb-4">Manage your educational background and qualifications.</p>
                  <Link 
                    to="/admin/education" 
                    className="btn btn-success rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#2e7d32', border: 'none' }}
                  >
                    <i className="fas fa-book me-2"></i>
                    Manage Education
                  </Link>
                </div>
              </div>
            </div>

            {/* Services Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#f8f9fa'
                      }}
                    >
                      <i className="fas fa-cogs text-dark" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Services</h5>
                  <p className="card-text text-muted mb-4">Manage your service offerings and pricing packages.</p>
                  <Link 
                    to="/admin/services" 
                    className="btn btn-dark rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#212529', border: 'none' }}
                  >
                    <i className="fas fa-tools me-2"></i>
                    Manage Services
                  </Link>
                </div>
              </div>
            </div>

            {/* Certificates Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#e8f5e8'
                      }}
                    >
                      <i className="fas fa-certificate text-success" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Certifications</h5>
                  <p className="card-text text-muted mb-4">Manage your professional certifications and achievements.</p>
                  <Link 
                    to="/admin/certificates" 
                    className="btn btn-success rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#388e3c', border: 'none' }}
                  >
                    <i className="fas fa-award me-2"></i>
                    Manage Certificates
                  </Link>
                </div>
              </div>
            </div>

            {/* Projects Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#e8f5e8'
                      }}
                    >
                      <i className="fas fa-project-diagram text-success" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Portfolio Projects</h5>
                  <p className="card-text text-muted mb-4">Create, edit, and manage your portfolio projects and showcase your work.</p>
                  <Link 
                    to="/admin/projects" 
                    className="btn btn-success rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#43a047', border: 'none' }}
                  >
                    <i className="fas fa-laptop-code me-2"></i>
                    Manage Projects
                  </Link>
                </div>
              </div>
            </div>

            {/* Testimonials Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#fff3e0'
                      }}
                    >
                      <i className="fas fa-quote-right text-warning" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Client Testimonials</h5>
                  <p className="card-text text-muted mb-4">Manage client testimonials and feedback to showcase your work.</p>
                  <Link 
                    to="/admin/testimonials" 
                    className="btn btn-warning rounded-pill px-4 py-2 fw-medium text-white"
                    style={{ backgroundColor: '#ffa000', border: 'none' }}
                  >
                    <i className="fas fa-comments me-2"></i>
                    Manage Testimonials
                  </Link>
                </div>
              </div>
            </div>

            {/* Blog Management Card */}
            <div className="col-12 col-md-6 col-lg-4">
              <div className="card h-100 shadow-sm border-0" style={{ borderRadius: '16px', transition: 'transform 0.2s ease-in-out' }}>
                <div className="card-body p-4 text-center">
                  <div className="mb-4">
                    <div 
                      className="rounded-circle mx-auto d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#e1f5fe'
                      }}
                    >
                      <i className="fas fa-blog text-info" style={{ fontSize: '2.5rem' }}></i>
                    </div>
                  </div>
                  <h5 className="card-title fw-bold text-dark mb-3">Blog Posts</h5>
                  <p className="card-text text-muted mb-4">Write and publish blog posts to share your thoughts and expertise.</p>
                  <Link 
                    to="/admin/blogs" 
                    className="btn btn-info rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#00acc1', border: 'none' }}
                  >
                    <i className="fas fa-pen me-2"></i>
                    Manage Blogs
                  </Link>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Actions Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#e8f5e8'
                  }}
                >
                  <i className="fas fa-bolt text-success fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Quick Actions</h5>
                  <small className="text-muted">Create new content or perform common tasks</small>
                </div>
              </div>
            </div>
            <div className="card-body px-4 pb-4">
              <div className="row g-3">
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/skills/create" 
                    className="btn btn-outline-info w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#0288d1', color: '#0288d1' }}
                  >
                    <i className="fas fa-plus me-2"></i>New Skill
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/experience/create" 
                    className="btn btn-outline-secondary w-100 rounded-pill py-3 fw-medium"
                  >
                    <i className="fas fa-plus me-2"></i>New Experience
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/characteristics/create" 
                    className="btn btn-outline-warning w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#f57c00', color: '#f57c00' }}
                  >
                    <i className="fas fa-plus me-2"></i>New Trait
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/education/create" 
                    className="btn btn-outline-primary w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#1976d2', color: '#1976d2' }}
                  >
                    <i className="fas fa-plus me-2"></i>New Education
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/services/create" 
                    className="btn btn-outline-dark w-100 rounded-pill py-3 fw-medium"
                  >
                    <i className="fas fa-plus me-2"></i>New Service
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/certificates/create" 
                    className="btn btn-outline-success w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#2e7d32', color: '#2e7d32' }}
                  >
                    <i className="fas fa-plus me-2"></i>New Certificate
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/projects/create" 
                    className="btn btn-outline-success w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#43a047', color: '#43a047' }}
                  >
                    <i className="fas fa-plus me-2"></i>New Project
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/testimonials/create" 
                    className="btn btn-outline-warning w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#ffa000', color: '#ffa000' }}
                  >
                    <i className="fas fa-plus me-2"></i>New Testimonial
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/blogs/create" 
                    className="btn btn-outline-info w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#00acc1', color: '#00acc1' }}
                  >
                    <i className="fas fa-plus me-2"></i>New Blog Post
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/admin/user/upload-resume" 
                    className="btn btn-outline-primary w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#1976d2', color: '#1976d2' }}
                  >
                    <i className="fas fa-file-pdf me-2"></i>Upload Resume
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <Link 
                    to="/" 
                    className="btn btn-outline-success w-100 rounded-pill py-3 fw-medium"
                    style={{ borderColor: '#2e7d32', color: '#2e7d32' }}
                  >
                    <i className="fas fa-eye me-2"></i>View Website
                  </Link>
                </div>
                <div className="col-12 col-sm-6 col-md-4 col-lg-3">
                  <button
                    onClick={() => {
                      localStorage.removeItem('adminToken');
                      localStorage.removeItem('adminSession');
                      window.location.href = '/';
                    }}
                    className="btn btn-outline-danger w-100 rounded-pill py-3 fw-medium"
                  >
                    <i className="fas fa-sign-out-alt me-2"></i>Logout
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
