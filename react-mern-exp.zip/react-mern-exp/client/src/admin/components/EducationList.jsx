import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import EducationDataApi from '../../api/EducationDataApi';

const EducationList = () => {
  const [education, setEducation] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    degree: 'all',
    institution: '',
    featured: 'all',
    status: 'all',
    current: 'all',
    search: ''
  });

  useEffect(() => {
    fetchEducation();
    fetchStats();
  }, [filters]);

  const fetchEducation = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.degree !== 'all') params.degree = filters.degree;
      if (filters.institution) params.institution = filters.institution;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.current !== 'all') params.current = filters.current;
      if (filters.search) params.search = filters.search;

      const data = await EducationDataApi.getEducationData(params);
      setEducation(data);
    } catch (err) {
      setError('Failed to fetch education records');
      console.error('Error fetching education:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await EducationDataApi.getEducationStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await EducationDataApi.deleteEducation(slug);
        fetchEducation(); // Refresh the list
      } catch (err) {
        setError('Failed to delete education record');
        console.error('Error deleting education:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await EducationDataApi.toggleFeatured(slug);
      fetchEducation(); // Refresh the list
    } catch (err) {
      setError('Failed to update featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await EducationDataApi.toggleActive(slug);
      fetchEducation(); // Refresh the list
    } catch (err) {
      setError('Failed to update active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const formatDate = (date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short'
    });
  };

  const getDuration = (startDate, endDate, current) => {
    const start = formatDate(startDate);
    const end = current ? 'Present' : formatDate(endDate);
    return `${start} - ${end}`;
  };

  if (loading) {
    return (
      <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
        <div className="container">
          <div className="row justify-content-center">
            <div className="col-12 col-md-6">
              <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                <div className="card-body py-5 text-center">
                  <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
                    <span className="visually-hidden">Loading...</span>
                  </div>
                  <h5 className="text-muted">Loading education records...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid" style={{ backgroundColor: '#f8f9fa', minHeight: '100vh', padding: '2rem 0' }}>
      <div className="container">
        {/* Header Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-body p-4">
            <div className="d-flex justify-content-between align-items-center">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle d-flex align-items-center justify-content-center me-3"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#1976d2',
                    color: 'white'
                  }}
                >
                  <i className="fas fa-graduation-cap" style={{ fontSize: '20px' }}></i>
                </div>
                <div>
                  <h2 className="mb-1" style={{ color: '#2c3e50', fontWeight: '600' }}>
                    Manage Education
                  </h2>
                  <p className="text-muted mb-0">
                    Showcase your academic achievements and qualifications
                  </p>
                </div>
              </div>
              <Link 
                to="/admin/education/create" 
                className="btn btn-primary d-flex align-items-center"
                style={{ borderRadius: '12px', padding: '0.6rem 1.2rem' }}
              >
                <i className="fas fa-plus me-2"></i>
                Add Education
              </Link>
            </div>
          </div>
        </div>

        {/* Error Message */}
        {error && (
          <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px', borderLeft: '4px solid #dc3545' }}>
            <div className="card-body p-4" style={{ backgroundColor: '#fff5f5' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ width: '40px', height: '40px', backgroundColor: '#dc3545', color: 'white' }}
                >
                  <i className="fas fa-exclamation-triangle"></i>
                </div>
                <div>
                  <h6 className="mb-1" style={{ color: '#dc3545', fontWeight: '600' }}>Error</h6>
                  <p className="mb-0 text-muted">{error}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Stats Cards */}
        {stats && (
          <div className="row g-4 mb-4">
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #1976d2' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#e3f2fd' }}
                        >
                          <i className="fas fa-graduation-cap" style={{ color: '#1976d2' }}></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Total</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#1976d2' }}>{stats.totalEducation}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #2e7d32' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#e8f5e8' }}
                        >
                          <i className="fas fa-check-circle text-success"></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Active</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#2e7d32' }}>{stats.activeEducation}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #ffa000' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#fff8e1' }}
                        >
                          <i className="fas fa-star" style={{ color: '#ffa000' }}></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Featured</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#ffa000' }}>{stats.featuredEducation}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-3">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px', borderLeft: '4px solid #00acc1' }}>
                <div className="card-body p-4">
                  <div className="d-flex justify-content-between align-items-center">
                    <div>
                      <div className="d-flex align-items-center mb-2">
                        <div 
                          className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                          style={{ width: '32px', height: '32px', backgroundColor: '#e0f7fa' }}
                        >
                          <i className="fas fa-clock" style={{ color: '#00acc1' }}></i>
                        </div>
                        <h6 className="card-title mb-0 text-muted">Current</h6>
                      </div>
                      <h2 className="mb-0 fw-bold" style={{ color: '#00acc1' }}>{stats.currentEducation}</h2>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Filters Card */}
        <div className="card border-0 shadow-sm mb-4" style={{ borderRadius: '16px' }}>
          <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
            <div className="d-flex align-items-center">
              <div 
                className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                style={{ 
                  width: '48px', 
                  height: '48px', 
                  backgroundColor: '#f3e5f5'
                }}
              >
                <i className="fas fa-filter text-secondary fs-5"></i>
              </div>
              <div>
                <h5 className="mb-0 fw-bold text-dark">Filters & Search</h5>
                <small className="text-muted">Filter and sort your education records</small>
              </div>
            </div>
          </div>
          <div className="card-body p-4">
            <div className="row g-3">
              <div className="col-md-3">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-search me-2 text-muted"></i>Search
                </label>
                <input
                  type="text"
                  className="form-control rounded-pill py-2"
                  name="search"
                  placeholder="Search education..."
                  value={filters.search}
                  onChange={handleFilterChange}
                  style={{ border: '2px solid #e0e0e0' }}
                />
              </div>
              
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-graduation-cap me-2 text-muted"></i>Degree
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  name="degree"
                  value={filters.degree}
                  onChange={handleFilterChange}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All Degrees</option>
                  <option value="Bachelor">Bachelor</option>
                  <option value="Master">Master</option>
                  <option value="PhD">PhD</option>
                  <option value="Diploma">Diploma</option>
                  <option value="Certificate">Certificate</option>
                </select>
              </div>
              
              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-university me-2 text-muted"></i>Institution
                </label>
                <input
                  type="text"
                  className="form-control rounded-pill py-2"
                  name="institution"
                  placeholder="Institution..."
                  value={filters.institution}
                  onChange={handleFilterChange}
                  style={{ border: '2px solid #e0e0e0' }}
                />
              </div>
              
              <div className="col-md-1">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-star me-2 text-muted"></i>Featured
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  name="featured"
                  value={filters.featured}
                  onChange={handleFilterChange}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Featured</option>
                  <option value="false">Not Featured</option>
                </select>
              </div>
              
              <div className="col-md-1">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-toggle-on me-2 text-muted"></i>Status
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  name="status"
                  value={filters.status}
                  onChange={handleFilterChange}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Active</option>
                  <option value="false">Inactive</option>
                </select>
              </div>
              
              <div className="col-md-1">
                <label className="form-label fw-medium text-dark">
                  <i className="fas fa-clock me-2 text-muted"></i>Current
                </label>
                <select
                  className="form-select rounded-pill py-2"
                  name="current"
                  value={filters.current}
                  onChange={handleFilterChange}
                  style={{ border: '2px solid #e0e0e0' }}
                >
                  <option value="all">All</option>
                  <option value="true">Current</option>
                  <option value="false">Completed</option>
                </select>
              </div>

              <div className="col-md-2">
                <label className="form-label fw-medium text-dark">&nbsp;</label>
                <button
                  className="btn btn-outline-secondary rounded-pill w-100 py-2"
                  onClick={() => {
                    setFilters({
                      degree: 'all',
                      institution: '',
                      featured: 'all',
                      status: 'all',
                      current: 'all',
                      search: ''
                    });
                  }}
                  title="Clear all filters"
                >
                  <i className="fas fa-times me-2"></i>Clear Filters
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Education List Card */}
        <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
          <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
            <div className="d-flex align-items-center justify-content-between">
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#e3f2fd'
                  }}
                >
                  <i className="fas fa-list text-primary fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Education Records</h5>
                  <small className="text-muted">Manage your academic achievements</small>
                </div>
              </div>
              {education.length > 0 && (
                <span className="badge bg-light text-dark px-3 py-2 rounded-pill">
                  {education.length} record{education.length !== 1 ? 's' : ''}
                </span>
              )}
            </div>
          </div>
          <div className="card-body p-4">
            {education.length === 0 ? (
              <div className="text-center py-5">
                <div 
                  className="rounded-circle mx-auto mb-4 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '80px', 
                    height: '80px', 
                    backgroundColor: '#f8f9fa'
                  }}
                >
                  <i className="fas fa-graduation-cap fa-2x text-muted"></i>
                </div>
                <h3 className="text-dark mb-3">No Education Records Found</h3>
                <p className="text-muted mb-4">
                  {filters.search || filters.degree !== 'all' || filters.institution || filters.featured !== 'all' || filters.status !== 'all' || filters.current !== 'all'
                    ? 'Try adjusting your filters or search terms.'
                    : 'Start building your education profile by adding your first record.'}
                </p>
                <Link 
                  to="/admin/education/create" 
                  className="btn btn-primary rounded-pill px-4 py-2"
                >
                  <i className="fas fa-plus me-2"></i>Create Education Record
                </Link>
              </div>
            ) : (
              <div className="table-responsive">
                <table className="table table-hover mb-0">
                  <thead style={{ backgroundColor: '#f8f9fa' }}>
                    <tr>
                      <th className="border-0 py-3 fw-bold text-dark">Education</th>
                      <th className="border-0 py-3 fw-bold text-dark">Institution</th>
                      <th className="border-0 py-3 fw-bold text-dark">Duration</th>
                      <th className="border-0 py-3 fw-bold text-dark">Degree</th>
                      <th className="border-0 py-3 fw-bold text-dark">Status</th>
                      <th className="border-0 py-3 fw-bold text-dark">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {education.map((edu) => (
                      <tr key={edu._id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                        <td className="py-3">
                          <div className="d-flex align-items-center">
                            <div 
                              className="me-3 rounded-circle d-flex align-items-center justify-content-center"
                              style={{ 
                                width: '48px', 
                                height: '48px', 
                                backgroundColor: '#e3f2fd',
                                border: '2px solid #1976d2'
                              }}
                            >
                              <i className="fas fa-graduation-cap text-primary"></i>
                            </div>
                            <div>
                              <h6 className="mb-1 fw-bold text-dark">{edu.title}</h6>
                              {edu.fieldOfStudy && (
                                <small className="text-muted d-block">{edu.fieldOfStudy}</small>
                              )}
                              {edu.grade && (
                                <div className="mt-1">
                                  <span className="badge bg-success px-2 py-1 rounded-pill">
                                    <i className="fas fa-medal me-1"></i>Grade: {edu.grade}
                                  </span>
                                </div>
                              )}
                            </div>
                          </div>
                        </td>
                        <td className="py-3">
                          <div>
                            <h6 className="mb-1 fw-bold text-dark">{edu.institution}</h6>
                            {edu.location && (
                              <div className="d-flex align-items-center">
                                <i className="fas fa-map-marker-alt me-1 text-muted"></i>
                                <small className="text-muted">{edu.location}</small>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="py-3">
                          <div>
                            <span className="fw-medium text-dark d-block">
                              {getDuration(edu.startDate, edu.endDate, edu.current)}
                            </span>
                            {edu.current && (
                              <span className="badge bg-info px-3 py-1 rounded-pill mt-1">
                                <i className="fas fa-clock me-1"></i>Current
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3">
                          {edu.degree && (
                            <span 
                              className="badge rounded-pill px-3 py-2 fw-medium"
                              style={{ 
                                backgroundColor: '#e3f2fd', 
                                color: '#1976d2'
                              }}
                            >
                              {edu.degree}
                            </span>
                          )}
                        </td>
                        <td className="py-3">
                          <div className="d-flex gap-2 flex-wrap">
                            <span className={`badge rounded-pill px-3 py-2 fw-medium ${
                              edu.isActive ? 'bg-success text-white' : 'bg-secondary text-white'
                            }`}>
                              <i className={`fas ${edu.isActive ? 'fa-check' : 'fa-times'} me-1`}></i>
                              {edu.isActive ? 'Active' : 'Inactive'}
                            </span>
                            {edu.featured && (
                              <span className="badge bg-warning text-dark px-3 py-2 rounded-pill fw-medium">
                                <i className="fas fa-star me-1"></i>Featured
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3">
                          <div className="btn-group" role="group">
                            <Link 
                              to={`/admin/education/edit/${edu.slug}`}
                              className="btn btn-sm btn-outline-primary rounded-pill px-3"
                              title="Edit education record"
                            >
                              <i className="fas fa-edit me-1"></i>Edit
                            </Link>
                            
                            <button
                              onClick={() => handleToggleFeatured(edu.slug)}
                              className={`btn btn-sm rounded-circle ms-1 ${
                                edu.featured ? 'btn-warning text-white' : 'btn-outline-warning'
                              }`}
                              style={{ width: '36px', height: '36px' }}
                              title={edu.featured ? 'Remove from featured' : 'Add to featured'}
                            >
                              <i className="fas fa-star"></i>
                            </button>
                            
                            <button
                              onClick={() => handleToggleActive(edu.slug)}
                              className={`btn btn-sm rounded-circle ms-1 ${
                                edu.isActive ? 'btn-success text-white' : 'btn-outline-success'
                              }`}
                              style={{ width: '36px', height: '36px' }}
                              title={edu.isActive ? 'Deactivate' : 'Activate'}
                            >
                              <i className={`fas ${edu.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                            </button>
                            
                            <button
                              onClick={() => handleDelete(edu.slug, edu.title)}
                              className="btn btn-sm btn-outline-danger rounded-circle ms-1"
                              style={{ width: '36px', height: '36px' }}
                              title="Delete education record"
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Back to Dashboard */}
        <div className="mt-4">
          <Link 
            to="/admin" 
            className="btn btn-outline-secondary rounded-pill px-4 py-2"
          >
            <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
          </Link>
        </div>
      </div>
    </div>
  );
};

export default EducationList;
