import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { showSuccess, showError } from '../../utils/toastUtils';

const BlogList = () => {
  const [blogs, setBlogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const fetchBlogs = async () => {
    try {
      setLoading(true);
      const res = await axios.get('/api/blogs');
      setBlogs(res.data);
    } catch (error) {
      console.error('Error fetching blogs:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteBlog = async (slug) => {
    if (window.confirm('Are you sure you want to delete this blog post? This action cannot be undone.')) {
      try {
        await axios.delete(`/api/blogs/${slug}`);
        showSuccess('Blog post deleted successfully!');
        fetchBlogs(); // refresh list
      } catch (error) {
        console.error('Error deleting blog:', error);
        showError('Failed to delete blog post. Please try again.');
      }
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  // Filter and search blogs
  const filteredBlogs = blogs.filter(blog => {
    const matchesSearch = blog.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         blog.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         blog.author?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (filter === 'all') return matchesSearch;
    if (filter === 'recent') {
      const blogDate = new Date(blog.date);
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return matchesSearch && blogDate >= thirtyDaysAgo;
    }
    if (filter === 'category') return matchesSearch && blog.category;
    
    return matchesSearch;
  });

  const stats = {
    total: blogs.length,
    recent: blogs.filter(blog => {
      const blogDate = new Date(blog.date);
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      return blogDate >= thirtyDaysAgo;
    }).length,
    categorized: blogs.filter(blog => blog.category).length
  };

  if (loading) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '400px' }}>
          <div className="text-center">
            <div className="spinner-border text-primary mb-3" role="status" style={{ width: '3rem', height: '3rem' }}>
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="text-muted">Loading blog posts...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-10">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: '#2e7d32',
                        color: 'white'
                      }}
                    >
                      <i className="fas fa-blog fs-3"></i>
                    </div>
                  </div>
                  <div>
                    <h2 className="mb-1 text-dark fw-bold">Blog Management</h2>
                    <p className="text-muted mb-0">Manage your blog posts and articles</p>
                  </div>
                </div>
                <Link 
                  to="/admin/blogs/create" 
                  className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                >
                  <i className="fas fa-plus me-2"></i>Create New Blog
                </Link>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="row g-4 mb-4">
            <div className="col-md-4">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px' }}>
                <div className="card-body p-4">
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-blog text-primary fs-5"></i>
                    </div>
                    <div>
                      <h3 className="mb-0 fw-bold text-dark">{stats.total}</h3>
                      <p className="text-muted mb-0 fw-medium">Total Posts</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px' }}>
                <div className="card-body p-4">
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#e8f5e8'
                      }}
                    >
                      <i className="fas fa-clock text-success fs-5"></i>
                    </div>
                    <div>
                      <h3 className="mb-0 fw-bold text-dark">{stats.recent}</h3>
                      <p className="text-muted mb-0 fw-medium">Recent (30 days)</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px' }}>
                <div className="card-body p-4">
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '48px', 
                        height: '48px', 
                        backgroundColor: '#fff3e0'
                      }}
                    >
                      <i className="fas fa-tags text-warning fs-5"></i>
                    </div>
                    <div>
                      <h3 className="mb-0 fw-bold text-dark">{stats.categorized}</h3>
                      <p className="text-muted mb-0 fw-medium">Categorized</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Filter and Search Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body p-4">
              <div className="row align-items-center">
                <div className="col-md-6">
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#f3e5f5'
                      }}
                    >
                      <i className="fas fa-filter text-purple fs-6"></i>
                    </div>
                    <div className="me-3">
                      <h6 className="mb-0 fw-bold text-dark">Filter & Search</h6>
                      <small className="text-muted">Find specific blog posts</small>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="row g-2">
                    <div className="col-7">
                      <input
                        type="text"
                        className="form-control border-2"
                        placeholder="Search blogs..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        style={{ borderRadius: '10px' }}
                      />
                    </div>
                    <div className="col-5">
                      <select
                        className="form-select border-2"
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                        style={{ borderRadius: '10px' }}
                      >
                        <option value="all">All Posts</option>
                        <option value="recent">Recent</option>
                        <option value="category">Categorized</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Blog Posts Grid */}
          <div className="row g-4">
            {filteredBlogs.length === 0 ? (
              <div className="col-12">
                <div className="card border-0 shadow-sm" style={{ borderRadius: '16px' }}>
                  <div className="card-body text-center py-5">
                    <div 
                      className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '80px', 
                        height: '80px', 
                        backgroundColor: '#f8f9fa'
                      }}
                    >
                      <i className="fas fa-blog text-muted fs-1"></i>
                    </div>
                    <h5 className="text-muted">No blog posts found</h5>
                    <p className="text-muted mb-3">
                      {searchTerm || filter !== 'all' 
                        ? 'Try adjusting your search or filter criteria'
                        : 'Get started by creating your first blog post'
                      }
                    </p>
                    {!searchTerm && filter === 'all' && (
                      <Link to="/admin/blogs/create" className="btn btn-primary rounded-pill px-4">
                        <i className="fas fa-plus me-2"></i>Create First Blog Post
                      </Link>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              filteredBlogs.map(blog => (
                <div key={blog.slug} className="col-md-6 col-lg-4">
                  <div className="card border-0 shadow-sm h-100" style={{ borderRadius: '16px' }}>
                    {(blog.bannerImage || blog.image) && (
                      <div className="position-relative">
                        <img 
                          src={blog.bannerImage || blog.image} 
                          alt={blog.title}
                          className="card-img-top"
                          style={{ 
                            height: '200px', 
                            objectFit: 'cover',
                            borderRadius: '16px 16px 0 0'
                          }}
                        />
                        {blog.category && (
                          <span 
                            className="badge position-absolute top-0 start-0 m-3 fw-medium"
                            style={{ 
                              backgroundColor: '#f57c00',
                              color: 'white',
                              borderRadius: '8px'
                            }}
                          >
                            {blog.category}
                          </span>
                        )}
                      </div>
                    )}
                    <div className="card-body p-4 d-flex flex-column">
                      <div className="mb-3">
                        <h5 className="card-title fw-bold text-dark mb-2">{blog.title}</h5>
                        <p className="card-text text-muted small">
                          {blog.description || 'No description available'}
                        </p>
                      </div>
                      
                      <div className="mt-auto">
                        <div className="d-flex align-items-center justify-content-between mb-3">
                          <div className="d-flex align-items-center">
                            <div 
                              className="rounded-circle me-2 d-flex align-items-center justify-content-center"
                              style={{ 
                                width: '24px', 
                                height: '24px', 
                                backgroundColor: '#e3f2fd'
                              }}
                            >
                              <i className="fas fa-user text-primary" style={{ fontSize: '10px' }}></i>
                            </div>
                            <small className="text-muted">{blog.author || 'Unknown'}</small>
                          </div>
                          <small className="text-muted">
                            {blog.date ? new Date(blog.date).toLocaleDateString() : 'No date'}
                          </small>
                        </div>
                        
                        <div className="d-flex gap-2">
                          <Link 
                            to={`/admin/blogs/edit/${blog.slug}`} 
                            className="btn btn-outline-primary btn-sm rounded-pill flex-fill fw-medium"
                          >
                            <i className="fas fa-edit me-1"></i>Edit
                          </Link>
                          <button 
                            className="btn btn-outline-danger btn-sm rounded-pill flex-fill fw-medium"
                            onClick={() => deleteBlog(blog.slug)}
                          >
                            <i className="fas fa-trash me-1"></i>Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BlogList;
