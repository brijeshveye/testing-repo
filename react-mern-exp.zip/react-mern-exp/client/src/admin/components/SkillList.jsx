import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import SkillsDataApi from '../../api/SkillsDataApi';

const SkillList = () => {
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    category: 'all',
    level: 'all',
    featured: 'all',
    status: 'all',
    search: ''
  });

  useEffect(() => {
    fetchSkills();
    fetchStats();
  }, [filters]);

  const fetchSkills = async () => {
    try {
      setLoading(true);
      const params = {};
      
      if (filters.category !== 'all') params.category = filters.category;
      if (filters.level !== 'all') params.level = filters.level;
      if (filters.featured !== 'all') params.featured = filters.featured;
      if (filters.status !== 'all') params.isActive = filters.status;
      if (filters.search) params.search = filters.search;

      const data = await SkillsDataApi.getSkillsData(params);
      setSkills(data);
    } catch (err) {
      setError('Failed to fetch skills');
      console.error('Error fetching skills:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchStats = async () => {
    try {
      const statsData = await SkillsDataApi.getSkillStats();
      setStats(statsData);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const handleDelete = async (slug, title) => {
    if (window.confirm(`Are you sure you want to delete "${title}"?`)) {
      try {
        await SkillsDataApi.deleteSkill(slug);
        fetchSkills(); // Refresh the list
      } catch (err) {
        setError('Failed to delete skill');
        console.error('Error deleting skill:', err);
      }
    }
  };

  const handleToggleFeatured = async (slug) => {
    try {
      await SkillsDataApi.toggleFeatured(slug);
      fetchSkills(); // Refresh the list
    } catch (err) {
      setError('Failed to update featured status');
      console.error('Error toggling featured:', err);
    }
  };

  const handleToggleActive = async (slug) => {
    try {
      await SkillsDataApi.toggleActive(slug);
      fetchSkills(); // Refresh the list
    } catch (err) {
      setError('Failed to update active status');
      console.error('Error toggling active:', err);
    }
  };

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const getSkillIcon = (skill) => {
    return skill.icon || 'fas fa-code';
  };

  const getSkillColor = (skill) => {
    return skill.color || '#007bff';
  };

  if (loading) {
    return (
      <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
        <div className="row justify-content-center">
          <div className="col-12 col-xl-10">
            <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
              <div className="card-body py-5 text-center">
                <div className="spinner-border text-primary" role="status" style={{ width: '3rem', height: '3rem' }}>
                  <span className="visually-hidden">Loading...</span>
                </div>
                <div className="mt-3">
                  <h5 className="text-muted">Loading skills...</h5>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container-fluid py-4" style={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <div className="row justify-content-center">
        <div className="col-12 col-xl-10">
          {/* Header Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-body py-4">
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div className="me-3">
                    <div 
                      className="rounded-circle d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: '#0288d1',
                        color: 'white'
                      }}
                    >
                      <i className="fas fa-code fs-3"></i>
                    </div>
                  </div>
                  <div>
                    <h2 className="mb-1 text-dark fw-bold">Manage Skills</h2>
                    <p className="text-muted mb-0">Organize and manage your technical skills and expertise</p>
                  </div>
                </div>
                <Link 
                  to="/admin/skills/create" 
                  className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                  style={{ backgroundColor: '#0288d1', border: 'none' }}
                >
                  <i className="fas fa-plus me-2"></i>Add New Skill
                </Link>
              </div>
            </div>
          </div>

          {error && (
            <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
              <div className="card-body p-4">
                <div className="alert alert-danger border-0 mb-0" style={{ borderRadius: '12px' }}>
                  <div className="d-flex align-items-center">
                    <div 
                      className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '40px', 
                        height: '40px', 
                        backgroundColor: '#ffebee',
                        color: '#d32f2f'
                      }}
                    >
                      <i className="fas fa-exclamation-triangle"></i>
                    </div>
                    <div className="fw-medium text-danger">{error}</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Stats Cards */}
          {stats && (
            <div className="row g-4 mb-4">
              <div className="col-12 col-sm-6 col-lg-3">
                <div className="card shadow-sm border-0 h-100" style={{ borderRadius: '16px' }}>
                  <div className="card-body p-4 text-center">
                    <div 
                      className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: '#e3f2fd'
                      }}
                    >
                      <i className="fas fa-code text-primary fs-4"></i>
                    </div>
                    <h4 className="fw-bold text-primary mb-1">{stats.totalSkills}</h4>
                    <p className="text-muted mb-0 fw-medium">Total Skills</p>
                  </div>
                </div>
              </div>
              <div className="col-12 col-sm-6 col-lg-3">
                <div className="card shadow-sm border-0 h-100" style={{ borderRadius: '16px' }}>
                  <div className="card-body p-4 text-center">
                    <div 
                      className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: '#e8f5e8'
                      }}
                    >
                      <i className="fas fa-check-circle text-success fs-4"></i>
                    </div>
                    <h4 className="fw-bold text-success mb-1">{stats.activeSkills}</h4>
                    <p className="text-muted mb-0 fw-medium">Active Skills</p>
                  </div>
                </div>
              </div>
              <div className="col-12 col-sm-6 col-lg-3">
                <div className="card shadow-sm border-0 h-100" style={{ borderRadius: '16px' }}>
                  <div className="card-body p-4 text-center">
                    <div 
                      className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: '#fff3e0'
                      }}
                    >
                      <i className="fas fa-star text-warning fs-4"></i>
                    </div>
                    <h4 className="fw-bold text-warning mb-1">{stats.featuredSkills}</h4>
                    <p className="text-muted mb-0 fw-medium">Featured Skills</p>
                  </div>
                </div>
              </div>
              <div className="col-12 col-sm-6 col-lg-3">
                <div className="card shadow-sm border-0 h-100" style={{ borderRadius: '16px' }}>
                  <div className="card-body p-4 text-center">
                    <div 
                      className="rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center"
                      style={{ 
                        width: '60px', 
                        height: '60px', 
                        backgroundColor: '#e1f5fe'
                      }}
                    >
                      <i className="fas fa-layer-group text-info fs-4"></i>
                    </div>
                    <h4 className="fw-bold text-info mb-1">{stats.categoryStats?.length || 0}</h4>
                    <p className="text-muted mb-0 fw-medium">Categories</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Filters Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
              <div className="d-flex align-items-center">
                <div 
                  className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                  style={{ 
                    width: '48px', 
                    height: '48px', 
                    backgroundColor: '#f3e5f5'
                  }}
                >
                  <i className="fas fa-filter text-secondary fs-5"></i>
                </div>
                <div>
                  <h5 className="mb-0 fw-bold text-dark">Filter & Search</h5>
                  <small className="text-muted">Find specific skills using filters and search</small>
                </div>
              </div>
            </div>
            <div className="card-body px-4 pb-4">
              <div className="row g-3">
                <div className="col-12 col-md-4">
                  <label className="form-label fw-medium text-dark">
                    <i className="fas fa-search me-2 text-muted"></i>Search Skills
                  </label>
                  <input
                    type="text"
                    className="form-control rounded-pill py-2"
                    name="search"
                    placeholder="Search by name or description..."
                    value={filters.search}
                    onChange={handleFilterChange}
                    style={{ border: '2px solid #e0e0e0' }}
                  />
                </div>
                
                <div className="col-6 col-md-2">
                  <label className="form-label fw-medium text-dark">
                    <i className="fas fa-layer-group me-2 text-muted"></i>Category
                  </label>
                  <select
                    className="form-select rounded-pill py-2"
                    name="category"
                    value={filters.category}
                    onChange={handleFilterChange}
                    style={{ border: '2px solid #e0e0e0' }}
                  >
                    <option value="all">All Categories</option>
                    <option value="Language">Language</option>
                    <option value="Frontend">Frontend</option>
                    <option value="Backend">Backend</option>
                    <option value="Database">Database</option>
                    <option value="Cloud">Cloud</option>
                    <option value="DevOps">DevOps</option>
                    <option value="Design">Design</option>
                    <option value="Mobile">Mobile</option>
                  </select>
                </div>
                
                <div className="col-6 col-md-2">
                  <label className="form-label fw-medium text-dark">
                    <i className="fas fa-chart-line me-2 text-muted"></i>Level
                  </label>
                  <select
                    className="form-select rounded-pill py-2"
                    name="level"
                    value={filters.level}
                    onChange={handleFilterChange}
                    style={{ border: '2px solid #e0e0e0' }}
                  >
                    <option value="all">All Levels</option>
                    <option value="Beginner">Beginner</option>
                    <option value="Intermediate">Intermediate</option>
                    <option value="Advanced">Advanced</option>
                    <option value="Expert">Expert</option>
                  </select>
                </div>
                
                <div className="col-6 col-md-2">
                  <label className="form-label fw-medium text-dark">
                    <i className="fas fa-star me-2 text-muted"></i>Featured
                  </label>
                  <select
                    className="form-select rounded-pill py-2"
                    name="featured"
                    value={filters.featured}
                    onChange={handleFilterChange}
                    style={{ border: '2px solid #e0e0e0' }}
                  >
                    <option value="all">All</option>
                    <option value="true">Featured</option>
                    <option value="false">Not Featured</option>
                  </select>
                </div>
                
                <div className="col-6 col-md-2">
                  <label className="form-label fw-medium text-dark">
                    <i className="fas fa-toggle-on me-2 text-muted"></i>Status
                  </label>
                  <select
                    className="form-select rounded-pill py-2"
                    name="status"
                    value={filters.status}
                    onChange={handleFilterChange}
                    style={{ border: '2px solid #e0e0e0' }}
                  >
                    <option value="all">All</option>
                    <option value="true">Active</option>
                    <option value="false">Inactive</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Skills List Card */}
          <div className="card shadow-sm border-0 mb-4" style={{ borderRadius: '16px' }}>
            <div className="card-header bg-white border-0 py-4" style={{ borderRadius: '16px 16px 0 0' }}>
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center">
                  <div 
                    className="rounded-circle me-3 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '48px', 
                      height: '48px', 
                      backgroundColor: '#e3f2fd'
                    }}
                  >
                    <i className="fas fa-list text-primary fs-5"></i>
                  </div>
                  <div>
                    <h5 className="mb-0 fw-bold text-dark">Skills List</h5>
                    <small className="text-muted">{skills.length} skills found</small>
                  </div>
                </div>
              </div>
            </div>
            <div className="card-body p-0">
              {skills.length === 0 ? (
                <div className="text-center py-5 px-4">
                  <div 
                    className="rounded-circle mx-auto mb-4 d-flex align-items-center justify-content-center"
                    style={{ 
                      width: '80px', 
                      height: '80px', 
                      backgroundColor: '#f8f9fa'
                    }}
                  >
                    <i className="fas fa-code text-muted" style={{ fontSize: '2rem' }}></i>
                  </div>
                  <h5 className="fw-bold text-dark mb-3">No skills found</h5>
                  <p className="text-muted mb-4">
                    {filters.search || filters.category !== 'all' || filters.level !== 'all' || filters.featured !== 'all' || filters.status !== 'all'
                      ? 'Try adjusting your filters or search terms.'
                      : 'Start by creating your first skill.'}
                  </p>
                  <Link 
                    to="/admin/skills/create" 
                    className="btn btn-primary rounded-pill px-4 py-2 fw-medium"
                    style={{ backgroundColor: '#0288d1', border: 'none' }}
                  >
                    <i className="fas fa-plus me-2"></i>Create Your First Skill
                  </Link>
                </div>
              ) : (
                <div className="table-responsive">
                  <table className="table table-hover mb-0">
                    <thead style={{ backgroundColor: '#f8f9fa' }}>
                      <tr>
                        <th className="border-0 py-3 fw-bold text-dark">Skill</th>
                        <th className="border-0 py-3 fw-bold text-dark">Category</th>
                        <th className="border-0 py-3 fw-bold text-dark">Level</th>
                        <th className="border-0 py-3 fw-bold text-dark">Proficiency</th>
                        <th className="border-0 py-3 fw-bold text-dark">Status</th>
                        <th className="border-0 py-3 fw-bold text-dark">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {skills.map((skill) => (
                        <tr key={skill._id} style={{ borderBottom: '1px solid #f0f0f0' }}>
                          <td className="py-3">
                            <div className="d-flex align-items-center">
                              <div 
                                className="skill-icon d-inline-flex align-items-center justify-content-center rounded-3 me-3"
                                style={{ 
                                  width: '48px', 
                                  height: '48px', 
                                  backgroundColor: getSkillColor(skill),
                                  color: '#fff'
                                }}
                              >
                                <i className={getSkillIcon(skill)}></i>
                              </div>
                              <div>
                                <h6 className="mb-1 fw-bold text-dark">{skill.title}</h6>
                                {skill.description && (
                                  <small className="text-muted">
                                    {skill.description.substring(0, 60)}
                                    {skill.description.length > 60 && '...'}
                                  </small>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="py-3">
                            <span className={`badge rounded-pill px-3 py-2 fw-medium ${
                              skill.category === 'Language' ? 'text-white' :
                              skill.category === 'Frontend' ? 'text-white' :
                              skill.category === 'Backend' ? 'text-white' :
                              skill.category === 'Database' ? 'text-dark' :
                              skill.category === 'Cloud' ? 'text-white' :
                              skill.category === 'DevOps' ? 'text-white' :
                              skill.category === 'Design' ? 'text-white' :
                              skill.category === 'Mobile' ? 'text-white' :
                              'text-white'
                            }`}
                            style={{
                              backgroundColor: 
                                skill.category === 'Language' ? '#1976d2' :
                                skill.category === 'Frontend' ? '#2e7d32' :
                                skill.category === 'Backend' ? '#0288d1' :
                                skill.category === 'Database' ? '#ffa000' :
                                skill.category === 'Cloud' ? '#d32f2f' :
                                skill.category === 'DevOps' ? '#424242' :
                                skill.category === 'Design' ? '#7b1fa2' :
                                skill.category === 'Mobile' ? '#388e3c' :
                                '#6c757d'
                            }}>
                              {skill.category}
                            </span>
                          </td>
                          <td className="py-3">
                            <span className={`badge rounded-pill px-3 py-2 fw-medium ${
                              skill.level === 'Expert' ? 'text-white' :
                              skill.level === 'Advanced' ? 'text-white' :
                              skill.level === 'Intermediate' ? 'text-dark' :
                              'text-white'
                            }`}
                            style={{
                              backgroundColor:
                                skill.level === 'Expert' ? '#2e7d32' :
                                skill.level === 'Advanced' ? '#0288d1' :
                                skill.level === 'Intermediate' ? '#ffa000' :
                                '#6c757d'
                            }}>
                              {skill.level}
                            </span>
                          </td>
                          <td className="py-3">
                            <div className="d-flex align-items-center">
                              <div className="progress me-3" style={{ width: '100px', height: '8px', borderRadius: '4px' }}>
                                <div 
                                  className="progress-bar"
                                  role="progressbar"
                                  style={{ 
                                    width: `${skill.percentage}%`,
                                    backgroundColor: skill.percentage >= 80 ? '#2e7d32' : skill.percentage >= 60 ? '#0288d1' : skill.percentage >= 40 ? '#ffa000' : '#6c757d'
                                  }}
                                ></div>
                              </div>
                              <small className="text-muted fw-medium">{skill.percentage}%</small>
                            </div>
                          </td>
                          <td className="py-3">
                            <div className="d-flex gap-2">
                              <span className={`badge rounded-pill px-2 py-1 ${skill.isActive ? 'bg-success' : 'bg-secondary'}`}>
                                <i className={`fas ${skill.isActive ? 'fa-check' : 'fa-times'} me-1`}></i>
                                {skill.isActive ? 'Active' : 'Inactive'}
                              </span>
                              {skill.featured && (
                                <span className="badge bg-warning rounded-pill px-2 py-1">
                                  <i className="fas fa-star me-1"></i>Featured
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-3">
                            <div className="btn-group" role="group">
                              <Link 
                                to={`/admin/skills/edit/${skill.slug}`}
                                className="btn btn-sm btn-outline-primary rounded-pill me-1"
                                title="Edit"
                                style={{ borderColor: '#0288d1', color: '#0288d1' }}
                              >
                                <i className="fas fa-edit"></i>
                              </Link>
                              
                              <button
                                onClick={() => handleToggleFeatured(skill.slug)}
                                className={`btn btn-sm rounded-pill me-1 ${skill.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                                title={skill.featured ? 'Remove from featured' : 'Add to featured'}
                                style={{ borderColor: '#ffa000', color: skill.featured ? '#fff' : '#ffa000' }}
                              >
                                <i className="fas fa-star"></i>
                              </button>
                              
                              <button
                                onClick={() => handleToggleActive(skill.slug)}
                                className={`btn btn-sm rounded-pill me-1 ${skill.isActive ? 'btn-success' : 'btn-outline-success'}`}
                                title={skill.isActive ? 'Deactivate' : 'Activate'}
                                style={{ borderColor: '#2e7d32', color: skill.isActive ? '#fff' : '#2e7d32' }}
                              >
                                <i className={`fas ${skill.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                              </button>
                              
                              <button
                                onClick={() => handleDelete(skill.slug, skill.title)}
                                className="btn btn-sm btn-outline-danger rounded-pill"
                                title="Delete"
                              >
                                <i className="fas fa-trash"></i>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Back to Dashboard Card */}
          <div className="card shadow-sm border-0" style={{ borderRadius: '16px' }}>
            <div className="card-body p-4">
              <Link 
                to="/admin" 
                className="btn btn-outline-secondary rounded-pill px-4 py-2 fw-medium"
              >
                <i className="fas fa-arrow-left me-2"></i>Back to Dashboard
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SkillList;
