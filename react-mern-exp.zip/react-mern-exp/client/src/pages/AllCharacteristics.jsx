import React, { useEffect, useState } from 'react';
import CharacteristicsDataApi from '../api/CharacteristicsDataApi';
import CharacteristicCard from '../components/characteristic/CharacteristicCard';
import Layout from '../layouts/Layout';

const AllCharacteristics = () => {
    const [characteristics, setCharacteristics] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filters, setFilters] = useState({
        category: '',
        featured: false,
        search: ''
    });

    useEffect(() => {
        fetchCharacteristics();
    }, [filters]);

    const fetchCharacteristics = async () => {
        try {
            setLoading(true);
            const data = await CharacteristicsDataApi.getAllCharacteristics(filters);
            setCharacteristics(data.data || data);
        } catch (error) {
            console.error('Error fetching characteristics:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleFilterChange = (key, value) => {
        setFilters(prev => ({
            ...prev,
            [key]: value
        }));
    };

    return (
        <Layout>
            <div className="br-breadcrumb padding-tb-100 bg-img" 
                 style={{backgroundImage: 'url(/assets/img/bg/breadcrumb.jpg)'}}>
                <div className="container">
                    <div className="row">
                        <div className="col-12">
                            <div className="breadcrumb-content text-center">
                                <h2>My Characteristics</h2>
                                <ul className="breadcrumb-list">
                                    <li><a href="/">Home</a></li>
                                    <li>Characteristics</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <section className="br-portfolio padding-tb-80">
                <div className="container">
                    {/* Filters */}
                    <div className="row mb-4">
                        <div className="col-12">
                            <div className="filter-controls d-flex flex-wrap gap-3 justify-content-center">
                                <div className="form-group">
                                    <input
                                        type="text"
                                        placeholder="Search characteristics..."
                                        className="form-control"
                                        value={filters.search}
                                        onChange={(e) => handleFilterChange('search', e.target.value)}
                                    />
                                </div>
                                <div className="form-group">
                                    <select
                                        className="form-control"
                                        value={filters.category}
                                        onChange={(e) => handleFilterChange('category', e.target.value)}
                                    >
                                        <option value="">All Categories</option>
                                        <option value="personal">Personal</option>
                                        <option value="professional">Professional</option>
                                        <option value="technical">Technical</option>
                                        <option value="creative">Creative</option>
                                    </select>
                                </div>
                                <div className="form-check">
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        id="featuredOnly"
                                        checked={filters.featured}
                                        onChange={(e) => handleFilterChange('featured', e.target.checked)}
                                    />
                                    <label className="form-check-label" htmlFor="featuredOnly">
                                        Featured Only
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Characteristics Grid */}
                    <div className="row">
                        {loading ? (
                            <div className="col-12 text-center">
                                <div className="spinner-border text-primary" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        ) : characteristics.length > 0 ? (
                            characteristics.map((characteristic) => (
                                <div key={characteristic._id} className="col-lg-4 col-md-6 mb-4">
                                    <CharacteristicCard characteristic={characteristic} />
                                </div>
                            ))
                        ) : (
                            <div className="col-12 text-center">
                                <p className="text-muted">No characteristics found matching your criteria.</p>
                            </div>
                        )}
                    </div>
                </div>
            </section>
        </Layout>
    );
};

export default AllCharacteristics;
