import React from 'react'
import AllBlogsSection from '../components/all-blogs/AllBlogsSection';

const AllBlogs = () => {
    return (
        <main className='wrapper mt-5 pt-5'>
            <AllBlogsSection />
        </main>
    )
}

export default AllBlogs