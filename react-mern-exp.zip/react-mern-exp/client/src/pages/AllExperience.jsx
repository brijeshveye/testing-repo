import React, { useState, useEffect } from 'react';
import Layout from '../layouts/Layout';
import ExperienceDataApi from '../api/ExperienceDataApi';
import ExperienceCard from '../components/experience/ExperienceCard';

const AllExperience = () => {
  const [experience, setExperience] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    company: '',
    employmentType: 'all',
    current: 'all'
  });

  useEffect(() => {
    fetchExperience();
  }, [filters]);

  const fetchExperience = async () => {
    try {
      setLoading(true);
      const params = { isActive: true };
      
      if (filters.search) params.search = filters.search;
      if (filters.company) params.company = filters.company;
      if (filters.employmentType !== 'all') params.employmentType = filters.employmentType;
      if (filters.current !== 'all') params.current = filters.current;

      const data = await ExperienceDataApi.getExperienceData(params);
      setExperience(data);
    } catch (error) {
      console.error('Error fetching experience:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="mt-5 pt-2">
      <div className="about-sections bg1-img2 mt-5 pt-5 pb-5 overflow-hidden">
        <div className="container">
          <div className="row">
            <div className="col-12">
              <div className="text-center mb-5">
                <h1 className="head-text mtitle">My Professional Experience</h1>
                <p className="text-muted">
                  A comprehensive overview of my career journey, roles, and professional growth.
                </p>
              </div>

              {/* Filters */}
              <div className="card mb-4">
                <div className="card-body">
                  <div className="row g-3">
                    <div className="col-md-4">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Search experience..."
                        value={filters.search}
                        onChange={(e) => handleFilterChange('search', e.target.value)}
                      />
                    </div>
                    <div className="col-md-3">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Company..."
                        value={filters.company}
                        onChange={(e) => handleFilterChange('company', e.target.value)}
                      />
                    </div>
                    <div className="col-md-3">
                      <select
                        className="form-select"
                        value={filters.employmentType}
                        onChange={(e) => handleFilterChange('employmentType', e.target.value)}
                      >
                        <option value="all">All Types</option>
                        <option value="Full-time">Full-time</option>
                        <option value="Part-time">Part-time</option>
                        <option value="Contract">Contract</option>
                        <option value="Internship">Internship</option>
                        <option value="Freelance">Freelance</option>
                        <option value="Volunteer">Volunteer</option>
                      </select>
                    </div>
                    <div className="col-md-2">
                      <select
                        className="form-select"
                        value={filters.current}
                        onChange={(e) => handleFilterChange('current', e.target.value)}
                      >
                        <option value="all">All</option>
                        <option value="true">Current</option>
                        <option value="false">Past</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              {/* Loading State */}
              {loading ? (
                <div className="text-center py-5">
                  <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                  </div>
                </div>
              ) : (
                <>
                  {/* Experience Grid */}
                  {experience.length === 0 ? (
                    <div className="text-center py-5">
                      <i className="fas fa-briefcase fa-3x text-muted mb-3"></i>
                      <h3 className="text-muted">No Experience Found</h3>
                      <p className="text-muted">
                        {filters.search || filters.company || filters.employmentType !== 'all' || filters.current !== 'all'
                          ? 'Try adjusting your filters to see more results.'
                          : 'Experience information will be available soon.'
                        }
                      </p>
                    </div>
                  ) : (
                    <div className="row">
                      {experience.map((exp) => (
                        <ExperienceCard
                          key={exp._id}
                          experience={exp}
                          showActions={false}
                        />
                      ))}
                    </div>
                  )}

                  {/* Experience Stats */}
                  {experience.length > 0 && (
                    <div className="row mt-5">
                      <div className="col-12">
                        <div className="card bg-light">
                          <div className="card-body text-center">
                            <div className="row">
                              <div className="col-md-3">
                                <h4 className="text-primary">{experience.length}</h4>
                                <p className="mb-0">Total Roles</p>
                              </div>
                              <div className="col-md-3">
                                <h4 className="text-success">
                                  {experience.filter(exp => exp.current).length}
                                </h4>
                                <p className="mb-0">Current Positions</p>
                              </div>
                              <div className="col-md-3">
                                <h4 className="text-info">
                                  {[...new Set(experience.map(exp => exp.company))].length}
                                </h4>
                                <p className="mb-0">Companies</p>
                              </div>
                              <div className="col-md-3">
                                <h4 className="text-warning">
                                  {[...new Set(experience.map(exp => exp.employmentType))].length}
                                </h4>
                                <p className="mb-0">Employment Types</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
        <img src="assets/img/about/ellip.png" alt="img" className="ellip" />
        <img src="assets/img/about/ellip.png" alt="img" className="ellip2" />
      </div>
    </div>
  );
};

export default AllExperience;
