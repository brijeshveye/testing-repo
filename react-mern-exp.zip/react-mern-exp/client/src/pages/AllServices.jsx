import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getAllServices } from '../api/ServiceDataApi';
import ServiceCard from '../components/service/ServiceCard';

const AllServices = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterTag, setFilterTag] = useState('');

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      setLoading(true);
      const response = await getAllServices({ 
        isActive: true,
        populate: false 
      });
      
      if (response.success) {
        setServices(response.data);
      } else {
        setError('Failed to load services');
      }
    } catch (error) {
      console.error('Error fetching services:', error);
      setError('Failed to load services');
    } finally {
      setLoading(false);
    }
  };

  // Get all unique tags from services
  const allTags = [...new Set(services.flatMap(service => service.tags || []))];

  // Filter services based on search term and selected tag
  const filteredServices = services.filter(service => {
    const matchesSearch = service.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTag = !filterTag || (service.tags && service.tags.includes(filterTag));
    return matchesSearch && matchesTag;
  });

  // Separate featured and regular services
  const featuredServices = filteredServices.filter(service => service.featured);
  const regularServices = filteredServices.filter(service => !service.featured);

  if (loading) {
    return (
      <div className="container mt-5">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading services...</span>
          </div>
          <p className="mt-2">Loading services...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mt-5">
        <div className="text-center">
          <div className="alert alert-danger" role="alert">
            <i className="fas fa-exclamation-triangle me-2"></i>
            {error}
          </div>
          <button 
            className="btn btn-primary" 
            onClick={fetchServices}
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-5">
      {/* Header */}
      <div className="row mb-5">
        <div className="col-12 text-center">
          <h1 className="display-4 fw-bold mb-3">Our Services</h1>
          <p className="lead text-muted mb-4">
            Discover our comprehensive range of professional services designed to help you achieve your goals.
          </p>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb justify-content-center">
              <li className="breadcrumb-item">
                <Link to="/" className="text-decoration-none">Home</Link>
              </li>
              <li className="breadcrumb-item active" aria-current="page">Services</li>
            </ol>
          </nav>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="row mb-4">
        <div className="col-md-8">
          <div className="input-group">
            <span className="input-group-text">
              <i className="fas fa-search"></i>
            </span>
            <input
              type="text"
              className="form-control"
              placeholder="Search services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="col-md-4">
          <select
            className="form-select"
            value={filterTag}
            onChange={(e) => setFilterTag(e.target.value)}
          >
            <option value="">All Categories</option>
            {allTags.map(tag => (
              <option key={tag} value={tag}>
                {tag.charAt(0).toUpperCase() + tag.slice(1)}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Results Count */}
      <div className="row mb-4">
        <div className="col-12">
          <p className="text-muted">
            Showing {filteredServices.length} of {services.length} services
            {searchTerm && ` for "${searchTerm}"`}
            {filterTag && ` in "${filterTag}"`}
          </p>
        </div>
      </div>

      {/* Featured Services */}
      {featuredServices.length > 0 && (
        <div className="mb-5">
          <h2 className="h4 mb-4">
            <i className="fas fa-star text-warning me-2"></i>
            Featured Services
          </h2>
          <div className="row g-4">
            {featuredServices.map(service => (
              <div key={service._id} className="col-lg-4 col-md-6">
                <ServiceCard service={service} featured={true} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Regular Services */}
      {regularServices.length > 0 && (
        <div className="mb-5">
          {featuredServices.length > 0 && (
            <h2 className="h4 mb-4">All Services</h2>
          )}
          <div className="row g-4">
            {regularServices.map(service => (
              <div key={service._id} className="col-lg-4 col-md-6">
                <ServiceCard service={service} />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* No Services Found */}
      {filteredServices.length === 0 && (
        <div className="text-center py-5">
          <div className="mb-4">
            <i className="fas fa-search fa-3x text-muted"></i>
          </div>
          <h3 className="h4 mb-3">No Services Found</h3>
          <p className="text-muted mb-4">
            {searchTerm || filterTag
              ? 'Try adjusting your search criteria or filters.'
              : 'No services are currently available.'}
          </p>
          {(searchTerm || filterTag) && (
            <button
              className="btn btn-outline-primary"
              onClick={() => {
                setSearchTerm('');
                setFilterTag('');
              }}
            >
              Clear Filters
            </button>
          )}
        </div>
      )}

      {/* Call to Action */}
      {services.length > 0 && (
        <div className="text-center mt-5 py-5 bg-light rounded">
          <h3 className="h4 mb-3">Ready to Get Started?</h3>
          <p className="text-muted mb-4">
            Contact us today to discuss your project and see how we can help you achieve your goals.
          </p>
          <Link to="/#contact" className="btn btn-primary btn-lg">
            Get In Touch
          </Link>
        </div>
      )}
    </div>
  );
};

export default AllServices;
