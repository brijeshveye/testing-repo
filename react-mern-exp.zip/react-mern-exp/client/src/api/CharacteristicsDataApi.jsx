import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const CharacteristicsDataApi = {
  // Fetch all characteristics from the backend
  getCharacteristicsData: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams(params).toString();
      const url = queryParams ? `${API_BASE_URL}/characteristics?${queryParams}` : `${API_BASE_URL}/characteristics`;
      const response = await axios.get(url);
      return response.data.characteristics || response.data;
    } catch (error) {
      console.error('Error fetching characteristics:', error);
      return [];
    }
  },

  // Get characteristics for home page with limit
  getCharacteristicsForHome: async (limit = 6) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/characteristics?isActive=true&limit=${limit}&sortBy=order&sortOrder=asc`);
      return response.data.characteristics || response.data;
    } catch (error) {
      console.error('Error fetching characteristics for home:', error);
      return [];
    }
  },

  // Get featured characteristics
  getFeaturedCharacteristics: async (limit = 3) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/characteristics?featured=true&isActive=true&limit=${limit}&sortBy=order&sortOrder=asc`);
      return response.data.characteristics || response.data;
    } catch (error) {
      console.error('Error fetching featured characteristics:', error);
      return [];
    }
  },

  // Get characteristics by category
  getCharacteristicsByCategory: async (category, limit = null) => {
    try {
      const params = { category, isActive: true };
      if (limit) params.limit = limit;
      
      const response = await axios.get(`${API_BASE_URL}/characteristics`, { params });
      return response.data.characteristics || response.data;
    } catch (error) {
      console.error('Error fetching characteristics by category:', error);
      return [];
    }
  },

  // Get categories (extract from characteristic data)
  getCategories: async () => {
    try {
      const characteristicData = await CharacteristicsDataApi.getCharacteristicsData({ isActive: true });
      let categories = new Set();
      
      characteristicData.forEach(characteristic => {
        if (characteristic.category) {
          categories.add(characteristic.category);
        }
      });

      return Array.from(categories).sort();
    } catch (error) {
      console.error('Error fetching categories:', error);
      return [];
    }
  },

  // Get characteristic details by slug
  getCharacteristicDetails: async (slug, includeInactive = false) => {
    try {
      const params = includeInactive ? '?includeInactive=true' : '';
      const response = await axios.get(`${API_BASE_URL}/characteristics/${slug}${params}`);
      return {
        success: true,
        data: response.data
      };
    } catch (error) {
      console.error('Error fetching characteristic details:', error);
      return {
        success: false,
        message: error.response?.data?.message || 'Failed to fetch characteristic details'
      };
    }
  },

  // Get characteristic statistics
  getCharacteristicStats: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/characteristics/stats`);
      return response.data;
    } catch (error) {
      console.error('Error fetching characteristic stats:', error);
      return null;
    }
  },

  // Create a new characteristic
  createCharacteristic: async (characteristicData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/characteristics`, characteristicData);
      return response.data;
    } catch (error) {
      console.error('Error creating characteristic:', error);
      throw error;
    }
  },

  // Update characteristic
  updateCharacteristic: async (slug, characteristicData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/characteristics/${slug}`, characteristicData);
      return response.data;
    } catch (error) {
      console.error('Error updating characteristic:', error);
      throw error;
    }
  },

  // Delete characteristic
  deleteCharacteristic: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/characteristics/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting characteristic:', error);
      throw error;
    }
  },

  // Update characteristic order
  updateCharacteristicOrder: async (characteristics) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/characteristics/order/update`, { characteristics });
      return response.data;
    } catch (error) {
      console.error('Error updating characteristic order:', error);
      throw error;
    }
  },

  // Toggle featured status
  toggleFeatured: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/characteristics/${slug}/toggle-featured`);
      return response.data;
    } catch (error) {
      console.error('Error toggling featured status:', error);
      throw error;
    }
  },

  // Toggle active status
  toggleActive: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/characteristics/${slug}/toggle-active`);
      return response.data;
    } catch (error) {
      console.error('Error toggling active status:', error);
      throw error;
    }
  },

  // Legacy support methods (for backward compatibility)
  getCharacteristics: async () => {
    return await CharacteristicsDataApi.getCharacteristicsData({ isActive: true });
  },

  getCharacteristicList: async () => {
    try {
      const characteristics = await CharacteristicsDataApi.getCharacteristicsData({ isActive: true });
      return characteristics.map(characteristic => ({
        title: characteristic.title,
        link: `/characteristics/${characteristic.slug}`
      }));
    } catch (error) {
      console.error('Error fetching characteristic list:', error);
      return [];
    }
  }
};

// Named exports for convenience
export const getAllCharacteristics = CharacteristicsDataApi.getCharacteristicsData;
export const getCharacteristic = (slug, includeInactive = false) => CharacteristicsDataApi.getCharacteristicDetails(slug, includeInactive);
export const createCharacteristic = CharacteristicsDataApi.createCharacteristic;
export const updateCharacteristic = CharacteristicsDataApi.updateCharacteristic;
export const deleteCharacteristic = CharacteristicsDataApi.deleteCharacteristic;
export const getCharacteristicStats = CharacteristicsDataApi.getCharacteristicStats;
export const toggleCharacteristicFeatured = CharacteristicsDataApi.toggleFeatured;
export const toggleCharacteristicActive = CharacteristicsDataApi.toggleActive;
export const updateCharacteristicOrder = CharacteristicsDataApi.updateCharacteristicOrder;

export default CharacteristicsDataApi;
