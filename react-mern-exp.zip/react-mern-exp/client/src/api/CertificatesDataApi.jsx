import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const CertificatesDataApi = {
  // Fetch all certificates from the backend
  getCertificatesData: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams(params).toString();
      const url = queryParams ? `${API_BASE_URL}/certificates?${queryParams}` : `${API_BASE_URL}/certificates`;
      const response = await axios.get(url);
      return response.data;
    } catch (error) {
      console.error('Error fetching certificates:', error);
      return [];
    }
  },

  // Get certificates for home page with limit
  getCertificatesForHome: async (limit = 6) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/certificates?isActive=true&limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching certificates for home:', error);
      return [];
    }
  },

  // Get featured certificates
  getFeaturedCertificates: async (limit = 8) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/certificates?featured=true&isActive=true&limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching featured certificates:', error);
      return [];
    }
  },

  // Get certificate categories (extract from certificates data)
  getCertificateCategories: async () => {
    try {
      const certificatesData = await CertificatesDataApi.getCertificatesData({ isActive: true });
      let categories = new Set();
      
      certificatesData.forEach(certificate => {
        if (certificate.category) {
          categories.add(certificate.category);
        }
      });

      // Add 'All' category to the set
      categories.add('All');

      return Array.from(categories).sort(); // Return categories as a sorted array
    } catch (error) {
      console.error('Error fetching certificate categories:', error);
      return ['All'];
    }
  },

  // Get certificate details by slug
  getCertificateDetails: async (slug) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/certificates/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching certificate details:', error);
      return null;
    }
  },

  // Create a new certificate
  createCertificate: async (certificateData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/certificates`, certificateData);
      return response.data;
    } catch (error) {
      console.error('Error creating certificate:', error);
      throw error;
    }
  },

  // Update certificate
  updateCertificate: async (slug, certificateData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/certificates/${slug}`, certificateData);
      return response.data;
    } catch (error) {
      console.error('Error updating certificate:', error);
      throw error;
    }
  },

  // Delete certificate
  deleteCertificate: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/certificates/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting certificate:', error);
      throw error;
    }
  },

  // Update certificates order
  updateCertificatesOrder: async (certificates) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/certificates/order/update`, { certificates });
      return response.data;
    } catch (error) {
      console.error('Error updating certificates order:', error);
      throw error;
    }
  },

  // Toggle featured status
  toggleFeatured: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/certificates/${slug}/toggle-featured`);
      return response.data;
    } catch (error) {
      console.error('Error toggling featured status:', error);
      throw error;
    }
  },

  // Toggle active status
  toggleActive: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/certificates/${slug}/toggle-active`);
      return response.data;
    } catch (error) {
      console.error('Error toggling active status:', error);
      throw error;
    }
  }
};

export default CertificatesDataApi;
