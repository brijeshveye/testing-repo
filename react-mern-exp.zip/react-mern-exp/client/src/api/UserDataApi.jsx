import axios from 'axios';
import { title } from "framer-motion/client";
import BlogsDataApi from "./BlogsDataApi";
import ProjectsDataApi from "./ProjectsDataApi";
import ServiceDataApi from "./ServiceDataApi";

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const UserDataApi = {

    getHeaderData: () => {
        let headerData = [
            {
                "title": "Home",
                "url": "/"
            },
            {
                "title": "About",
                "url": "/about"
            },
            {
                "title": "Services",
                "url": "/services"
            },
            {
                "title": "Projects",
                "url": "/projects"
            },
            {
                "title": "Testimonials",
                "url": "/testimonials"
            },
            {
                "title": "Blogs",
                "url": "/blogs"
            },
            {
                "title": "Contact",
                "url": "/contact"
            }
        ]

        return headerData;
    },

    getAbout: () => {
        let aboutData = {
            "name": "John Doe",
            "email": "abc@gmai.com",
            "phone": "+01 9033 333 333 / 123",
            "address": "123 Main St, Anytown, USA",
            "tagline": "A lead Full Stack Developer based in India",
            "bio": "I design and develop services for customers of all sizes, specializing in creating stylish, modern websites, web services and online stores. My passion is to design digital user experiences through the bold interface and meaningful interactions. Check out my Portfolio",
            "afterBio": "I like work with new people. New people new Experiences.",
            "linkedin": "https://www.linkedin.com/in/johndoe",
            "github": "https://github.com",
            "twitter": "https://twitter.com/johndoe",
            "instagram": "https://instagram.com/johndoe",
            "facebook": "https://facebook.com/johndoe",
            "website": "https://johndoe.com",
            "cv": "https://johndoe.com/cv.pdf",

        }

        return aboutData;
    },

    getMyProcess: () => {
        let processData = [
            {
                "tag": "Approach",
                "number": 1,
                "title": "Requirement Analysis",
                "bgText": "Understanding client needs and project requirements.",
                "link": "requirement-analysis"
            },
            {
                "tag": "Design",
                "number": 2,
                "title": "Design",
                "bgText": "Creating wireframes and prototypes for the project.",
                "link": "design"
            },
            {
                "tag": "Development",
                "number": 3,
                "title": "Development",
                "bgText": "Coding and implementing the project features.",
                "link": "development"
            },
            {
                "tag": "Testing",
                "number": 4,
                "title": "Testing",
                "bgText": "Ensuring the application is bug-free and meets quality standards.",
                "link": "testing"
            },
            {
                "tag": "Deployment",
                "number": 5,
                "title": "Deployment",
                "bgText": "Launching the application to production.",
                "link": "deployment"
            }
        ];

        return processData;
    },


    getMyCertificates: () => {
        let certificatesData = [
            {
                "title": "Certified Full Stack Developer",
                "description": "Full Stack Web Development Certification",
                "issuer": "Tech Institute",
                "year": "2021",
                "image": "assets/img/project/pro1.png",
                "url": "https://example.com/certificate/full-stack-developer",
                "category": "Web Development",
            },
            {
                "title": "JavaScript Mastery",
                "description": "Advanced JavaScript Programming",
                "issuer": "Online Academy",
                "year": "2020",
                "image": "assets/img/project/pro2.png",
                "url": "https://example.com/certificate/javascript-mastery",
                "category": "Programming"
            },
            {
                "title": "UI/UX Design Fundamentals",
                "description": "Introduction to UI/UX Design Principles",
                "issuer": "Design School",
                "year": "2019",
                "image": "assets/img/project/pro3.png",
                "url": "https://example.com/certificate/ui-ux-design-fundamentals",
                "category": "Frameworks"
            },
            {
                "title": "Cloud Computing Essentials",
                "description": "Understanding Cloud Technologies and Services",
                "issuer": "Cloud Academy",
                "year": "2022",
                "image": "assets/img/project/pro4.png",
                "url": "https://example.com/certificate/cloud-computing-essentials",
                "category": "Cloud Computing"
            },
            {
                "title": "Data Science with Python",
                "description": "Data Analysis and Machine Learning with Python",
                "issuer": "Data Science Institute",
                "year": "2023",
                "image": "assets/img/project/pro5.png",
                "url": "https://example.com/certificate/data-science-python",
                "category": "Cloud Computing"
            },
            {
                "title": "Agile Project Management",
                "description": "Agile Methodologies and Project Management Techniques",
                "issuer": "Project Management Institute",
                "year": "2021",
                "image": "assets/img/project/pro6.png",
                "url": "https://example.com/certificate/agile-project-management",
                "category": "Frameworks"
            }
        ];

        return certificatesData;
    },

    getCertificateCategories: () => {
        let certificatesData = UserDataApi.getMyCertificates() || []; // Ensure certificatesData is not undefined
        if (certificatesData.length === 0) {
            return ["all"]; // Return only "all" if no certificates are found
        }

        const categories = certificatesData
            .map(cert => cert.category)
            .sort(); // Sort before creating a Set to ensure proper order

        const uniqueCategories = [...new Set(categories)]; // Remove duplicates
        uniqueCategories.unshift("all"); // Add "all" category at the beginning

        return uniqueCategories;
    },

    getCertificatesForHome: (limit = 8) => {
        let certificatesData = UserDataApi.getMyCertificates();
        let shuffledCertificates = certificatesData.sort(() => 0.5 - Math.random()).slice(0, limit);
        return shuffledCertificates;
    },

    getMyProjects: async () => {
        const projectsData = await ProjectsDataApi.getProjectsData();
        return projectsData;
    },

    getProjectsForHome: async (limit = 6) => {
        const projectsData = await ProjectsDataApi.getPorjectsForHome(limit);
        return projectsData;
    },

    getProjectCategories: async () => {
        const projectCategories = await ProjectsDataApi.getProjectCategories();
        return projectCategories;
    },

    getProjectDetails: async (slug) => {
        const projectDetails = await ProjectsDataApi.getProjectDetails(slug);
        return projectDetails;
    },

    convertSlugToTitle: (slug) => {
        let title = slug.replace(/-/g, ' ').replace(/^\w/, c => c.toUpperCase());
        return title;
    },

    getBlogs: async () => {
        const BlogsData = await BlogsDataApi.getBlogsData();
        return BlogsData;
    },

    getBlogsForHome: async (limit = 6) => {
        const blogsData = await BlogsDataApi.getBlogsForHome(limit);
        return blogsData;
    },

    getBlogDetails: async (slug) => {
        const blogDetails = await BlogsDataApi.getBlogDetails(slug);
        return blogDetails;
    },

    getBlogTags: async () => {
        const blogTags = await BlogsDataApi.getBlogTags();
        return blogTags;
    },

    getBlogCategories: async () => {
        const blogCategories = await BlogsDataApi.getBlogCategories();
        return blogCategories;
    },

    getRecentBlogPosts: async () => {
        const recentBlogs = await BlogsDataApi.getRecentBlogs();
        return recentBlogs;
    },

    getServices: (limit = 4) => {
        let servicesData = ServiceDataApi.getServices(limit);
        return servicesData;
    },

    getServiceDetails: (slug) => {
        let serviceDetails = ServiceDataApi.getServiceDetails(slug);
        return serviceDetails;
    },

    getCoffieData: () => {
        let coffeeData = {
            "title": "Take a Coffee & chat with me",
            "email": "hello@itsbrijesh.me",
            "phone": "+91 7017 442 328",
        }
        return coffeeData;
    },

    getMarqueeData: () => {
        let marqueeData = [
            "Web Development",
            "Mobile App Development",
            "UI/UX Design",
            "Software Engineering",
            "Cloud Computing",
            "Data Science"
        ];

        return marqueeData;
    },


    getFooterMarqueeData: () => {
        let footerMarqueeData = [
            "© 2023 John Doe. All rights reserved.",
            "Follow me on social media: LinkedIn, GitHub, Twitter, Instagram, Facebook",
            "Contact me for collaborations and inquiries"
        ];

        return footerMarqueeData;
    },

    getFooterData: () => {
        let footerData = {
            "address": "123 Main St, Anytown, USA",
            "email": "abc@gmail.com",
            "phone": "+01 9033 333 333 / 123",
            "socialLinks": {
                "linkedin": "https://www.linkedin.com/in/johndoe",
                "github": "",
                "twitter": "https://twitter.com/johndoe",
                "instagram": "https://instagram.com/johndoe",
                "facebook": "https://facebook.com/johndoe",
                "website": "https://johndoe.com"
            },
        }

        return footerData;
    },

    getCopyrightData: () => {
        let currentYear = new Date().getFullYear();
        let copyrightData = {
            "text": `© ${currentYear} John Doe. All rights reserved.`,
            "socialLinks": {
                "linkedin": "https://www.linkedin.com/in/johndoe",
                "github": "",
                "twitter": "https://twitter.com/johndoe",
                "instagram": "https://instagram.com/johndoe",
                "facebook": "https://facebook.com/johndoe",
                "website": "https://johndoe.com"
            }
        };

        return copyrightData;
    },

    getServiceList: async () => {
        try {
            const serviceList = await ServiceDataApi.getServiceList();
            return serviceList;
        } catch (error) {
            console.error('Error fetching service list:', error);
            return [];
        }
    },

}

export default UserDataApi