import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const EducationDataApi = {
  // Fetch all education records from the backend
  getEducationData: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams(params).toString();
      const url = queryParams ? `${API_BASE_URL}/education?${queryParams}` : `${API_BASE_URL}/education`;
      const response = await axios.get(url);
      return response.data.education || response.data;
    } catch (error) {
      console.error('Error fetching education:', error);
      return [];
    }
  },

  // Get education for home page with limit
  getEducationForHome: async (limit = 3) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/education?isActive=true&limit=${limit}&sortBy=startDate&sortOrder=desc`);
      return response.data.education || response.data;
    } catch (error) {
      console.error('Error fetching education for home:', error);
      return [];
    }
  },

  // Get featured education
  getFeaturedEducation: async (limit = 3) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/education?featured=true&isActive=true&limit=${limit}&sortBy=startDate&sortOrder=desc`);
      return response.data.education || response.data;
    } catch (error) {
      console.error('Error fetching featured education:', error);
      return [];
    }
  },

  // Get current education (ongoing studies)
  getCurrentEducation: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/education?current=true&isActive=true`);
      return response.data.education || response.data;
    } catch (error) {
      console.error('Error fetching current education:', error);
      return [];
    }
  },

  // Get education by degree type
  getEducationByDegree: async (degree, limit = null) => {
    try {
      const params = { degree, isActive: true };
      if (limit) params.limit = limit;
      
      const response = await axios.get(`${API_BASE_URL}/education`, { params });
      return response.data.education || response.data;
    } catch (error) {
      console.error('Error fetching education by degree:', error);
      return [];
    }
  },

  // Get education by institution
  getEducationByInstitution: async (institution, limit = null) => {
    try {
      const params = { institution, isActive: true };
      if (limit) params.limit = limit;
      
      const response = await axios.get(`${API_BASE_URL}/education`, { params });
      return response.data.education || response.data;
    } catch (error) {
      console.error('Error fetching education by institution:', error);
      return [];
    }
  },

  // Get degree types (extract from education data)
  getDegreeTypes: async () => {
    try {
      const educationData = await EducationDataApi.getEducationData({ isActive: true });
      let degrees = new Set();
      
      educationData.forEach(edu => {
        if (edu.degree) {
          degrees.add(edu.degree);
        }
      });

      return Array.from(degrees).sort();
    } catch (error) {
      console.error('Error fetching degree types:', error);
      return [];
    }
  },

  // Get institutions (extract from education data)
  getInstitutions: async () => {
    try {
      const educationData = await EducationDataApi.getEducationData({ isActive: true });
      let institutions = new Set();
      
      educationData.forEach(edu => {
        if (edu.institution) {
          institutions.add(edu.institution);
        }
      });

      return Array.from(institutions).sort();
    } catch (error) {
      console.error('Error fetching institutions:', error);
      return [];
    }
  },

  // Get education details by slug
  getEducationDetails: async (slug) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/education/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching education details:', error);
      return null;
    }
  },

  // Get education statistics
  getEducationStats: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/education/stats`);
      return response.data;
    } catch (error) {
      console.error('Error fetching education stats:', error);
      return null;
    }
  },

  // Create a new education record
  createEducation: async (educationData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/education`, educationData);
      return response.data;
    } catch (error) {
      console.error('Error creating education:', error);
      throw error;
    }
  },

  // Update education record
  updateEducation: async (slug, educationData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/education/${slug}`, educationData);
      return response.data;
    } catch (error) {
      console.error('Error updating education:', error);
      throw error;
    }
  },

  // Delete education record
  deleteEducation: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/education/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting education:', error);
      throw error;
    }
  },

  // Update education order
  updateEducationOrder: async (education) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/education/order/update`, { education });
      return response.data;
    } catch (error) {
      console.error('Error updating education order:', error);
      throw error;
    }
  },

  // Toggle featured status
  toggleFeatured: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/education/${slug}/toggle-featured`);
      return response.data;
    } catch (error) {
      console.error('Error toggling featured status:', error);
      throw error;
    }
  },

  // Toggle active status
  toggleActive: async (slug) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/education/${slug}/toggle-active`);
      return response.data;
    } catch (error) {
      console.error('Error toggling active status:', error);
      throw error;
    }
  }
};

export default EducationDataApi;
