import axios from 'axios';

// API base URL
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

/**
 * Enhanced User Data API that can fetch from both database and individual JSON files
 */
const UserDataApiNew = {
    
    /**
     * Get complete user data from the database
     */
    getUserData: async () => {
        try {
            const response = await axios.get(`${API_BASE_URL}/user`);
            return response.data;
        } catch (error) {
            console.error('Error fetching user data:', error);
            throw error;
        }
    },

    /**
     * Get specific section data from the database
     */
    getSection: async (section) => {
        try {
            const response = await axios.get(`${API_BASE_URL}/user`);
            return response.data[section] || (section === 'aboutData' ? {} : []);
        } catch (error) {
            console.error(`Error fetching ${section}:`, error);
            return section === 'aboutData' ? {} : [];
        }
    },

    /**
     * Update specific section in the database
     */
    updateSection: async (section, data) => {
        try {
            const response = await axios.put(`${API_BASE_URL}/user/${section}`, data);
            return response.data;
        } catch (error) {
            console.error(`Error updating ${section}:`, error);
            throw error;
        }
    },

    /**
     * Add item to array section
     */
    addItem: async (section, item) => {
        try {
            const response = await axios.post(`${API_BASE_URL}/user/${section}/add`, item);
            return response.data;
        } catch (error) {
            console.error(`Error adding item to ${section}:`, error);
            throw error;
        }
    },

    /**
     * Update specific item in array section
     */
    updateItem: async (section, index, item) => {
        try {
            const response = await axios.put(`${API_BASE_URL}/user/${section}/${index}`, item);
            return response.data;
        } catch (error) {
            console.error(`Error updating item in ${section}:`, error);
            throw error;
        }
    },

    /**
     * Delete specific item from array section
     */
    deleteItem: async (section, index) => {
        try {
            const response = await axios.delete(`${API_BASE_URL}/user/${section}/${index}`);
            return response.data;
        } catch (error) {
            console.error(`Error deleting item from ${section}:`, error);
            throw error;
        }
    },

    // Convenience methods for specific sections

    /**
     * Get about data
     */
    getAboutData: async () => {
        return await UserDataApiNew.getSection('aboutData');
    },

    /**
     * Get education data
     */
    getEducationData: async () => {
        return await UserDataApiNew.getSection('educationData');
    },

    /**
     * Get experience data
     */
    getExperienceData: async () => {
        return await UserDataApiNew.getSection('experienceData');
    },

    /**
     * Get services data
     */
    getServicesData: async () => {
        return await UserDataApiNew.getSection('servicesData');
    },

    /**
     * Get process data
     */
    getProcessData: async () => {
        return await UserDataApiNew.getSection('processData');
    },

    /**
     * Get certificates data
     */
    getCertificatesData: async () => {
        return await UserDataApiNew.getSection('certificatesData');
    },

    /**
     * Get testimonials data
     */
    getTestimonialsData: async () => {
        return await UserDataApiNew.getSection('testimonialsData');
    },

    /**
     * Get certificate categories
     */
    getCertificateCategories: async () => {
        try {
            const certificatesData = await UserDataApiNew.getCertificatesData();
            const categories = [...new Set(certificatesData.map(cert => cert.category))].filter(Boolean);
            return categories;
        } catch (error) {
            console.error('Error getting certificate categories:', error);
            return [];
        }
    },

    /**
     * Get certificates for home page (with limit)
     */
    getCertificatesForHome: async (limit = 6) => {
        try {
            const certificatesData = await UserDataApiNew.getCertificatesData();
            return certificatesData.slice(0, limit);
        } catch (error) {
            console.error('Error getting certificates for home:', error);
            return [];
        }
    },

    /**
     * Get header navigation data
     */
    getHeaderData: () => {
        return [
            { title: "Home", url: "/" },
            { title: "About", url: "/about" },
            { title: "Services", url: "/services" },
            { title: "Projects", url: "/projects" },
            { title: "Testimonials", url: "/testimonials" },
            { title: "Blogs", url: "/blogs" },
            { title: "Contact", url: "/contact" }
        ];
    },

    // Legacy compatibility methods (return promises for consistency)
    
    /**
     * Legacy getAbout method (now async)
     */
    getAbout: async () => {
        return await UserDataApiNew.getAboutData();
    },

    /**
     * Legacy getMyProcess method (now async)
     */
    getMyProcess: async () => {
        return await UserDataApiNew.getProcessData();
    },

    /**
     * Legacy getMyCertificates method (now async)
     */
    getMyCertificates: async () => {
        return await UserDataApiNew.getCertificatesData();
    }
};

export default UserDataApiNew;
