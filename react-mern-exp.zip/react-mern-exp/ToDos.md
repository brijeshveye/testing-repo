## Todos

# Todo Level - Brijesh (Level 1)

Smaller the font size of years in Education Cards - ✅
Fix Testimonials details edit in Admin panel - ✅
Use Phone and email from about section inside Coffee Section - ✅

Fix bottom padding in Certificate heading - ✅

Add option to also use Svg in Characteristic Cards - ✅
Fix Read more button in Characteristic boxes - ✅
Increase icon size and bottom padding in Characteristic boxes - ✅
Icons not working in characteristic cards

Make tagline font italic in Footer - ✅

Add Take Backup and Restore Option in json format - ✅

Error on adding resume

Control pin and login from Admin panel - ✅
Make pin validation server based, with max try option and auto block for 2 hours feature - ✅

Redesigning Required in:
- Project - ✅
- Testimonials - ✅
- Blogs - ✅

Deploy CI/CD Pipeline with Github Actions

Toaster added for notifications - ✅

Logo Change - ✅

Make Contact Form Working - ✅

# Pending or Stucked (Level 2)
1. 2 photos in hero and about
2. Update photos in 5 services


# Frontend Pages (Level 3)
- All Skills Page
- All Experience Page
- All Education Page
- All Certificates Page
- All Projects Page
- All Blogs Page
- Service Details Page
- Project Details Page
- Blog Details Page







===========================
# ToDo Level - Generic (Level 1)

Add Content in 5 Services
Add Certificates
Add Projects
Add Blogs and Events

Add keywords in two marquee Text Sliders - ✅

Change Read more text in characteristic cards - ✅

# Pending or Stucked (Level 3)
1. Add more skills
2. Add Resume PDF



========================
Change Read more text in characteristic cards:
Key Trait , Core Strength , Core Skill , Clear Vision , Main Edge ,Key Aspect , Clear Goal , Key Quality

Main Power , Real Strength


===============================================


Web Development
I design and develop responsive, user-friendly websites using modern tools and frameworks. With hands-on experience in both frontend and backend technologies, I build scalable, maintainable web solutions tailored to specific project needs and user goals.

My development process focuses on writing clean, efficient code and creating thoughtful, accessible user experiences. Whether it’s crafting a sleek landing page, building a dynamic dashboard, or deploying a full-stack web
application — I aim for performance, clarity, and long-term maintainability.

I also work on cross-platform development using Flutter, allowing me to deliver seamless experiences on both web and mobile platforms.

🧠 Core Competencies
Responsive & mobile-first design

UI/UX integration from Figma to code

RESTful API integration

Clean architecture & scalable backend

Web performance optimization

Cross-browser compatibility

SEO-friendly structure

Tech Stack
Frontend
HTML, CSS, JavaScript

React

Sass / SCSS

Bootstrap

Materialize CSS

Backend
Node.js

Express.js

MongoDB

Cross-Platform
Flutter (for web & mobile)
Shruti Kansal
16:16
mobile 
UI UX
AI and ML 
Digital and Marketing SEO


------------------------------------------------------
📱 Mobile App Development
I build high-performance mobile applications that offer seamless user experiences across devices. With expertise in both native Android and Flutter, I develop apps that are fast, intuitive, and scalable — whether it’s a business solution, a utility tool, or a user-facing product.

I take a user-first approach, combining clean design with optimized performance, accessibility, and responsiveness.
My experience includes working with real-time data, authentication, and cloud-connected databases to ensure apps are reliable and user-friendly.

For backend and data handling, I integrate MongoDB and MySQL, ensuring efficient and structured data flow. I prioritize clean architecture and maintainable code, making updates and scaling seamless.

From MVPs to fully-featured apps, I deliver products that are not just functional — but polished, thoughtful, and ready for real-world use.
✅ Key Capabilities
Cross-platform app development with Flutter

Native Android development

Backend and API integration

Real-time database handling

Clean and scalable codebase

Smooth UI and responsive UX

App testing, deployment, and versioning

Offline-first architecture (when needed)

🛠️ Tech Stack
Mobile Technologies
Android (Java/Kotlin)

Flutter (Dart) — for iOS & Android cross-platform apps

Databases & Backend
MongoDB

MySQL

----------------------------------------------------------
🎨 Designing & UI/UX
I create clean, intuitive, and engaging user interfaces that prioritize user experience and visual appeal. Leveraging industry-standard tools like Figma, Adobe XD, Illustrator, and Photoshop, I transform concepts into interactive designs that balance aesthetics with functionality.

My approach focuses on user-centered design principles, ensuring that every element serves a purpose and enhances usability. From wireframes and prototypes to final UI mockups,
I collaborate closely with clients and developers to deliver seamless digital experiences.

By combining creativity with practical design workflows, I help brands communicate their message effectively and provide users with memorable interactions.
✅ Key Capabilities
User-centered wireframing & prototyping

High-fidelity UI design

Interactive prototypes for testing & feedback

Visual branding & graphic design

Design system creation & maintenance

Cross-platform design consistency

Collaboration with development teams
🛠️ Design Tools & Skills
Figma (70%)

Adobe XD (65%)

Illustrator (70%)

Photoshop (Proficient)


---------------------------------------------------------
🤖 Artificial Intelligence & Machine Learning
I develop intelligent systems and predictive models that harness the power of data to solve complex problems and automate decision-making processes. Using state-of-the-art algorithms and frameworks, I build machine learning models tailored to real-world applications — from data analysis and classification to natural language processing and computer vision.
My work involves data preprocessing, feature engineering, model training, and deployment, with a strong emphasis on accuracy, efficiency, and scalability. I’m proficient in leveraging AI tools and libraries to create solutions that enhance business insights, automate workflows, and deliver smart user experiences.
✅ Key Capabilities
Data analysis & preprocessing

Supervised & unsupervised learning

Neural networks & deep learning

Natural language processing (NLP)

Computer vision & image processing

Model evaluation & optimization

Deployment & integration of ML models
🛠️ Tech Stack
Python (NumPy, Pandas, Scikit-learn)

TensorFlow & Keras

PyTorch

OpenCV

NLP libraries (NLTK, SpaCy)

Data visualization tools


-----------------------------------------------------------
📈 Digital Marketing & SEO
I help businesses grow their online presence by crafting effective digital marketing strategies combined with robust SEO practices. From keyword research and on-page optimization to content marketing and link building, I focus on driving targeted traffic and improving search engine rankings.
My approach is data-driven and results-oriented, leveraging analytics tools to monitor performance, identify opportunities, and continuously optimize campaigns. Whether it’s boosting brand visibility, increasing conversions, or enhancing user engagement, I aim to deliver measurable outcomes that align with business goals.
✅ Key Capabilities
Keyword research & competitive analysis

On-page & off-page SEO

Content strategy & marketing

Google Analytics & Search Console

Social media marketing

Pay-per-click (PPC) campaigns

Website audit & technical SEO

Performance tracking & reporting
Tools & Platforms
Google Analytics & Search Console

SEMrush & Ahrefs

Moz

Google Ads

Facebook & Instagram Ads Manager

WordPress SEO plugins (Yoast, Rank Math)
