# Contact Form Email Setup Guide

This guide will help you set up the email functionality for the contact forms.

## Prerequisites

1. Gmail account (or any SMTP provider)
2. App Password for Gmail (if using Gmail)

## Setup Steps

### 1. Create .env file

Copy the `.env.example` file to `.env` in the server directory:

```bash
cp .env.example .env
```

### 2. Configure Email Settings

Edit the `.env` file with your email configuration:

```env
# For Gmail
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASS=your-app-password
SMTP_FROM=noreply@yourdomain.com
ADMIN_EMAIL=your-admin-email@gmail.com
```

### 3. Gmail App Password Setup

1. Go to [Google Account settings](https://myaccount.google.com/)
2. Click on "Security" in the left sidebar
3. Under "How you sign in to Google", click "App passwords"
4. Select "Mail" as the app and "Other" as the device
5. Enter a name like "Portfolio Contact Form"
6. Copy the generated app password and use it as `SMTP_PASS`

### 4. Alternative Email Providers

#### SendGrid
```env
SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=587
SMTP_USER=apikey
SMTP_PASS=your-sendgrid-api-key
```

#### Mailgun
```env
SMTP_HOST=smtp.mailgun.org
SMTP_PORT=587
SMTP_USER=your-mailgun-username
SMTP_PASS=your-mailgun-password
```

#### AWS SES
```env
SMTP_HOST=email-smtp.us-east-1.amazonaws.com
SMTP_PORT=587
SMTP_USER=your-ses-access-key
SMTP_PASS=your-ses-secret-key
```

## Features

### Contact Form Functionality

1. **Form Validation**: Both client-side and server-side validation
2. **Email Notifications**: Automatic email to admin when form is submitted
3. **Auto-Reply**: Confirmation email sent to the user
4. **Database Storage**: All contact messages are stored in MongoDB
5. **Status Management**: Messages can be marked as new, read, replied, or archived

### Admin Features

1. **Contact List**: View all contact messages with filtering
2. **Status Updates**: Mark messages as read, replied, or archived
3. **Delete Messages**: Remove unwanted contact messages
4. **Pagination**: Handle large numbers of contact messages

## API Endpoints

- `POST /api/contact` - Submit contact form
- `GET /api/contact` - Get all contacts (admin)
- `PUT /api/contact/:id/status` - Update contact status
- `DELETE /api/contact/:id` - Delete contact

## Testing

1. Start the server: `npm start`
2. Fill out the contact form on the frontend
3. Check your email for notifications
4. Check the database for stored messages
5. Use the admin panel to manage messages

## Troubleshooting

### Email Not Sending

1. Check your `.env` file configuration
2. Verify your email credentials
3. Check if your email provider blocks less secure apps
4. Look at server logs for error messages

### Gmail Issues

1. Enable 2-factor authentication
2. Generate an app password (don't use your regular password)
3. Make sure "Less secure app access" is enabled (if not using app password)

### Database Issues

1. Make sure MongoDB is running
2. Check the connection string in `.env`
3. Verify the database name is correct

## Security Notes

1. Never commit your `.env` file to version control
2. Use strong passwords and app passwords
3. Consider using environment variables in production
4. Implement rate limiting for the contact form
5. Add CAPTCHA for additional security

## Production Deployment

1. Use environment variables instead of `.env` file
2. Use a proper email service (SendGrid, Mailgun, AWS SES)
3. Implement proper error handling and logging
4. Add rate limiting and CAPTCHA
5. Use HTTPS for all communications
