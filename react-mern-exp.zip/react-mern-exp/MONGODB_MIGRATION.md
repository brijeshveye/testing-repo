# MongoDB Migration Guide

This guide explains the complete migration from JSON file storage to MongoDB for the portfolio server.

## 🎯 What's Changed

The server has been completely refactored to use MongoDB instead of JSON files for data storage:

### ✅ Completed
- **Database Connection**: MongoDB connection setup in `config/database.js`
- **Mongoose Models**: Created comprehensive schemas for all data types
- **Controllers Refactored**: All controllers now use MongoDB operations
- **Enhanced Routes**: Added CRUD operations for better data management
- **Upload Tracking**: File uploads are now tracked in MongoDB
- **Migration Script**: Automated script to import existing JSON data

### 📁 New File Structure
```
server/
├── config/
│   └── database.js          # MongoDB connection
├── models/
│   ├── Project.js           # Project schema with dynamic widgets
│   ├── Blog.js              # Blog schema with dynamic widgets
│   ├── User.js              # User/portfolio owner schema
│   └── Upload.js            # File upload tracking schema
├── controllers/
│   ├── projectController.js # MongoDB-based project operations
│   ├── blogController.js    # MongoDB-based blog operations
│   └── userController.js    # MongoDB-based user operations
├── routes/
│   ├── projectRoutes.js     # Enhanced project routes
│   ├── blogRoutes.js        # Enhanced blog routes
│   ├── userRoutes.js        # Enhanced user routes
│   └── uploadRoutes.js      # Enhanced upload routes with MongoDB tracking
├── scripts/
│   └── migrateData.js       # Data migration utility
└── data/
    ├── backup/              # Backup directory for JSON files
    ├── projectsData.json    # Legacy (will be backed up)
    ├── blogsData.json       # Legacy (will be backed up)
    └── userData.json        # Legacy (will be backed up)
```

## 🚀 Setup Instructions

### 1. Install MongoDB
Make sure MongoDB is installed and running on your system:
- **Windows**: Download from [MongoDB Download Center](https://www.mongodb.com/try/download/community)
- **macOS**: `brew install mongodb-community`
- **Linux**: Follow [MongoDB installation guide](https://docs.mongodb.com/manual/installation/)

### 2. Environment Variables
Create a `.env` file in the server directory:
```env
MONGODB_URI=mongodb://localhost:27017/portfolio
NODE_ENV=development
```

### 3. Install Dependencies
```bash
cd server
npm install
```

### 4. Run Migration (Optional)
If you have existing JSON data to migrate:
```bash
npm run migrate
```

### 5. Start Server
```bash
npm start
# or for development
npm run dev
```

## 📊 Data Models

### Project Schema
```javascript
{
  title: String (required)
  description: String
  shortDescription: String
  slug: String (unique)
  image: String
  images: [String]
  technologies: [String]
  liveUrl: String
  githubUrl: String
  category: String
  status: String (enum: draft, in-progress, completed, on-hold)
  featured: Boolean
  startDate: Date
  endDate: Date
  widgets: [Mixed] // Dynamic content widgets
  domains: [String]
  details: Mixed // Additional project details
}
```

### Blog Schema
```javascript
{
  title: String (required)
  content: String
  excerpt: String
  slug: String (unique)
  featuredImage: String
  images: [String]
  tags: [String]
  category: String
  author: String
  published: Boolean
  featured: Boolean
  readTime: Number
  publishedAt: Date
  widgets: [Mixed] // Dynamic content widgets
  seo: Mixed // SEO metadata
  details: Mixed // Additional blog details
}
```

### User Schema
```javascript
{
  userId: String (unique, default: 'portfolio_owner')
  aboutData: {
    name: String
    email: String
    phone: String
    bio: String
    profileImage: String
    location: String
    resume: String
  }
  educationData: [EducationItem]
  experienceData: [ExperienceItem]
  skillsData: [SkillItem]
  certificatesData: [CertificateItem]
  testimonialsData: [TestimonialItem]
  servicesData: [ServiceItem]
  socialLinks: {
    linkedin: String
    github: String
    twitter: String
    instagram: String
    facebook: String
    website: String
  }
}
```

### Upload Schema
```javascript
{
  filename: String (required)
  originalName: String (required)
  mimetype: String (required)
  size: Number (required)
  category: String (enum: general, profile, project, blog, content, banner, thumbnail)
  url: String (required)
  uploadedBy: String
  isActive: Boolean (for soft delete)
}
```

## 🛠 API Endpoints

### Projects
- `GET /api/projects` - Get all projects
- `GET /api/projects/:slug` - Get project by slug
- `POST /api/projects` - Create new project
- `PUT /api/projects/:slug` - Update project
- `DELETE /api/projects/:slug` - Delete project

### Blogs
- `GET /api/blogs` - Get all blogs
- `GET /api/blogs/:slug` - Get blog by slug
- `POST /api/blogs` - Create new blog
- `PUT /api/blogs/:slug` - Update blog
- `DELETE /api/blogs/:slug` - Delete blog

### User Data
- `GET /api/user` - Get all user data
- `PUT /api/user/:section` - Update specific section (aboutData, educationData, etc.)
- `POST /api/user/:section/add` - Add item to array section
- `PUT /api/user/:section/:index` - Update specific item in array section
- `DELETE /api/user/:section/:index` - Delete specific item from array section

### File Uploads
- `POST /api/upload/upload` - Single file upload
- `POST /api/upload/upload-multiple` - Multiple files upload
- `GET /api/upload/list/:category` - List files in category
- `GET /api/upload/all` - Get all uploads (admin)
- `DELETE /api/upload/delete/:category/:filename` - Delete file

## 🔄 Migration Process

The migration script (`scripts/migrateData.js`) will:

1. **Connect to MongoDB**
2. **Clear existing data** (if any)
3. **Import Projects** from `projectsData.json`
4. **Import Blogs** from `blogsData.json`
5. **Import User Data** from `userData.json`
6. **Create Backups** of original JSON files in `data/backup/`

### Running Migration
```bash
# Run the migration script
npm run migrate

# Or run directly
node scripts/migrateData.js
```

## 🎨 Dynamic Widgets Support

Both Project and Blog models support dynamic widgets for flexible content management:

```javascript
// Example widgets array
widgets: [
  {
    type: 'text',
    content: 'This is a text widget',
    order: 1
  },
  {
    type: 'image',
    src: '/uploads/project/image.jpg',
    alt: 'Project screenshot',
    caption: 'Main application interface',
    order: 2
  },
  {
    type: 'code',
    language: 'javascript',
    content: 'console.log("Hello World");',
    order: 3
  },
  {
    type: 'gallery',
    images: ['/uploads/project/img1.jpg', '/uploads/project/img2.jpg'],
    order: 4
  }
]
```

## 🔍 Query Examples

### Get Featured Projects
```javascript
const featuredProjects = await Project.find({ featured: true, status: 'completed' })
  .sort({ createdAt: -1 })
  .limit(6);
```

### Get Published Blogs by Category
```javascript
const techBlogs = await Blog.find({ category: 'technology', published: true })
  .sort({ publishedAt: -1 });
```

### Update User About Section
```javascript
await User.findOneAndUpdate(
  { userId: 'portfolio_owner' },
  { $set: { aboutData: newAboutData } },
  { new: true, upsert: true }
);
```

## 🔒 Security Features

- **Input Validation**: Mongoose schema validation
- **Unique Constraints**: Slugs are automatically validated for uniqueness
- **File Upload Security**: File type and size restrictions
- **Soft Delete**: Files are marked as inactive instead of hard deletion
- **Error Handling**: Comprehensive error handling and logging

## 🧪 Testing

After migration, test the following:

1. **Start the server**: `npm start`
2. **Test API endpoints** using tools like Postman or curl
3. **Verify data integrity** by comparing with original JSON files
4. **Test file uploads** and MongoDB tracking
5. **Test CRUD operations** for all models

## 📝 Notes

- **Legacy Files**: Original JSON files are backed up automatically during migration
- **Environment**: Make sure MongoDB is running before starting the server
- **Performance**: Indexes are created for better query performance
- **Scalability**: MongoDB provides better scalability than JSON files
- **Backup**: Regular MongoDB backups are recommended for production

## 🆘 Troubleshooting

### MongoDB Connection Issues
```bash
# Check if MongoDB is running
mongosh

# Start MongoDB service (Windows)
net start MongoDB

# Start MongoDB service (macOS/Linux)
sudo systemctl start mongod
```

### Migration Errors
- Ensure MongoDB is running and accessible
- Check that JSON files exist and are valid
- Verify file permissions in the data directory

### Performance Issues
- Check MongoDB indexes: `db.collection.getIndexes()`
- Monitor query performance with MongoDB Compass
- Consider adding custom indexes for frequently queried fields

---

🎉 **Congratulations!** Your portfolio server is now powered by MongoDB with enhanced features and better performance.
