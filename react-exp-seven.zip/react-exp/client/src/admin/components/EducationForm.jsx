import React, { useState, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import EducationDataApi from '../../api/EducationDataApi';

const EducationForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    institution: '',
    degree: '',
    fieldOfStudy: '',
    startDate: '',
    endDate: '',
    current: false,
    grade: '',
    description: '',
    activities: [],
    achievements: [],
    skills: [],
    location: '',
    image: '',
    certificateUrl: '',
    transcriptUrl: '',
    featured: false,
    isActive: true,
    order: 0
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Predefined options
  const degreeTypes = [
    'Bachelor of Science', 'Bachelor of Arts', 'Bachelor of Engineering', 'Bachelor of Technology',
    'Master of Science', 'Master of Arts', 'Master of Engineering', 'Master of Technology', 'MBA',
    'PhD', 'Doctorate', 'Diploma', 'Certificate', 'Associate Degree', 'Other'
  ];

  const fieldOptions = [
    'Computer Science', 'Information Technology', 'Software Engineering', 'Computer Engineering',
    'Data Science', 'Artificial Intelligence', 'Cybersecurity', 'Web Development',
    'Mobile Development', 'UI/UX Design', 'Digital Marketing', 'Business Administration',
    'Project Management', 'Other'
  ];

  useEffect(() => {
    if (isEdit) {
      fetchEducationData();
    }
  }, [isEdit, slug]);

  const fetchEducationData = async () => {
    try {
      setLoading(true);
      const data = await EducationDataApi.getEducationDetails(slug);
      if (data) {
        setFormData({
          title: data.title || '',
          institution: data.institution || '',
          degree: data.degree || '',
          fieldOfStudy: data.fieldOfStudy || '',
          startDate: data.startDate ? new Date(data.startDate).toISOString().split('T')[0] : '',
          endDate: data.endDate ? new Date(data.endDate).toISOString().split('T')[0] : '',
          current: data.current || false,
          grade: data.grade || '',
          description: data.description || '',
          activities: data.activities || [],
          achievements: data.achievements || [],
          skills: data.skills || [],
          location: data.location || '',
          image: data.image || '',
          certificateUrl: data.certificateUrl || '',
          transcriptUrl: data.transcriptUrl || '',
          featured: data.featured || false,
          isActive: data.isActive !== undefined ? data.isActive : true,
          order: data.order || 0
        });
      }
    } catch (err) {
      setError('Failed to fetch education data');
      console.error('Error fetching education:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleArrayChange = (index, field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => 
        i === index ? value : item
      )
    }));
  };

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], '']
    }));
  };

  const removeArrayItem = (index, field) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Clean up empty array items
      const cleanedData = {
        ...formData,
        activities: formData.activities.filter(activity => activity.trim()),
        achievements: formData.achievements.filter(achievement => achievement.trim()),
        skills: formData.skills.filter(skill => skill.trim()),
        order: parseInt(formData.order)
      };

      // Validate dates
      if (cleanedData.startDate && cleanedData.endDate && !cleanedData.current) {
        const start = new Date(cleanedData.startDate);
        const end = new Date(cleanedData.endDate);
        if (start > end) {
          setError('End date cannot be before start date');
          setLoading(false);
          return;
        }
      }

      if (isEdit) {
        await EducationDataApi.updateEducation(slug, cleanedData);
        setSuccess('Education record updated successfully!');
      } else {
        await EducationDataApi.createEducation(cleanedData);
        setSuccess('Education record created successfully!');
      }

      setTimeout(() => {
        navigate('/admin/education');
      }, 1500);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save education record');
      console.error('Error saving education:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-12">
          <div className="d-flex justify-content-between align-items-center mb-4">
            <h1>{isEdit ? 'Edit Education Record' : 'Create New Education Record'}</h1>
            <Link to="/admin/education" className="btn btn-secondary">
              <i className="fas fa-arrow-left me-2"></i>Back to List
            </Link>
          </div>
        </div>
      </div>

      {error && (
        <div className="alert alert-danger">
          <i className="fas fa-exclamation-triangle me-2"></i>
          {error}
        </div>
      )}

      {success && (
        <div className="alert alert-success">
          <i className="fas fa-check-circle me-2"></i>
          {success}
        </div>
      )}

      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-body">
              <form onSubmit={handleSubmit}>
                {/* Basic Information */}
                <div className="row mb-3">
                  <div className="col-md-6">
                    <label className="form-label">Title/Program Name *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                      required
                      placeholder="e.g., Computer Science, Web Development"
                    />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Institution *</label>
                    <input
                      type="text"
                      className="form-control"
                      name="institution"
                      value={formData.institution}
                      onChange={handleChange}
                      required
                      placeholder="e.g., University of Technology"
                    />
                  </div>
                </div>

                <div className="row mb-3">
                  <div className="col-md-6">
                    <label className="form-label">Degree Type</label>
                    <select
                      className="form-select"
                      name="degree"
                      value={formData.degree}
                      onChange={handleChange}
                    >
                      <option value="">Select Degree Type</option>
                      {degreeTypes.map(degree => (
                        <option key={degree} value={degree}>
                          {degree}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Field of Study</label>
                    <select
                      className="form-select"
                      name="fieldOfStudy"
                      value={formData.fieldOfStudy}
                      onChange={handleChange}
                    >
                      <option value="">Select Field of Study</option>
                      {fieldOptions.map(field => (
                        <option key={field} value={field}>
                          {field}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="row mb-3">
                  <div className="col-md-4">
                    <label className="form-label">Start Date *</label>
                    <input
                      type="date"
                      className="form-control"
                      name="startDate"
                      value={formData.startDate}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="col-md-4">
                    <label className="form-label">End Date</label>
                    <input
                      type="date"
                      className="form-control"
                      name="endDate"
                      value={formData.endDate}
                      onChange={handleChange}
                      disabled={formData.current}
                    />
                  </div>
                  <div className="col-md-4">
                    <label className="form-label">Location</label>
                    <input
                      type="text"
                      className="form-control"
                      name="location"
                      value={formData.location}
                      onChange={handleChange}
                      placeholder="City, Country"
                    />
                  </div>
                </div>

                <div className="row mb-3">
                  <div className="col-md-6">
                    <label className="form-label">Grade/GPA</label>
                    <input
                      type="text"
                      className="form-control"
                      name="grade"
                      value={formData.grade}
                      onChange={handleChange}
                      placeholder="e.g., 3.8/4.0, First Class, A+"
                    />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Display Order</label>
                    <input
                      type="number"
                      className="form-control"
                      name="order"
                      value={formData.order}
                      onChange={handleChange}
                      min="0"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Description</label>
                  <textarea
                    className="form-control"
                    name="description"
                    rows="4"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Brief description of the program, coursework, or achievements..."
                  />
                </div>

                {/* Activities */}
                <div className="mb-3">
                  <label className="form-label">Activities & Societies</label>
                  {formData.activities.map((activity, index) => (
                    <div key={index} className="input-group mb-2">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Activity or society"
                        value={activity}
                        onChange={(e) => handleArrayChange(index, 'activities', e.target.value)}
                      />
                      <button
                        type="button"
                        className="btn btn-outline-danger"
                        onClick={() => removeArrayItem(index, 'activities')}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    onClick={() => addArrayItem('activities')}
                  >
                    <i className="fas fa-plus me-2"></i>Add Activity
                  </button>
                </div>

                {/* Achievements */}
                <div className="mb-3">
                  <label className="form-label">Achievements & Awards</label>
                  {formData.achievements.map((achievement, index) => (
                    <div key={index} className="input-group mb-2">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Achievement or award"
                        value={achievement}
                        onChange={(e) => handleArrayChange(index, 'achievements', e.target.value)}
                      />
                      <button
                        type="button"
                        className="btn btn-outline-danger"
                        onClick={() => removeArrayItem(index, 'achievements')}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    onClick={() => addArrayItem('achievements')}
                  >
                    <i className="fas fa-plus me-2"></i>Add Achievement
                  </button>
                </div>

                {/* Skills */}
                <div className="mb-3">
                  <label className="form-label">Skills Gained</label>
                  {formData.skills.map((skill, index) => (
                    <div key={index} className="input-group mb-2">
                      <input
                        type="text"
                        className="form-control"
                        placeholder="Skill gained during education"
                        value={skill}
                        onChange={(e) => handleArrayChange(index, 'skills', e.target.value)}
                      />
                      <button
                        type="button"
                        className="btn btn-outline-danger"
                        onClick={() => removeArrayItem(index, 'skills')}
                      >
                        <i className="fas fa-times"></i>
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    className="btn btn-outline-secondary btn-sm"
                    onClick={() => addArrayItem('skills')}
                  >
                    <i className="fas fa-plus me-2"></i>Add Skill
                  </button>
                </div>

                {/* Links */}
                <div className="row mb-3">
                  <div className="col-md-6">
                    <label className="form-label">Institution Logo/Image URL</label>
                    <input
                      type="url"
                      className="form-control"
                      name="image"
                      value={formData.image}
                      onChange={handleChange}
                      placeholder="https://example.com/logo.png"
                    />
                  </div>
                  <div className="col-md-6">
                    <label className="form-label">Certificate URL</label>
                    <input
                      type="url"
                      className="form-control"
                      name="certificateUrl"
                      value={formData.certificateUrl}
                      onChange={handleChange}
                      placeholder="https://example.com/certificate.pdf"
                    />
                  </div>
                </div>

                <div className="mb-3">
                  <label className="form-label">Transcript URL</label>
                  <input
                    type="url"
                    className="form-control"
                    name="transcriptUrl"
                    value={formData.transcriptUrl}
                    onChange={handleChange}
                    placeholder="https://example.com/transcript.pdf"
                  />
                </div>

                {/* Status Options */}
                <div className="row mb-4">
                  <div className="col-md-4">
                    <div className="form-check form-switch">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        name="current"
                        id="current"
                        checked={formData.current}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="current">
                        <i className="fas fa-clock text-info me-2"></i>
                        Currently Studying
                      </label>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="form-check form-switch">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        name="featured"
                        id="featured"
                        checked={formData.featured}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="featured">
                        <i className="fas fa-star text-warning me-2"></i>
                        Featured Education
                      </label>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="form-check form-switch">
                      <input
                        className="form-check-input"
                        type="checkbox"
                        name="isActive"
                        id="isActive"
                        checked={formData.isActive}
                        onChange={handleChange}
                      />
                      <label className="form-check-label" htmlFor="isActive">
                        <i className="fas fa-eye text-success me-2"></i>
                        Active/Visible
                      </label>
                    </div>
                  </div>
                </div>

                {/* Submit Buttons */}
                <div className="d-flex gap-2">
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? (
                      <>
                        <span className="spinner-border spinner-border-sm me-2" role="status"></span>
                        {isEdit ? 'Updating...' : 'Creating...'}
                      </>
                    ) : (
                      <>
                        <i className={`fas ${isEdit ? 'fa-save' : 'fa-plus'} me-2`}></i>
                        {isEdit ? 'Update Education' : 'Create Education'}
                      </>
                    )}
                  </button>
                  <Link to="/admin/education" className="btn btn-secondary">
                    Cancel
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </div>

        {/* Preview Card */}
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h5 className="card-title mb-0">
                <i className="fas fa-eye me-2"></i>Preview
              </h5>
            </div>
            <div className="card-body">
              <div className="d-flex align-items-start mb-3">
                <div 
                  className="me-3 d-flex align-items-center justify-content-center rounded"
                  style={{ 
                    width: '50px', 
                    height: '50px', 
                    backgroundColor: '#007bff',
                    color: '#fff'
                  }}
                >
                  <i className="fas fa-graduation-cap"></i>
                </div>
                
                <div className="flex-grow-1">
                  <h6 className="mb-1">{formData.title || 'Program Title'}</h6>
                  <div className="text-primary mb-1">{formData.institution || 'Institution Name'}</div>
                  {formData.location && (
                    <small className="text-muted">
                      <i className="fas fa-map-marker-alt me-1"></i>
                      {formData.location}
                    </small>
                  )}
                </div>
                
                {formData.current && (
                  <span className="badge bg-success">Current</span>
                )}
              </div>

              {(formData.degree || formData.fieldOfStudy) && (
                <div className="mb-2">
                  {formData.degree && (
                    <span className="badge bg-primary me-2">{formData.degree}</span>
                  )}
                  {formData.fieldOfStudy && (
                    <span className="badge bg-secondary">{formData.fieldOfStudy}</span>
                  )}
                </div>
              )}

              {formData.startDate && (
                <div className="mb-2">
                  <small className="text-muted">
                    <i className="fas fa-calendar-alt me-1"></i>
                    {new Date(formData.startDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })} - 
                    {formData.current ? ' Present' : 
                     formData.endDate ? ` ${new Date(formData.endDate).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })}` : ' Present'}
                  </small>
                </div>
              )}

              {formData.grade && (
                <div className="mb-2">
                  <small className="text-muted">
                    <strong>Grade:</strong> {formData.grade}
                  </small>
                </div>
              )}

              {formData.description && (
                <p className="text-muted small mb-2">
                  {formData.description.substring(0, 100)}
                  {formData.description.length > 100 && '...'}
                </p>
              )}

              <div className="d-flex justify-content-center gap-1 mt-2">
                {formData.featured && (
                  <span className="badge bg-warning text-dark">
                    <i className="fas fa-star me-1"></i>Featured
                  </span>
                )}
                <span className={`badge ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                  {formData.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EducationForm;
