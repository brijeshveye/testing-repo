import React, { useState } from 'react';
import {
  WIDGET_TYPES,
  HeadingWidget,
  ParagraphWidget,
  ListWidget,
  SpacerWidget,
  ImageWidget,
  YouTubeWidget
} from './DynamicWidgets';

const WidgetManager = ({ widgets = [], onChange, onImageUpload }) => {
  const [isEditing, setIsEditing] = useState(true);

  const addWidget = (type) => {
    const newWidget = {
      id: Date.now().toString(),
      type,
      data: getDefaultData(type)
    };
    const newWidgets = [...widgets, newWidget];
    onChange(newWidgets);
  };

  const updateWidget = (id, data) => {
    const newWidgets = widgets.map(widget =>
      widget.id === id ? { ...widget, data } : widget
    );
    onChange(newWidgets);
  };

  const deleteWidget = (id) => {
    const newWidgets = widgets.filter(widget => widget.id !== id);
    onChange(newWidgets);
  };

  const moveWidget = (fromIndex, toIndex) => {
    const newWidgets = [...widgets];
    const [removed] = newWidgets.splice(fromIndex, 1);
    newWidgets.splice(toIndex, 0, removed);
    onChange(newWidgets);
  };

  const getDefaultData = (type) => {
    switch (type) {
      case WIDGET_TYPES.HEADING:
        return { text: 'New Heading', level: 'h2' };
      case WIDGET_TYPES.PARAGRAPH:
        return { text: 'Enter your paragraph text here...' };
      case WIDGET_TYPES.LIST:
        return { items: ['List item 1', 'List item 2'], type: 'ul' };
      case WIDGET_TYPES.SPACER:
        return { height: 30 };
      case WIDGET_TYPES.IMAGE:
        return { 
          src: '', 
          alt: '', 
          caption: '', 
          alignment: 'center', 
          size: 'medium',
          title: '',
          description: '',
          layout: 'single',
          images: [],
          width: '100%',
          borderRadius: '0px'
        };
      case WIDGET_TYPES.YOUTUBE:
        return { url: '', title: '', description: '' };
      default:
        return {};
    }
  };

  const renderWidget = (widget, index) => {
    const commonProps = {
      data: widget.data,
      onChange: (data) => updateWidget(widget.id, data),
      onDelete: () => deleteWidget(widget.id),
      isEditing,
      onImageUpload
    };

    let WidgetComponent;
    switch (widget.type) {
      case WIDGET_TYPES.HEADING:
        WidgetComponent = HeadingWidget;
        break;
      case WIDGET_TYPES.PARAGRAPH:
        WidgetComponent = ParagraphWidget;
        break;
      case WIDGET_TYPES.LIST:
        WidgetComponent = ListWidget;
        break;
      case WIDGET_TYPES.SPACER:
        WidgetComponent = SpacerWidget;
        break;
      case WIDGET_TYPES.IMAGE:
        WidgetComponent = ImageWidget;
        break;
      case WIDGET_TYPES.YOUTUBE:
        WidgetComponent = YouTubeWidget;
        break;
      default:
        return null;
    }

    return (
      <div key={widget.id} className="widget-container position-relative">
        {isEditing && (
          <div className="widget-controls d-flex position-absolute" style={{ top: '-10px', right: '-10px', zIndex: 10 }}>
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary me-1"
              onClick={() => moveWidget(index, Math.max(0, index - 1))}
              disabled={index === 0}
              title="Move Up"
            >
              <i className="fas fa-arrow-up"></i>
            </button>
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary"
              onClick={() => moveWidget(index, Math.min(widgets.length - 1, index + 1))}
              disabled={index === widgets.length - 1}
              title="Move Down"
            >
              <i className="fas fa-arrow-down"></i>
            </button>
          </div>
        )}
        <WidgetComponent {...commonProps} />
      </div>
    );
  };

  return (
    <div className="widget-manager">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <h5>Dynamic Content</h5>
        <div className="btn-group">
          <button
            type="button"
            className={`btn btn-sm ${isEditing ? 'btn-primary' : 'btn-outline-primary'}`}
            onClick={() => setIsEditing(true)}
          >
            <i className="fas fa-edit me-1"></i>Edit
          </button>
          <button
            type="button"
            className={`btn btn-sm ${!isEditing ? 'btn-success' : 'btn-outline-success'}`}
            onClick={() => setIsEditing(false)}
          >
            <i className="fas fa-eye me-1"></i>Preview
          </button>
        </div>
      </div>

      {isEditing && (
        <div className="widget-toolbar mb-4 p-3 bg-light rounded">
          <h6 className="mb-3">Add Widgets</h6>
          <div className="row g-2">
            <div className="col-md-2 col-6">
              <button
                type="button"
                className="btn btn-outline-primary w-100 btn-sm"
                onClick={() => addWidget(WIDGET_TYPES.HEADING)}
              >
                <i className="fas fa-heading d-block mb-1"></i>
                <small>Heading</small>
              </button>
            </div>
            <div className="col-md-2 col-6">
              <button
                type="button"
                className="btn btn-outline-primary w-100 btn-sm"
                onClick={() => addWidget(WIDGET_TYPES.PARAGRAPH)}
              >
                <i className="fas fa-paragraph d-block mb-1"></i>
                <small>Paragraph</small>
              </button>
            </div>
            <div className="col-md-2 col-6">
              <button
                type="button"
                className="btn btn-outline-primary w-100 btn-sm"
                onClick={() => addWidget(WIDGET_TYPES.LIST)}
              >
                <i className="fas fa-list d-block mb-1"></i>
                <small>List</small>
              </button>
            </div>
            <div className="col-md-2 col-6">
              <button
                type="button"
                className="btn btn-outline-primary w-100 btn-sm"
                onClick={() => addWidget(WIDGET_TYPES.SPACER)}
              >
                <i className="fas fa-arrows-alt-v d-block mb-1"></i>
                <small>Spacer</small>
              </button>
            </div>
            <div className="col-md-2 col-6">
              <button
                type="button"
                className="btn btn-outline-primary w-100 btn-sm"
                onClick={() => addWidget(WIDGET_TYPES.IMAGE)}
              >
                <i className="fas fa-image d-block mb-1"></i>
                <small>Image</small>
              </button>
            </div>
            <div className="col-md-2 col-6">
              <button
                type="button"
                className="btn btn-outline-primary w-100 btn-sm"
                onClick={() => addWidget(WIDGET_TYPES.YOUTUBE)}
              >
                <i className="fab fa-youtube d-block mb-1"></i>
                <small>YouTube</small>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="widgets-container">
        {widgets.length === 0 ? (
          <div className="text-center text-muted py-5">
            <i className="fas fa-plus-circle fa-3x mb-3"></i>
            <p>No content widgets added yet.<br />Click the buttons above to add dynamic content.</p>
          </div>
        ) : (
          widgets.map((widget, index) => renderWidget(widget, index))
        )}
      </div>
    </div>
  );
};

export default WidgetManager;
