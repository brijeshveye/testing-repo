import React, { useState, useEffect } from 'react';
import AdminPinAuth from './AdminPinAuth';
import AdminNavBar from './AdminNavBar';

const AdminProtectedRoute = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    checkAuthentication();
  }, []);

  const checkAuthentication = () => {
    const deviceInfo = getDeviceInfo();
    const sessionKey = `adminSession_${deviceInfo}`;
    const sessionData = localStorage.getItem(sessionKey);
    const adminToken = localStorage.getItem('adminToken');
    
    if (sessionData && adminToken) {
      const { expiresAt } = JSON.parse(sessionData);
      const now = Date.now();
      
      if (now < expiresAt) {
        setIsAuthenticated(true);
      } else {
        // Session expired
        localStorage.removeItem(sessionKey);
        localStorage.removeItem('adminToken');
        setIsAuthenticated(false);
      }
    } else {
      setIsAuthenticated(false);
    }
    
    setIsLoading(false);
  };

  const getDeviceInfo = () => {
    // Create a unique device fingerprint
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('Device fingerprint', 2, 2);
    
    const fingerprint = canvas.toDataURL() + 
                       navigator.userAgent + 
                       navigator.language + 
                       window.screen.width + 'x' + window.screen.height;
    
    return btoa(fingerprint).slice(0, 32);
  };

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
  };

  if (isLoading) {
    return (
      <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">Loading...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AdminPinAuth onSuccess={handleAuthSuccess} />;
  }

  return (
    <div className="admin-layout">
      <AdminNavBar />
      <div className="admin-content">
        {children}
      </div>
    </div>
  );
};

export default AdminProtectedRoute;
