import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ResumeUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [currentResume, setCurrentResume] = useState('');
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    fetchCurrentResume();
  }, []);

  const fetchCurrentResume = async () => {
    try {
      const response = await axios.get('/api/user');
      setCurrentResume(response.data.aboutData?.resume || '');
    } catch (error) {
      console.error('Error fetching user data:', error);
      setMessage('Error loading current resume data');
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files?.[0];
    
    if (!file) return;

    // Validate file
    if (file.type !== 'application/pdf') {
      setMessage('Please select a PDF file.');
      event.target.value = '';
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setMessage('File size must be less than 10MB.');
      event.target.value = '';
      return;
    }

    setMessage('');
    setUploading(true);

    try {
      // Upload file
      const formData = new FormData();
      formData.append('file', file);

      console.log('Uploading file:', file.name, 'Size:', file.size);
      
      const uploadResponse = await axios.post('/api/upload/resume', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        timeout: 30000, // 30 second timeout
      });
      
      console.log('Upload response:', uploadResponse.data);
      
      const resumeUrl = uploadResponse.data.url;

      // Update user profile
      const userResponse = await axios.get('/api/user');
      const aboutData = { ...userResponse.data.aboutData, resume: resumeUrl };
      
      await axios.put('/api/user/aboutData', aboutData);

      setCurrentResume(resumeUrl);
      setMessage('Resume uploaded successfully!');
      event.target.value = '';

      // Redirect after success
      setTimeout(() => navigate('/admin/user'), 1500);

    } catch (error) {
      console.error('Upload error:', error);
      if (error.response) {
        setMessage(`Upload failed: ${error.response.data?.error || error.response.statusText}`);
      } else if (error.request) {
        setMessage('Upload failed: Server not responding. Please check if the server is running.');
      } else {
        setMessage('Upload failed: ' + error.message);
      }
      event.target.value = '';
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveResume = async () => {
    if (!window.confirm('Remove current resume?')) return;

    try {
      const userResponse = await axios.get('/api/user');
      const aboutData = { ...userResponse.data.aboutData, resume: '' };
      
      await axios.put('/api/user/aboutData', aboutData);
      
      setCurrentResume('');
      setMessage('Resume removed successfully!');
    } catch (error) {
      console.error('Remove error:', error);
      setMessage('Failed to remove resume.');
    }
  };

  return (
    <div className="container mt-4">
      <h3>Resume Management</h3>
      
      {message && (
        <div className={`alert ${message.includes('success') ? 'alert-success' : 'alert-danger'}`}>
          {message}
        </div>
      )}

      {currentResume && (
        <div className="card mb-4">
          <div className="card-body">
            <h5>Current Resume</h5>
            <a href={currentResume} target="_blank" rel="noopener noreferrer" className="btn btn-outline-primary btn-sm me-2">
              <i className="fas fa-eye me-1"></i>View Resume
            </a>
            <button onClick={handleRemoveResume} className="btn btn-outline-danger btn-sm" disabled={uploading}>
              <i className="fas fa-trash me-1"></i>Remove
            </button>
          </div>
        </div>
      )}

      <div className="card">
        <div className="card-body">
          <h5>Upload New Resume</h5>
          <div className="mb-3">
            <label className="form-label">Select PDF File (Max 10MB)</label>
            <input
              type="file"
              className="form-control"
              accept=".pdf"
              onChange={handleFileUpload}
              disabled={uploading}
            />
          </div>
          
          {uploading && (
            <div className="alert alert-info">
              <i className="fas fa-spinner fa-spin me-2"></i>
              Uploading resume...
            </div>
          )}

          <button 
            onClick={() => navigate('/admin/user')} 
            className="btn btn-secondary"
            disabled={uploading}
          >
            <i className="fas fa-arrow-left me-1"></i>Back to Profile
          </button>
        </div>
      </div>

      <div className="alert alert-info mt-4">
        <h6>Requirements:</h6>
        <ul className="mb-0">
          <li>PDF format only</li>
          <li>Maximum 10MB file size</li>
          <li>Will appear on your portfolio's About section</li>
        </ul>
      </div>
    </div>
  );
};

export default ResumeUpload;
