import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { createService, getService, updateService } from '../../api/ServiceDataApi';
import WidgetManager from './widgets/WidgetManager';
import { ImageUploader, uploadImage, IMAGE_CATEGORIES } from './ImageUpload';

const ServiceForm = () => {
  const navigate = useNavigate();
  const { slug } = useParams();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDescription: '',
    icon: '',
    iconClass: '',
    image: '',
    bannerImage: '',
    widgets: [], // Dynamic content widgets
    details: {
      section1: { para1: '', para2: '' },
      section2: { image1: '', image2: '', image3: '', image4: '' },
      section3: { title: '', para: '' },
      section4: { image1: '', video: '' }
    },
    faqs: [],
    category: 'general',
    tag: '',
    number: 1,
    bgText: '',
    technologies: [],
    features: [],
    pricing: {
      startingPrice: 0,
      currency: 'USD',
      pricingModel: 'custom'
    },
    deliveryTime: '',
    processSteps: [],
    featured: false,
    isActive: true,
    seoTitle: '',
    seoDescription: '',
    seoKeywords: []
  });

  const [activeTab, setActiveTab] = useState('basic');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  useEffect(() => {
    if (isEdit) {
      fetchService();
    }
  }, [slug, isEdit]);

  const fetchService = async () => {
    try {
      setLoading(true);
      const response = await getService(slug, true);
      if (response.success) {
        const serviceData = response.data;
        setFormData({
          title: serviceData.title || '',
          description: serviceData.description || '',
          shortDescription: serviceData.shortDescription || '',
          icon: serviceData.icon || '',
          iconClass: serviceData.iconClass || '',
          image: serviceData.image || '',
          bannerImage: serviceData.bannerImage || '',
          widgets: serviceData.widgets || [],
          details: {
            section1: serviceData.details?.section1 || { para1: '', para2: '' },
            section2: serviceData.details?.section2 || { image1: '', image2: '', image3: '', image4: '' },
            section3: serviceData.details?.section3 || { title: '', para: '' },
            section4: serviceData.details?.section4 || { image1: '', video: '' }
          },
          faqs: serviceData.faqs || [],
          category: serviceData.category || 'general',
          tag: serviceData.tag || '',
          number: serviceData.number || 1,
          bgText: serviceData.bgText || '',
          technologies: serviceData.technologies || [],
          features: serviceData.features || [],
          pricing: {
            startingPrice: serviceData.pricing?.startingPrice || 0,
            currency: serviceData.pricing?.currency || 'USD',
            pricingModel: serviceData.pricing?.pricingModel || 'custom'
          },
          deliveryTime: serviceData.deliveryTime || '',
          processSteps: serviceData.processSteps || [],
          featured: serviceData.featured || false,
          isActive: serviceData.isActive !== false,
          seoTitle: serviceData.seoTitle || '',
          seoDescription: serviceData.seoDescription || '',
          seoKeywords: serviceData.seoKeywords || []
        });
      } else {
        setErrors({ general: response.message || 'Failed to fetch service details' });
      }
    } catch (error) {
      console.error('Error fetching service:', error);
      setErrors({ general: 'Failed to fetch service details' });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData(prev => ({
        ...prev,
        [parent]: {
          ...prev[parent],
          [child]: type === 'checkbox' ? checked : (type === 'number' ? parseFloat(value) : value)
        }
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [name]: type === 'checkbox' ? checked : value
      }));
    }
  };

  const handleWidgetsChange = (widgets) => {
    setFormData(prev => ({ ...prev, widgets }));
  };

  const handleImageUpload = async (file, category) => {
    try {
      return await uploadImage(file, category);
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  };

  const validateForm = () => {
    const newErrors = {};

    if (!formData.title.trim()) {
      newErrors.title = 'Title is required';
    }

    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }

    if (formData.pricing.startingPrice < 0) {
      newErrors['pricing.startingPrice'] = 'Price cannot be negative';
    }

    // Debug: Log validation results
    console.log('Form validation errors:', newErrors);
    console.log('Current form data structure:', {
      title: formData.title,
      description: formData.description,
      widgets: formData.widgets.length,
      faqs: formData.faqs.length,
      technologies: formData.technologies.length,
      features: formData.features.length,
      pricing: formData.pricing
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    try {
      setLoading(true);
      
      // Debug: Log the form data being sent
      console.log('Submitting service data:', formData);
      
      let response;

      if (isEdit) {
        response = await updateService(slug, formData);
      } else {
        response = await createService(formData);
      }

      // Debug: Log the response
      console.log('Service save response:', response);

      if (response.success) {
        navigate('/admin/services');
      } else {
        setErrors({ general: response.message || 'Failed to save service' });
      }
    } catch (error) {
      console.error('Error saving service:', error);
      setErrors({ general: 'Failed to save service. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      <div className="row">
        <div className="col-lg-8">
          <div className="card">
            <div className="card-header">
              <h5 className="mb-0">
                {isEdit ? 'Edit Service' : 'Create New Service'}
              </h5>
            </div>
            <div className="card-body">
              {errors.general && (
                <div className="alert alert-danger" role="alert">
                  {errors.general}
                </div>
              )}

              {/* Tab Navigation */}
              <ul className="nav nav-tabs mb-4">
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'basic' ? 'active' : ''}`}
                    onClick={() => setActiveTab('basic')}
                    type="button"
                  >
                    Basic Info
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'content' ? 'active' : ''}`}
                    onClick={() => setActiveTab('content')}
                    type="button"
                  >
                    Content
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'faqs' ? 'active' : ''}`}
                    onClick={() => setActiveTab('faqs')}
                    type="button"
                  >
                    FAQs
                  </button>
                </li>
                <li className="nav-item">
                  <button 
                    className={`nav-link ${activeTab === 'advanced' ? 'active' : ''}`}
                    onClick={() => setActiveTab('advanced')}
                    type="button"
                  >
                    Advanced
                  </button>
                </li>
              </ul>

              <form onSubmit={handleSubmit}>
                {/* Basic Information Tab */}
                {activeTab === 'basic' && (
                  <div>
                    <div className="mb-4">
                      <h6 className="border-bottom pb-2">Basic Information</h6>
                      
                      <div className="mb-3">
                        <label htmlFor="title" className="form-label">Title *</label>
                        <input
                          type="text"
                          className={`form-control ${errors.title ? 'is-invalid' : ''}`}
                          id="title"
                          name="title"
                          value={formData.title}
                          onChange={handleChange}
                          required
                        />
                        {errors.title && <div className="invalid-feedback">{errors.title}</div>}
                      </div>

                      <div className="mb-3">
                        <label htmlFor="description" className="form-label">Description *</label>
                        <textarea
                          className={`form-control ${errors.description ? 'is-invalid' : ''}`}
                          id="description"
                          name="description"
                          rows="4"
                          value={formData.description}
                          onChange={handleChange}
                          required
                        />
                        {errors.description && <div className="invalid-feedback">{errors.description}</div>}
                      </div>

                      <div className="mb-3">
                        <label htmlFor="shortDescription" className="form-label">Short Description</label>
                        <textarea
                          className="form-control"
                          id="shortDescription"
                          name="shortDescription"
                          rows="2"
                          value={formData.shortDescription}
                          onChange={handleChange}
                        />
                      </div>

                      <div className="row">
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label htmlFor="image" className="form-label">Service Image</label>
                            <ImageUploader
                              onUpload={(imageUrl) => setFormData(prev => ({ ...prev, image: imageUrl }))}
                              category={IMAGE_CATEGORIES.GENERAL}
                            />
                            {formData.image && (
                              <div className="mt-2">
                                <img src={formData.image} alt="Current" className="img-thumbnail" style={{maxWidth: '150px'}} />
                              </div>
                            )}
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label htmlFor="bannerImage" className="form-label">Banner Image</label>
                            <ImageUploader
                              onUpload={(imageUrl) => setFormData(prev => ({ ...prev, bannerImage: imageUrl }))}
                              category={IMAGE_CATEGORIES.GENERAL}
                            />
                            {formData.bannerImage && (
                              <div className="mt-2">
                                <img src={formData.bannerImage} alt="Current Banner" className="img-thumbnail" style={{maxWidth: '150px'}} />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label htmlFor="category" className="form-label">Category</label>
                            <select
                              className="form-control"
                              id="category"
                              name="category"
                              value={formData.category}
                              onChange={handleChange}
                            >
                              <option value="general">General</option>
                              <option value="development">Development</option>
                              <option value="design">Design</option>
                              <option value="marketing">Marketing</option>
                              <option value="consultation">Consultation</option>
                            </select>
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label htmlFor="deliveryTime" className="form-label">Delivery Time</label>
                            <input
                              type="text"
                              className="form-control"
                              id="deliveryTime"
                              name="deliveryTime"
                              value={formData.deliveryTime}
                              onChange={handleChange}
                              placeholder="e.g., 2-3 weeks"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label className="form-check-label" htmlFor="featured">
                              <input
                                type="checkbox"
                                className="form-check-input me-2"
                                id="featured"
                                name="featured"
                                checked={formData.featured}
                                onChange={handleChange}
                              />
                              Featured Service
                            </label>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label className="form-check-label" htmlFor="isActive">
                              <input
                                type="checkbox"
                                className="form-check-input me-2"
                                id="isActive"
                                name="isActive"
                                checked={formData.isActive}
                                onChange={handleChange}
                              />
                              Active
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Content Tab */}
                {activeTab === 'content' && (
                  <div>
                    <div className="mb-4">
                      <h6 className="border-bottom pb-2">Dynamic Content Widgets</h6>
                      <p className="text-muted mb-3">
                        Create dynamic content using widgets. This will replace the legacy content sections.
                      </p>
                      <WidgetManager
                        widgets={formData.widgets}
                        onChange={handleWidgetsChange}
                        onImageUpload={handleImageUpload}
                      />
                    </div>
                  </div>
                )}

                {/* FAQs Tab */}
                {activeTab === 'faqs' && (
                  <div>
                    <div className="mb-4">
                      <h6 className="border-bottom pb-2">Frequently Asked Questions</h6>
                      <p className="text-muted mb-3">
                        Manage FAQ entries for this service.
                      </p>
                      {/* Simple FAQ management */}
                      {formData.faqs.map((faq, index) => (
                        <div key={index} className="border p-3 mb-3 rounded">
                          <div className="mb-3">
                            <label className="form-label">Question</label>
                            <input
                              type="text"
                              className="form-control"
                              value={faq.title}
                              onChange={(e) => {
                                const newFaqs = [...formData.faqs];
                                newFaqs[index].title = e.target.value;
                                setFormData(prev => ({ ...prev, faqs: newFaqs }));
                              }}
                            />
                          </div>
                          <div className="mb-3">
                            <label className="form-label">Answer</label>
                            <textarea
                              className="form-control"
                              rows="3"
                              value={faq.description}
                              onChange={(e) => {
                                const newFaqs = [...formData.faqs];
                                newFaqs[index].description = e.target.value;
                                setFormData(prev => ({ ...prev, faqs: newFaqs }));
                              }}
                            />
                          </div>
                          <button
                            type="button"
                            className="btn btn-sm btn-danger"
                            onClick={() => {
                              const newFaqs = formData.faqs.filter((_, i) => i !== index);
                              setFormData(prev => ({ ...prev, faqs: newFaqs }));
                            }}
                          >
                            Remove FAQ
                          </button>
                        </div>
                      ))}
                      <button
                        type="button"
                        className="btn btn-outline-primary"
                        onClick={() => {
                          setFormData(prev => ({
                            ...prev,
                            faqs: [...prev.faqs, { title: '', description: '' }]
                          }));
                        }}
                      >
                        Add FAQ
                      </button>
                    </div>
                  </div>
                )}

                {/* Advanced Tab */}
                {activeTab === 'advanced' && (
                  <div>
                    <div className="mb-4">
                      <h6 className="border-bottom pb-2">Advanced Settings</h6>
                      
                      <div className="mb-3">
                        <label htmlFor="technologies" className="form-label">Technologies (comma-separated)</label>
                        <input
                          type="text"
                          className="form-control"
                          id="technologies"
                          value={(formData.technologies || []).join(', ')}
                          onChange={(e) => {
                            const technologies = e.target.value.split(',').map(tech => tech.trim()).filter(tech => tech);
                            setFormData(prev => ({ ...prev, technologies }));
                          }}
                          placeholder="React, Node.js, MongoDB"
                        />
                      </div>

                      <div className="mb-3">
                        <label htmlFor="features" className="form-label">Features (comma-separated)</label>
                        <input
                          type="text"
                          className="form-control"
                          id="features"
                          value={(formData.features || []).join(', ')}
                          onChange={(e) => {
                            const features = e.target.value.split(',').map(feature => feature.trim()).filter(feature => feature);
                            setFormData(prev => ({ ...prev, features }));
                          }}
                          placeholder="Custom Design, Responsive Layout"
                        />
                      </div>

                      <div className="row">
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label htmlFor="pricing.startingPrice" className="form-label">Starting Price</label>
                            <input
                              type="number"
                              className="form-control"
                              id="pricing.startingPrice"
                              name="pricing.startingPrice"
                              value={formData.pricing.startingPrice}
                              onChange={handleChange}
                              min="0"
                              step="0.01"
                            />
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label htmlFor="pricing.currency" className="form-label">Currency</label>
                            <select
                              className="form-control"
                              id="pricing.currency"
                              name="pricing.currency"
                              value={formData.pricing.currency}
                              onChange={handleChange}
                            >
                              <option value="USD">USD</option>
                              <option value="EUR">EUR</option>
                              <option value="GBP">GBP</option>
                            </select>
                          </div>
                        </div>
                        <div className="col-md-4">
                          <div className="mb-3">
                            <label htmlFor="pricing.pricingModel" className="form-label">Pricing Model</label>
                            <select
                              className="form-control"
                              id="pricing.pricingModel"
                              name="pricing.pricingModel"
                              value={formData.pricing.pricingModel}
                              onChange={handleChange}
                            >
                              <option value="hourly">Hourly</option>
                              <option value="fixed">Fixed</option>
                              <option value="monthly">Monthly</option>
                              <option value="custom">Custom</option>
                            </select>
                          </div>
                        </div>
                      </div>

                      <div className="row">
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label htmlFor="seoTitle" className="form-label">SEO Title</label>
                            <input
                              type="text"
                              className="form-control"
                              id="seoTitle"
                              name="seoTitle"
                              value={formData.seoTitle}
                              onChange={handleChange}
                            />
                          </div>
                        </div>
                        <div className="col-md-6">
                          <div className="mb-3">
                            <label htmlFor="seoDescription" className="form-label">SEO Description</label>
                            <textarea
                              className="form-control"
                              id="seoDescription"
                              name="seoDescription"
                              rows="2"
                              value={formData.seoDescription}
                              onChange={handleChange}
                            />
                          </div>
                        </div>
                      </div>

                      <div className="mb-3">
                        <label htmlFor="seoKeywords" className="form-label">SEO Keywords (comma-separated)</label>
                        <input
                          type="text"
                          className="form-control"
                          id="seoKeywords"
                          value={(formData.seoKeywords || []).join(', ')}
                          onChange={(e) => {
                            const keywords = e.target.value.split(',').map(keyword => keyword.trim()).filter(keyword => keyword);
                            setFormData(prev => ({ ...prev, seoKeywords: keywords }));
                          }}
                          placeholder="web development, react, nodejs"
                        />
                      </div>
                    </div>
                  </div>
                )}

                <div className="d-flex gap-2 mt-4">
                  <button 
                    type="submit" 
                    className="btn btn-primary"
                    disabled={loading}
                  >
                    {loading ? 'Saving...' : (isEdit ? 'Update Service' : 'Create Service')}
                  </button>
                  <button 
                    type="button" 
                    className="btn btn-secondary"
                    onClick={() => navigate('/admin/services')}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
        
        {/* Preview Panel */}
        <div className="col-lg-4">
          <div className="card">
            <div className="card-header">
              <h6 className="mb-0">Preview</h6>
            </div>
            <div className="card-body">
              <div className="d-flex flex-column gap-2">
                <h6>{formData.title || 'Service Title'}</h6>
                <p className="text-muted small">{formData.shortDescription || 'No description provided'}</p>
                {formData.image && (
                  <img src={formData.image} alt="Service" className="img-fluid rounded" style={{maxHeight: '200px'}} />
                )}
                <div className="d-flex flex-wrap gap-1">
                  {formData.featured && (
                    <span className="badge bg-warning text-dark">
                      <i className="fas fa-star me-1"></i>Featured
                    </span>
                  )}
                  <span className={`badge ${formData.isActive ? 'bg-success' : 'bg-secondary'}`}>
                    {formData.isActive ? 'Active' : 'Inactive'}
                  </span>
                  <span className="badge bg-info">
                    {formData.category}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceForm;
