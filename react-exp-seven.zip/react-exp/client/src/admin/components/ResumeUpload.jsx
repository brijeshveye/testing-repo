import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const ResumeUpload = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [currentResume, setCurrentResume] = useState('');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState(''); // 'success' or 'error'
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;
    
    // Fetch current user data to show existing resume
    const fetchUserData = async () => {
      try {
        const response = await axios.get('/api/user');
        if (mountedRef.current) {
          setCurrentResume(response.data.aboutData?.resume || '');
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        if (mountedRef.current) {
          setMessage('Error loading current resume data');
          setMessageType('error');
        }
      }
    };
    
    fetchUserData();
    
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const clearMessage = () => {
    setMessage('');
    setMessageType('');
  };

  const showMessage = (msg, type = 'info') => {
    setMessage(msg);
    setMessageType(type);
  };

  const handleFileSelect = (event) => {
    clearMessage();
    const file = event.target.files?.[0];
    
    if (!file) {
      setSelectedFile(null);
      return;
    }

    // Validate file type (PDF only for resume)
    if (file.type !== 'application/pdf') {
      showMessage('Please select a PDF file for your resume.', 'error');
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      return;
    }
    
    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      showMessage('File size should be less than 10MB.', 'error');
      setSelectedFile(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      return;
    }
    
    setSelectedFile(file);
    clearMessage();
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      showMessage('Please select a file first.', 'error');
      return;
    }

    if (!mountedRef.current) return;

    setUploading(true);
    setUploadProgress(0);
    clearMessage();

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);
      formData.append('category', 'resume');

      // Upload the file
      const uploadResponse = await axios.post('/api/upload/resume', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          if (mountedRef.current && progressEvent.total) {
            const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
            setUploadProgress(progress);
          }
        },
      });

      if (!mountedRef.current) return;

      const resumeUrl = uploadResponse.data.url;

      // Update user's aboutData with the new resume URL
      const userResponse = await axios.get('/api/user');
      if (!mountedRef.current) return;
      
      const currentAboutData = userResponse.data.aboutData || {};
      
      const updatedAboutData = {
        ...currentAboutData,
        resume: resumeUrl
      };

      await axios.put('/api/user/aboutData', updatedAboutData);

      if (!mountedRef.current) return;

      showMessage('Resume uploaded successfully!', 'success');
      setCurrentResume(resumeUrl);
      setSelectedFile(null);
      
      // Reset file input safely
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
      
      // Navigate back after a short delay
      setTimeout(() => {
        if (mountedRef.current) {
          navigate('/admin/user');
        }
      }, 2000);
      
    } catch (error) {
      console.error('Error uploading resume:', error);
      if (mountedRef.current) {
        showMessage('Error uploading resume. Please try again.', 'error');
      }
    } finally {
      if (mountedRef.current) {
        setUploading(false);
        setUploadProgress(0);
      }
    }
  };

  const handleRemoveResume = async () => {
    if (!window.confirm('Are you sure you want to remove your current resume?')) {
      return;
    }

    clearMessage();
    
    try {
      const userResponse = await axios.get('/api/user');
      if (!mountedRef.current) return;
      
      const currentAboutData = userResponse.data.aboutData || {};
      
      const updatedAboutData = {
        ...currentAboutData,
        resume: ''
      };

      await axios.put('/api/user/aboutData', updatedAboutData);
      
      if (!mountedRef.current) return;
      
      setCurrentResume('');
      showMessage('Resume removed successfully!', 'success');
    } catch (error) {
      console.error('Error removing resume:', error);
      if (mountedRef.current) {
        showMessage('Error removing resume. Please try again.', 'error');
      }
    }
  };

  const getMessageClass = () => {
    switch (messageType) {
      case 'success': return 'alert-success';
      case 'error': return 'alert-danger';
      default: return 'alert-info';
    }
  };

  return (
    <div className="container mt-4">
      <h3>Upload Resume/CV</h3>
      
      {/* Message Display */}
      {message && (
        <div className={`alert ${getMessageClass()} mb-4`} role="alert">
          <div className="d-flex align-items-center">
            <i className={`fas ${messageType === 'success' ? 'fa-check-circle' : messageType === 'error' ? 'fa-exclamation-triangle' : 'fa-info-circle'} me-2`}></i>
            {message}
          </div>
        </div>
      )}
      
      {/* Current Resume Section */}
      {currentResume && (
        <div className="card mb-4">
          <div className="card-body">
            <h5 className="card-title">Current Resume</h5>
            <div className="mb-3">
              <a 
                href={currentResume} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="btn btn-outline-primary btn-sm me-2"
              >
                <i className="fas fa-file-pdf me-2"></i>View Current Resume
              </a>
              <button 
                type="button" 
                className="btn btn-outline-danger btn-sm"
                onClick={handleRemoveResume}
                disabled={uploading}
              >
                <i className="fas fa-trash me-2"></i>Remove Resume
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload New Resume Section */}
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Upload New Resume</h5>
          
          <div className="mb-3">
            <label htmlFor="resumeFile" className="form-label">
              Select PDF Resume (Max 10MB)
            </label>
            <input
              ref={fileInputRef}
              id="resumeFile"
              type="file"
              className="form-control"
              accept=".pdf"
              onChange={handleFileSelect}
              disabled={uploading}
            />
            {selectedFile && (
              <div className="form-text text-success">
                <i className="fas fa-check me-1"></i>
                Selected: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
              </div>
            )}
          </div>

          {uploading && (
            <div className="mb-3">
              <div className="progress">
                <div 
                  className="progress-bar progress-bar-striped progress-bar-animated" 
                  role="progressbar" 
                  style={{width: `${uploadProgress}%`}}
                  aria-valuenow={uploadProgress} 
                  aria-valuemin="0" 
                  aria-valuemax="100"
                >
                  {uploadProgress}%
                </div>
              </div>
              <small className="text-muted">Uploading... Please wait.</small>
            </div>
          )}

          <div className="d-flex gap-2">
            <button
              type="button"
              className="btn btn-primary"
              onClick={handleUpload}
              disabled={!selectedFile || uploading}
            >
              {uploading ? (
                <>
                  <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                  Uploading...
                </>
              ) : (
                <>
                  <i className="fas fa-upload me-2"></i>Upload Resume
                </>
              )}
            </button>
            
            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate('/admin/user')}
              disabled={uploading}
            >
              <i className="fas fa-arrow-left me-2"></i>Back to Profile
            </button>
          </div>
        </div>
      </div>

      <div className="alert alert-info mt-4">
        <h6><i className="fas fa-info-circle me-2"></i>Important Notes:</h6>
        <ul className="mb-0">
          <li>Only PDF files are accepted for resumes</li>
          <li>Maximum file size is 10MB</li>
          <li>The uploaded resume will be available for download on your portfolio's About section</li>
          <li>Uploading a new resume will replace the existing one</li>
        </ul>
      </div>
    </div>
  );
};

export default ResumeUpload;
