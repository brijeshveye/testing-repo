import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import ExperienceDataApi from '../../api/ExperienceDataApi';

const ExperienceForm = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(slug);

  const [formData, setFormData] = useState({
    title: '',
    company: '',
    location: '',
    startDate: '',
    endDate: '',
    current: false,
    employmentType: 'Full-time',
    description: '',
    responsibilities: [''],
    achievements: [''],
    skills: [''],
    technologies: [''],
    companyLogo: '',
    companyWebsite: '',
    industry: '',
    featured: false,
    isActive: true
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isEdit) {
      fetchExperience();
    }
  }, [slug, isEdit]);

  const fetchExperience = async () => {
    try {
      setLoading(true);
      const data = await ExperienceDataApi.getExperienceDetails(slug);
      if (data) {
        setFormData({
          ...data,
          startDate: data.startDate ? new Date(data.startDate).toISOString().split('T')[0] : '',
          endDate: data.endDate ? new Date(data.endDate).toISOString().split('T')[0] : '',
          responsibilities: data.responsibilities?.length ? data.responsibilities : [''],
          achievements: data.achievements?.length ? data.achievements : [''],
          skills: data.skills?.length ? data.skills : [''],
          technologies: data.technologies?.length ? data.technologies : ['']
        });
      }
    } catch (err) {
      setError('Failed to fetch experience details');
      console.error('Error fetching experience:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleArrayChange = (field, index, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].map((item, i) => i === index ? value : item)
    }));
  };

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: [...prev[field], '']
    }));
  };

  const removeArrayItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.title || !formData.company || !formData.startDate) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      setError('');

      // Clean up array fields (remove empty strings)
      const cleanedData = {
        ...formData,
        responsibilities: formData.responsibilities.filter(item => item.trim() !== ''),
        achievements: formData.achievements.filter(item => item.trim() !== ''),
        skills: formData.skills.filter(item => item.trim() !== ''),
        technologies: formData.technologies.filter(item => item.trim() !== '')
      };

      if (isEdit) {
        await ExperienceDataApi.updateExperience(slug, cleanedData);
      } else {
        await ExperienceDataApi.createExperience(cleanedData);
      }

      navigate('/admin/experience');
    } catch (err) {
      setError(`Failed to ${isEdit ? 'update' : 'create'} experience record`);
      console.error(`Error ${isEdit ? 'updating' : 'creating'} experience:`, err);
    } finally {
      setLoading(false);
    }
  };

  if (loading && isEdit) {
    return (
      <div className="container mt-4">
        <div className="text-center">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-4">
      {/* Header */}
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1>{isEdit ? 'Edit Experience' : 'Add New Experience'}</h1>
          <nav aria-label="breadcrumb">
            <ol className="breadcrumb">
              <li className="breadcrumb-item"><Link to="/admin">Admin</Link></li>
              <li className="breadcrumb-item"><Link to="/admin/experience">Experience</Link></li>
              <li className="breadcrumb-item active">{isEdit ? 'Edit' : 'Add New'}</li>
            </ol>
          </nav>
        </div>
        <Link to="/admin/experience" className="btn btn-secondary">
          <i className="fas fa-arrow-left me-2"></i>Back to List
        </Link>
      </div>

      {/* Error Message */}
      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}

      {/* Form */}
      <div className="card">
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="row">
              {/* Basic Information */}
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Job Title *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="title"
                    value={formData.title}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Company *</label>
                  <input
                    type="text"
                    className="form-control"
                    name="company"
                    value={formData.company}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Location</label>
                  <input
                    type="text"
                    className="form-control"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    placeholder="City, State/Country"
                  />
                </div>
              </div>

              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Employment Type</label>
                  <select
                    className="form-select"
                    name="employmentType"
                    value={formData.employmentType}
                    onChange={handleInputChange}
                  >
                    <option value="Full-time">Full-time</option>
                    <option value="Part-time">Part-time</option>
                    <option value="Contract">Contract</option>
                    <option value="Internship">Internship</option>
                    <option value="Freelance">Freelance</option>
                    <option value="Volunteer">Volunteer</option>
                  </select>
                </div>
              </div>

              {/* Dates */}
              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">Start Date *</label>
                  <input
                    type="date"
                    className="form-control"
                    name="startDate"
                    value={formData.startDate}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">End Date</label>
                  <input
                    type="date"
                    className="form-control"
                    name="endDate"
                    value={formData.endDate}
                    onChange={handleInputChange}
                    disabled={formData.current}
                  />
                </div>
              </div>

              <div className="col-md-4">
                <div className="mb-3">
                  <label className="form-label">&nbsp;</label>
                  <div className="form-check">
                    <input
                      type="checkbox"
                      className="form-check-input"
                      name="current"
                      checked={formData.current}
                      onChange={handleInputChange}
                    />
                    <label className="form-check-label">
                      I currently work here
                    </label>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="col-12">
                <div className="mb-3">
                  <label className="form-label">Job Description</label>
                  <textarea
                    className="form-control"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows="4"
                    placeholder="Brief description of your role and what the company does..."
                  />
                </div>
              </div>

              {/* Company Info */}
              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Company Website</label>
                  <input
                    type="url"
                    className="form-control"
                    name="companyWebsite"
                    value={formData.companyWebsite}
                    onChange={handleInputChange}
                    placeholder="https://company.com"
                  />
                </div>
              </div>

              <div className="col-md-6">
                <div className="mb-3">
                  <label className="form-label">Industry</label>
                  <input
                    type="text"
                    className="form-control"
                    name="industry"
                    value={formData.industry}
                    onChange={handleInputChange}
                    placeholder="e.g., Technology, Healthcare, Finance"
                  />
                </div>
              </div>

              <div className="col-12">
                <div className="mb-3">
                  <label className="form-label">Company Logo URL</label>
                  <input
                    type="url"
                    className="form-control"
                    name="companyLogo"
                    value={formData.companyLogo}
                    onChange={handleInputChange}
                    placeholder="https://example.com/logo.png"
                  />
                </div>
              </div>
            </div>

            {/* Responsibilities */}
            <div className="mb-4">
              <label className="form-label">Key Responsibilities</label>
              {formData.responsibilities.map((responsibility, index) => (
                <div key={index} className="mb-2">
                  <div className="input-group">
                    <textarea
                      className="form-control"
                      value={responsibility}
                      onChange={(e) => handleArrayChange('responsibilities', index, e.target.value)}
                      placeholder="Describe a key responsibility..."
                      rows="2"
                    />
                    <button
                      type="button"
                      className="btn btn-outline-danger"
                      onClick={() => removeArrayItem('responsibilities', index)}
                      disabled={formData.responsibilities.length === 1}
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              ))}
              <button
                type="button"
                className="btn btn-outline-primary btn-sm"
                onClick={() => addArrayItem('responsibilities')}
              >
                <i className="fas fa-plus me-1"></i>Add Responsibility
              </button>
            </div>

            {/* Achievements */}
            <div className="mb-4">
              <label className="form-label">Key Achievements</label>
              {formData.achievements.map((achievement, index) => (
                <div key={index} className="mb-2">
                  <div className="input-group">
                    <textarea
                      className="form-control"
                      value={achievement}
                      onChange={(e) => handleArrayChange('achievements', index, e.target.value)}
                      placeholder="Describe a key achievement or accomplishment..."
                      rows="2"
                    />
                    <button
                      type="button"
                      className="btn btn-outline-danger"
                      onClick={() => removeArrayItem('achievements', index)}
                      disabled={formData.achievements.length === 1}
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              ))}
              <button
                type="button"
                className="btn btn-outline-primary btn-sm"
                onClick={() => addArrayItem('achievements')}
              >
                <i className="fas fa-plus me-1"></i>Add Achievement
              </button>
            </div>

            {/* Skills */}
            <div className="mb-4">
              <label className="form-label">Skills Used</label>
              {formData.skills.map((skill, index) => (
                <div key={index} className="mb-2">
                  <div className="input-group">
                    <input
                      type="text"
                      className="form-control"
                      value={skill}
                      onChange={(e) => handleArrayChange('skills', index, e.target.value)}
                      placeholder="Skill name..."
                    />
                    <button
                      type="button"
                      className="btn btn-outline-danger"
                      onClick={() => removeArrayItem('skills', index)}
                      disabled={formData.skills.length === 1}
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              ))}
              <button
                type="button"
                className="btn btn-outline-primary btn-sm"
                onClick={() => addArrayItem('skills')}
              >
                <i className="fas fa-plus me-1"></i>Add Skill
              </button>
            </div>

            {/* Technologies */}
            <div className="mb-4">
              <label className="form-label">Technologies Used</label>
              {formData.technologies.map((tech, index) => (
                <div key={index} className="mb-2">
                  <div className="input-group">
                    <input
                      type="text"
                      className="form-control"
                      value={tech}
                      onChange={(e) => handleArrayChange('technologies', index, e.target.value)}
                      placeholder="Technology/tool name..."
                    />
                    <button
                      type="button"
                      className="btn btn-outline-danger"
                      onClick={() => removeArrayItem('technologies', index)}
                      disabled={formData.technologies.length === 1}
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </div>
              ))}
              <button
                type="button"
                className="btn btn-outline-primary btn-sm"
                onClick={() => addArrayItem('technologies')}
              >
                <i className="fas fa-plus me-1"></i>Add Technology
              </button>
            </div>

            {/* Settings */}
            <div className="row">
              <div className="col-md-6">
                <div className="form-check mb-3">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    name="featured"
                    checked={formData.featured}
                    onChange={handleInputChange}
                  />
                  <label className="form-check-label">
                    Featured Experience
                  </label>
                </div>
              </div>
              <div className="col-md-6">
                <div className="form-check mb-3">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    name="isActive"
                    checked={formData.isActive}
                    onChange={handleInputChange}
                  />
                  <label className="form-check-label">
                    Active (Visible on website)
                  </label>
                </div>
              </div>
            </div>

            {/* Form Actions */}
            <div className="d-flex justify-content-between">
              <Link to="/admin/experience" className="btn btn-secondary">
                Cancel
              </Link>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading && <span className="spinner-border spinner-border-sm me-2"></span>}
                {isEdit ? 'Update Experience' : 'Create Experience'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ExperienceForm;
