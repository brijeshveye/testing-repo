import logo from './logo.svg';
import './App.css';
import Layout from "./layouts/Layout";
import AppRoutes from "./router/AppRoutes";
import { createContext, useEffect, useState } from "react";

export const RootContext = createContext();

function App() {
  const [progress, setProgress] = useState(0);

  return (
    <>
      <RootContext.Provider value={{ progress, setProgress }}>
        <Layout>
          <AppRoutes />
        </Layout>
      </RootContext.Provider>
    </>
  );
}

export default App;
