import React, { useEffect, useState } from 'react'
import PortfolioTopSection from '../components/portfolio/PortfolioTopSection'
import ProjectSection from '../components/portfolio/ProjectSection'
import UserDataApi from '../api/UserDataApi';
import { useParams } from 'react-router-dom';

import AOS from 'aos';
import 'aos/dist/aos.css';


const ProjectDetails = () => {
  const [projectData, setProjectData] = useState({});

  const slug = useParams().slug;


  useEffect(() => {
    AOS.init({
      once: true,
      easing: 'ease-in-out',
    });

  }, []);


  useEffect(() => {
    const fetchProjectDetails = async () => {
      try {
        const project = await UserDataApi.getProjectDetails(slug);
        setProjectData(project);
      } catch (error) {
        console.error('Error fetching project details:', error);
        setProjectData({});
      }
    };

    if (slug) {
      fetchProjectDetails();
    }
  }, [slug]);


  return (
    <main className='wrapper'>
      <PortfolioTopSection projectData={projectData} />
      <ProjectSection projectData={projectData} />
    </main>
  )
}

export default ProjectDetails