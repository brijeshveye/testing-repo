import React, { useState, useEffect } from 'react';
import Layout from '../layouts/Layout';
import CertificatesDataApi from '../api/CertificatesDataApi';
import CertificateCard from '../components/certificate/CertificateCard';

const AllCertificates = () => {
  const [certificates, setCertificates] = useState([]);
  const [categories, setCategories] = useState(['all']);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchCertificates();
    fetchCategories();
  }, []);

  useEffect(() => {
    fetchCertificates();
  }, [selectedCategory]);

  const fetchCertificates = async () => {
    try {
      setLoading(true);
      const params = { isActive: true };
      if (selectedCategory !== 'all') {
        params.category = selectedCategory;
      }
      const data = await CertificatesDataApi.getCertificatesData(params);
      setCertificates(data);
    } catch (err) {
      setError('Failed to load certificates');
      console.error('Error fetching certificates:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const data = await CertificatesDataApi.getCertificateCategories();
      setCategories(data);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  if (loading) {
    return (
      <div>
        <div className="container py-5">
          <div className="text-center">
            <div className="spinner-border" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div>
        <div className="container py-5">
          <div className="alert alert-danger text-center">
            {error}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-5 pt-2">
      <div className="container mt-5 py-5">
        <div className="row">
          <div className="col-12">
            <div className="section-heading text-center mb-5">
              <h1>My Certificates</h1>
              <p className="text-muted">
                Professional certifications and achievements that showcase my expertise and commitment to continuous learning.
              </p>
            </div>
          </div>
        </div>

        {/* Category Filter */}
        <div className="row mb-4">
          <div className="col-12">
            <div className="d-flex flex-wrap justify-content-center gap-2">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  className={`btn ${selectedCategory === category ? 'btn-primary' : 'btn-outline-primary'}`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category === 'all' ? 'All Categories' : category}
                </button>
              ))}
            </div>
          </div>
        </div>

        {certificates.length === 0 ? (
          <div className="row">
            <div className="col-12">
              <div className="text-center py-5">
                <i className="fas fa-certificate fa-3x text-muted mb-3"></i>
                <h4>No certificates found</h4>
                <p className="text-muted">
                  {selectedCategory !== 'all' 
                    ? `No certificates found in the "${selectedCategory}" category.`
                    : 'No certificates available at the moment.'
                  }
                </p>
                {selectedCategory !== 'all' && (
                  <button 
                    className="btn btn-primary"
                    onClick={() => setSelectedCategory('all')}
                  >
                    View All Categories
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="row g-4">
            {certificates.map((certificate) => (
              <div key={certificate._id} className="col-lg-4 col-md-6">
                <CertificateCard certificate={certificate} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AllCertificates;