import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../layouts/Layout';
import EducationCard from '../components/education/EducationCard';
import EducationDataApi from '../api/EducationDataApi';

const AllEducation = () => {
  const [education, setEducation] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [degrees, setDegrees] = useState([]);
  const [institutions, setInstitutions] = useState([]);
  const [selectedDegree, setSelectedDegree] = useState('all');
  const [selectedInstitution, setSelectedInstitution] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredEducation, setFilteredEducation] = useState([]);

  useEffect(() => {
    fetchEducation();
    fetchDegrees();
    fetchInstitutions();
  }, []);

  useEffect(() => {
    filterEducation();
  }, [education, selectedDegree, selectedInstitution, searchTerm]);

  const fetchEducation = async () => {
    try {
      setLoading(true);
      const data = await EducationDataApi.getEducationData({ isActive: true });
      setEducation(data);
    } catch (err) {
      setError('Failed to fetch education records');
      console.error('Error fetching education:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchDegrees = async () => {
    try {
      const degreesData = await EducationDataApi.getDegreeTypes();
      setDegrees(['all', ...degreesData]);
    } catch (err) {
      console.error('Error fetching degrees:', err);
    }
  };

  const fetchInstitutions = async () => {
    try {
      const institutionsData = await EducationDataApi.getInstitutions();
      setInstitutions(['all', ...institutionsData]);
    } catch (err) {
      console.error('Error fetching institutions:', err);
    }
  };

  const filterEducation = () => {
    let filtered = education;

    // Filter by degree
    if (selectedDegree !== 'all') {
      filtered = filtered.filter(edu => 
        edu.degree && edu.degree.toLowerCase().includes(selectedDegree.toLowerCase())
      );
    }

    // Filter by institution
    if (selectedInstitution !== 'all') {
      filtered = filtered.filter(edu =>
        edu.institution && edu.institution.toLowerCase().includes(selectedInstitution.toLowerCase())
      );
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(edu =>
        edu.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        edu.institution?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        edu.degree?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        edu.fieldOfStudy?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        edu.description?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredEducation(filtered);
  };

  const handleDegreeChange = (degree) => {
    setSelectedDegree(degree);
  };

  const handleInstitutionChange = (institution) => {
    setSelectedInstitution(institution);
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const getDegreeIcon = (degree) => {
    const iconMap = {
      'bachelor': 'fas fa-graduation-cap',
      'master': 'fas fa-user-graduate',
      'phd': 'fas fa-university',
      'doctorate': 'fas fa-university',
      'diploma': 'fas fa-certificate',
      'certificate': 'fas fa-award',
      'all': 'fas fa-th-large'
    };
    
    if (!degree) return 'fas fa-graduation-cap';
    
    const lowerDegree = degree.toLowerCase();
    for (const [key, icon] of Object.entries(iconMap)) {
      if (lowerDegree.includes(key)) {
        return icon;
      }
    }
    return 'fas fa-graduation-cap';
  };

  if (loading) {
    return (
      <div>
        <div className="container mt-5">
          <div className="text-center">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="mt-3">Loading education records...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-5 pt-2">
      {/* Hero Section */}
      <section className="bg-secondary text-white mt-5 py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-8">
              <h1 className="display-4 fw-bold mb-3">My Education Journey</h1>
              <p className="lead mb-4">
                Explore my academic background, qualifications, and learning experiences. 
                Each educational milestone has contributed to my professional development and expertise.
              </p>
              <div className="d-flex gap-3">
                <div className="text-center">
                  <h3 className="mb-0">{education.length}</h3>
                  <small>Total Records</small>
                </div>
                <div className="text-center">
                  <h3 className="mb-0">{education.filter(e => e.featured).length}</h3>
                  <small>Featured</small>
                </div>
                <div className="text-center">
                  <h3 className="mb-0">{education.filter(e => e.current).length}</h3>
                  <small>Current Studies</small>
                </div>
                <div className="text-center">
                  <h3 className="mb-0">{degrees.length - 1}</h3>
                  <small>Degree Types</small>
                </div>
              </div>
            </div>
            <div className="col-lg-4 text-center">
              <i className="fas fa-graduation-cap display-1 opacity-50"></i>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-5">
        <div className="container">
          {error && (
            <div className="alert alert-danger mb-4">
              <i className="fas fa-exclamation-triangle me-2"></i>
              {error}
            </div>
          )}

          {/* Search and Filter */}
          <div className="row mb-5">
            <div className="col-lg-4 mb-3">
              <div className="input-group">
                <span className="input-group-text">
                  <i className="fas fa-search"></i>
                </span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search education records..."
                  value={searchTerm}
                  onChange={handleSearchChange}
                />
              </div>
            </div>
            <div className="col-lg-4 mb-3">
              <select
                className="form-select"
                value={selectedDegree}
                onChange={(e) => handleDegreeChange(e.target.value)}
              >
                {degrees.map(degree => (
                  <option key={degree} value={degree}>
                    {degree === 'all' ? 'All Degrees' : degree}
                  </option>
                ))}
              </select>
            </div>
            <div className="col-lg-4 mb-3">
              <select
                className="form-select"
                value={selectedInstitution}
                onChange={(e) => handleInstitutionChange(e.target.value)}
              >
                {institutions.map(institution => (
                  <option key={institution} value={institution}>
                    {institution === 'all' ? 'All Institutions' : institution}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Education Grid */}
          <div className="row">
            {filteredEducation.length === 0 ? (
              <div className="col-12">
                <div className="text-center py-5">
                  <i className="fas fa-search fa-3x text-muted mb-3"></i>
                  <h4>No education records found</h4>
                  <p className="text-muted">
                    {searchTerm || selectedDegree !== 'all' || selectedInstitution !== 'all'
                      ? 'Try adjusting your search or filter criteria.'
                      : 'No education records available at the moment.'}
                  </p>
                  {(searchTerm || selectedDegree !== 'all' || selectedInstitution !== 'all') && (
                    <button
                      className="btn btn-outline-primary"
                      onClick={() => {
                        setSearchTerm('');
                        setSelectedDegree('all');
                        setSelectedInstitution('all');
                      }}
                    >
                      Clear Filters
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <>
                {/* Current Education */}
                {filteredEducation.filter(edu => edu.current).length > 0 && (
                  <>
                    <div className="col-12 mb-4">
                      <h3 className="text-primary">
                        <i className="fas fa-clock me-2"></i>
                        Current Studies
                      </h3>
                      <hr />
                    </div>
                    {filteredEducation
                      .filter(edu => edu.current)
                      .sort((a, b) => new Date(b.startDate) - new Date(a.startDate))
                      .map(edu => (
                        <div key={edu._id} className="col-lg-4 col-md-6 mb-4">
                          <EducationCard education={edu} />
                        </div>
                      ))}
                  </>
                )}

                {/* Featured Education */}
                {filteredEducation.filter(edu => edu.featured && !edu.current).length > 0 && (
                  <>
                    <div className="col-12 mb-4">
                      <h3 className="text-primary">
                        <i className="fas fa-star me-2"></i>
                        Featured Education
                      </h3>
                      <hr />
                    </div>
                    {filteredEducation
                      .filter(edu => edu.featured && !edu.current)
                      .sort((a, b) => new Date(b.startDate) - new Date(a.startDate))
                      .map(edu => (
                        <div key={edu._id} className="col-lg-4 col-md-6 mb-4">
                          <EducationCard education={edu} featured={true} />
                        </div>
                      ))}
                  </>
                )}

                {/* Other Education */}
                {filteredEducation.filter(edu => !edu.featured && !edu.current).length > 0 && (
                  <>
                    <div className="col-12 mb-4">
                      <h3 className="text-primary">
                        <i className="fas fa-graduation-cap me-2"></i>
                        {filteredEducation.filter(edu => edu.featured || edu.current).length > 0 
                          ? 'Other Education' 
                          : 'All Education'}
                      </h3>
                      <hr />
                    </div>
                    {filteredEducation
                      .filter(edu => !edu.featured && !edu.current)
                      .sort((a, b) => new Date(b.startDate) - new Date(a.startDate))
                      .map(edu => (
                        <div key={edu._id} className="col-lg-4 col-md-6 mb-4">
                          <EducationCard education={edu} />
                        </div>
                      ))}
                  </>
                )}
              </>
            )}
          </div>

          {/* Education Timeline */}
          {filteredEducation.length > 0 && (
            <div className="row mt-5">
              <div className="col-12">
                <h3 className="text-primary mb-4">
                  <i className="fas fa-timeline me-2"></i>
                  Education Timeline
                </h3>
                <div className="timeline">
                  {filteredEducation
                    .sort((a, b) => new Date(b.startDate) - new Date(a.startDate))
                    .map((edu, index) => (
                      <div key={edu._id} className="timeline-item">
                        <div className="timeline-marker">
                          <i className={getDegreeIcon(edu.degree)}></i>
                        </div>
                        <div className="timeline-content">
                          <div className="card">
                            <div className="card-body">
                              <div className="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                  <h5 className="card-title mb-1">{edu.title}</h5>
                                  <h6 className="text-primary">{edu.institution}</h6>
                                </div>
                                <small className="text-muted">
                                  {new Date(edu.startDate).getFullYear()} - 
                                  {edu.current ? ' Present' : 
                                   edu.endDate ? ` ${new Date(edu.endDate).getFullYear()}` : ' Present'}
                                </small>
                              </div>
                              {edu.degree && (
                                <span className="badge bg-primary me-2">{edu.degree}</span>
                              )}
                              {edu.fieldOfStudy && (
                                <span className="badge bg-secondary">{edu.fieldOfStudy}</span>
                              )}
                              {edu.current && (
                                <span className="badge bg-success ms-2">Current</span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          )}

          {/* Back to Home */}
          <div className="text-center mt-5">
            <Link to="/" className="btn btn-outline-primary">
              <i className="fas fa-home me-2"></i>
              Back to Home
            </Link>
          </div>
        </div>
      </section>

      <style jsx>{`
        .timeline {
          position: relative;
          padding-left: 30px;
        }
        
        .timeline::before {
          content: '';
          position: absolute;
          left: 15px;
          top: 0;
          bottom: 0;
          width: 2px;
          background: #dee2e6;
        }
        
        .timeline-item {
          position: relative;
          margin-bottom: 30px;
        }
        
        .timeline-marker {
          position: absolute;
          left: -22px;
          top: 10px;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          background: #007bff;
          color: white;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1;
        }
        
        .timeline-content {
          margin-left: 20px;
        }
      `}</style>
    </div>
  );
};

export default AllEducation;
