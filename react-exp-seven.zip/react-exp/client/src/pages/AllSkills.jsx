import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../layouts/Layout';
import SkillCard from '../components/skill/SkillCard';
import SkillsDataApi from '../api/SkillsDataApi';

const AllSkills = () => {
  const [skills, setSkills] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [categories, setCategories] = useState(['all']);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredSkills, setFilteredSkills] = useState([]);

  useEffect(() => {
    fetchSkills();
    fetchCategories();
  }, []);

  useEffect(() => {
    filterSkills();
  }, [skills, selectedCategory, searchTerm]);

  const fetchSkills = async () => {
    try {
      setLoading(true);
      const data = await SkillsDataApi.getSkillsData({ isActive: true });
      setSkills(data);
    } catch (err) {
      setError('Failed to fetch skills');
      console.error('Error fetching skills:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const categoriesData = await SkillsDataApi.getSkillCategories();
      setCategories(categoriesData);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const filterSkills = () => {
    let filtered = skills;

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(skill =>
        skill.category.toLowerCase() === selectedCategory.toLowerCase()
      );
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(skill =>
        skill.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        skill.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        skill.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
        skill.level.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredSkills(filtered);
  };

  const handleCategoryChange = (category) => {
    setSelectedCategory(category);
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const getCategoryIcon = (category) => {
    const iconMap = {
      'all': 'fas fa-th-large',
      'language': 'fas fa-code',
      'frontend': 'fab fa-html5',
      'backend': 'fas fa-server',
      'database': 'fas fa-database',
      'cloud': 'fas fa-cloud',
      'devops': 'fas fa-cogs',
      'design': 'fas fa-palette',
      'mobile': 'fas fa-mobile-alt',
      'testing': 'fas fa-bug',
      'other': 'fas fa-ellipsis-h'
    };
    return iconMap[category.toLowerCase()] || 'fas fa-code';
  };

  if (loading) {
    return (
      <Layout>
        <div className="container mt-5">
          <div className="text-center">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="mt-3">Loading skills...</p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <div>
      {/* Hero Section */}
      <div className="mt-5 pt-2">
        <section className="bg-secondary text-white mt-5 py-5">
          <div className="container">
            <div className="row align-items-center">
              <div className="col-lg-8">
                <h1 className="display-4 fw-bold mb-3">My Skills & Expertise</h1>
                <p className="lead mb-4">
                  Explore my technical skills, programming languages, frameworks, and tools.
                  Each skill represents years of experience and continuous learning in the ever-evolving world of technology.
                </p>
                <div className="d-flex gap-3">
                  <div className="text-center">
                    <h3 className="mb-0">{skills.length}</h3>
                    <small>Total Skills</small>
                  </div>
                  <div className="text-center">
                    <h3 className="mb-0">{skills.filter(s => s.featured).length}</h3>
                    <small>Featured</small>
                  </div>
                  <div className="text-center">
                    <h3 className="mb-0">{categories.length - 1}</h3>
                    <small>Categories</small>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 text-center">
                <i className="fas fa-code display-1 opacity-50"></i>
              </div>
            </div>
          </div>
        </section>
      </div>


      {/* Main Content */}
      <section className="py-5">
        <div className="container">
          {error && (
            <div className="alert alert-danger mb-4">
              <i className="fas fa-exclamation-triangle me-2"></i>
              {error}
            </div>
          )}

          {/* Search and Filter */}
          <div className="row mb-5">
            <div className="col-lg-6 mb-3">
              <div className="input-group">
                <span className="input-group-text">
                  <i className="fas fa-search"></i>
                </span>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search skills..."
                  value={searchTerm}
                  onChange={handleSearchChange}
                />
              </div>
            </div>
            <div className="col-lg-6">
              <div className="d-flex flex-wrap gap-2">
                {categories.map(category => (
                  <button
                    key={category}
                    className={`btn ${selectedCategory === category
                        ? 'btn-primary'
                        : 'btn-outline-primary'
                      } btn-sm`}
                    onClick={() => handleCategoryChange(category)}
                  >
                    <i className={`${getCategoryIcon(category)} me-2`}></i>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Skills Grid */}
          <div className="row">
            {filteredSkills.length === 0 ? (
              <div className="col-12">
                <div className="text-center py-5">
                  <i className="fas fa-search fa-3x text-muted mb-3"></i>
                  <h4>No skills found</h4>
                  <p className="text-muted">
                    {searchTerm || selectedCategory !== 'all'
                      ? 'Try adjusting your search or filter criteria.'
                      : 'No skills available at the moment.'}
                  </p>
                  {(searchTerm || selectedCategory !== 'all') && (
                    <button
                      className="btn btn-outline-primary"
                      onClick={() => {
                        setSearchTerm('');
                        setSelectedCategory('all');
                      }}
                    >
                      Clear Filters
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <>
                {/* Featured Skills First */}
                {filteredSkills.filter(skill => skill.featured).length > 0 && (
                  <>
                    <div className="col-12 mb-4">
                      <h3 className="text-primary">
                        <i className="fas fa-star me-2"></i>
                        Featured Skills
                      </h3>
                      <hr />
                    </div>
                    {filteredSkills
                      .filter(skill => skill.featured)
                      .sort((a, b) => (b.percentage || 0) - (a.percentage || 0))
                      .map(skill => (
                        <div key={skill._id} className="col-lg-3 col-md-4 col-sm-6 mb-4">
                          <SkillCard skill={skill} featured={true} />
                        </div>
                      ))}
                  </>
                )}

                {/* Other Skills */}
                {filteredSkills.filter(skill => !skill.featured).length > 0 && (
                  <>
                    <div className="col-12 mb-4">
                      <h3 className="text-primary">
                        <i className="fas fa-code me-2"></i>
                        {filteredSkills.filter(skill => skill.featured).length > 0
                          ? 'Other Skills'
                          : 'All Skills'}
                      </h3>
                      <hr />
                    </div>
                    {filteredSkills
                      .filter(skill => !skill.featured)
                      .sort((a, b) => {
                        // Sort by category, then by percentage
                        if (a.category !== b.category) {
                          return a.category.localeCompare(b.category);
                        }
                        return (b.percentage || 0) - (a.percentage || 0);
                      })
                      .map(skill => (
                        <div key={skill._id} className="col-lg-3 col-md-4 col-sm-6 mb-4">
                          <SkillCard skill={skill} />
                        </div>
                      ))}
                  </>
                )}
              </>
            )}
          </div>

          {/* Skills by Category Summary */}
          {filteredSkills.length > 0 && selectedCategory === 'all' && (
            <div className="row mt-5">
              <div className="col-12">
                <h3 className="text-primary mb-4">
                  <i className="fas fa-chart-bar me-2"></i>
                  Skills by Category
                </h3>
                <div className="row">
                  {categories
                    .filter(cat => cat !== 'all')
                    .map(category => {
                      const categorySkills = skills.filter(skill =>
                        skill.category.toLowerCase() === category.toLowerCase()
                      );
                      if (categorySkills.length === 0) return null;

                      return (
                        <div key={category} className="col-lg-3 col-md-4 col-sm-6 mb-3">
                          <div className="card h-100 border-0 shadow-sm">
                            <div className="card-body text-center">
                              <i className={`${getCategoryIcon(category)} fa-2x text-primary mb-3`}></i>
                              <h5 className="card-title">
                                {category.charAt(0).toUpperCase() + category.slice(1)}
                              </h5>
                              <p className="card-text text-muted">
                                {categorySkills.length} skill{categorySkills.length !== 1 ? 's' : ''}
                              </p>
                              <button
                                className="btn btn-outline-primary btn-sm"
                                onClick={() => handleCategoryChange(category)}
                              >
                                View Skills
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          )}

          
        </div>
      </section>
    </div>
  );
};

export default AllSkills;
