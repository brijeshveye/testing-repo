import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const NotFound = () => {
  return (
    <div className="not-found-container">
      <div className="container-fluid min-vh-100 d-flex align-items-center justify-content-center">
        <div className="row justify-content-center text-center">
          <div className="col-lg-8 col-md-10">
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="not-found-content"
            >
              {/* 404 Animation */}
              <motion.div
                initial={{ scale: 0.5, rotate: -10 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ duration: 1, delay: 0.2 }}
                className="error-code mb-4"
              >
                <h1 className="display-1 fw-bold text-primary mb-0" style={{ fontSize: '8rem', textShadow: '2px 2px 4px rgba(0,0,0,0.3)' }}>
                  404
                </h1>
              </motion.div>

              {/* Glitch Effect Text */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="error-message mb-4"
              >
                <h2 className="h1 fw-bold mb-3" style={{ color: '#333' }}>
                  Oops! Page Not Found
                </h2>
                <p className="lead text-muted mb-4">
                  The page you're looking for seems to have wandered off into the digital void. 
                  Don't worry, even the best explorers sometimes take a wrong turn!
                </p>
              </motion.div>

              {/* Floating Elements */}
              <motion.div
                animate={{ 
                  y: [0, -20, 0],
                  rotate: [0, 5, -5, 0]
                }}
                transition={{ 
                  duration: 4,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
                className="floating-icon mb-4"
              >
                <i className="fas fa-rocket fa-3x text-secondary opacity-75"></i>
              </motion.div>

              {/* Action Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="action-buttons"
              >
                <Link 
                  to="/" 
                  className="btn btn-primary btn-lg me-3 mb-2"
                  style={{ 
                    borderRadius: '50px',
                    padding: '12px 30px',
                    fontWeight: '600',
                    textDecoration: 'none',
                    transition: 'all 0.3s ease'
                  }}
                >
                  <i className="fas fa-home me-2"></i>
                  Back to Home
                </Link>
                <button 
                  onClick={() => window.history.back()}
                  className="btn btn-outline-secondary btn-lg mb-2"
                  style={{ 
                    borderRadius: '50px',
                    padding: '12px 30px',
                    fontWeight: '600',
                    transition: 'all 0.3s ease'
                  }}
                >
                  <i className="fas fa-arrow-left me-2"></i>
                  Go Back
                </button>
              </motion.div>

              {/* Decorative Elements */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1, delay: 1 }}
                className="decorative-elements mt-5"
              >
                <div className="row justify-content-center">
                  <div className="col-auto">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                      className="text-primary opacity-25"
                    >
                      <i className="fas fa-cog fa-2x"></i>
                    </motion.div>
                  </div>
                  <div className="col-auto mx-4">
                    <motion.div
                      animate={{ 
                        scale: [1, 1.2, 1],
                        opacity: [0.3, 0.7, 0.3]
                      }}
                      transition={{ duration: 3, repeat: Infinity }}
                      className="text-warning"
                    >
                      <i className="fas fa-star fa-2x"></i>
                    </motion.div>
                  </div>
                  <div className="col-auto">
                    <motion.div
                      animate={{ rotate: -360 }}
                      transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
                      className="text-success opacity-25"
                    >
                      <i className="fas fa-sync fa-2x"></i>
                    </motion.div>
                  </div>
                </div>
              </motion.div>

              {/* Quick Links */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 1.2 }}
                className="quick-links mt-5"
              >
                <p className="text-muted mb-3">Or explore these sections:</p>
                <div className="d-flex flex-wrap justify-content-center gap-3">
                  <Link to="/projects" className="btn btn-sm btn-outline-primary rounded-pill">
                    <i className="fas fa-project-diagram me-1"></i>Projects
                  </Link>
                  <Link to="/blogs" className="btn btn-sm btn-outline-info rounded-pill">
                    <i className="fas fa-blog me-1"></i>Blogs
                  </Link>
                  <Link to="/services" className="btn btn-sm btn-outline-success rounded-pill">
                    <i className="fas fa-cogs me-1"></i>Services
                  </Link>
                  <Link to="/skills" className="btn btn-sm btn-outline-warning rounded-pill">
                    <i className="fas fa-code me-1"></i>Skills
                  </Link>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Background Animation */}
      <div className="position-fixed top-0 start-0 w-100 h-100" style={{ zIndex: -1, overflow: 'hidden' }}>
        <motion.div
          animate={{
            background: [
              'linear-gradient(45deg, #f8f9fa 0%, #e9ecef 100%)',
              'linear-gradient(45deg, #e9ecef 0%, #dee2e6 100%)',
              'linear-gradient(45deg, #f8f9fa 0%, #e9ecef 100%)'
            ]
          }}
          transition={{ duration: 10, repeat: Infinity }}
          className="w-100 h-100"
        />
        
        {/* Floating Shapes */}
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="position-absolute"
            style={{
              width: Math.random() * 100 + 50 + 'px',
              height: Math.random() * 100 + 50 + 'px',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              borderRadius: '50%',
              background: `rgba(${Math.random() * 255}, ${Math.random() * 255}, ${Math.random() * 255}, 0.1)`,
            }}
            animate={{
              y: [0, -30, 0],
              x: [0, Math.random() * 20 - 10, 0],
              scale: [1, 1.1, 1],
            }}
            transition={{
              duration: Math.random() * 5 + 3,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <style jsx>{`
        .not-found-container {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
          position: relative;
        }
        
        .btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .error-code h1 {
          background: linear-gradient(45deg, #007bff, #6f42c1);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        
        .floating-icon {
          animation: float 3s ease-in-out infinite;
        }
        
        @keyframes glitch {
          0%, 100% { transform: translateX(0); }
          10% { transform: translateX(-2px); }
          20% { transform: translateX(2px); }
          30% { transform: translateX(-2px); }
          40% { transform: translateX(2px); }
          50% { transform: translateX(-2px); }
        }
        
        .error-message h2:hover {
          animation: glitch 0.5s ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default NotFound;
