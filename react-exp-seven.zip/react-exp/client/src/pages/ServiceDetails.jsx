import React, { useEffect, useState } from 'react'
import ServiceTopSection from '../components/service/ServiceTopSection'
import ServiceSection from '../components/service/ServiceSection'
import ServiceDataApi from '../api/ServiceDataApi';
import { useParams } from 'react-router-dom';


const ServiceDetails = () => {
  const [serviceData, setServiceData] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const { slug } = useParams();

  useEffect(() => {
    fetchServiceData();
  }, [slug]);

  const fetchServiceData = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await ServiceDataApi.getServiceDetails(slug);
      if (response.success) {
        setServiceData(response.data);
      } else {
        setError(response.message || 'Service not found');
      }
    } catch (error) {
      console.error('Error fetching service details:', error);
      setError('Failed to load service details');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <main className='wrapper'>
        <div className="container text-center py-5">
          <div className="spinner-border text-primary" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
        </div>
      </main>
    );
  }

  if (error) {
    return (
      <main className='wrapper'>
        <div className="container text-center py-5">
          <h2>Service Not Found</h2>
          <p className="text-muted">{error}</p>
          <a href="/services" className="btn btn-primary">View All Services</a>
        </div>
      </main>
    );
  }

  return (
    <main className='wrapper'>
        <ServiceTopSection serviceData={serviceData} />
        <ServiceSection serviceData={serviceData} />
    </main>
  )
}

export default ServiceDetails