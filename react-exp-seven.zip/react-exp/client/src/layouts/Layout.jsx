import React, { useContext } from 'react'
import { RootContext } from '../App';
import LoadingBar from 'react-top-loading-bar'
import Header from './Header';
import Footer from './Footer';
import BackToTopWidget from '../components/common/BackToTopWidget';

const Layout = ({ children }) => {
    const rootContext = useContext(RootContext);
    const { progress, setProgress } = rootContext;


    return (
        <div className="layout-wrapper layout-content-navbar">
            <div className="layout-container">
                <div className="layout-page ">
                    <Header />
                    <LoadingBar color='#279EFF' progress={progress} onLoaderFinished={() => setProgress(0)} />
                    <div className="content-wrapper">
                        <div className="container-fluid flex-grow-1 container-p-y">
                            {children}
                        </div>
                        <Footer />
                        <BackToTopWidget />
                    </div>
                </div>
                <div className="layout-overlay layout-menu-toggle"></div>
            </div>
        </div>
    )
}


export default Layout;