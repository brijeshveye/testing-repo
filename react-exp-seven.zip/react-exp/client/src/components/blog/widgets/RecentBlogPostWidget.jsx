import React from 'react'

const RecentBlogPostWidget = (props) => {
    return (
        <>
            <li>
                <a href={props.link} className="recent__innter">
                    <img src={props.imgSrc} alt="img" />
                    <div className="cont__box">
                        <span className="retitle">
                            {props.title}
                        </span>
                        <span className="base fz-16 d-flex align-items-center gap-2">
                            <i className="bi bi-clock"></i>
                            {props.date}
                        </span>
                    </div>
                </a>
            </li>
        </>
    )
}

RecentBlogPostWidget.defaultProps = {
    imgSrc: 'assets/img/blog/bsmall1.png',
    title: 'Default Blog Title',
    date: 'Default Date',
    link: '#'
}

export default RecentBlogPostWidget