import React from 'react'

const BlogTopSection = ({ blogData }) => {
    return (
        <>
            <div className='d-flex pt-5 pb-5'></div>
            <div className="container pt-5 pb-5">
                <div className="row g-4 justify-content-center">
                    <div className="col-lg-8">
                        <div className="breadcrumnd__wrap text-center">
                            <h1>
                                {blogData.title}
                            </h1>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default BlogTopSection