import React from 'react';

const TestimonialCard = ({ testimonial }) => {
  const {
    customerName,
    customerFeedback,
    customerPosition,
    stars = 5,
    customerImage,
    featured
  } = testimonial;

  return (
    <div className={`card h-100 shadow-sm ${featured ? 'border-primary' : ''}`}>
      {featured && (
        <div className="position-absolute top-0 end-0 m-2">
          <span className="badge bg-primary">
            <i className="fas fa-star me-1"></i>Featured
          </span>
        </div>
      )}
      
      <div className="card-body d-flex flex-column">
        <div className="text-center mb-3">
          {customerImage ? (
            <img 
              src={customerImage} 
              alt={customerName}
              className="rounded-circle mb-2"
              style={{ width: '60px', height: '60px', objectFit: 'cover' }}
            />
          ) : (
            <div 
              className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-2"
              style={{ width: '60px', height: '60px' }}
            >
              <i className="fas fa-user fa-lg"></i>
            </div>
          )}
          
          <div className="d-flex justify-content-center mb-2">
            {[...Array(5)].map((_, index) => (
              <i 
                key={index} 
                className={`bi ${index < stars ? 'bi-star-fill text-warning' : 'bi-star text-muted'}`}
              ></i>
            ))}
          </div>
        </div>

        <blockquote className="flex-grow-1">
          <p className="text-muted mb-3 fst-italic">
            "{customerFeedback}"
          </p>
        </blockquote>

        <div className="text-center mt-auto">
          <h6 className="mb-0">{customerName}</h6>
          <small className="text-muted">{customerPosition}</small>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;
