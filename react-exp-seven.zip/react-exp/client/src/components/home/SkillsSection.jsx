import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import SkillsDataApi from '../../api/SkillsDataApi';
import SkillCardWidget from './widgets/SkillCardWidget';

const SkillsSection = () => {

    const [skills, setSkills] = useState([]);
    const [skillCategories, setSkillCategories] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchSkillsData();
    }, []);

    const fetchSkillsData = async () => {
        try {
            setLoading(true);
            const [skillsData, categoriesData] = await Promise.all([
                SkillsDataApi.getSkillsForHome(20), // Get top 20 skills for home
                SkillsDataApi.getSkillCategories()
            ]);
            setSkills(skillsData);
            setSkillCategories(categoriesData.filter(cat => cat !== 'all'));
        } catch (error) {
            console.error('Error fetching skills data:', error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) {
        return (
            <section id="resume" data-scroll-index="2" className="section skills-section bg-gray">
                <div className="container">
                    <div className="section-heading">
                        <h3>Skills</h3>
                    </div>
                    <div className="text-center">
                        <div className="spinner-border text-primary" role="status">
                            <span className="visually-hidden">Loading...</span>
                        </div>
                    </div>
                </div>
            </section>
        );
    }

    return (
        <>
            <section id="resume" data-scroll-index="2" className="section skills-section bg-gray">
                <div className="container">
                    <div className="section-heading">
                        <h3>Skills</h3>
                        <p>My technical expertise and programming proficiencies</p>
                    </div>
                    <div className="row">
                        {
                            skillCategories.map((item, index) => {
                                const categorySkills = skills.filter(skill => 
                                    skill.category.toLowerCase() === item.toLowerCase()
                                );
                                
                                if (categorySkills.length === 0) return null;
                                
                                return (
                                    <React.Fragment key={`skill-category-${index}`}>
                                        <div className="col-xl-3 col-lg-3 col-md-4 col-sm-12 col-sm-12" key={`skill-section-${index}`}>
                                            <div className="skill-category">
                                                <h5 className="common__sub">{item}</h5>
                                            </div>
                                        </div>
                                        <div className="col-lg-3 col-lg-9 col-md-8 col-sm-12" key={`skills-${index}`}>
                                            <div className="row gy-4">
                                                <div className="col-lg-12">
                                                    <ul className="skills-list counter">
                                                        {
                                                            categorySkills.map((skill, idx) => (
                                                                <SkillCardWidget
                                                                    key={skill._id || idx}
                                                                    name={skill.title}
                                                                    icon={skill.icon}
                                                                    color={skill.color}
                                                                    percentage={skill.percentage}
                                                                />
                                                            ))
                                                        }
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </React.Fragment>
                                );
                            })
                        }
                    </div>
                    
                    {/* View All Skills Link */}
                    <div className="row mt-4">
                        <div className="col-12 text-center">
                            <Link to="/skills" className="px-btn px-btn-primary">
                                <span>View All Skills</span>
                                <i className="fas fa-arrow-right ms-2"></i>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default SkillsSection