import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import ServiceCardWidget from './widgets/ServiceCardWidget';
import CharacteristicsDataApi from '../../api/CharacteristicsDataApi';

const CharacteristicsSection = () => {
    const [characteristicsData, setCharacteristicsData] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchCharacteristicsData();
    }, []);

    const fetchCharacteristicsData = async () => {
        try {
            setLoading(true);
            const data = await CharacteristicsDataApi.getCharacteristicsForHome(6); // Get top 6 for home
            setCharacteristicsData(data);
        } catch (error) {
            console.error('Error fetching characteristics data:', error);
        } finally {
            setLoading(false);
        }
    };


    return (
        <>
            <section id="service" className="br-service padding-tb-80 sec-bg">
                <div className="container">
                    <div className="section-title d-none">
                        <h2>My<span> characteristics</span></h2>
                        <span className="ligh-title">characteristics</span>
                    </div>
                    <div className="row service-box m-tb-minus-15px">
                        {loading ? (
                            <div className="col-12 text-center">
                                <div className="spinner-border text-primary" role="status">
                                    <span className="visually-hidden">Loading...</span>
                                </div>
                            </div>
                        ) : (
                            characteristicsData.map((characteristic, index) => (
                                <ServiceCardWidget
                                    key={characteristic._id || index}
                                    title={characteristic.title}
                                    description={characteristic.description}
                                    icon={characteristic.icon || characteristic.iconClass}
                                    link={characteristic.link || `/characteristics/${characteristic.slug}`}
                                    backTitle={characteristic.backTitle || characteristic.title}
                                    backDescription={characteristic.backDescription || characteristic.shortDescription || characteristic.description}
                                />
                            ))
                        )}
                    </div>
                    
                    {/* View All Characteristics Button */}
                    {/* <div className="row mt-4">
                        <div className="col-12 text-center">
                            <Link to="/characteristics" className="px-btn px-btn-primary">
                                <span>View All Characteristics</span>
                                <i className="fas fa-arrow-right ms-2"></i>
                            </Link>
                        </div>
                    </div> */}
                </div>
            </section>
        </>
    )
}

export default CharacteristicsSection;