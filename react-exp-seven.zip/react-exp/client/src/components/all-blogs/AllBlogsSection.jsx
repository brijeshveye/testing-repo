import React, { useEffect, useState } from 'react'
import BlogCardWidget from '../home/widgets/BlogCardWidget';
import BlogsDataApi from '../../api/BlogsDataApi';

const AllBlogsSection = () => {
    const [blogsData, setBlogsData] = useState([]);

    useEffect(() => {
        const fetchBlogs = async () => {
            try {
                const blogs = await BlogsDataApi.getBlogsData();
                setBlogsData(blogs);
            } catch (error) {
                console.error('Error fetching blogs:', error);
                setBlogsData([]);
            }
        };

        fetchBlogs();
    }, []);

    const generateLink = (slug) => {
        return `/blog/details/${slug}`;
    }

    return (
        <>
            <section id="news" className="br-news padding-tb-80">
                <div className="container">
                    <div className="section-title">
                        <h2>Latest <span>News</span></h2>
                        <span className="ligh-title">All Blogs</span>
                    </div>
                    <div className="row m-b-minus-30px">

                        {Array.isArray(blogsData) && blogsData.map((blog, index) => (
                            <div className="col-6 col-md-4 col-lg-3 m-b-30px" key={blog._id || index}>
                                <BlogCardWidget key={blog._id || index}
                                    title={blog.title}
                                    description={blog.description}
                                    image={blog.image}
                                    date={blog.date}
                                    category={blog.category}
                                    link={generateLink(blog.slug)} />
                            </div>

                        ))}

                    </div>
                </div>
            </section>
        </>
    )
}

export default AllBlogsSection