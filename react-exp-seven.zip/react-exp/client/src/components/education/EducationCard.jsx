import React from 'react';

const EducationCard = ({ education, showDetails = true }) => {
  const {
    title,
    institution,
    degree,
    fieldOfStudy,
    startDate,
    endDate,
    current,
    grade,
    description,
    activities = [],
    achievements = [],
    skills = [],
    location,
    image,
    certificateUrl,
    featured
  } = education;

  const formatDate = (date) => {
    if (!date) return '';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short'
    });
  };

  const getDuration = () => {
    const start = formatDate(startDate);
    const end = current ? 'Present' : formatDate(endDate);
    return `${start} - ${end}`;
  };

  const getYearsDuration = () => {
    const start = new Date(startDate);
    const end = current ? new Date() : new Date(endDate);
    const years = (end - start) / (1000 * 60 * 60 * 24 * 365.25);
    return years >= 1 ? `${Math.round(years * 10) / 10} years` : `${Math.round(years * 12)} months`;
  };

  const getDegreeIcon = (degree) => {
    const degreeMap = {
      'bachelor': 'fas fa-graduation-cap',
      'master': 'fas fa-user-graduate',
      'phd': 'fas fa-university',
      'doctorate': 'fas fa-university',
      'diploma': 'fas fa-certificate',
      'certificate': 'fas fa-award'
    };
    
    if (!degree) return 'fas fa-graduation-cap';
    
    const lowerDegree = degree.toLowerCase();
    for (const [key, icon] of Object.entries(degreeMap)) {
      if (lowerDegree.includes(key)) {
        return icon;
      }
    }
    return 'fas fa-graduation-cap';
  };

  const getDegreeColor = (degree) => {
    const colorMap = {
      'bachelor': '#007bff',
      'master': '#28a745',
      'phd': '#dc3545',
      'doctorate': '#dc3545',
      'diploma': '#ffc107',
      'certificate': '#17a2b8'
    };
    
    if (!degree) return '#007bff';
    
    const lowerDegree = degree.toLowerCase();
    for (const [key, color] of Object.entries(colorMap)) {
      if (lowerDegree.includes(key)) {
        return color;
      }
    }
    return '#007bff';
  };

  return (
    <div className={`card h-100 ${featured ? 'border-warning' : ''}`}>
      {featured && (
        <div className="card-header bg-warning text-dark py-1">
          <small className="d-flex align-items-center justify-content-center">
            <i className="fas fa-star me-1"></i>
            Featured Education
          </small>
        </div>
      )}
      
      <div className="card-body d-flex flex-column">
        <div className="d-flex align-items-start mb-3">
          {image ? (
            <img 
              src={image} 
              alt={institution}
              className="me-3 rounded"
              style={{ width: '60px', height: '60px', objectFit: 'cover' }}
            />
          ) : (
            <div 
              className="me-3 d-flex align-items-center justify-content-center rounded"
              style={{ 
                width: '60px', 
                height: '60px', 
                backgroundColor: getDegreeColor(degree),
                color: '#fff'
              }}
            >
              <i className={`${getDegreeIcon(degree)} fa-lg`}></i>
            </div>
          )}
          
          <div className="flex-grow-1">
            <h5 className="card-title mb-1">{title}</h5>
            <h6 className="text-primary mb-1">{institution}</h6>
            {location && (
              <small className="text-muted">
                <i className="fas fa-map-marker-alt me-1"></i>
                {location}
              </small>
            )}
          </div>
          
          {current && (
            <span className="badge bg-success">Current</span>
          )}
        </div>

        <div className="flex-grow-1">
          {degree && (
            <div className="mb-2">
              <span className="badge bg-primary me-2">{degree}</span>
              {fieldOfStudy && (
                <span className="badge bg-secondary">{fieldOfStudy}</span>
              )}
            </div>
          )}

          <div className="mb-2">
            <small className="text-muted">
              <i className="fas fa-calendar-alt me-1"></i>
              {getDuration()}
              <span className="ms-2">({getYearsDuration()})</span>
            </small>
          </div>

          {grade && (
            <div className="mb-2">
              <small className="text-muted">
                <strong>Grade:</strong> {grade}
              </small>
            </div>
          )}

          {showDetails && description && (
            <p className="card-text text-muted small mb-3">
              {description.length > 100 ? `${description.substring(0, 100)}...` : description}
            </p>
          )}

          {showDetails && achievements.length > 0 && (
            <div className="mb-2">
              <small className="text-muted d-block mb-1">
                <strong><i className="fas fa-trophy me-1"></i>Achievements:</strong>
              </small>
              <ul className="list-unstyled small">
                {achievements.slice(0, 2).map((achievement, index) => (
                  <li key={index} className="text-muted">
                    <i className="fas fa-check text-success me-1"></i>
                    {achievement}
                  </li>
                ))}
                {achievements.length > 2 && (
                  <li className="text-muted">
                    <i className="fas fa-ellipsis-h me-1"></i>
                    +{achievements.length - 2} more
                  </li>
                )}
              </ul>
            </div>
          )}

          {showDetails && activities.length > 0 && (
            <div className="mb-2">
              <small className="text-muted">
                <i className="fas fa-users me-1"></i>
                {activities.length} activit{activities.length !== 1 ? 'ies' : 'y'}
              </small>
            </div>
          )}

          {showDetails && skills.length > 0 && (
            <div className="mb-2">
              <small className="text-muted d-block mb-1">
                <strong>Skills gained:</strong>
              </small>
              <div className="d-flex flex-wrap gap-1">
                {skills.slice(0, 4).map((skill, index) => (
                  <span key={index} className="badge bg-light text-dark">
                    {skill}
                  </span>
                ))}
                {skills.length > 4 && (
                  <span className="badge bg-light text-muted">
                    +{skills.length - 4} more
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {certificateUrl && (
          <div className="mt-auto pt-2">
            <a 
              href={certificateUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="btn btn-outline-primary btn-sm"
            >
              <i className="fas fa-certificate me-1"></i>
              View Certificate
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

export default EducationCard;
