import React from 'react';

const ExperienceCard = ({ experience, onEdit, onDelete, onToggleFeatured, onToggleActive, showActions = true }) => {
  const formatDate = (date) => {
    if (!date) return 'Present';
    return new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  const getDuration = (startDate, endDate, current) => {
    const start = formatDate(startDate);
    const end = current ? 'Present' : formatDate(endDate);
    return `${start} - ${end}`;
  };

  return (
    <div className="col-md-6 col-lg-4 mb-4">
      <div className="card h-100 shadow-sm">
        {experience.companyLogo && (
          <div className="card-img-top d-flex justify-content-center align-items-center p-3" style={{ height: '150px' }}>
            <img 
              src={experience.companyLogo} 
              alt={experience.company}
              className="img-fluid"
              style={{ maxHeight: '100%', maxWidth: '100%', objectFit: 'contain' }}
            />
          </div>
        )}
        
        <div className="card-body d-flex flex-column">
          <div className="d-flex justify-content-between align-items-start mb-2">
            <h5 className="card-title text-primary mb-0">{experience.title}</h5>
            <div className="d-flex gap-1">
              {experience.featured && (
                <span className="badge bg-warning text-dark">
                  <i className="fas fa-star"></i>
                </span>
              )}
              {experience.current && (
                <span className="badge bg-success">
                  <i className="fas fa-circle"></i> Current
                </span>
              )}
              {!experience.isActive && (
                <span className="badge bg-secondary">
                  <i className="fas fa-eye-slash"></i> Hidden
                </span>
              )}
            </div>
          </div>
          
          <h6 className="card-subtitle mb-2 text-muted">{experience.company}</h6>
          
          <div className="mb-2">
            <small className="text-muted">
              <i className="fas fa-calendar me-1"></i>
              {getDuration(experience.startDate, experience.endDate, experience.current)}
            </small>
            {experience.location && (
              <div>
                <small className="text-muted">
                  <i className="fas fa-map-marker-alt me-1"></i>
                  {experience.location}
                </small>
              </div>
            )}
          </div>

          <div className="mb-2">
            <span className="badge bg-light text-dark">{experience.employmentType}</span>
            {experience.industry && (
              <span className="badge bg-light text-dark ms-1">{experience.industry}</span>
            )}
          </div>
          
          {experience.description && (
            <p className="card-text">
              {experience.description.length > 100 
                ? `${experience.description.substring(0, 100)}...` 
                : experience.description
              }
            </p>
          )}

          {experience.responsibilities && experience.responsibilities.length > 0 && (
            <div className="mb-3">
              <small className="text-muted">Key Responsibilities:</small>
              <ul className="list-unstyled mt-1">
                {experience.responsibilities.slice(0, 2).map((resp, index) => (
                  <li key={index} className="small">
                    <i className="fas fa-check text-success me-1"></i>
                    {resp.length > 60 ? `${resp.substring(0, 60)}...` : resp}
                  </li>
                ))}
                {experience.responsibilities.length > 2 && (
                  <li className="small text-muted">
                    +{experience.responsibilities.length - 2} more...
                  </li>
                )}
              </ul>
            </div>
          )}

          {experience.skills && experience.skills.length > 0 && (
            <div className="mb-3">
              <div className="d-flex flex-wrap gap-1">
                {experience.skills.slice(0, 4).map((skill, index) => (
                  <span key={index} className="badge bg-primary">
                    {skill}
                  </span>
                ))}
                {experience.skills.length > 4 && (
                  <span className="badge bg-secondary">
                    +{experience.skills.length - 4} more
                  </span>
                )}
              </div>
            </div>
          )}
          
          {showActions && (
            <div className="mt-auto pt-3 border-top">
              <div className="d-flex justify-content-between align-items-center">
                <div className="btn-group" role="group">
                  <button
                    className="btn btn-outline-primary btn-sm"
                    onClick={() => onEdit(experience)}
                    title="Edit Experience"
                  >
                    <i className="fas fa-edit"></i>
                  </button>
                  <button
                    className={`btn btn-sm ${experience.featured ? 'btn-warning' : 'btn-outline-warning'}`}
                    onClick={() => onToggleFeatured(experience.slug)}
                    title="Toggle Featured"
                  >
                    <i className="fas fa-star"></i>
                  </button>
                  <button
                    className={`btn btn-sm ${experience.isActive ? 'btn-success' : 'btn-outline-success'}`}
                    onClick={() => onToggleActive(experience.slug)}
                    title="Toggle Visibility"
                  >
                    <i className={`fas ${experience.isActive ? 'fa-eye' : 'fa-eye-slash'}`}></i>
                  </button>
                </div>
                <button
                  className="btn btn-outline-danger btn-sm"
                  onClick={() => onDelete(experience)}
                  title="Delete Experience"
                >
                  <i className="fas fa-trash"></i>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ExperienceCard;
