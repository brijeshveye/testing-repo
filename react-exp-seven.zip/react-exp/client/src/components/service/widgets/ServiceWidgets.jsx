import React from 'react';

const ServiceWidgets = {
  // Heading Widget
  heading: ({ data }) => (
    <div className="text__box mb__cus60">
      <h3 className="textt36 d-block" style={{ fontSize: data.size || '36px', color: data.color || 'inherit' }}>
        {data.text}
      </h3>
    </div>
  ),

  // Paragraph Widget
  paragraph: ({ data }) => (
    <div className="text__box mb__cus60">
      <p className="fz-16 pra" style={{ color: data.color || 'inherit' }}>
        {data.text}
      </p>
    </div>
  ),

  // List Widget
  list: ({ data }) => (
    <div className="text__box mb__cus60">
      {data.title && (
        <h3 className="textt36 d-block">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra">
          {data.description}
        </p>
      )}
      <ul className={data.listType === 'ordered' ? 'challenge__list ordered-list' : 'challenge__list'}>
        {data.items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ul>
    </div>
  ),

  // Spacer Widget
  spacer: ({ data }) => (
    <div style={{ height: data.height || '20px' }}>
      {/* Spacer for layout */}
    </div>
  ),

  // Image Widget
  image: ({ data }) => (
    <div className="text__box mb__cus60">
      {data.title && (
        <h3 className="textt36 d-block">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra mb-3">
          {data.description}
        </p>
      )}
      {data.layout === 'side-by-side' && data.images?.length >= 2 ? (
        <div className="row g-2 mb__cus60">
          <div className="col-lg-6 col-md-6 col-sm-6">
            <div className="w-100">
              <img 
                src={data.images[0]} 
                alt={data.alt || 'Service image'} 
                className="w-100"
                style={{ borderRadius: data.borderRadius || '0px' }}
              />
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6">
            <div className="w-100">
              <img 
                src={data.images[1]} 
                alt={data.alt || 'Service image'} 
                className="w-100"
                style={{ borderRadius: data.borderRadius || '0px' }}
              />
            </div>
          </div>
          {data.images[2] && (
            <div className="col-lg-6 col-md-6 col-sm-6">
              <div className="w-100">
                <img 
                  src={data.images[2]} 
                  alt={data.alt || 'Service image'} 
                  className="w-100"
                  style={{ borderRadius: data.borderRadius || '0px' }}
                />
              </div>
            </div>
          )}
          {data.images[3] && (
            <div className="col-lg-6 col-md-6 col-sm-6">
              <div className="w-100">
                <img 
                  src={data.images[3]} 
                  alt={data.alt || 'Service image'} 
                  className="w-100"
                  style={{ borderRadius: data.borderRadius || '0px' }}
                />
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="single-image mb__cus60">
          <img 
            src={data.src || data.images?.[0]} 
            alt={data.alt || 'Service image'} 
            style={{ 
              width: data.width || '100%', 
              borderRadius: data.borderRadius || '0px'
            }} 
          />
        </div>
      )}
      {data.caption && (
        <div className="image-caption text-center mt-2" style={{ fontSize: '14px', color: '#6c757d', fontStyle: 'italic' }}>
          {data.caption}
        </div>
      )}
    </div>
  ),

  // Video Widget (specific to services)
  video: ({ data }) => (
    <div className="paythumb position-relative mb__cus60" data-aos="fade-up" data-aos-duration="2000">
      {data.title && (
        <h3 className="textt36 d-block mb-3">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra mb-3">
          {data.description}
        </p>
      )}
      <img src={data.image || data.src} alt={data.alt || 'Service video thumbnail'} />
      <a href={data.videoUrl} className="video__80 video-btn">
        <i className="bi bi-play-fill"></i>
      </a>
    </div>
  ),

  // YouTube Widget
  youtube: ({ data }) => (
    <div className="text__box mb__cus60" data-aos="fade-up" data-aos-duration="2000">
      {data.title && (
        <h3 className="textt36 d-block">
          {data.title}
        </h3>
      )}
      {data.description && (
        <p className="fz-16 pra mb-3">
          {data.description}
        </p>
      )}
      <div className="video-container" style={{ position: 'relative', paddingBottom: '56.25%', height: 0, overflow: 'hidden' }}>
        <iframe
          src={`https://www.youtube.com/embed/${data.videoId}`}
          title={data.title || 'Service video'}
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            width: '100%',
            height: '100%',
            border: 'none'
          }}
          allowFullScreen
        />
      </div>
    </div>
  )
};

export default ServiceWidgets;
