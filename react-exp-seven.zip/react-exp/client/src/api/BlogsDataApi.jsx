import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const BlogsDataApi = {
  // Fetch all blogs from the backend
  getBlogsData: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/blogs`);
      return response.data;
    } catch (error) {
      console.error('Error fetching blogs:', error);
      return [];
    }
  },

  // Get blogs for home page with limit
  getBlogsForHome: async (limit = 4) => {
    try {
      const blogsData = await BlogsDataApi.getBlogsData();
      const shuffled = blogsData.sort(() => Math.random() - 0.5);
      return shuffled.slice(0, limit);
    } catch (error) {
      console.error('Error fetching blogs for home:', error);
      return [];
    }
  },

  // Get unique blog categories
  getBlogCategories: async () => {
    try {
      const blogsData = await BlogsDataApi.getBlogsData();
      const blogCategories = new Set();
      
      blogsData.forEach(blog => {
        if (blog.category) {
          blogCategories.add(blog.category);
        }
      });

      return Array.from(blogCategories).map(category => ({
        name: category,
        link: "#0"
      }));
    } catch (error) {
      console.error('Error fetching blog categories:', error);
      return [];
    }
  },

  // Get recent blogs (sorted by date)
  getRecentBlogs: async (limit = 3) => {
    try {
      const blogsData = await BlogsDataApi.getBlogsData();
      const sortedBlogs = blogsData
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, limit);

      return sortedBlogs.map(blog => ({
        title: blog.title,
        slug: blog.slug,
        image: blog.image,
        date: blog.date
      }));
    } catch (error) {
      console.error('Error fetching recent blogs:', error);
      return [];
    }
  },

  // Get blogs by category
  getBlogsFromCategory: async (category) => {
    try {
      const blogsData = await BlogsDataApi.getBlogsData();
      return blogsData.filter(blog => blog.category === category);
    } catch (error) {
      console.error('Error fetching blogs from category:', error);
      return [];
    }
  },

  // Get all unique blog tags
  getBlogTags: async () => {
    try {
      const blogsData = await BlogsDataApi.getBlogsData();
      const blogTags = new Set();
      
      blogsData.forEach(blog => {
        if (blog.tags && Array.isArray(blog.tags)) {
          blog.tags.forEach(tag => {
            blogTags.add(tag);
          });
        }
      });
      
      return Array.from(blogTags).map(tag => ({
        name: tag,
        link: "#0"
      }));
    } catch (error) {
      console.error('Error fetching blog tags:', error);
      return [];
    }
  },

  // Get blog details by slug
  getBlogDetails: async (slug) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/blogs/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching blog details:', error);
      return null;
    }
  },

  // Create a new blog
  createBlog: async (blogData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/blogs`, blogData);
      return response.data;
    } catch (error) {
      console.error('Error creating blog:', error);
      throw error;
    }
  },

  // Update an existing blog
  updateBlog: async (blogId, blogData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/blogs/${blogId}`, blogData);
      return response.data;
    } catch (error) {
      console.error('Error updating blog:', error);
      throw error;
    }
  },

  // Delete a blog
  deleteBlog: async (blogId) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/blogs/${blogId}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting blog:', error);
      throw error;
    }
  }
};

export default BlogsDataApi;