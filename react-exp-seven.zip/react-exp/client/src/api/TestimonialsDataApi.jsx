import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api';

const TestimonialsDataApi = {
  // Fetch all testimonials from the backend
  getTestimonialsData: async (params = {}) => {
    try {
      const queryParams = new URLSearchParams(params).toString();
      const url = queryParams ? `${API_BASE_URL}/testimonials?${queryParams}` : `${API_BASE_URL}/testimonials`;
      const response = await axios.get(url);
      return response.data;
    } catch (error) {
      console.error('Error fetching testimonials:', error);
      return [];
    }
  },

  // Get testimonials for home page with limit
  getTestimonialsForHome: async (limit = 3) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/testimonials?isActive=true&limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching testimonials for home:', error);
      return [];
    }
  },

  // Get featured testimonials
  getFeaturedTestimonials: async (limit = 6) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/testimonials?featured=true&isActive=true&limit=${limit}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching featured testimonials:', error);
      return [];
    }
  },

  // Get testimonial details by slug
  getTestimonialDetails: async (slug) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/testimonials/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error fetching testimonial details:', error);
      return null;
    }
  },

  // Create a new testimonial
  createTestimonial: async (testimonialData) => {
    try {
      const response = await axios.post(`${API_BASE_URL}/testimonials`, testimonialData);
      return response.data;
    } catch (error) {
      console.error('Error creating testimonial:', error);
      throw error;
    }
  },

  // Update an existing testimonial
  updateTestimonial: async (slug, testimonialData) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/testimonials/${slug}`, testimonialData);
      return response.data;
    } catch (error) {
      console.error('Error updating testimonial:', error);
      throw error;
    }
  },

  // Delete a testimonial (soft delete)
  deleteTestimonial: async (slug) => {
    try {
      const response = await axios.delete(`${API_BASE_URL}/testimonials/${slug}`);
      return response.data;
    } catch (error) {
      console.error('Error deleting testimonial:', error);
      throw error;
    }
  },

  // Update testimonials order
  updateTestimonialsOrder: async (testimonials) => {
    try {
      const response = await axios.put(`${API_BASE_URL}/testimonials/order`, { testimonials });
      return response.data;
    } catch (error) {
      console.error('Error updating testimonials order:', error);
      throw error;
    }
  },

  // Get testimonials by rating
  getTestimonialsByRating: async (rating) => {
    try {
      const testimonials = await TestimonialsDataApi.getTestimonialsData({ isActive: true });
      return testimonials.filter(testimonial => testimonial.rating === rating);
    } catch (error) {
      console.error('Error fetching testimonials by rating:', error);
      return [];
    }
  },

  // Get testimonials by company
  getTestimonialsByCompany: async (company) => {
    try {
      const testimonials = await TestimonialsDataApi.getTestimonialsData({ isActive: true });
      return testimonials.filter(testimonial => 
        testimonial.company.toLowerCase().includes(company.toLowerCase())
      );
    } catch (error) {
      console.error('Error fetching testimonials by company:', error);
      return [];
    }
  }
};

export default TestimonialsDataApi;
