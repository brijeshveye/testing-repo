const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../data/blogsData.json');

const readBlogs = () => {
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
};

const writeBlogs = (blogs) => {
    fs.writeFileSync(filePath, JSON.stringify(blogs, null, 4));
};

module.exports = {
    readBlogs,
    writeBlogs
};
