const mongoose = require('mongoose');

// Widget Schema for dynamic content (reusable)
const widgetSchema = new mongoose.Schema({
  id: {
    type: String,
    required: true
  },
  type: {
    type: String,
    required: true,
    enum: ['heading', 'paragraph', 'list', 'spacer', 'image', 'youtube', 'video', 'quote']
  },
  data: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  }
}, { _id: false });

// Blog details schema
const blogDetailsSchema = new mongoose.Schema({
  section1: {
    para1: String,
    para2: String
  },
  section2: {
    quote: String,
    author: String
  },
  section3: {
    para: String
  },
  section4: {
    title: String,
    image1: String,
    para1: String,
    para2: String,
    list: [String]
  }
}, { _id: false });

// Blog Schema
const blogSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    trim: true
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  bannerImage: {
    type: String,
    default: ''
  },
  image: {
    type: String,
    default: ''
  },
  date: {
    type: String,
    default: ''
  },
  author: {
    type: String,
    default: ''
  },
  category: {
    type: String,
    default: ''
  },
  tags: {
    type: [String],
    default: []
  },
  widgets: {
    type: [widgetSchema],
    default: []
  },
  details: {
    type: blogDetailsSchema,
    default: {}
  },
  published: {
    type: Boolean,
    default: true
  },
  views: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true
});

// Indexes for better search performance
blogSchema.index({ slug: 1 });
blogSchema.index({ category: 1 });
blogSchema.index({ author: 1 });
blogSchema.index({ published: 1 });
blogSchema.index({ title: 'text', description: 'text' });
blogSchema.index({ date: -1 });

module.exports = mongoose.model('Blog', blogSchema);
