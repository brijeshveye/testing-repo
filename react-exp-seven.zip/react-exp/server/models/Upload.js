const mongoose = require('mongoose');

// Upload Schema for tracking uploaded files
const uploadSchema = new mongoose.Schema({
  filename: {
    type: String,
    required: true
  },
  originalName: {
    type: String,
    required: true
  },
  mimetype: {
    type: String,
    required: true
  },
  size: {
    type: Number,
    required: true
  },
  category: {
    type: String,
    required: true,
    enum: ['general', 'profile', 'project', 'blog', 'content', 'banner', 'thumbnail', 'resume'],
    default: 'general'
  },
  url: {
    type: String,
    required: true
  },
  uploadedBy: {
    type: String,
    default: 'admin'
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

// Indexes for better search performance
uploadSchema.index({ category: 1 });
uploadSchema.index({ filename: 1 });
uploadSchema.index({ isActive: 1 });
uploadSchema.index({ createdAt: -1 });

module.exports = mongoose.model('Upload', uploadSchema);
