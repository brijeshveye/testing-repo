const mongoose = require('mongoose');

const skillSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true
  },
  description: {
    type: String,
    default: ''
  },
  icon: {
    type: String,
    default: 'fas fa-code'
  },
  color: {
    type: String,
    default: '#007bff'
  },
  percentage: {
    type: Number,
    required: true,
    min: 0,
    max: 100,
    default: 50
  },
  category: {
    type: String,
    required: true,
    default: 'General'
  },
  slug: {
    type: String,
    required: true,
    unique: true,
    index: true
  },
  level: {
    type: String,
    enum: ['Beginner', 'Intermediate', 'Advanced', 'Expert'],
    default: 'Intermediate'
  },
  yearsOfExperience: {
    type: Number,
    default: 0
  },
  featured: {
    type: Boolean,
    default: false
  },
  isActive: {
    type: Boolean,
    default: true
  },
  order: {
    type: Number,
    default: 0
  },
  relatedSkills: [{
    type: String,
    trim: true
  }],
  projects: [{
    type: String,
    trim: true
  }],
  certifications: [{
    type: String,
    trim: true
  }]
}, {
  timestamps: true
});

// Create slug from title before saving
skillSchema.pre('save', function(next) {
  if (this.isModified('title') && !this.slug) {
    this.slug = this.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '');
  }
  next();
});

module.exports = mongoose.model('Skill', skillSchema);
