const Education = require('../models/Education');

// Get all education records
const getAllEducation = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search,
      featured,
      isActive,
      degree,
      institution,
      current,
      sortBy = 'startDate',
      sortOrder = 'desc'
    } = req.query;

    // Build filter object
    const filter = {};
    
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { institution: { $regex: search, $options: 'i' } },
        { degree: { $regex: search, $options: 'i' } },
        { fieldOfStudy: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    if (featured !== undefined) {
      filter.featured = featured === 'true';
    }

    if (isActive !== undefined) {
      filter.isActive = isActive === 'true';
    }

    if (degree) {
      filter.degree = { $regex: degree, $options: 'i' };
    }

    if (institution) {
      filter.institution = { $regex: institution, $options: 'i' };
    }

    if (current !== undefined) {
      filter.current = current === 'true';
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Add secondary sort by order for consistent ordering
    if (sortBy !== 'order') {
      sort.order = 1;
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const education = await Education.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limitNum);

    const total = await Education.countDocuments(filter);

    res.json({
      education,
      pagination: {
        currentPage: pageNum,
        totalPages: Math.ceil(total / limitNum),
        totalItems: total,
        itemsPerPage: limitNum
      }
    });
  } catch (error) {
    console.error('Error fetching education:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get education by slug
const getEducationBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const education = await Education.findOne({ slug, isActive: true });

    if (!education) {
      return res.status(404).json({ message: 'Education record not found' });
    }

    res.json(education);
  } catch (error) {
    console.error('Error fetching education by slug:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Create new education record
const createEducation = async (req, res) => {
  try {
    const educationData = req.body;

    // Generate slug if not provided
    if (!educationData.slug && educationData.title && educationData.institution) {
      educationData.slug = `${educationData.title}-${educationData.institution}`
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
    }

    // Check if slug already exists
    if (educationData.slug) {
      const existingEducation = await Education.findOne({ slug: educationData.slug });
      if (existingEducation) {
        return res.status(400).json({ 
          message: 'Education record with this slug already exists' 
        });
      }
    }

    const education = new Education(educationData);
    await education.save();

    res.status(201).json(education);
  } catch (error) {
    console.error('Error creating education:', error);
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        message: 'Validation error', 
        errors: Object.values(error.errors).map(e => e.message) 
      });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update education record
const updateEducation = async (req, res) => {
  try {
    const { slug } = req.params;
    const updateData = req.body;

    // If slug is being updated, check if new slug already exists
    if (updateData.slug && updateData.slug !== slug) {
      const existingEducation = await Education.findOne({ slug: updateData.slug });
      if (existingEducation) {
        return res.status(400).json({ 
          message: 'Education record with this slug already exists' 
        });
      }
    }

    const education = await Education.findOneAndUpdate(
      { slug },
      updateData,
      { new: true, runValidators: true }
    );

    if (!education) {
      return res.status(404).json({ message: 'Education record not found' });
    }

    res.json(education);
  } catch (error) {
    console.error('Error updating education:', error);
    if (error.name === 'ValidationError') {
      return res.status(400).json({ 
        message: 'Validation error', 
        errors: Object.values(error.errors).map(e => e.message) 
      });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Delete education record
const deleteEducation = async (req, res) => {
  try {
    const { slug } = req.params;

    const education = await Education.findOneAndDelete({ slug });

    if (!education) {
      return res.status(404).json({ message: 'Education record not found' });
    }

    res.json({ message: 'Education record deleted successfully' });
  } catch (error) {
    console.error('Error deleting education:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Toggle featured status
const toggleFeatured = async (req, res) => {
  try {
    const { slug } = req.params;

    const education = await Education.findOne({ slug });
    if (!education) {
      return res.status(404).json({ message: 'Education record not found' });
    }

    education.featured = !education.featured;
    await education.save();

    res.json(education);
  } catch (error) {
    console.error('Error toggling featured status:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Toggle active status
const toggleActive = async (req, res) => {
  try {
    const { slug } = req.params;

    const education = await Education.findOne({ slug });
    if (!education) {
      return res.status(404).json({ message: 'Education record not found' });
    }

    education.isActive = !education.isActive;
    await education.save();

    res.json(education);
  } catch (error) {
    console.error('Error toggling active status:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update education order
const updateEducationOrder = async (req, res) => {
  try {
    const { education } = req.body;

    if (!Array.isArray(education)) {
      return res.status(400).json({ message: 'Education must be an array' });
    }

    // Update order for each education record
    const updatePromises = education.map((edu, index) => 
      Education.findByIdAndUpdate(edu._id, { order: index + 1 })
    );

    await Promise.all(updatePromises);

    res.json({ message: 'Education order updated successfully' });
  } catch (error) {
    console.error('Error updating education order:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get education statistics
const getEducationStats = async (req, res) => {
  try {
    const totalEducation = await Education.countDocuments();
    const activeEducation = await Education.countDocuments({ isActive: true });
    const featuredEducation = await Education.countDocuments({ featured: true });
    const currentEducation = await Education.countDocuments({ current: true });

    // Get degree statistics
    const degreeStats = await Education.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$degree', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    // Get institution statistics
    const institutionStats = await Education.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$institution', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      totalEducation,
      activeEducation,
      featuredEducation,
      currentEducation,
      degreeStats,
      institutionStats
    });
  } catch (error) {
    console.error('Error fetching education stats:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getAllEducation,
  getEducationBySlug,
  createEducation,
  updateEducation,
  deleteEducation,
  toggleFeatured,
  toggleActive,
  updateEducationOrder,
  getEducationStats
};
