const Skill = require('../models/Skill');

// Get all skills with filtering
const getSkills = async (req, res) => {
  try {
    const { 
      category, 
      level,
      featured, 
      isActive, 
      limit, 
      minPercentage,
      maxPercentage,
      search
    } = req.query;

    // Build filter object
    let filter = {};

    if (category && category !== 'all') {
      filter.category = new RegExp(category, 'i');
    }

    if (level && level !== 'all') {
      filter.level = level;
    }

    if (featured !== undefined) {
      filter.featured = featured === 'true';
    }

    if (isActive !== undefined) {
      filter.isActive = isActive === 'true';
    }

    if (minPercentage) {
      filter.percentage = { ...filter.percentage, $gte: parseInt(minPercentage) };
    }

    if (maxPercentage) {
      filter.percentage = { ...filter.percentage, $lte: parseInt(maxPercentage) };
    }

    if (search) {
      filter.$or = [
        { title: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') },
        { category: new RegExp(search, 'i') },
        { level: new RegExp(search, 'i') }
      ];
    }

    // Build query
    let query = Skill.find(filter).sort({ order: 1, percentage: -1, createdAt: -1 });

    // Apply limit if specified
    if (limit) {
      query = query.limit(parseInt(limit));
    }

    const skills = await query;
    res.json(skills);
  } catch (error) {
    console.error('Error fetching skills:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get skill by slug
const getSkillBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const skill = await Skill.findOne({ slug, isActive: true });
    
    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    res.json(skill);
  } catch (error) {
    console.error('Error fetching skill:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Create new skill
const createSkill = async (req, res) => {
  try {
    const skillData = req.body;

    // Generate slug if not provided
    if (!skillData.slug && skillData.title) {
      skillData.slug = skillData.title
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
    }

    // Check if slug already exists
    const existingSkill = await Skill.findOne({ slug: skillData.slug });
    if (existingSkill) {
      skillData.slug = `${skillData.slug}-${Date.now()}`;
    }

    const skill = new Skill(skillData);
    await skill.save();

    res.status(201).json(skill);
  } catch (error) {
    console.error('Error creating skill:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update skill
const updateSkill = async (req, res) => {
  try {
    const { slug } = req.params;
    const updateData = req.body;

    const skill = await Skill.findOneAndUpdate(
      { slug },
      updateData,
      { new: true, runValidators: true }
    );

    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    res.json(skill);
  } catch (error) {
    console.error('Error updating skill:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Delete skill
const deleteSkill = async (req, res) => {
  try {
    const { slug } = req.params;
    
    const skill = await Skill.findOneAndDelete({ slug });
    
    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    res.json({ message: 'Skill deleted successfully' });
  } catch (error) {
    console.error('Error deleting skill:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Update skills order
const updateSkillsOrder = async (req, res) => {
  try {
    const { skills } = req.body;

    // Update order for each skill
    const updatePromises = skills.map((skill, index) => 
      Skill.findByIdAndUpdate(skill._id, { order: index + 1 })
    );

    await Promise.all(updatePromises);

    res.json({ message: 'Skills order updated successfully' });
  } catch (error) {
    console.error('Error updating skills order:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Toggle skill featured status
const toggleFeatured = async (req, res) => {
  try {
    const { slug } = req.params;
    
    const skill = await Skill.findOne({ slug });
    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    skill.featured = !skill.featured;
    await skill.save();

    res.json(skill);
  } catch (error) {
    console.error('Error toggling featured status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Toggle skill active status
const toggleActive = async (req, res) => {
  try {
    const { slug } = req.params;
    
    const skill = await Skill.findOne({ slug });
    if (!skill) {
      return res.status(404).json({ error: 'Skill not found' });
    }

    skill.isActive = !skill.isActive;
    await skill.save();

    res.json(skill);
  } catch (error) {
    console.error('Error toggling active status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

// Get skill statistics
const getSkillStats = async (req, res) => {
  try {
    const totalSkills = await Skill.countDocuments();
    const activeSkills = await Skill.countDocuments({ isActive: true });
    const featuredSkills = await Skill.countDocuments({ featured: true, isActive: true });
    
    const categoryStats = await Skill.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$category', count: { $sum: 1 }, avgPercentage: { $avg: '$percentage' } } },
      { $sort: { count: -1 } }
    ]);

    const levelStats = await Skill.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$level', count: { $sum: 1 }, avgPercentage: { $avg: '$percentage' } } },
      { $sort: { count: -1 } }
    ]);

    res.json({
      totalSkills,
      activeSkills,
      featuredSkills,
      categoryStats,
      levelStats
    });
  } catch (error) {
    console.error('Error getting skill stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};

module.exports = {
  getSkills,
  getSkillBySlug,
  createSkill,
  updateSkill,
  deleteSkill,
  updateSkillsOrder,
  toggleFeatured,
  toggleActive,
  getSkillStats
};
