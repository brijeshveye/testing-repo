const Experience = require('../models/Experience');

// Get all experience records
const getAllExperience = async (req, res) => {
  try {
    const {
      page = 1,
      limit = 10,
      search,
      featured,
      isActive,
      company,
      employmentType,
      current,
      sortBy = 'startDate',
      sortOrder = 'desc'
    } = req.query;

    // Build filter object
    const filter = {};
    
    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { company: { $regex: search, $options: 'i' } },
        { location: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { industry: { $regex: search, $options: 'i' } }
      ];
    }

    if (featured !== undefined) {
      filter.featured = featured === 'true';
    }

    if (isActive !== undefined) {
      filter.isActive = isActive === 'true';
    }

    if (company) {
      filter.company = { $regex: company, $options: 'i' };
    }

    if (employmentType) {
      filter.employmentType = employmentType;
    }

    if (current !== undefined) {
      filter.current = current === 'true';
    }

    // Build sort object
    const sort = {};
    sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

    // Add secondary sort by order for consistent ordering
    if (sortBy !== 'order') {
      sort.order = 1;
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const experience = await Experience.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(limitNum);

    const total = await Experience.countDocuments(filter);

    res.json({
      experience,
      pagination: {
        currentPage: pageNum,
        totalPages: Math.ceil(total / limitNum),
        totalItems: total,
        itemsPerPage: limitNum
      }
    });
  } catch (error) {
    console.error('Error fetching experience:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get experience by slug
const getExperienceBySlug = async (req, res) => {
  try {
    const { slug } = req.params;
    const experience = await Experience.findOne({ slug, isActive: true });

    if (!experience) {
      return res.status(404).json({ message: 'Experience record not found' });
    }

    res.json(experience);
  } catch (error) {
    console.error('Error fetching experience by slug:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Create new experience record
const createExperience = async (req, res) => {
  try {
    const experience = new Experience(req.body);
    await experience.save();
    res.status(201).json(experience);
  } catch (error) {
    console.error('Error creating experience:', error);
    res.status(400).json({ message: 'Error creating experience', error: error.message });
  }
};

// Update experience record
const updateExperience = async (req, res) => {
  try {
    const { slug } = req.params;
    const experience = await Experience.findOneAndUpdate(
      { slug },
      req.body,
      { new: true, runValidators: true }
    );

    if (!experience) {
      return res.status(404).json({ message: 'Experience record not found' });
    }

    res.json(experience);
  } catch (error) {
    console.error('Error updating experience:', error);
    res.status(400).json({ message: 'Error updating experience', error: error.message });
  }
};

// Delete experience record
const deleteExperience = async (req, res) => {
  try {
    const { slug } = req.params;
    const experience = await Experience.findOneAndDelete({ slug });

    if (!experience) {
      return res.status(404).json({ message: 'Experience record not found' });
    }

    res.json({ message: 'Experience record deleted successfully' });
  } catch (error) {
    console.error('Error deleting experience:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Toggle featured status
const toggleFeatured = async (req, res) => {
  try {
    const { slug } = req.params;
    const experience = await Experience.findOne({ slug });

    if (!experience) {
      return res.status(404).json({ message: 'Experience record not found' });
    }

    experience.featured = !experience.featured;
    await experience.save();

    res.json(experience);
  } catch (error) {
    console.error('Error toggling featured status:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Toggle active status
const toggleActive = async (req, res) => {
  try {
    const { slug } = req.params;
    const experience = await Experience.findOne({ slug });

    if (!experience) {
      return res.status(404).json({ message: 'Experience record not found' });
    }

    experience.isActive = !experience.isActive;
    await experience.save();

    res.json(experience);
  } catch (error) {
    console.error('Error toggling active status:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update experience order
const updateExperienceOrder = async (req, res) => {
  try {
    const { experience } = req.body;

    // Update order for each experience
    const updatePromises = experience.map((exp, index) => 
      Experience.findByIdAndUpdate(exp._id, { order: index })
    );

    await Promise.all(updatePromises);

    res.json({ message: 'Experience order updated successfully' });
  } catch (error) {
    console.error('Error updating experience order:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get experience statistics
const getExperienceStats = async (req, res) => {
  try {
    const totalExperience = await Experience.countDocuments();
    const activeExperience = await Experience.countDocuments({ isActive: true });
    const featuredExperience = await Experience.countDocuments({ featured: true });
    const currentExperience = await Experience.countDocuments({ current: true });

    // Get employment type distribution
    const employmentTypes = await Experience.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$employmentType', count: { $sum: 1 } } },
      { $sort: { count: -1 } }
    ]);

    // Get companies with most experience records
    const topCompanies = await Experience.aggregate([
      { $match: { isActive: true } },
      { $group: { _id: '$company', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);

    res.json({
      totalExperience,
      activeExperience,
      featuredExperience,
      currentExperience,
      employmentTypes,
      topCompanies
    });
  } catch (error) {
    console.error('Error fetching experience stats:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getAllExperience,
  getExperienceBySlug,
  createExperience,
  updateExperience,
  deleteExperience,
  toggleFeatured,
  toggleActive,
  updateExperienceOrder,
  getExperienceStats
};
