const mongoose = require('mongoose');
const Characteristic = require('../models/Characteristic');

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb+srv://sanjayveye:nsnGBIJHzrzkmZw6@cluster0.czkcxtw.mongodb.net/');
    console.log('✅ MongoDB connected for testing');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
};

const testCharacteristics = async () => {
  try {
    await connectDB();
    
    // Get all characteristics
    const characteristics = await Characteristic.find({}).sort({ order: 1 });
    
    console.log('\n📊 Characteristics in database:');
    console.log('================================');
    
    characteristics.forEach((char, index) => {
      console.log(`${index + 1}. ${char.title}`);
      console.log(`   Category: ${char.category}`);
      console.log(`   Value: ${char.value}${char.unit}`);
      console.log(`   Featured: ${char.featured ? 'Yes' : 'No'}`);
      console.log(`   Slug: ${char.slug}`);
      console.log(`   Order: ${char.order}`);
      console.log('');
    });
    
    console.log(`📈 Total characteristics: ${characteristics.length}`);
    console.log(`⭐ Featured characteristics: ${characteristics.filter(c => c.featured).length}`);
    console.log(`🟢 Active characteristics: ${characteristics.filter(c => c.isActive).length}`);
    
    // Test the API endpoint structure
    const featured = await Characteristic.find({ featured: true, isActive: true }).sort({ order: 1 }).limit(3);
    console.log(`\n🎯 Featured characteristics for home: ${featured.length}`);
    
    mongoose.connection.close();
    console.log('\n✅ Test completed successfully!');
    
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
};

testCharacteristics();
