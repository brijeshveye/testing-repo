const mongoose = require('mongoose');

// Connect to MongoDB
const mongoURI = 'mongodb+srv://sanjayveye:nsnGBIJHzrzkmZw6@cluster0.czkcxtw.mongodb.net/';

console.log('Connecting to MongoDB...');

mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log('Connected to MongoDB successfully');
  
  // Test query
  const Upload = require('../models/Upload');
  
  Upload.find({}).then(uploads => {
    console.log(`Found ${uploads.length} upload records`);
    uploads.forEach(upload => {
      console.log(`File: ${upload.filename}, Category: ${upload.category}, URL: ${upload.url}`);
    });
    process.exit(0);
  }).catch(error => {
    console.error('Error querying uploads:', error);
    process.exit(1);
  });
  
}).catch(error => {
  console.error('Error connecting to MongoDB:', error);
  process.exit(1);
});
