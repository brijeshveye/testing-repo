const express = require('express');
const router = express.Router();
const {
  getCertificates,
  getCertificateBySlug,
  createCertificate,
  updateCertificate,
  deleteCertificate,
  updateCertificatesOrder,
  toggleFeatured,
  toggleActive
} = require('../controllers/certificateController');

// Public routes
router.get('/', getCertificates);
router.get('/:slug', getCertificateBySlug);

// Admin routes (in production, add authentication middleware)
router.post('/', createCertificate);
router.put('/:slug', updateCertificate);
router.delete('/:slug', deleteCertificate);
router.put('/:slug/toggle-featured', toggleFeatured);
router.put('/:slug/toggle-active', toggleActive);
router.put('/order/update', updateCertificatesOrder);

module.exports = router;
