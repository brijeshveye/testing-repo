const express = require('express');
const router = express.Router();
const {
  getSkills,
  getSkillBySlug,
  createSkill,
  updateSkill,
  deleteSkill,
  updateSkillsOrder,
  toggleFeatured,
  toggleActive,
  getSkillStats
} = require('../controllers/skillController');

// Public routes
router.get('/', getSkills);
router.get('/stats', getSkillStats);
router.get('/:slug', getSkillBySlug);

// Admin routes (in production, add authentication middleware)
router.post('/', createSkill);
router.put('/:slug', updateSkill);
router.delete('/:slug', deleteSkill);
router.put('/:slug/toggle-featured', toggleFeatured);
router.put('/:slug/toggle-active', toggleActive);
router.put('/order/update', updateSkillsOrder);

module.exports = router;
