const express = require('express');
const cors = require('cors');
const path = require('path');
const connectDB = require('./config/database');
const app = express();

// Connect to MongoDB
connectDB();

// CORS configuration
const corsOptions = {
  origin: [
    'http://localhost:3000',  // React development server
    'http://localhost:3001',  // Alternative React port
    'http://127.0.0.1:3000',
    'http://127.0.0.1:3001',
    'http://localhost:5000'  // API server
  ],
  credentials: true,
  optionsSuccessStatus: 200,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
};

app.use(cors(corsOptions));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
const projectRoutes = require('./routes/projectRoutes');
const blogRoutes = require('./routes/blogRoutes');
const userRoutes = require('./routes/userRoutes');
const uploadRoutes = require('./routes/uploadRoutes');
const testimonialRoutes = require('./routes/testimonialRoutes');
const certificateRoutes = require('./routes/certificateRoutes');
const skillRoutes = require('./routes/skillRoutes');
const educationRoutes = require('./routes/educationRoutes');
const experienceRoutes = require('./routes/experienceRoutes');
const serviceRoutes = require('./routes/serviceRoutes');
const characteristicRoutes = require('./routes/characteristicRoutes');


['get', 'post', 'put', 'delete', 'use'].forEach(method => {
  const original = app[method];
  app[method] = function(path, ...args) {
    if (typeof path === 'string') {
      console.log(`Registering ${method.toUpperCase()} route: ${path}`);
    } else {
      console.log(`Registering ${method.toUpperCase()} route with non-string first arg`);
    }
    return original.call(this, path, ...args);
  };
});


// API route example
app.get('/api', (req, res) => {
  res.json({ message: 'Back-end API is working' });
});

app.use('/api/projects', projectRoutes);
app.use('/api/blogs', blogRoutes);
app.use('/api/user', userRoutes);
app.use('/api/upload', uploadRoutes);
app.use('/api/testimonials', testimonialRoutes);
app.use('/api/certificates', certificateRoutes);
app.use('/api/skills', skillRoutes);
app.use('/api/education', educationRoutes);
app.use('/api/experience', experienceRoutes);
app.use('/api/services', serviceRoutes);
app.use('/api/characteristics', characteristicRoutes);

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve static files from the React app
app.use(express.static(path.join(__dirname, '../client/build')));


// Catch-all to serve React's index.html for any non-API routes
app.get("/", (req, res, next) => {
  // Only serve index.html if request path looks like a relative path
  console.log('Catch-all req.path:', req.path);
  if (req.path.startsWith('/')) {
    res.sendFile(path.join(__dirname, '../client/build/index.html'));
  } else {
    next(); // Pass on invalid paths
  }
});

// Start server
const PORT = process.env.PORT || 5000;

app.listen(PORT, (error) => {
  if (!error) {
    console.log("Server is Successfully Running, and App is listening on port " + PORT);
  }
  else {
    console.log("Error occurred, server can't start", error);
  }

});
