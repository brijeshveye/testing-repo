import React from 'react'

const EducationCardWidget = (props) => {
    return (
        <>
            <div className={`col-lg-8 mb-xxl-5 mb-4 ${props.oddEven ? '' : 'd-flex justify-content-end ms-auto'}`} data-aos="zoom-out-down" data-aos-duration={props.aosDuration}>
                <div className="row g-4 align-items-center justify-content-between">
                    <div className="col-xl-9 col-lg-8">
                        <div className="aria-edubox">
                            <div className="expri__cont">
                                <h4 className="mb-15 mtitle">
                                    {props.courseTitle}
                                </h4>
                                <p className="fz-18 mtitle d-block">
                                    {props.institution}
                                </p>
                            </div>
                            <p className="mtitle">
                                {props.description}
                            </p>
                        </div>
                    </div>
                    <div className="col-xl-3 col-lg-4">
                        <span className="years-about fw-500 base">
                            {props.years}
                        </span>
                    </div>
                </div>
            </div>
        </>
    )
}

EducationCardWidget.defaultProps = {
    oddEven: false,
    aosDuration: '1000',
    courseTitle: 'Course Title',
    institution: 'Institution Name',
    description: 'Brief description of the course or education.',
    years: 'Year(s)'
}

export default EducationCardWidget