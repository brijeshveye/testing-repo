import React from 'react'
import { Link } from 'react-router-dom'

const WhatIDoCardWidget = (props) => {
    return (
        <>
            <div className={`unique__comititem unc__${props.number}  ${props.number === 3 ? 'activecard' : ''} d-flex align-items-end`}>
                <div className="ucom">
                    <span>
                        {props.tag}
                    </span>
                </div>
                <div className="cont__box">
                    <span className="head-both">
                        0{props.number}
                    </span>
                    <h4>
                        {props.title}
                        <span className="d-block"> {props.bgText}</span>
                    </h4>
                    <Link to={props.link} className="cmn--btn">
                        <span>
                            {props.linkText}
                        </span>
                    </Link>
                    
                </div>
            </div>
        </>
    )
}

WhatIDoCardWidget.defaultProps = {
    "tag": "My Tag",
    "number": 1,
    "title": "My Title",
    "bgText": "My Background Text",
    "linkText": "More Details",
    "link": "service-details.html",
}

export default WhatIDoCardWidget