import React from 'react'
import { Route, Routes } from "react-router-dom";
import Home from '../pages/Home';
import ServiceDetails from '../pages/ServiceDetails';
import ProjectDetails from '../pages/ProjectDetails';
import BlogDetails from '../pages/BlogDetails';

const AppRoutes = () => {
  return (
    <Routes>
        <Route path="/" element={ <Home /> } />
        <Route path="/blog-details" element={ <BlogDetails /> } />
        <Route path="/project-details" element={ <ProjectDetails /> } />
        <Route path="/service-details" element={ <ServiceDetails />} />

        <Route path="blog/details/:slug" element={<BlogDetails />} />
        <Route path="project/details/:slug" element={<ProjectDetails />} />
        <Route path="service/details/:slug" element={<ServiceDetails />} />
        
        <Route path="*" element={<div>404 Not Found</div>} />
    </Routes>
  )
}

export default AppRoutes