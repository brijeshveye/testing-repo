import React, { useEffect, useState } from 'react'
import ServiceTopSection from '../components/service/ServiceTopSection'
import ServiceSection from '../components/service/ServiceSection'
import UserDataApi from '../api/UserDataApi';
import { useParams } from 'react-router-dom';


const ServiceDetails = () => {
  const [serviceData, setServiceData] = useState({});

  const slug = useParams().slug;

  useEffect(() => {
    setServiceData(UserDataApi.getServiceDetails(slug));
  }, [slug]);

  return (
    <main className='wrapper'>
        <ServiceTopSection serviceData={serviceData} />
        <ServiceSection serviceData={serviceData} />
    </main>
  )
}

export default ServiceDetails