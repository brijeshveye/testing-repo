import React, { useEffect, useState } from 'react'
import PortfolioTopSection from '../components/portfolio/PortfolioTopSection'
import ProjectSection from '../components/portfolio/ProjectSection'
import UserDataApi from '../api/UserDataApi';
import { useParams } from 'react-router-dom';


const ProjectDetails = () => {
  const [projectData, setProjectData] = useState({});

  const slug = useParams().slug;


  useEffect(() => {
    setProjectData(UserDataApi.getProjectDetails(slug));
  }, [slug]);


  return (
    <main className='wrapper'>
      <PortfolioTopSection projectData={projectData} />
      <ProjectSection projectData={projectData} />
    </main>
  )
}

export default ProjectDetails