const ServiceDataApi = {
    getServices: () => {
        let services = [
            {
                title: "Web Development",
                description: "Building responsive and dynamic websites.",
                category: "development",
                bannerImage: "assets/img/project/ser-dv1.png",

                details: {
                    section1: {
                        para1: "We create modern and responsive websites tailored to your business needs.",
                        para2: "Our team specializes in both front-end and back-end development."
                    },
                    section2: {
                        image1: "/assets/img/project/pro1.png",
                        image2: "/assets/img/project/pro2.png",
                        image3: "/assets/img/project/pro3.png",
                        image4: "/assets/img/project/pro4.png",
                    },
                    section3: {
                        title: "Technologies We Use",
                        para: "We utilize the latest technologies to ensure your website is fast, secure, and scalable.",
                        list: ["HTML", "CSS", "JavaScript", "React", "Node.js"]
                    },
                    section4: {
                        image1: "assets/img/project/ser-dv2.png",
                        video: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
                    }
                },

                faqs: [
                    {
                        title: "What is web development?",
                        description: "Web development is the process of creating websites and web applications that run on the internet."
                    },
                    {
                        title: "What technologies do you use?",
                        description: "We use a variety of technologies including HTML, CSS, JavaScript, React, and Node.js to build modern web applications."
                    },
                    {
                        title: "How long does it take to develop a website?",
                        description: "The timeline for web development varies based on the complexity of the project. Typically, it can take anywhere from a few weeks to several months."
                    }
                ]
            }
        ];

        return services;
    },

    getServiceList: () => {
        let serviceList = [
            {
                "title": "Web Development",
                "link": "/services/web-development",
            },
            {
                "title": "Mobile App Development",
                "link": "/services/mobile-app-development",
            },
            {
                "title": "UI/UX Design",
                "link": "/services/ui-ux-design",
            }
        ];

        return serviceList;
    },

    getServiceDetails: (slug) => {
        let services = ServiceDataApi.getServices();
        // return services.find(service => service.slug === slug);
        return services[0];
    }
}

export default ServiceDataApi