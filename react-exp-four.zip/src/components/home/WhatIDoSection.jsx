import React, { useEffect, useState } from 'react'
import UserDataApi from '../../api/UserDataApi';
import WhatIDoCardWidget from './widgets/WhatIDoCardWidget';

const WhatIDoSection = () => {

    const [processData, setProcessData] = useState([]);

    useEffect(() => {
        setProcessData(UserDataApi.getMyProcess());
    }, []);

    const generateLink = (slug) => {
        return `/service/details/${slug}`;
    }

    return (
        <>
            <section className="unique__commit bg1-img2 position-relative overflow-hidden">
                <div className="container-fluid p-0">
                    <div className="unique__commitwrap d-flex justify-content-between">
                        {
                            processData.map((item, index) => (
                                <WhatIDoCardWidget key={index} tag={item.tag} number={item.number} bgText={item.bgText} link={generateLink(item.link)} linkText="More Details" />
                            ))
                        }
                        
                    </div>
                </div>
            </section>
        </>
    )
}

export default WhatIDoSection