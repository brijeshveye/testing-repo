import React, { useEffect, useRef } from 'react'

const SkillCardWidget = (props) => {

    const countRef = useRef(null);

    const getBackgroundColor = (colour) => {
        const color = colour || '#000000';

        // Convert hex to RGB
        const rgb = parseInt(color.slice(1), 16);
        const r = (rgb >> 16) & 0xff;
        const g = (rgb >> 8) & 0xff;
        const b = rgb & 0xff;

        // Blend with white (e.g., 80% white, 20% original color)
        const mixRatio = 0.8; // adjust this to control how light the result is
        const newR = Math.round(r + (255 - r) * mixRatio);
        const newG = Math.round(g + (255 - g) * mixRatio);
        const newB = Math.round(b + (255 - b) * mixRatio);

        // Convert back to hex
        const toHex = (c) => c.toString(16).padStart(2, '0');
        return `#${toHex(newR)}${toHex(newG)}${toHex(newB)}`;
    };

    // Animate numbers (optional JS-based animation)
    useEffect(() => {
        const target = props.percentage || 0;
        const speed = 20; // smaller = faster

        let current = 0;
        const step = () => {
            if (countRef.current && current <= target) {
                countRef.current.innerText = current;
                current++;
                setTimeout(step, speed);
            }
        };
        step();
    }, [props.percentage]);

    return (
        <>
            <li>
                <div className="skill-box">
                    <div className="skill-icon" style={{ background: getBackgroundColor(props.color) }}>
                        <i className={props.icon} style={{ color: props.color }}></i>
                        <span ref={countRef} className="count after-p" data-to={props.percentage} data-speed="80">{props.percentage}</span>
                    </div>
                    <h6>{props.name}</h6>
                </div>
            </li>
        </>
    )
}

SkillCardWidget.propTypes = {
    "name": "My Skill",
    "icon": "fab fa-html5",
    "color": "#e54c21",
    "percentage": 80
}

export default SkillCardWidget