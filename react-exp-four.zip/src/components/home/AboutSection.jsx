import React, { useEffect, useState } from 'react'
import UserDataApi from '../../api/UserDataApi';

const AboutSection = () => {

    const [aboutData, setAboutData] = useState({});

    useEffect(() => {
        setAboutData(UserDataApi.getAbout());
    }, []);

    return (
        <>
            <section id="about" data-scroll-index="1" className="section about-section">
                <div className="container">
                    <div className="section-heading">
                        <h3>About Me</h3>
                    </div>
                    <div className="row align-items-center gy-4">
                        <div className="col-lg-6">
                            <img src="assets/img/about-me.png" title="" alt="" />
                        </div>
                        <div className="col-lg-6 ps-xl-5">
                            <div className="about-intro">
                                <h6>MY INTRO</h6>
                                <h2>I am <span>{aboutData.name}</span></h2>
                                <h5>{aboutData.tagline}</h5>
                                <div className="text">
                                    <p>{aboutData.bio}</p>
                                    <p>{aboutData.afterBio}</p>
                                </div>
                                <div className="row">
                                    <div className="col-sm-6">
                                        <ul>
                                            {
                                                aboutData.birthday && (
                                                    <li>
                                                        <span>Birthday :</span> <label>{aboutData.birthday ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                            {
                                                aboutData.age && (
                                                    <li>
                                                        <span>Age :</span> <label>{aboutData.age ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                            <li>
                                                <span>Address :</span> <label>{aboutData.address ?? 'N/A'}</label>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="col-sm-6">
                                        <ul>
                                            {
                                                aboutData.phone && (
                                                    <li>
                                                        <span>Phone :</span> <label>{aboutData.phone ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                            <li>
                                                <span>Email :</span> <label>{aboutData.email ?? 'N/A'}</label>
                                            </li>
                                            {
                                                aboutData.skype && (
                                                    <li>
                                                        <span>Skype :</span> <label>{aboutData.skype ?? 'N/A'}</label>
                                                    </li>
                                                )
                                            }

                                        </ul>
                                    </div>
                                </div>
                                <div className="btn-bar">
                                    <a href={aboutData.cv} target="_blank"  rel="noopener noreferrer" className="px-btn px-btn-primary">DOWNLOAD CV</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default AboutSection