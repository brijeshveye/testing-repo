import { title } from "framer-motion/client";
import BlogsDataApi from "./BlogsDataApi";
import ProjectsDataApi from "./ProjectsDataApi";
import ServiceDataApi from "./ServiceDataApi";

const UserDataApi = {

    getHeaderData: () => {
        let headerData = [
            {
                "title": "Home",
                "url": "/"
            },
            {
                "title": "About",
                "url": "/about"
            },
            {
                "title": "Services",
                "url": "/services"
            },
            {
                "title": "Projects",
                "url": "/projects"
            },
            {
                "title": "Testimonials",
                "url": "/testimonials"
            },
            {
                "title": "Blogs",
                "url": "/blogs"
            },
            {
                "title": "Contact",
                "url": "/contact"
            }
        ]

        return headerData;
    },

    getAbout: () => {
        let aboutData = {
            "name": "John Doe",
            "email": "abc@gmai.com",
            "phone": "+01 9033 333 333 / 123",
            "address": "123 Main St, Anytown, USA",
            "tagline": "A lead Full Stack Developer based in India",
            "bio": "I design and develop services for customers of all sizes, specializing in creating stylish, modern websites, web services and online stores. My passion is to design digital user experiences through the bold interface and meaningful interactions. Check out my Portfolio",
            "afterBio": "I like work with new people. New people new Experiences.",
            "linkedin": "https://www.linkedin.com/in/johndoe",
            "github": "https://github.com",
            "twitter": "https://twitter.com/johndoe",
            "instagram": "https://instagram.com/johndoe",
            "facebook": "https://facebook.com/johndoe",
            "website": "https://johndoe.com",
            "cv": "https://johndoe.com/cv.pdf",

        }

        return aboutData;
    },

    getEducation: () => {
        let educationData = [
            {
                "title": "Bachelor of Science in Computer Science",
                "institution": "University of Technology",
                "year": "2015 - 2019",
                "details": "Graduated with honors, specializing in software development."
            },
            {
                "title": "Master of Science in Software Engineering",
                "institution": "Tech University",
                "year": "2020 - 2022",
                "details": "Focused on advanced software architecture and design patterns."
            }
        ];

        return educationData;
    },

    getMySkills: () => {
        let skillsData = [
            // 🟦 Languages
            { title: "C", icon: "fas fa-code", color: "#555555", percentage: 70, category: "Language" },
            { title: "Java", icon: "fab fa-java", color: "#dd0031", percentage: 70, category: "Language" },
            { title: "JavaScript", icon: "fab fa-js", color: "#f0db4f", percentage: 85, category: "Language" },
            { title: "Python", icon: "fab fa-python", color: "#306998", percentage: 75, category: "Language" },
            { title: "PHP", icon: "fab fa-php", color: "#8993be", percentage: 80, category: "Language" },
            { title: "Dart", icon: "fas fa-feather", color: "#0175c2", percentage: 75, category: "Language" },
            { title: "Kotlin", icon: "fas fa-code", color: "#7f52ff", percentage: 70, category: "Language" },

            // 🟩 Frontend (Libraries, Frameworks, UI)
            { title: "HTML5", icon: "fab fa-html5", color: "#e54c21", percentage: 90, category: "Frontend" },
            { title: "CSS3", icon: "fab fa-css3-alt", color: "#264de4", percentage: 80, category: "Frontend" },
            { title: "Sass", icon: "fab fa-sass", color: "#cc6699", percentage: 80, category: "Frontend" },
            { title: "Bootstrap", icon: "fab fa-bootstrap", color: "#7952b3", percentage: 85, category: "Frontend" },
            { title: "Materialize", icon: "fas fa-layer-group", color: "#ee6e73", percentage: 70, category: "Frontend" },
            { title: "React", icon: "fab fa-react", color: "#61dafb", percentage: 90, category: "Frontend" },
            { title: "Flutter", icon: "fas fa-mobile-alt", color: "#02569b", percentage: 80, category: "Frontend" },

            // 🟧 Backend (Frameworks, Platforms)
            { title: "Node.js", icon: "fab fa-node-js", color: "#80bd00", percentage: 80, category: "Backend" },
            { title: "Express", icon: "fas fa-server", color: "#000000", percentage: 70, category: "Backend" },
            { title: "Laravel", icon: "fab fa-laravel", color: "#f55247", percentage: 75, category: "Backend" },
            { title: "CodeIgniter", icon: "fas fa-fire", color: "#ee4623", percentage: 70, category: "Backend" },

            // 🟨 Databases
            { title: "MongoDB", icon: "fas fa-database", color: "#47a248", percentage: 80, category: "Database" },
            { title: "MySQL", icon: "fas fa-database", color: "#00758f", percentage: 75, category: "Database" },

            // 🟥 Cloud & DevOps
            { title: "AWS", icon: "fab fa-aws", color: "#ff9900", percentage: 75, category: "Cloud" },
            { title: "GCP", icon: "fas fa-cloud", color: "#4285f4", percentage: 70, category: "Cloud" },
            { title: "Firebase", icon: "fas fa-fire", color: "#ffca28", percentage: 75, category: "Cloud" },
            { title: "Git", icon: "fab fa-git-alt", color: "#f1502f", percentage: 85, category: "DevOps" },
            { title: "Postman", icon: "fas fa-paper-plane", color: "#ff6c37", percentage: 70, category: "DevOps" },

            // 🟪 Design & Prototyping
            { title: "Figma", icon: "fab fa-figma", color: "#a259ff", percentage: 80, category: "Design" },
            { title: "Adobe XD", icon: "fa-brands fa-gripfire", color: "#ff2bc2", percentage: 70, category: "Design" },
            { title: "Illustrator", icon: "fa-brands fa-empire", color: "#ff9a00", percentage: 65, category: "Design" },
            { title: "Photoshop", icon: "fa-brands fa-unsplash", color: "#31a8ff", percentage: 70, category: "Design" },

            // 🟫 Mobile Platforms
            { title: "Android", icon: "fab fa-android", color: "#3ddc84", percentage: 80, category: "Mobile" }
        ];

        return skillsData;

    },

    getSkillCategories: () => {
        let skillsData = UserDataApi.getMySkills();
        const categories = [...new Set(skillsData.map(skill => skill.category))];
        return categories;
    },


    getExperience: () => {
        let experienceData = [
            {
                "title": "Software Engineer",
                "company": "Tech Solutions Inc.",
                "duration": "2020 - Present",
                "responsibilities": [
                    "Developing web applications using React and Node.js.",
                    "Collaborating with cross-functional teams to define, design, and ship new features.",
                    "Maintaining code quality and ensuring responsiveness of applications."
                ]
            },
            {
                "title": "Junior Developer",
                "company": "Web Innovations Ltd.",
                "duration": "2019 - 2020",
                "responsibilities": [
                    "Assisted in the development of client-side applications.",
                    "Participated in code reviews and contributed to team knowledge sharing."
                ]
            }
        ];

        return experienceData;
    },

    getCharacteristics: () => {
        let servicesData = [
            {
                "title": "Web Development",
                "description": "Building responsive and high-performance web applications.",
                "icon": "web-development-icon.svg"
            },
            {
                "title": "Mobile App Development",
                "description": "Creating user-friendly mobile applications for iOS and Android.",
                "icon": "mobile-app-icon.svg"
            },
            {
                "title": "UI/UX Design",
                "description": "Designing intuitive user interfaces and enhancing user experience.",
                "icon": "ui-ux-icon.svg"
            }
        ];

        return servicesData;
    },

    getMyProcess: () => {
        let processData = [
            {
                "tag": "Approach",
                "number": 1,
                "title": "Requirement Analysis",
                "bgText": "Understanding client needs and project requirements.",
                "link": "requirement-analysis"
            },
            {
                "tag": "Design",
                "number": 2,
                "title": "Design",
                "bgText": "Creating wireframes and prototypes for the project.",
                "link": "design"
            },
            {
                "tag": "Development",
                "number": 3,
                "title": "Development",
                "bgText": "Coding and implementing the project features.",
                "link": "development"
            },
            {
                "tag": "Testing",
                "number": 4,
                "title": "Testing",
                "bgText": "Ensuring the application is bug-free and meets quality standards.",
                "link": "testing"
            },
            {
                "tag": "Deployment",
                "number": 5,
                "title": "Deployment",
                "bgText": "Launching the application to production.",
                "link": "deployment"
            }
        ];

        return processData;
    },


    getMyCertificates: () => {
        let certificatesData = [
            {
                "title": "Certified Full Stack Developer",
                "description": "Full Stack Web Development Certification",
                "issuer": "Tech Institute",
                "year": "2021",
                "image": "assets/img/project/pro1.png",
                "url": "https://example.com/certificate/full-stack-developer",
                "category": "Web Development",
            },
            {
                "title": "JavaScript Mastery",
                "description": "Advanced JavaScript Programming",
                "issuer": "Online Academy",
                "year": "2020",
                "image": "assets/img/project/pro2.png",
                "url": "https://example.com/certificate/javascript-mastery",
                "category": "Programming"
            },
            {
                "title": "UI/UX Design Fundamentals",
                "description": "Introduction to UI/UX Design Principles",
                "issuer": "Design School",
                "year": "2019",
                "image": "assets/img/project/pro3.png",
                "url": "https://example.com/certificate/ui-ux-design-fundamentals",
                "category": "Frameworks"
            },
            {
                "title": "Cloud Computing Essentials",
                "description": "Understanding Cloud Technologies and Services",
                "issuer": "Cloud Academy",
                "year": "2022",
                "image": "assets/img/project/pro4.png",
                "url": "https://example.com/certificate/cloud-computing-essentials",
                "category": "Cloud Computing"
            },
            {
                "title": "Data Science with Python",
                "description": "Data Analysis and Machine Learning with Python",
                "issuer": "Data Science Institute",
                "year": "2023",
                "image": "assets/img/project/pro5.png",
                "url": "https://example.com/certificate/data-science-python",
                "category": "Cloud Computing"
            },
            {
                "title": "Agile Project Management",
                "description": "Agile Methodologies and Project Management Techniques",
                "issuer": "Project Management Institute",
                "year": "2021",
                "image": "assets/img/project/pro6.png",
                "url": "https://example.com/certificate/agile-project-management",
                "category": "Frameworks"
            }
        ];

        return certificatesData;
    },

    getMyProjects: () => {
        let projectsData = ProjectsDataApi.getProjectsData();

        return projectsData;
    },

    getProjectDetails: (slug) => {
        let projectDetails = ProjectsDataApi.getProjectDetails(slug);
        return projectDetails;
    },

    getTestimonials: () => {
        let testimonialsData = [
            {
                "stars": 5,
                "customerName": "Jane Smith",
                "customerFeedback": "John's work on our project was exceptional. He delivered high-quality code and met all deadlines.",
                "customerPosition": "CEO, Tech Solutions"
            },
            {
                "stars": 5,
                "customerName": "Michael Johnson",
                "customerFeedback": "A pleasure to work with! John has a keen eye for detail and a strong understanding of modern web technologies.",
                "customerPosition": "CTO, Web Innovations"
            },
            {
                "stars": 5,
                "customerName": "Emily Davis",
                "customerFeedback": "John's expertise in UI/UX design significantly improved our user engagement. Highly recommended!",
                "customerPosition": "Product Manager, Creative Agency"
            }
        ];

        return testimonialsData;
    },

    convertSlugToTitle: (slug) => {
        let title = slug.replace(/-/g, ' ').replace(/^\w/, c => c.toUpperCase());
        return title;
    },

    getBlogs: () => {
        let BlogsData = BlogsDataApi.getBlogsData();
        return BlogsData;
    },

    getBlogDetails: (slug) => {
        let blogDetails = BlogsDataApi.getBlogDetails(slug);
        return blogDetails;
    },

    getBlogTags: () => {
        let blogTags = BlogsDataApi.getBlogTags();
        return blogTags;
    },

    getBlogCategories: () => {
        let blogCategories = BlogsDataApi.getBlogCategories();
        return blogCategories;
    },

    getRecentBlogPosts: () => {
        let recentBlogs = BlogsDataApi.getRecentBlogs();
        return recentBlogs;
    },

    getServices: () => {
        let servicesData = ServiceDataApi.getServices();
        return servicesData;
    },

    getServiceDetails: (slug) => {
        let serviceDetails = ServiceDataApi.getServiceDetails(slug);
        return serviceDetails;
    },

    getCoffieData: () => {
        let coffeeData = {
            "title": "Take a Coffee & chat with me",
            "email": "abc@gmail.com",
            "phone": "+01 9033 333 333 / 123",
        }
        return coffeeData;
    },

    getMarqueeData: () => {
        let marqueeData = [
            "Web Development",
            "Mobile App Development",
            "UI/UX Design",
            "Software Engineering",
            "Cloud Computing",
            "Data Science"
        ];

        return marqueeData;
    },


    getFooterMarqueeData: () => {
        let footerMarqueeData = [
            "© 2023 John Doe. All rights reserved.",
            "Follow me on social media: LinkedIn, GitHub, Twitter, Instagram, Facebook",
            "Contact me for collaborations and inquiries"
        ];

        return footerMarqueeData;
    },

    getFooterData: () => {
        let footerData = {
            "address": "123 Main St, Anytown, USA",
            "email": "abc@gmail.com",
            "phone": "+01 9033 333 333 / 123",
            "socialLinks": {
                "linkedin": "https://www.linkedin.com/in/johndoe",
                "github": "",
                "twitter": "https://twitter.com/johndoe",
                "instagram": "https://instagram.com/johndoe",
                "facebook": "https://facebook.com/johndoe",
                "website": "https://johndoe.com"
            },
        }

        return footerData;
    },

    getCopyrightData: () => {
        let currentYear = new Date().getFullYear();
        let copyrightData = {
            "text": `© ${currentYear} John Doe. All rights reserved.`,
            "socialLinks": {
                "linkedin": "https://www.linkedin.com/in/johndoe",
                "github": "",
                "twitter": "https://twitter.com/johndoe",
                "instagram": "https://instagram.com/johndoe",
                "facebook": "https://facebook.com/johndoe",
                "website": "https://johndoe.com"
            }
        };

        return copyrightData;
    },

    getServiceList: () => {
        let serviceList = ServiceDataApi.getServiceList();

        return serviceList;
    },

}

export default UserDataApi