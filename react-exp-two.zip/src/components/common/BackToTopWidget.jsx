import React from 'react'

const BackToTopWidget = () => {
    return (
        <>
            <a href="#" id="back_to_top" className="back-to-top">
                <img src="assets/img/arrow.svg" title="" alt="" />
            </a>
        </>
    )
}

export default BackToTopWidget