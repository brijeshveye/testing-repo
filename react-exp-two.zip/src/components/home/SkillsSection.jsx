import React, { useEffect, useState } from 'react'
import UserDataApi from '../../api/UserDataApi';
import SkillCardWidget from './widgets/SkillCardWidget';

const SkillsSection = () => {

    const [skills, setSkills] = useState([]);
    const [skillCategories, setSkillCategories] = useState([]);

    useEffect(() => {
        setSkills(UserDataApi.getMySkills());
        setSkillCategories(UserDataApi.getSkillCategories());
    }, []);

    return (
        <>
            <section id="resume" data-scroll-index="2" className="section skills-section bg-gray">
                <div className="container">
                    <div className="section-heading">
                        <h3>Skills & Experience</h3>
                    </div>
                    <div className="row">
                        {
                            skillCategories.map((item, index) => (
                                <>
                                    <div className="col-3 col-md-4 col-sm-12" key={index}>
                                        <div className="skill-category">
                                            <h5 className="common__sub">{item}</h5>
                                        </div>
                                    </div>
                                    <div className="col-9 col-md-8 col-sm-12" key={`skills-${index}`}>
                                        <div className="row gy-4">
                                            <div className="col-lg-12">
                                                <ul className="skills-list counter">
                                                    {
                                                        skills.filter(skill => skill.category === item).map((skill, idx) => (
                                                            <SkillCardWidget
                                                                key={idx}
                                                                name={skill.title}
                                                                icon={skill.icon}
                                                                color={skill.color}
                                                                percentage={skill.percentage}
                                                            />
                                                        ))
                                                    }

                                                </ul>
                                            </div>

                                        </div>

                                    </div>
                                </>

                            ))
                        }
                    </div>
                    
                </div>
            </section>
        </>
    )
}

export default SkillsSection