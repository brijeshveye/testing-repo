import { link } from 'framer-motion/client'
import React from 'react'

const BlogCardWidget = (props) => {

    return (
        <div className="br-item">
            <div className="news-info">
                <figure className="news-img">
                    <a href="#">
                        <img src={props.image} alt="news imag" />
                    </a>
                </figure>
                <div className="detail">
                    <label>{props.date} - <a href="#">{props.category}</a></label>
                    <h3><a href="#">{props.title}</a></h3>
                    <div className="more-info">
                        <a href="#">{props.readMoreLink ?? 'Read More'}<span></span></a>
                    </div>
                </div>
            </div>
        </div>
    )
}

BlogCardWidget.defaultProps = {
    title: 'Blog Card Widget',
    description: 'This is a blog card widget component that displays a blog post with an image, title, date, and a link to read more.',
    image: 'assets/img/blog/5.jpg',
    date: 'July 30, 2025',
    category: 'Marketing',
    postTitle: 'Marketing Guide: 5 Steps to Success.',
    readMoreLink: 'Read More',
    link: '#'
}

export default BlogCardWidget