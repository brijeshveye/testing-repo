import React from 'react'

const ProjectCardWidget = (props) => {
    return (
        <>
            <div className={`col-lg-12 mix ${props.category}`}>
                <div className="br-project-box">
                    <h3>{props.title}</h3>
                    <div className="links">
                        {
                             (props.domains.length === 1) ? (
                                <a href={props.domains[0].url} key={props.domains[0].title}>
                                    {props.domains[0].title}
                                </a>
                            ) : (props.domains.length > 1) ? (
                                props.domains.map((domain, index) => (
                                    <>
                                    {index > 0 && " | "}
                                    <a key={domain.title} href={domain.url}>
                                        {domain.title}
                                    </a>
                                    </>
                                ))
                            ) : null
                        }
            
                    </div>
                    <p>
                        {props.description}
                        <a href="#">Read more</a>
                    </p>
                    <div className="br-info">
                        <div className="portfolio-img">
                            <a className="" data-fancybox="gallery"
                                href={props.image}
                                style={{ backgroundImage: `url(${props.image})` }}>
                                <span className="overlay">+</span>
                            </a>
                        </div>
                        <div className="br-detail">
                            <ul>
                                <li>Date : {props.date}</li>
                                <li>Client : {props.client}</li>
                                <li>Tech : {props.techStack}</li>
                                <li>Type : {props.type}</li>
                                <li>URL : <a href="#">{props.url}</a></li>
                            </ul>

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

ProjectCardWidget.defaultProps = {
    title: 'Project Card Widget',
    description: 'This is a project card widget component that displays a project with details such as title, description, and links.',
    domains: [
        { title: 'Design', url: '#' }
    ],
    image: 'assets/img/portfolio/2.jpg',
    date: 'March 15, 2022',
    client: 'BR Media',
    techStack: 'React, Nodejs, Android',
    type: 'Entertainment',
    url: 'www.your-project-url.com',
    category: 'design'
}

export default ProjectCardWidget