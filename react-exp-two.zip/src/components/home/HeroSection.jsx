import React from 'react'

const HeroSection = () => {
    return (
        <>
            <section id="home" data-scroll-index="0" className="home-section" style={{ backgroundImage: `url(/assets/img/bg.jpg)` }}>
                <div className="container">
                    <div className="home-intro-box">
                        <div className="user-text">
                            <h6><img src="assets/img/hend.png" title="" alt="" /> Hello, I am</h6>
                            <h1>Good.</h1>
                            <h2>Freelance <span id="type-it"></span></h2>
                        </div>
                        <div className="user-review">
                            <div className="d-flex star-box">
                                <i className="bi bi-star-fill"></i>
                                <i className="bi bi-star-fill"></i>
                                <i className="bi bi-star-fill"></i>
                                <i className="bi bi-star-fill"></i>
                                <i className="bi bi-star-fill"></i>
                            </div>
                            <p>He is absolutely brilliant Developer!”</p>
                            <h6>Freelancers</h6>
                        </div>
                        <div className="user-img">
                            <div className="user-img-round"></div>
                            <img src="assets/img/user-image.png" title="" alt="" />
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default HeroSection