import React, { useEffect } from 'react'
import UserDataApi from '../../api/UserDataApi';

const AboutSection = () => {

    const [aboutData, setAboutData] = React.useState({});

    useEffect(() => {
        setAboutData(UserDataApi.getAbout());
    }, []);

    return (
        <>
            <section id="about" data-scroll-index="1" className="section about-section">
                <div className="container">
                    <div className="section-heading">
                        <h3>About Me</h3>
                    </div>
                    <div className="row align-items-center gy-4">
                        <div className="col-lg-6">
                            <img src="assets/img/about-me.png" title="" alt="" />
                        </div>
                        <div className="col-lg-6 ps-xl-5">
                            <div className="about-intro">
                                <h6>MY INTRO</h6>
                                <h2>I am <span>Brijesh Chauhan</span></h2>
                                <h5>A lead Full Stack Developer based in India</h5>
                                <div className="text">
                                    <p>I design and develop services for customers of all sizes, specializing in creating
                                        stylish, modern websites, web services and online stores. My passion is to design
                                        digital user experiences through the bold interface and meaningful interactions.
                                        Check out my Portfolio.</p>
                                    <p>I like work with new people. New people new Experiences.</p>
                                </div>
                                <div className="row">
                                    <div className="col-sm-6">
                                        <ul>
                                            <li>
                                                <span>Birthday :</span> <label>{aboutData.birthday ?? 'N/A'}</label>
                                            </li>
                                            <li>
                                                <span>Age :</span> <label>{aboutData.age ?? 'N/A'}</label>
                                            </li>
                                            <li>
                                                <span>Address :</span> <label>{aboutData.address ?? 'N/A'}</label>
                                            </li>
                                        </ul>
                                    </div>
                                    <div className="col-sm-6">
                                        <ul>
                                            <li>
                                                <span>Phone :</span> <label>{aboutData.phone ?? 'N/A'}</label>
                                            </li>
                                            <li>
                                                <span>Email :</span> <label>{aboutData.email ?? 'N/A'}</label>
                                            </li>
                                            <li>
                                                <span>Skype :</span> <label>{aboutData.skype ?? 'N/A'}</label>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="btn-bar">
                                    <a href="#" className="px-btn px-btn-primary">DOWNLOAD CV</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default AboutSection