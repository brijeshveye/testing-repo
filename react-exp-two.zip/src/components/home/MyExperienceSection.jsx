import React, { useEffect, useState } from 'react'
import UserDataApi from '../../api/UserDataApi';
import ExperienceCardWidget from './widgets/ExperienceCardWidget';

const MyExperienceSection = () => {

    const aosDelay = 200;
    const [experienceData, setExperienceData] = useState([]);


    useEffect(() => {
        setExperienceData(UserDataApi.getExperience());
    }, []);

    return (
        <>
            <section id="experience" className="br-experience padding-tb-80 br-bg1-img">
                <div className="container">
                    <div className="row">
                        <div className="section-title">
                            <h2>My <span>Res</span></h2>
                            <span className="ligh-title">Achievements</span>
                        </div>
                        <div className="col-lg-6 col-md-12 col-sm-12">
                            <div className="education br-ex-box m-b-991">
                                <div className="about__onethumb aos-init aos-animate" data-aos="zoom-out-down" data-aos-duration="2000">
                                    <img alt="img" src="assets/img/cart/t4.png" />
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-6 col-md-12 col-sm-12">
                            <div className="experiense br-ex-box">
                                <h4>Experiense</h4>
                                <ul className="timeline">

                                    {
                                        experienceData.map((item, index) => (
                                            <ExperienceCardWidget
                                                key={index}
                                                duration={item.duration}
                                                company={item.company}
                                                role={item.role}
                                                description={item.description}
                                                aosDelay={aosDelay + (index * aosDelay)}
                                            />
                                        ))
                                    }

                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </section>
        </>
    )
}

export default MyExperienceSection