import React from 'react'

const ServiceFaqCardWidget = (props) => {
    return (
        <>
            <div className="accordion-item">
                <h2 className="accordion-header" id={`cmnid${props.id}`}>
                    <button className="accordion-button collapsed" type="button"
                        data-bs-toggle="collapse" data-bs-target={`#collapsecmn${props.id}`}
                        aria-expanded="false" aria-controls={`collapsecmn${props.id}`}>
                        <span>
                            {props.title}
                        </span>
                        <i className="bi bi-arrow-down"></i>
                    </button>
                </h2>
                <div id={`collapsecmn${props.id}`} className="accordion-collapse collapse"
                    aria-labelledby={`cmnid${props.id}`} data-bs-parent="#accordionExample">
                    <div className="accordion-body">
                        <p>
                            {props.description}
                        </p>
                    </div>
                </div>
            </div>
        </>
    )
}

ServiceFaqCardWidget.defaultProps = {
    id: 0,
    title: 'Default Title',
    description: 'Default Description'
}

export default ServiceFaqCardWidget