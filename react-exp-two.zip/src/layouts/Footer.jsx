import React from 'react'

const Footer = () => {
    return (
        <>
            <footer className="footer__section" id="fott">

                <div className="marquee-wrapper text-slider">
                    <div className="marquee-inner to-left">
                        <ul className="marqee-list d-flex">
                            <li className="marquee-item">
                                <span>Satisfied Client</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                                <span>Branding App</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                                <span>Website</span> <span className="basee">*</span> <span className="stroke-text"></span><span>Lets's
                                    Work</span> <span className="base">*</span>
                                <span>App Design</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                                <span>SEO Expart</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                                <span>Lets's Work</span> <span className="basee">*</span> <span
                                    className="stroke-text"></span><span>Lets's Work</span> <span className="base">*</span>
                            </li>
                        </ul>
                    </div>
                </div>

                <div className="container">
                    <div className="footer__top pt-5 pb-2">
                        <div className="row g-4 justify-content-between">
                            <div className="col-lg-4 col-md-6">
                                <div className="footer-widget">
                                    <a href="index.html" className="flogo">
                                        <img src="assets/img/logo.png" height="130px" alt="img" />
                                    </a>
                                    <p className="iam">
                                        Hello, I’m Brijesh, Website & User Interface
                                        Designer based in India.
                                    </p>
                                </div>
                            </div>
                            <div className="col-lg-2 col-md-6">
                                <div className="footer-widget">
                                    <h4 className="fhead-title">
                                        Quick Link
                                    </h4>
                                    <ul className="quick-link">
                                        <li>
                                            <a href="#0" className="pra">
                                                Service
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Project
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Blog
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Faqs
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#0" className="pra">
                                                Contact
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-6">
                                <div className="footer-widget">
                                    <h4 className="fhead-title">
                                        Address
                                    </h4>
                                    <ul className="address-link">
                                        <li className="d-flex align-items-center gap-3">
                                            <div className="icons">
                                                <i className="bi bi-geo-alt"></i>
                                            </div>
                                            <a href="#0" className="cont">
                                                Meerut, Uttar Pradesh, India
                                            </a>
                                        </li>
                                        <li className="d-flex align-items-center gap-3">
                                            <div className="icons">
                                                <i className="bi bi-chat-left-dots"></i>
                                            </div>
                                            <div className="box">
                                                <a href="#0" className="cont d-block">
                                                    hello@itsbrijesh.me
                                                </a>
                                                <a href="#0" className="cont">
                                                    brijeshch027@gmail.com
                                                </a>
                                            </div>
                                        </li>
                                        <li className="d-flex align-items-center gap-3">
                                            <div className="icons">
                                                <i className="bi bi-geo-alt"></i>
                                            </div>
                                            <div className="box">
                                                <a href="#0" className="cont d-block">
                                                    +91 7017 442 328
                                                </a>
                                                <a href="#0" className="cont">
                                                    +91 8650 876 100
                                                </a>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className="col-lg-3 col-md-6">
                                <div className="footer-widget">
                                    <div className="contact-wrap">
                                        <div id="form-message-warning" className="mb-4 d-none"></div>
                                        <div id="form-message-success" className="mb-4 d-none">Your message was sent, thank you!</div>
                                        <form method="POST" id="contactForm" name="contactForm" className="contactForm">
                                            <div className="row">
                                                <div className="col-md-12">
                                                    <div className="form-group">
                                                        <input type="text" className="form-control" name="name" id="name"
                                                            placeholder="Name" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12">
                                                    <div className="form-group">
                                                        <input type="email" className="form-control" name="email" id="email"
                                                            placeholder="Email" />
                                                    </div>
                                                </div>
                                                <div className="col-md-12">
                                                    <input type="text" className="form-control" name="subject" id="subject"
                                                        placeholder="Subject" />
                                                </div>
                                            </div>
                                            <div className="col-md-12">
                                                <div className="form-group">
                                                    <textarea name="message" className="form-control" id="message" cols="30"
                                                        rows="4" placeholder="Message"></textarea>
                                                </div>
                                            </div>
                                            <div className="col-md-12">
                                                <div className="form-group">
                                                    <input type="submit" value="Send Message" className="cmn--btn base" />
                                                    <div className="submitting"></div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="footer__bottom">
                    <div className="container">
                        <div className="copyright">
                            <p className="white"> Copyright © 2025 <a href="index.html" className="base">Brijesh.</a> All rights reserved.
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        </>
    )
}

export default Footer